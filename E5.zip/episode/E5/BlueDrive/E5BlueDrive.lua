local E5BlueDrive = class("E5BlueDrive", function()
  return BasePlace.new()
end)

function E5BlueDrive:initPhoto()
end

function E5BlueDrive:initButton()
  self:addButton("goBlueDriveSlot", 0, 628, 386, 520)
  self:addButton("openDoor", 0, 324, 302, 300)
  self:addButton("goBlueCup", 1178, 762, 562, 386)
  self:addButton("goMeter", 460, 80, 706, 370)
  self:addButton("goCD", 1172, 422, 566, 334)
  self:addButton("goGlove", 1744, 492, 300, 656)
end

function E5BlueDrive:arrowDown(rect)
  self:switchPlaceZoomOut("BlueRearRight")
end

function E5BlueDrive:arrowRight(rect)
  self:switchPlaceRight("BlueSeeArm")
end

function E5BlueDrive:beforeLoad()
  if self:getInteger("blue_engine_on") ~= 0 then
    self:imageOn("1")

    return
  end

  self:imageOn("0")
end

function E5BlueDrive:afterLoad()

end

function E5BlueDrive:afterLoad2()
  -- self:cacheImage("BlueSeeArm/0")
  -- self:cacheImage("BlueDriveSlot/0")
  self:cacheImage("BlueCup/0")
  -- self:cacheImage("BlueDashboard/1")
  self:cacheImage("BluePanel/0")
  -- self:cacheImage("BlueGlove/0")
end

function E5BlueDrive:beforeUseItem(itemName)
  return false
end

function E5BlueDrive:afterUseItem(itemName)
  return true
end

function E5BlueDrive:goBlueDriveSlot(rect)
  self:switchPlaceZoomIn("BlueDriveSlot", rect)
end

function E5BlueDrive:openDoor(rect)
  self:play("tryopen")
  self:sayI18n("openDoor_1")
end

function E5BlueDrive:goBlueCup(rect)
  self:switchPlaceZoomIn("BlueCup", rect)
end

function E5BlueDrive:goMeter(rect)
  self:switchPlaceZoomIn("BlueDashboard", rect)
end

function E5BlueDrive:goCD(rect)
  self:switchPlaceZoomIn("BluePanel", rect)
end

function E5BlueDrive:goGlove(rect)
  self:switchPlaceZoomIn("BlueGlove", rect)
end

return E5BlueDrive
