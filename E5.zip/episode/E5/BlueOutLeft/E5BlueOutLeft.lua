local E5BlueOutLeft = class("E5BlueOutLeft", function()
  return BasePlace.new()
end)

function E5BlueOutLeft:initPhoto()
end

function E5BlueOutLeft:initButton()
  self:addButton("click", 562, 122, 1092, 656, false)
end

function E5BlueOutLeft:arrowLeft(rect)
  self:switchPlaceLeft("BlueOutFront")
end

function E5BlueOutLeft:arrowRight(rect)
  self:switchPlaceRight("BlueOutRear")
end

function E5BlueOutLeft:beforeLoad()
  self:imageOn("0")
end

function E5BlueOutLeft:afterLoad()

end

function E5BlueOutLeft:afterLoad2()
  self:cacheImage("BlueOutFront/0")
  self:cacheImage("BlueOutRear/2")
end

function E5BlueOutLeft:beforeUseItem(itemName)
  return false
end

function E5BlueOutLeft:afterUseItem(itemName)
  return true
end

function E5BlueOutLeft:click(rect)
  self:sayI18n("click_1")
end

return E5BlueOutLeft
