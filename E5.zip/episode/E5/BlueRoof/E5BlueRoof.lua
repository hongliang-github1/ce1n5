local E5BlueRoof = class("E5BlueRoof", function()
  return BasePlace.new()
end)

function E5BlueRoof:initPhoto()
end

function E5BlueRoof:initButton()
  self:addButton("openRoof", 50, 90, 1994, 838)
end

function E5BlueRoof:arrowDown(rect)
  self:switchPlaceDown("BlueRearRight")
end

function E5BlueRoof:beforeLoad()
  self:imageOn("2")
end

function E5BlueRoof:afterLoad()

end

function E5BlueRoof:afterLoad2()
  self:cacheImage("BlueRoof/2")
  self:cacheImage("BlueRearRight/1")
end

function E5BlueRoof:beforeUseItem(itemName)
  return false
end

function E5BlueRoof:afterUseItem(itemName)
  return true
end

function E5BlueRoof:openRoof(rect)
  if self:imageIsOn("1") then
    -- 关上盖板
    self:imageOn("2")

    self:play("roofwindow")
    self:sayI18n("openRoof_1")

    return
  end

  self:imageOn("1")

  if self:getInteger("key_drop") > 0 then
    self:play("roofwindow")
    self:sayI18n("openRoof_2")

    return
  end

  self:play("keydrop")
  self:setInteger("key_drop", 1)
  self:sayI18n("openRoof_3")
end

return E5BlueRoof
