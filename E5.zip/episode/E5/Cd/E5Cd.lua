local E5Cd = class("E5Cd", function()
  return BasePlace.new()
end)

function E5Cd:initPhoto()
end

function E5Cd:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E5Cd:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "BlueRearRight")
end

function E5Cd:beforeLoad()
  self:imageOn("0")
  self:disableAlwaysUseItem()

  local fontSize = 50 * 2

  if self.gamingScene and self.gamingScene.labelSay then
    fontSize = math.ceil(self.gamingScene.labelSay:getFontSize() * 1.85)
  end

  local label1 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label2 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label3 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label4 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  label1:setColor(cc.c4b(0, 0, 0, 255))
  label2:setColor(cc.c4b(0, 0, 0, 255))
  label3:setColor(cc.c4b(0, 0, 0, 255))
  label4:setColor(cc.c4b(0, 0, 0, 255))
  label1:setAnchorPoint(0, 0)
  label2:setAnchorPoint(0, 0)
  label3:setAnchorPoint(0, 0)
  label4:setAnchorPoint(0, 0)
  label1:setPosition(0, 0)
  label2:setPosition(0, 0)
  label3:setPosition(0, 0)
  label4:setPosition(0, 0)

  self.label1 = label1
  self.label2 = label2
  self.label3 = label3
  self.label4 = label4

  self.label1:setString(tostring(self:getInteger("num_one")))
  self.label2:setString(tostring(self:getInteger("num_two")))
  self.label3:setString(tostring(self:getInteger("num_three")))
  self.label4:setString(tostring(self:getInteger("num_four")))

  self:addChild(label1)
  self:addChild(label2)
  self:addChild(label3)
  self:addChild(label4)

  -- 计算四个label的位置，居中为准，分别向两边延伸
  local bgSize    = self:getContentSize()
  local labelSize = label1:getContentSize()
  local x         = bgSize.width / 2
  local y         = bgSize.height - 860

  label1:setPosition(x - labelSize.width * 2, y)
  label2:setPosition(x - labelSize.width, y)
  label3:setPosition(x, y)
  label4:setPosition(x + labelSize.width, y)

end

function E5Cd:afterLoad()

end

function E5Cd:afterLoad2()
end

function E5Cd:recordLastPlaceName()
  return false
end

function E5Cd:beforeUseItem(itemName)
  return false
end

function E5Cd:afterUseItem(itemName)
  return true
end

function E5Cd:click(rect)
  self:sayI18n("click_1")
end

return E5Cd
