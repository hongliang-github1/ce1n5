local E5BlueSeatSwitch = class("E5BlueSeatSwitch", function()
  return BasePlace.new()
end)

function E5BlueSeatSwitch:initPhoto()
  self:addPhoto("1", 1024, 448)
  self:addPhoto("3", 1024, 448)
end

function E5BlueSeatSwitch:initButton()
  self:addButton("open", 902, 332, 456, 418)
end

function E5BlueSeatSwitch:arrowLeft(rect)
  self:switchPlaceZoomOut("BlueRearLeft")
end

function E5BlueSeatSwitch:beforeLoad()
  self:imageOn("0")
end

function E5BlueSeatSwitch:afterLoad()
  if self:getInteger("tip_rolled") <= 0 then
    self:sayI18n("afterLoad_1")
  end
end

function E5BlueSeatSwitch:afterLoad2()
  self:cacheImage("BlueRearLeft/11")
end

function E5BlueSeatSwitch:beforeUseItem(itemName)
  if itemName == "redlamp" then
    if self:getInteger("tip_rolled") ~= 0 or self:imageIsOn("2") then
      -- 已经用过红灯，不用再用了
      return false
    end

    return true
  end

  return false
end

function E5BlueSeatSwitch:afterUseItem(itemName)
  if itemName == "redlamp" then
    self:hideArrowButton()
    self:imageOn("2")
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E5BlueSeatSwitch:open(rect)
  -- 座椅已经翻倒，回退到向左看视角
  if self:getInteger("seat_rolled") > 0 then
    self:play("seatrolled")
    self:switchPlace("BlueRearLeft")

    return
  end

  -- 红灯已经照出来了
  if self:imageIsOn("2") then
    self:imageOn("3")
    self:play("seatswitch")
    self:setInteger("tip_rolled", 1)
    self:setInteger("seat_rolled", 1)
    self:sayI18n("open_1")

    return
  end

  -- 已经知道这里有开关了，可以直接打开
  if self:getInteger("tip_rolled") > 0 then
    self:imageOn("1")
    self:play("seatswitch")
    self:setInteger("seat_rolled", 1)
    self:sayI18n("open_2")

    return
  end

  self:sayI18n("open_3")
end

return E5BlueSeatSwitch
