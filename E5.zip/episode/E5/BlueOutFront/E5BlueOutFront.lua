local E5BlueOutFront = class("E5BlueOutFront", function()
  return BasePlace.new()
end)

function E5BlueOutFront:initPhoto()
end

function E5BlueOutFront:initButton()
end

function E5BlueOutFront:arrowRight(rect)
  self:switchPlaceRight("BlueOutLeft")
end

function E5BlueOutFront:beforeLoad()
  self:imageOn("0")
end

function E5BlueOutFront:afterLoad()

end

function E5BlueOutFront:afterLoad2()
  self:cacheImage("BlueOutLeft/0")
end

function E5BlueOutFront:beforeUseItem(itemName)
  return false
end

function E5BlueOutFront:afterUseItem(itemName)
  return true
end

return E5BlueOutFront
