local E5BlueGlove = class("E5BlueGlove", function()
  return BasePlace.new()
end)

function E5BlueGlove:initPhoto()
  self:addPhoto("01", 384, 192)
  self:addPhoto("02", 1216, 192)
end

function E5BlueGlove:initButton()
  self:addButton("openGlove", 132, 64, 1016, 786)
end

function E5BlueGlove:arrowLeft(rect)
  self:switchPlaceZoomOut("BlueDrive")
end

function E5BlueGlove:beforeLoad()
  self:imageOn("0")
end

function E5BlueGlove:afterLoad()

end

function E5BlueGlove:afterLoad2()
  self:cacheImage("00")
  self:cacheImage("BlueDrive/0")
end

function E5BlueGlove:beforeUseItem(itemName)
  return false
end

function E5BlueGlove:afterUseItem(itemName)
  return true
end

function E5BlueGlove:openGlove(rect)
  -- 判断手套箱是否解锁
  if self:getInteger("glovebox_unlock") == 0 then
    self:sayI18n("openGlove_1")

    return
  end

  if self:imageIsOn("00") then
    -- 这里需要判断，是否已经拿了道具，如果已经拿到道具了，就直接关闭，如果没有拿到道具，就拿道具
    if self:getInteger("tin") ~= 0 then
      self:imageOn("0")
      self:play("armclose")
      self:sayI18n("openGlove_2")

      return
    end

    self:imageOff("01")
    self:getItem("tin")
    self:sayI18n("openGlove_3")

    return
  end

  self:imageOn("00")
  self:play("armopen")

  if self:getInteger("tin") ~= 0 then
    self:sayI18n("openGlove_4")

    return
  end

  self:imageOn("01")
  self:sayI18n("openGlove_5")
end

return E5BlueGlove
