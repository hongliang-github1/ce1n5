local E5BlueHandCuff = class("E5BlueHandCuff", function()
  return BasePlace.new()
end)

function E5BlueHandCuff:initPhoto()
end

function E5BlueHandCuff:initButton()
  self:addButton("unLock", 386, 0, 840, 820)
end

function E5BlueHandCuff:arrowLeft(rect)
  self:switchPlaceLeft("BlueRearRight")
end

function E5BlueHandCuff:beforeLoad()
  if self:getInteger("pin") < 0 then
    self:imageOn("2")

    return
  end

  self:imageOn("0")
  self:sayI18n("beforeLoad_1")
end

function E5BlueHandCuff:afterLoad()

end

function E5BlueHandCuff:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("2")
  self:cacheImage("BlueRearRight/1")
end

function E5BlueHandCuff:beforeUseItem(itemName)
  if itemName == "pin" then
    return true
  end

  return false
end

function E5BlueHandCuff:afterUseItem(itemName)
  if itemName == "pin" then
    self:hideArrowButton()
    self:imageOn("1")
    self:play("handcuff")
    self:sayI18n("afterUseItem_1")

    return false
  end

  return true
end

function E5BlueHandCuff:unLock(rect)
  if self:getInteger("pin") < 0 then
    self:showArrowButton()
    self:imageOn("2")

    if self:getInteger("handcuff_played") < 1 then
      self:play("item")
      self:setInteger("handcuff_played", 1)
    end

    if self:getInteger("rescue") < 0 then
      self:sayI18n("unLock_1")

      return
    end

    self:sayI18n("unLock_2")

    return
  end

  self:sayI18n("unLock_3")
end

return E5BlueHandCuff
