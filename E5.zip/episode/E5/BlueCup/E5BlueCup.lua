local E5BlueCup = class("E5BlueCup", function()
  return BasePlace.new()
end)

function E5BlueCup:initPhoto()
  self:addPhoto("1", 1088, 512)
  self:addPhoto("2", 896, 192)
  self:addPhoto("3", 896, 192)
end

function E5BlueCup:initButton()
  self:addButton("getKey", 832, 460, 422, 434)
  self:addButton("getElectricBox", 800, 120, 1022, 334)
end

function E5BlueCup:arrowLeft(rect)
  self:switchPlaceZoomOut("BlueDrive")
end

function E5BlueCup:beforeLoad()
  self:imageOn("0")

  if self:getInteger("key_drop") ~= 0 and self:getInteger("bluekey1") == 0 then
    self:imageOn("1")
  end
end

function E5BlueCup:afterLoad()

end

function E5BlueCup:afterLoad2()
  self:cacheImage("2")
  self:cacheImage("BlueDrive/0")
end

function E5BlueCup:beforeUseItem(itemName)
  return false
end

function E5BlueCup:afterUseItem(itemName)
  return true
end

function E5BlueCup:getKey(rect)
  if self:getInteger("key_drop") ~= 0 and self:getInteger("bluekey1") == 0 then
    self:imageOff("1")
    self:getItem("bluekey1")
    self:sayI18n("getKey_1")
  end
end

function E5BlueCup:getElectricBox(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:play("ashclose")
    self:sayI18n("getElectricBox_1")

    return
  end

  self:play("ashopen")
  self:imageOn("2")
  self:sayI18n("getElectricBox_3")

end

return E5BlueCup
