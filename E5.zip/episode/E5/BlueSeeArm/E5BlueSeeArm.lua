local E5BlueSeeArm = class("E5BlueSeeArm", function()
  return BasePlace.new()
end)

function E5BlueSeeArm:initPhoto()
end

function E5BlueSeeArm:initButton()
  self:addButton("goArm", 1042, 524, 1002, 524)
end

function E5BlueSeeArm:arrowLeft(rect)
  self:switchPlaceLeft("BlueDrive")
end

function E5BlueSeeArm:beforeLoad()
  self:imageOn("0")
end

function E5BlueSeeArm:afterLoad()

end

function E5BlueSeeArm:afterLoad2()
  self:cacheImage("BlueDrive/0")
  self:cacheImage("BlueArm/0")
end

function E5BlueSeeArm:beforeUseItem(itemName)
  return false
end

function E5BlueSeeArm:afterUseItem(itemName)
  return true
end

function E5BlueSeeArm:goArm(rect)
  self:switchPlaceZoomIn("BlueArm", rect)
end

return E5BlueSeeArm
