local E5Beginning = class("E5Beginning", function()
  return BasePlace.new()
end)

function E5Beginning:initPhoto()
end

function E5Beginning:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E5Beginning:beforeLoad()
  if userdata.getEpisodeLastPlace(userdata.currentEpisode) == "" then
    local p1 = math.random(8)
    local p2 = math.random(8)
    local p3 = math.random(8)
    local p4 = math.random(8)

    self:setInteger("num_one", p1)
    self:setInteger("num_two", p2)
    self:setInteger("num_three", p3)
    self:setInteger("num_four", p4)
  end

  self:imageOn("0")
end

function E5Beginning:afterLoad()
  self:click(nil)
end

function E5Beginning:afterLoad2()
  self:cacheImage("enemy")
  self:cacheImage("BlueRearRight/1")
end

function E5Beginning:beforeUseItem(itemName)
  return false
end

function E5Beginning:afterUseItem(itemName)
  return true
end

function E5Beginning:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("enemy")
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_5")

    self.blackLayer = self:effectFadeBlack(nil, 1.5, 0, 0, function()
      self:sayI18n("click_6")

      -- 保留黑屏状态，后面还需要渐变回去
      return true
    end)

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_7")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 苏醒动画
    self:imageOn("BlueRearRight/1")
    self.blackLayer:runAction(cc.Sequence:create(cc.FadeOut:create(1.5), cc.CallFunc:create(function()
      self:sayI18n("click_8")
      self.blackLayer:removeFromParent(true)

      self.blackLayer = nil
    end)))

    return
  end

  if progress == self:nextProgressIndex() then
    progress = 0

    self:switchPlace("BlueRearRight")

    return
  end
end

return E5Beginning
