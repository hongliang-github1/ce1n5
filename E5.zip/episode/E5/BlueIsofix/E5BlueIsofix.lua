local E5BlueIsofix = class("E5BlueIsofix", function()
  return BasePlace.new()
end)

function E5BlueIsofix:initPhoto()
  self:addPhoto("1", 704, 576)
  self:addPhoto("2", 704, 576)
end

function E5BlueIsofix:initButton()
  self:addButton("open", 562, 566, 500, 406)
end

function E5BlueIsofix:arrowDown(rect)
  self:switchPlaceZoomOut("BlueRearLeft")
end

function E5BlueIsofix:beforeLoad()
  self:imageOn("0")
end

function E5BlueIsofix:afterLoad()

end

function E5BlueIsofix:afterLoad2()
  self:cacheImage("BlueRearLeft/11")
end

function E5BlueIsofix:beforeUseItem(itemName)
  return false
end

function E5BlueIsofix:afterUseItem(itemName)
  return true
end

function E5BlueIsofix:open(rect)
  if self:imageIsOn("2") then
    -- 如果是打开的，就关上
    if self:getInteger("redlamp") ~= 0 then
      self:imageOff("2")
      self:play("isofix")
      self:sayI18n("open_1")

      return
    end

    self:imageOff("1")
    self:getItem("redlamp")
    self:sayI18n("open_2")

    return
  end

  self:imageOn("2")
  self:play("isofix")

  if self:getInteger("redlamp") ~= 0 then
    self:sayI18n("open_3")

    return
  end

  self:imageOn("1")
  self:sayI18n("open_4")
end

return E5BlueIsofix
