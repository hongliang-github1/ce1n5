local E5BlueDashboard = class("E5BlueDashboard", function()
  return BasePlace.new()
end)

function E5BlueDashboard:initPhoto()
end

function E5BlueDashboard:initButton()
  self:addButton("start", 1568, 524, 476, 624)
end

function E5BlueDashboard:arrowDown(rect)
  self:switchPlaceZoomOut("BlueDrive")
end

function E5BlueDashboard:beforeLoad()
  if self:getInteger("blue_engine_on") ~= 0 then
    self:imageOn("2")

    return
  end

  self:imageOn("1")
end

function E5BlueDashboard:afterLoad()

end

function E5BlueDashboard:afterLoad2()
  if self:getInteger("blue_engine_on") ~= 0 then
    self:cacheImage("1")
  else
    self:cacheImage("2")
  end

  self:cacheImage("BlueDrive/0")
end

function E5BlueDashboard:beforeUseItem(itemName)
  if itemName == "bluekey" then
    return true
  end

  return false
end

function E5BlueDashboard:afterUseItem(itemName)
  if itemName == "bluekey" then
    self:play("button1")
    self:imageOn("2")
    self:setInteger("blue_engine_on", 1)
    self:sayI18n("start_3")
    
    return false
  end

  return true
end

function E5BlueDashboard:start(rect)
  -- 如果已经通电，再点击就没反应了
  if self:getInteger("blue_engine_on") ~= 0 then
    return
  end

  -- 如果没有通电，点击也无法启动
  self:play("button1")
  self:sayI18n("start_2")
end

return E5BlueDashboard
