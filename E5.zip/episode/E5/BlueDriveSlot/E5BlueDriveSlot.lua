local E5BlueDriveSlot = class("E5BlueDriveSlot", function()
  return BasePlace.new()
end)

function E5BlueDriveSlot:initPhoto()
  self:addPhoto("1", 576, 768)
end

function E5BlueDriveSlot:initButton()
  self:addButton("getKey", 444, 660, 454, 380)
end

function E5BlueDriveSlot:arrowRight(rect)
  self:switchPlaceZoomOut("BlueDrive")
end

function E5BlueDriveSlot:beforeLoad()
  self:imageOn("0")

  if self:getInteger("bluekey2") == 0 then
    self:imageOn("1")
  end
end

function E5BlueDriveSlot:afterLoad()

end

function E5BlueDriveSlot:afterLoad2()
  self:cacheImage("BlueDrive/0")
end

function E5BlueDriveSlot:beforeUseItem(itemName)
  return false
end

function E5BlueDriveSlot:afterUseItem(itemName)
  return true
end

function E5BlueDriveSlot:getKey(rect)
  if self:getInteger("bluekey2") ~= 0 then
    self:sayI18n("getKey_1")

    return
  end

  self:imageOff("1")
  self:getItem("bluekey2")
  self:sayI18n("getKey_2")
end

return E5BlueDriveSlot
