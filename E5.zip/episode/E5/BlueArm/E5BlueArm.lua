local E5BlueArm = class("E5BlueArm", function()
  return BasePlace.new()
end)

function E5BlueArm:initPhoto()
  self:addPhoto("1", 512, 0)
  self:addPhoto("2", 960, 640)
end

function E5BlueArm:initButton()
  self:addButton("open", 542, 352, 1310, 764)
end

function E5BlueArm:arrowLeft(rect)
  self:switchPlaceZoomOut("BlueSeeArm")
end

function E5BlueArm:beforeLoad()
  self:imageOn("0")
  self:imageOn("1")
end

function E5BlueArm:afterLoad()

end

function E5BlueArm:afterLoad2()
  self:cacheImage("BlueSeeArm/0")
end

function E5BlueArm:beforeUseItem(itemName)
  return false
end

function E5BlueArm:afterUseItem(itemName)
  return true
end

function E5BlueArm:open(rect)
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:play("armopen")

    if self:getInteger("tinkey") ~= 0 then
      self:sayI18n("open_2")

      return
    end

    self:imageOn("2")
    self:sayI18n("open_3")

    return
  end

  if self:getInteger("tinkey") ~= 0 then
    self:imageOn("1")
    self:play("armclose")
    self:sayI18n("open_4")

    return
  end

  self:imageOff("2")
  self:getItem("tinkey")
  self:sayI18n("open_5")
end

return E5BlueArm
