local E5BlueTrunkPath = class("E5BlueTrunkPath", function()
  return BasePlace.new()
end)

function E5BlueTrunkPath:initPhoto()
  self:addPhoto("2", 1472, 256)
end

function E5BlueTrunkPath:initButton()
  self:addButton("goTrunk", 542, 278, 800, 800)
  self:addButton("goMedical", 1358, 408, 534, 450)
end

function E5BlueTrunkPath:arrowDown(rect)
  self:switchPlaceZoomOut("BlueRearLeft")
end

function E5BlueTrunkPath:beforeLoad()
  self:imageOn("0")
end

function E5BlueTrunkPath:afterLoad()

end

function E5BlueTrunkPath:afterLoad2()
  self:cacheImage("BlueRearLeft/11")
  self:cacheImage("BlueTrunkLock/0")
  self:cacheImage("BlueTrunkTool/1")
end

function E5BlueTrunkPath:beforeUseItem(itemName)
  return false
end

function E5BlueTrunkPath:afterUseItem(itemName)
  return true
end

function E5BlueTrunkPath:goTrunk(rect)
  self:switchPlaceZoomIn("BlueTrunkLock", rect)
end

function E5BlueTrunkPath:goMedical(rect)
  self:switchPlaceZoomIn("BlueTrunkTool", rect)
end

return E5BlueTrunkPath
