local E5BlueTrunkTool = class("E5BlueTrunkTool", function()
  return BasePlace.new()
end)

function E5BlueTrunkTool:initPhoto()
end

function E5BlueTrunkTool:initButton()
  self:addButton("open", 812, 0, 990, 1138)
end

function E5BlueTrunkTool:arrowLeft(rect)
  self:switchPlaceZoomOut("BlueTrunkPath")
end

function E5BlueTrunkTool:beforeLoad()
  if self.lastPlaceName == "Rescue" then
    self:imageOn("4")

    return
  end

  self:imageOn("1")
end

function E5BlueTrunkTool:afterLoad()

end

function E5BlueTrunkTool:afterLoad2()
  self:cacheImage("2")
  self:cacheImage("3")
  self:cacheImage("4")
  self:cacheImage("BlueTrunkPath/0")
  self:cacheImage("Rescue/1")
end

function E5BlueTrunkTool:beforeUseItem(itemName)
  if itemName == "redlamp" then
    return true
  end

  return false
end

function E5BlueTrunkTool:afterUseItem(itemName)
  if itemName == "redlamp" then
    -- 使用应急红灯
    self:imageOn("2")
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E5BlueTrunkTool:open(rect)
  if self:imageIsOn("2") or self:imageIsOn("3") or self:imageIsOn("4") then
    -- 如果用灯照了，就需要判断，道具是否拿到了，如果没有拿到，打开盒子之后拿医药包，如果道具已经拿了，就没有东西可拿了
    if self:imageIsOn("4") or self:imageIsOn("3") then
      -- 如果是打开的，就关上
      if self:getInteger("rescue") ~= 0 then
        self:imageOn("2")
        self:play("rescueclose")
        self:sayI18n("open_1")

        return
      end

      -- 道具还没取得，切换到道具界面
      self:switchPlace("Rescue")

      return
    end

    self:play("rescueopen")

    if self:getInteger("rescue") ~= 0 then
      self:imageOn("4")
      self:sayI18n("open_2")

      return
    end

    self:hideArrowButton()
    self:imageOn("3")
    self:sayI18n("open_3")

    return
  end

  self:sayI18n("open_4")
end

return E5BlueTrunkTool
