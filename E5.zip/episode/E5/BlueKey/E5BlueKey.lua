local E5BlueKey = class("E5BlueKey", function()
  return BasePlace.new()
end)

function E5BlueKey:initPhoto()
  self:addPhoto("1", 832, 256)
  self:addPhoto("2", 832, 256)
  self:addPhoto("3", 832, 320)
  self:addPhoto("4", 896, 320)
end

function E5BlueKey:initButton()
  self:addButton("combination", 0, 0, 2044, 1148, false)
end

function E5BlueKey:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "BlueRearRight")
end

function E5BlueKey:beforeLoad()
  self:disableAlwaysUseItem()
  self:imageOn("0")
  self:imageOn("1")
end

function E5BlueKey:afterLoad()
  self.useKey1  = false
  self.click    = 0
end

function E5BlueKey:afterLoad2()
end

function E5BlueKey:recordLastPlaceName()
  return false
end

function E5BlueKey:beforeUseItem(itemName)
  if itemName == "bluekey1" then
    if self.useKey1 then
      -- 如果已经使用过金属钥匙了就不能在当前场景下再次使用
      return false
    end

    return true
  end

  return false
end

function E5BlueKey:afterUseItem(itemName)
  if itemName == "bluekey1" then
    self.useKey1 = true
    self:imageOn("2")
    self:imageOff("1")
    self:hideArrowButton()
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E5BlueKey:combination(rect)
  -- 如果没有使用钥匙，就不做操作
  if self.useKey1 then
    if self.click == 0 then
      self:play("tik")
      self:imageOn("3")
      self:imageOff("2")
      self:sayI18n("combination_1")

    elseif self.click == 1 then
      self:showArrowButton()
      self:imageOn("4")
      self:imageOff("3")
      self:voidItem("bluekey1")
      self:voidItem("bluekey2")
      self:getItem("bluekey")
      self:sayI18n("combination_2")
    end

    self.click = self.click + 1

    return
  end

  self:sayI18n("combination_3")
end

return E5BlueKey
