local E5Ending = class("E5Ending", function()
  return BasePlace.new()
end)

function E5Ending:initPhoto()
end

function E5Ending:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E5Ending:beforeLoad()
  self:imageOn("see_red_car")
end

function E5Ending:afterLoad()
  self:click(nil)
end

function E5Ending:afterLoad2()
end

function E5Ending:beforeUseItem(itemName)
  return false
end

function E5Ending:afterUseItem(itemName)
  return true
end

function E5Ending:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 黑屏动画
    self:effectFadeBlack(nil, 1.5, 0, 0, function()
      self:setInteger("electric_on", 1)
      userdata.setEpisodePassed(self.episodeName)
      -- TODO 设置通关时间

      -- TODO 进入通关字幕CreditScene
      cc.Director:getInstance():replaceScene(BaseScene.create("CreditScene"))

      -- 保留黑屏状态
      return true
    end)

    return
  end
end

-- function E5Ending:endMenuDidLoad()
--   -- 构造滚动字幕
--   self:label18WithText(@{
--    "chs" : "恭喜您通关！",
--    "cht" : "恭喜您過關！",
--    "en"  : "Clear! Congratulations!",
--    "jp"  : "クリアおめでとうございます！",
--    "kr"  : "축하합니다, 통과하였습니다!",
--    end)

--   -- 显示通关时间
--   NSString *timingString  = [self timingString]
--   NSString *labelStr    = UikitEnhancement:textByI18nDict(@{
--                  "chs" : "本次通关耗时：",
--                  "cht" : "本次過關耗時：",
--                  "en"  : "Consuming Time：",
--                  "jp"  : "クリア時間：",
--                  "kr"  : "이번 통관 사용시간: ",
--                  end)

--   self:label16WithText([labelStr stringByAppendingFormat:"%@", timingString)]

--   self:label16WithText(@{
--    "chs" : "玩的开心吗？去给我们5星级评价吧！",
--    "cht" : "玩的開心嗎？去給我們5星級評價吧！",
--    "en"  : "Have fun? Don't forget to give us 5 rating stars!",
--    "jp"  : "面白かった？五つ星の評価はよろしく頼むよ!",
--    "kr"  : "재밌었나요? 5개 별 평가를 해주세요!",
--    end)

--   [self blank]

--   self:label16WithText(@{
--    "chs" : "本章出场车辆 - 宝马1系 116i (2012)",
--    "cht" : "本章出場車輛 - BMW 116i (2012)",
--    "en"  : "The Car of This Chapter - BMW 116i (2012)",
--    "jp"  : "登場車 - BMW 116i (2012)",
--    "kr"  : "이번 장 출연 차량 - BMW 116i (2012)",
--    end)

--   self:imageViewWithImageName("ce4_Ending_1")

--   [self blank]

--   self:label16WithText(@{
--    "chs" : "事情后续",
--    "cht" : "事情后續",
--    "en"  : "Follow-Up",
--    "jp"  : "事件の後に",
--    "kr"  : "사건 후속",
--    end)

--   self:label16WithText(@{
--    "chs" : "抡起大扳手撂倒了坏人",
--    "cht" : "掄起大扳手撂倒了壞人",
--    "en"  : "After I beat the bad guy with a wrench",
--    "jp"  : "スパナでテロリストを倒した",
--    "kr"  : "스패너로 나쁜 사람을 쓰러뜨렸습니다",
--    end)

--   self:label16WithText(@{
--    "chs" : "我已没有退路",
--    "cht" : "我已沒有退路",
--    "en"  : "I have no choice but run",
--    "jp"  : "もう選択肢はない",
--    "kr"  : "뒤로 돌아갈 길이 없습니다",
--    end)

--   self:label16WithText(@{
--    "chs" : "只有跟坏人斗智斗勇逃出这里",
--    "cht" : "只有跟壞人鬥智斗勇逃出這裡",
--    "en"  : "The only way I can survive",
--    "jp"  : "テロリストと戦うしかない",
--    "kr"  : "나쁜 사람하고 지혜와 용기를 겨루어 이곳을 탈출해야 합니다",
--    end)

--   self:label16WithText(@{
--    "chs" : "才是我唯一活下去的方法",
--    "cht" : "才是我唯一活下去的方法",
--    "en"  : "Is to escape this place",
--    "jp"  : "自力で逃げなきゃ",
--    "kr"  : "이것이 살아남는 유일한 방법입니다",
--    end)

--   self:label16WithText(@{
--    "chs" : "我必须鼓足勇气忘掉恐惧",
--    "cht" : "我必須鼓足勇氣忘掉恐懼",
--    "en"  : "I must summon the courage and forget the fear",
--    "jp"  : "勇気を出して行動する",
--    "kr"  : "반드시 용기를 내어 공포를 잊어버려야 합니다",
--    end)

--   self:label16WithText(@{
--    "chs" : "尽快离开这里！",
--    "cht" : "盡快離開這裡！",
--    "en"  : "Think of a way to leave here as soon as possible!",
--    "jp"  : "一刻も早くここから逃げ出すんだ！",
--    "kr"  : "이곳을 빨리 나가야합니다!",
--    end)

--   self:label16WithText(@{
--    "chs" : "可谁知抓我的坏人",
--    "cht" : "可誰知抓我的壞人",
--    "en"  : "The only problem is",
--    "jp"  : "しかし、テロリストは…",
--    "kr"  : "그런데 나를 붙잡은 나쁜 사람이",
--    end)

--   self:label16WithText(@{
--    "chs" : "却不止一个...",
--    "cht" : "卻不止一個...",
--    "en"  : "There are more bad guys than I thought...",
--    "jp"  : "一人じゃなかった…",
--    "kr"  : "한명인 것이 아니었습니다…",
--    end)

--   self:label16WithText(@{
--    "chs" : "欲知详情，请继续玩第六章！",
--    "cht" : "欲知詳情，請繼續玩第六章！",
--    "en"  : "For more information, please continue to play Chapter 6!",
--    "jp"  : "一体どんな事件に陥ったのか…引き続いてチャプター6をお楽しみに",
--    "kr"  : "상세한 내용은 제6장에서!",
--    end)

--   NSInteger hour = [[NSCalendar currentCalendar] components:NSHourCalendarUnit fromDate:[NSDate date]].hour

--   if (hour > 0
--     && hour < 7
--   ) {
--     self:label14WithText(@{
--      "chs" : "(友情提醒：天色已晚，玩归玩，要注意身体哦！)",
--      "cht" : "(友情提醒：天色已晚，玩歸玩，要注意身體哦！)",
--      "en"  : "(Hint: It's late night. We appreciate you enjoying the game but please take care yourself.)",
--      "jp"  : "(チャプターをクリアする度に少し休もう、健康を大切にしてね~)",
--      "kr"  : "(안내사항:밤이 깊어졌으니, 놀면서 건강도 챙겨야 합니다!)",
--      end)
--   end

--   [self blank]

--   self:musicPlay("bgem_ce4")
-- end

return E5Ending
