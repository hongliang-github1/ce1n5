local E5BlueArmRear = class("E5BlueArmRear", function()
  return BasePlace.new()
end)

function E5BlueArmRear:initPhoto()
  self:addPhoto("2", 704, 448)
end

function E5BlueArmRear:initButton()
  self:addButton("open", 380, 106, 854, 568)
end

function E5BlueArmRear:arrowUp(rect)
  self:switchPlaceZoomOut("BlueRearRight")
end

function E5BlueArmRear:beforeLoad()
  self:imageOn("1")
  self:imageOn("3")
end

function E5BlueArmRear:afterLoad()

end

function E5BlueArmRear:afterLoad2()
  self:cacheImage("BlueRearRight/1")
end

function E5BlueArmRear:beforeUseItem(itemName)
  return false
end

function E5BlueArmRear:afterUseItem(itemName)
  return true
end

function E5BlueArmRear:open(rect)
  -- 扶手箱关着的时候，打开扶手箱
  if self:imageIsOn("3") then
    self:imageOff("3")
    self:play("armpull")

    if self:getInteger("pin") ~= 0 then
      self:sayI18n("open_1")

    else
      self:imageOn("2")
      self:sayI18n("open_2")
    end

    return
  end

  if self:getInteger("pin") ~= 0 then
    self:imageOn("3")
    self:play("armpull")
    self:sayI18n("open_3")

    return
  end

  self:imageOff("2")
  self:getItem("pin")
  self:sayI18n("open_4")
end

return E5BlueArmRear
