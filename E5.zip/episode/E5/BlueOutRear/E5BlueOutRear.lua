local E5BlueOutRear = class("E5BlueOutRear", function()
  return BasePlace.new()
end)

function E5BlueOutRear:initPhoto()
end

function E5BlueOutRear:initButton()
  self:addButton("openTrunk", 542, 430, 932, 556)
  self:addButton("closeTrunk", 544, 2, 928, 418, false)
  self:addButton("goElectricBox", 1690, 102, 352, 484)
  self:addButton("goLeft", 0, 190, 426, 686)
end

function E5BlueOutRear:beforeLoad()
  if self:getInteger("trunk_open") == 0 then
    self:imageOn("1")

    return
  end

  self:imageOn("2")
end

function E5BlueOutRear:afterLoad()
  if self:getInteger("blue_first_out") < 1 then
    self:setInteger("blue_first_out", 1)
    self:sayI18n("afterLoad_3")

  elseif self.lastPlaceName == "BlueTrunkLock" then
    self:sayI18n("afterLoad_4")
  end
end

function E5BlueOutRear:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("3")
  self:cacheImage("BlueRearRight/1")
  self:cacheImage("ElectricBox/0")
  self:cacheImage("BlueOutLeft/0")
end

function E5BlueOutRear:beforeUseItem(itemName)
  return false
end

function E5BlueOutRear:afterUseItem(itemName)
  return true
end

function E5BlueOutRear:openTrunk(rect)
  if self:getInteger("trunk_open") == 1 then
    self:switchPlaceZoomIn("BlueRearRight", rect)

    return
  end

  self:imageOn("2")
  self:play("trunkopen")
  self:setInteger("trunk_open", 1)
  self:sayI18n("openTrunk_1")
end

function E5BlueOutRear:closeTrunk(rect)
  if self:getInteger("trunk_open") == 1 then
    -- 如果是打开的就关上，否则，无视
    self:imageOn("1")
    self:play("trunkclose")
    self:setInteger("trunk_open", 0)
    self:sayI18n("closeTrunk_1")
  end
end

function E5BlueOutRear:goElectricBox(rect)
  self:switchPlaceZoomIn("ElectricBox", rect)
end

function E5BlueOutRear:goLeft(rect)
  self:switchPlaceLeft("BlueOutLeft")
end

return E5BlueOutRear
