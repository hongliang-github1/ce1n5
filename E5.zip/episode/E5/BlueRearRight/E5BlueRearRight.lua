local E5BlueRearRight = class("E5BlueRearRight", function()
  return BasePlace.new()
end)

function E5BlueRearRight:initPhoto()
end

function E5BlueRearRight:initButton()
  self:addButton("goArmRear", 588, 926, 452, 222)
  self:addButton("goDrivingPosition", 262, 244, 520, 644)
  self:addButton("lookLeft", 0, 0, 254, 1148)
  self:addButton("goHandcuff", 1492, 128, 552, 1020)
  self:addButton("goSkylight", 262, 0, 1224, 240)
end

function E5BlueRearRight:beforeLoad()
  if self:getInteger("blue_engine_on") ~= 0 then
    self:imageOn("2")

    return
  end

  self:imageOn("1")
end

function E5BlueRearRight:afterLoad()
  if self.lastPlaceName == "Beginning" then
    self:sayI18n("afterLoad_1")

  elseif self.lastPlaceName == "BlueOutRear" or self.lastPlaceName == "BlueFuse" then
    self:sayI18n("afterLoad_2")
  end
end

function E5BlueRearRight:afterLoad2()
  self:cacheImage("BlueArmRear/1")
  self:cacheImage("BlueDrive/0")
  self:cacheImage("BlueRearLeft/11")
  self:cacheImage("BlueHandCuff/0")
  self:cacheImage("BlueRoof/2")
end

function E5BlueRearRight:beforeUseItem(itemName)
  return false
end

function E5BlueRearRight:afterUseItem(itemName)
  return true
end

function E5BlueRearRight:goArmRear(rect)
  self:switchPlaceZoomIn("BlueArmRear", rect)
end

function E5BlueRearRight:goDrivingPosition(rect)
  if self:getInteger("rescue") < 0 and self:getInteger("pin") < 0 then
    self:switchPlaceZoomIn("BlueDrive", rect)

    return
  end

  self:sayI18n("goDrivingPosition_1")
end

function E5BlueRearRight:lookLeft(rect)
  self:switchPlaceLeft("BlueRearLeft")
end

function E5BlueRearRight:goHandcuff(rect)
  self:switchPlaceRight("BlueHandCuff")
end

function E5BlueRearRight:goSkylight(rect)
  if self:getInteger("rescue") < 0 and self:getInteger("pin") < 0 then
    self:switchPlaceUp("BlueRoof")

    return
  end

  self:sayI18n("goSkylight_1")
end

return E5BlueRearRight
