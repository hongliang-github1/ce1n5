local E5Rescue = class("E5Rescue", function()
  return BasePlace.new()
end)

function E5Rescue:initPhoto()
end

function E5Rescue:initButton()
  self:addButton("open", 0, 0, 2044, 1148, false)
end

function E5Rescue:recordLastPlaceName()
  return false
end

function E5Rescue:beforeLoad()
  self:imageOn("1")
end

function E5Rescue:afterLoad()
  self:sayI18n("afterLoad_1")
  self.click = 0
end

function E5Rescue:afterLoad2()
  self:cacheImage("2")
  self:cacheImage("3")
  self:cacheImage("BlueTrunkTool/1")
end

function E5Rescue:beforeUseItem(itemName)
  return false
end

function E5Rescue:afterUseItem(itemName)
  return true
end

function E5Rescue:open(rect)
  if self.click == 0 then
    self:imageOn("2")
    self:sayI18n("open_1")

  elseif self.click == 1 then
    self:imageOn("3")
    self:sayI18n("open_2")

  elseif self.click == 2 then
    self:getItem("rescue")
    self:switchPlace("BlueTrunkTool")

    return
  end

  self.click = self.click + 1
end

return E5Rescue
