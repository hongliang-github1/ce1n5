local E5Tip = class("E5Tip", function()
  return BaseTip.new()
end)

function E5Tip:getTipAtIndex(index)
  self:resetProgress()

  -- 拿别针
  if self:nextProgress() == index or (self:getInteger("pin") == 0) then
    local place1 = self:addPlace("BlueRearRight")
    local place2 = self:addPlace("BlueArmRear")

    place1:markButton("goArmRear")
    place2:markButton("open")

    self:textI18n("progress_1")

    return self.progress
  end

  -- 使用别针打开手铐
  if self:nextProgress() == index or (self:getInteger("pin") > 0) then
    local place1 = self:addPlace("BlueRearRight")
    local place2 = self:addPlace("BlueHandCuff")

    place1:markButton("goHandcuff")
    place2:markButton("unLock")

    self:textI18n("progress_2")

    return self.progress
  end

  -- 拿应急红灯
  if self:nextProgress() == index or (self:getInteger("redlamp") == 0) then
    local place1 = self:addPlace("BlueRearRight")
    local place2 = self:addPlace("BlueRearLeft")
    local place3 = self:addPlace("BlueIsofix")

    place1:markButton("lookLeft")
    place2:markButton("seatBottom")
    place3:markButton("open")

    self:textI18n("progress_3")

    return self.progress
  end

  -- 后座开关
  if self:nextProgress() == index or (self:getInteger("tip_rolled") <= 0) then
    local place1 = self:addPlace("BlueRearLeft")
    local place2 = self:addPlace("BlueSeatSwitch")

    place1:markButton("headRest")
    place2:markButton("open")

    self:textI18n("progress_4")

    return self.progress
  end

  -- 拿医药包
  if self:nextProgress() == index or (self:getInteger("rescue") == 0) then
    local place1 = self:addPlace("BlueRearLeft")
    local place2 = self:addPlace("BlueTrunkPath")
    local place3 = self:addPlace("BlueTrunkTool")

    place1:markButton("goTrunkPath")
    place2:markButton("goMedical")
    place3:imageOn("2")
    place3:markButton("open")

    self:textI18n("progress_5")

    return self.progress
  end

  -- 使用医药包，拔针
  if self:nextProgress() == index or (self:getInteger("rescue") > 0) then
    self:addPlace("BlueRearLeft")

    self:textI18n("progress_6")

    return self.progress
  end

  -- 开天窗，掉落钥匙
  -- if self:nextProgress() == index or (self:getInteger("key_drop") == 0) then
  --   local place1 = self:addPlace("BlueRearRight")
  --   local place2 = self:addPlace("BlueRoof")

  --   place1:markButton("goSkylight")
  --   place2:markButton("openRoof")

  --   self:textI18n("progress_7")

  --   return self.progress
  -- end

  -- 蓝车钥匙金属部分
  if self:nextProgress() == index or (self:getInteger("bluekey1") == 0) then
    local place1 = self:addPlace("BlueRearRight")
    local place2 = self:addPlace("BlueDrive")
    local place3 = self:addPlace("BlueCup")

    place1:markButton("goDrivingPosition")
    place2:markButton("goBlueCup")
    place3:markButton("getKey")

    self:textI18n("progress_8")

    return self.progress
  end

  -- 蓝车钥匙遥控部分
  if self:nextProgress() == index or (self:getInteger("bluekey2") == 0) then
    local place1 = self:addPlace("BlueDrive")
    local place2 = self:addPlace("BlueDriveSlot")

    place1:markButton("goBlueDriveSlot")
    place2:markButton("getKey")

    self:textI18n("progress_9")

    return self.progress
  end

  -- 组装蓝车完整钥匙
  if self:nextProgress() == index or (self:getInteger("bluekey") == 0) then
    local place1 = self:addPlace("BlueKey")

    place1:imageOn("2")

    self:textI18n("progress_10")

    return self.progress
  end

  -- 使车通电
  if self:nextProgress() == index or (self:getInteger("blue_engine_on") < 1) then
    local place1 = self:addPlace("BlueDrive")
    local place2 = self:addPlace("BlueDashboard")

    place1:markButton("goMeter")
    -- place2:markButton("start")

    self:textI18n("progress_11")

    return self.progress
  end

  -- 拿光盘
  if self:nextProgress() == index or (self:getInteger("cd") == 0) then
    local place1 = self:addPlace("BlueDrive")
    local place2 = self:addPlace("BluePanel")

    place1:markButton("goCD")
    place2:markButton("outWarehouse")

    self:textI18n("progress_12")

    return self.progress
  end

  -- 解锁手套箱
  if self:nextProgress() == index or (self:getInteger("glovebox_unlock") == 0) then
    local place1 = self:addPlace("Cd")
    local place2 = self:addPlace("BluePanel")

    place1:markButton("click")
    place2:markButton("number1")
    place2:markButton("number2")
    place2:markButton("number3")
    place2:markButton("number4")
    place2:markButton("number5")
    place2:markButton("number6")
    place2:markButton("number7")
    place2:markButton("number8")

    self:textI18n("progress_13")

    return self.progress
  end

  -- 拿铁盒
  if self:nextProgress() == index or (self:getInteger("tin") == 0) then
    local place1 = self:addPlace("BlueDrive")
    local place2 = self:addPlace("BlueGlove")

    place1:markButton("goGlove")
    place2:markButton("openGlove")

    self:textI18n("progress_14")

    return self.progress
  end

  -- 拿铁盒小钥匙
  if self:nextProgress() == index or (self:getInteger("tinkey") == 0) then
    local place1 = self:addPlace("BlueDrive")
    local place2 = self:addPlace("BlueSeeArm")
    local place3 = self:addPlace("BlueArm")

    place1:markButton("_right")
    place2:markButton("goArm")
    place3:markButton("open")

    self:textI18n("progress_17")

    return self.progress
  end

  -- 拿开后备厢的工具
  if self:nextProgress() == index or (self:getInteger("tool") == 0) then
    local place1 = self:addPlace("Tin")
    local place2 = self:addPlace("Tin")

    place1:imageOn("2")
    place1:markButton("open")
    place2:imageOn("30")

    if self:getInteger("tool") == 0 then
      place2:imageOn("31")
    end

    self:textI18n("progress_18")

    return self.progress
  end

  -- 使用小工具打开后备厢
  if self:nextProgress() == index or (self:getInteger("tool") > 0) then
    local place1 = self:addPlace("BlueRearLeft")
    local place2 = self:addPlace("BlueTrunkPath")
    local place3 = self:addPlace("BlueTrunkLock")

    place1:markButton("goTrunkPath")
    place2:markButton("goTrunk")
    place3:markButton("open")

    self:textI18n("progress_19")

    return self.progress
  end

  -- 使用电箱钥匙
  if self:nextProgress() == index or (self:getInteger("electric_on") == 0) then
    local place1 = self:addPlace("BlueOutRear")
    local place2 = self:addPlace("ElectricBox")

    place1:markButton("goElectricBox")
    place2:markButton("pullPower")

    self:textI18n("progress_23")

    return self.progress
  end

  return self:nextProgress()
end

return E5Tip
