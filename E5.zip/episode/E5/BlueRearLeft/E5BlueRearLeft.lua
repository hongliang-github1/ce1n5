local E5BlueRearLeft = class("E5BlueRearLeft", function()
  return BasePlace.new()
end)

function E5BlueRearLeft:initPhoto()
  self:addPhoto("12", 1024, 0)
  self:addPhoto("21", 0, 0)
  self:addPhoto("22", 1024, 0)
end

function E5BlueRearLeft:initButton()
  self:addButton("infusion", 870, 0, 550, 470, false)
  self:addButton("openDoor", 1424, 390, 528, 342)
  self:addButton("seatBottom", 802, 736, 1028, 412)
  self:addButton("headRest", 174, 0, 610, 518)
  self:addButton("goTrunkPath", 0, 520, 800, 628)
end

function E5BlueRearLeft:arrowRight(rect)
  self:switchPlaceRight("BlueRearRight")
end

function E5BlueRearLeft:beforeLoad()
  -- 如果点滴袋没有了
  if self:getInteger("rescue") < 0 then
    -- 座椅被扳倒
    if self:getInteger("seat_rolled") > 0 then
      self:imageOn("21")

      return
    end

    -- 座椅没有被扳倒
    self:imageOn("11")

    return
  end

  -- 座椅被扳倒
  if self:getInteger("seat_rolled") > 0 then
    self:imageOn("21")
    self:imageOn("22")
    self:sayI18n("beforeLoad_1")

    return
  end

  self:imageOn("11")
  self:imageOn("12")
  self:sayI18n("beforeLoad_2")
end

function E5BlueRearLeft:afterLoad()

end

function E5BlueRearLeft:afterLoad2()
  if self:getInteger("seat_rolled") > 0 then
    self:cacheImage("11")

  else
    -- 座椅没有被扳倒
    self:cacheImage("21")
  end

  self:cacheImage("BlueIsofix/0")
  self:cacheImage("BlueSeatSwitch/0")
end

function E5BlueRearLeft:beforeUseItem(itemName)
  if itemName == "rescue" then
    return true
  end

  return false
end

function E5BlueRearLeft:afterUseItem(itemName)
  if itemName == "rescue" then
    -- 使用急救包，判断当前座椅是否是被扳倒的，并记录应急红灯为已使用
    local imageName = "11"
    if self:getInteger("seat_rolled") > 0 then
      imageName = "21"
    end
    self:imageOn(imageName)
    self:imageOff("22")
    self:imageOff("12")
    self:voidItem("redlamp")
    self:play("item")

    if self:getInteger("pin") < 0 then
      self:sayI18n("afterUseItem_1")

    else
      self:sayI18n("afterUseItem_2")
    end

    return false
  end

  return true
end

function E5BlueRearLeft:infusion(rect)
  -- 判断点滴药水袋是否拿下来了，如果没有拿下来就提示正打着点滴，如果拿下来了，就什么都不做
  if self:getInteger("rescue") >= 0 then
    self:sayI18n("infusion_1")
  end
end

function E5BlueRearLeft:openDoor(rect)
  self:play("tryopen")
  self:sayI18n("openDoor_1")
end

function E5BlueRearLeft:seatBottom(rect)
  -- 判断座椅是否被扳倒，如果被扳倒了，当前按钮要做的是合上座椅，如果座椅没有被扳倒，当前按钮要做的是移动到座椅下方
  if self:getInteger("seat_rolled") > 0 then
    self:setInteger("seat_rolled", 0)
    self:imageOn("11")
    self:play("seatunrolled")
    self:sayI18n("seatBottom_1")

    -- 判断点滴袋是否拿掉
    if self:getInteger("rescue") >= 0 then
      self:imageOn("12")
    end

    return
  end

  if self:getInteger("pin") >= 0 then
    self:sayI18n("seatBottom_2")

    return
  end

  self:switchPlaceZoomIn("BlueIsofix", rect)
end

function E5BlueRearLeft:headRest(rect)
  -- 判断座椅是否被扳倒，如果被扳倒了，当前按钮无效，如果座椅没有被扳倒，当前按钮要做的是切换到靠枕视角
  if self:getInteger("seat_rolled") <= 0 then
    if self:getInteger("pin") >= 0 then
      self:sayI18n("headRest_1")

      return
    end

    self:switchPlaceZoomIn("BlueSeatSwitch", rect)
  end
end

function E5BlueRearLeft:goTrunkPath(rect)
  if self:getInteger("seat_rolled") > 0 then
    self:switchPlaceZoomIn("BlueTrunkPath", cc.rect(385, 262, 300, 300))
  end
end

return E5BlueRearLeft
