local E5ElectricBox = class("E5ElectricBox", function()
  return BasePlace.new()
end)

function E5ElectricBox:initPhoto()
  self:addPhoto("2", 1024, 256)
end

function E5ElectricBox:initButton()
  self:addButton("pullPower", 560, 28, 916, 1024)
end

function E5ElectricBox:arrowRight(rect)
  self:switchPlaceZoomOut("BlueOutRear")
end

function E5ElectricBox:beforeLoad()
  self:imageOn("0")
end

function E5ElectricBox:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E5ElectricBox:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("BlueOutRear/2")
  self:cacheImage("Ending/1")
end

function E5ElectricBox:beforeUseItem(itemName)
  return false
end

function E5ElectricBox:afterUseItem(itemName)
  return true
end

function E5ElectricBox:pullPower(rect)
  if self:imageIsOn("1") then
    -- 电箱已经打开了
    self:disableTouch()
    self:imageOn("2")
    self:play("item")
    self:sayI18n("pullPower_1")

    -- 因为这个方法封装会enableTouch()，所以需要再调用一次
    self.blackLayer = self:effectFadeBlack(nil, 2, 0, 0, function()
      self:disableTouch()
      self:imageOff("1", true)
      self:imageOff("2", true)
      self:imageOn("BlueOutRear/3")

      self.blackLayer:runAction(cc.Sequence:create(cc.FadeOut:create(2), cc.CallFunc:create(function()
        self:sayI18n("pullPower_2")
      end), cc.DelayTime:create(1.5), cc.FadeIn:create(2), cc.CallFunc:create(function()
        self.blackLayer:removeFromParent(true)
        self:enableTouch()
        self:switchPlace("Ending")

        self.blackLayer = nil
      end)))


      return true
    end)
    
    return
  end

  self:imageOn("1")
  self:play("armopen")
  self:sayI18n("pullPower_3")

end

return E5ElectricBox
