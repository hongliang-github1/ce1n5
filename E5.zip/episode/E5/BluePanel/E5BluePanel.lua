local E5BluePanel = class("E5BluePanel", function()
  return BasePlace.new()
end)

function E5BluePanel:initPhoto()
  self:addPhoto("1", 256, 832)
end

function E5BluePanel:initButton()
  self:addButton("outWarehouse", 1698, 668, 340, 340)
  self:addButton("getCD", 158, 890, 1466, 214, false)
  self:addButton("number1", 0, 616, 226, 268, false)
  self:addButton("number2", 230, 616, 206, 268, false)
  self:addButton("number3", 440, 614, 196, 270, false)
  self:addButton("number4", 642, 614, 198, 270, false)
  self:addButton("number5", 844, 614, 190, 272, false)
  self:addButton("number6", 1038, 614, 190, 270, false)
  self:addButton("number7", 1232, 612, 184, 272, false)
  self:addButton("number8", 1422, 616, 210, 268, false)
  self:addButton("warningLights", 438, 0, 694, 486, false)
end

function E5BluePanel:arrowLeft(rect)
  self.label1:setVisible(false)
  self.label2:setVisible(false)
  self.label3:setVisible(false)
  self.label4:setVisible(false)

  self:switchPlaceZoomOut("BlueDrive")
end

function E5BluePanel:beforeLoad()
  self:imageOn("0")
end

function E5BluePanel:afterLoad()
  -- 默认设置当前输入的数字为第一个
  self.nowNum = 1

  local fontSize = 50 * 2

  if self.gamingScene and self.gamingScene.labelSay then
    fontSize = math.ceil(self.gamingScene.labelSay:getFontSize() * 2.85)
  end

function E5BluePanel:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("BlueDrive/0")
end

  local label1 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label2 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label3 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label4 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  label1:setColor(cc.c4b(255, 255, 255, 255))
  label2:setColor(cc.c4b(255, 255, 255, 255))
  label3:setColor(cc.c4b(255, 255, 255, 255))
  label4:setColor(cc.c4b(255, 255, 255, 255))
  label1:setAnchorPoint(0, 0)
  label2:setAnchorPoint(0, 0)
  label3:setAnchorPoint(0, 0)
  label4:setAnchorPoint(0, 0)
  label1:setPosition(0, 0)
  label2:setPosition(0, 0)
  label3:setPosition(0, 0)
  label4:setPosition(0, 0)

  self.label1 = label1
  self.label2 = label2
  self.label3 = label3
  self.label4 = label4

  self:addChild(label1)
  self:addChild(label2)
  self:addChild(label3)
  self:addChild(label4)

  -- 计算四个label的位置，居中为准，分别向两边延伸
  local bgSize    = self:getContentSize()
  local labelSize = label1:getContentSize()
  local x         = bgSize.width / 2
  local y         = bgSize.height / 2

  label1:setPosition(x - labelSize.width * 2, y)
  label2:setPosition(x - labelSize.width, y)
  label3:setPosition(x, y)
  label4:setPosition(x + labelSize.width, y)
end

function E5BluePanel:afterLoad2()
  self:cacheImage("BlueDrive/0")
end

function E5BluePanel:beforeUseItem(itemName)
  return false
end

function E5BluePanel:afterUseItem(itemName)
  return true
end

function E5BluePanel:outWarehouse(rect)
  if self:getInteger("blue_engine_on") ~= 0 then
    if self:imageIsOn("1") then
      -- CD已经弹出，再按下去没有反应
      self:play("tik")

      return
    end

    if self:getInteger("cd") ~= 0 then
      self:play("tik")
      self:sayI18n("outWarehouse_1")

      return
    end

    self:play("cdejected")
    self:imageOn("1")
    self:sayI18n("outWarehouse_2")

    return
  end

  self:play("tik")
  self:sayI18n("outWarehouse_3")
end

function E5BluePanel:getCD(rect)
  if self:getInteger("cd") ~= 0 or not self:imageIsOn("1") then
    return
  end

  self:imageOff("1")
  self:getItem("cd")
  self:sayI18n("getCD_1")
end

function E5BluePanel:number1(rect)
  self:input(1)
end

function E5BluePanel:number2(rect)
  self:input(2)
end

function E5BluePanel:number3(rect)
  self:input(3)
end

function E5BluePanel:number4(rect)
  self:input(4)
end

function E5BluePanel:number5(rect)
  self:input(5)
end

function E5BluePanel:number6(rect)
  self:input(6)
end

function E5BluePanel:number7(rect)
  self:input(7)
end

function E5BluePanel:number8(rect)
  self:input(8)
end

function E5BluePanel:warningLights(rect)
  self:play("button1")
  self:sayI18n("warningLights_1")
end

-- 清除label文字
function E5BluePanel:clearLabel()
  self.label1:setString("")
  self.label2:setString("")
  self.label3:setString("")
  self.label4:setString("")
end

-- 修改label颜色
function E5BluePanel:labelColorChange(isRed)
  local color = cc.c4b(255, 255, 255, 255)
  
  if isRed then
    color = cc.c4b(255, 0, 0, 255)
  end

  self.label1:setColor(color)
  self.label2:setColor(color)
  self.label3:setColor(color)
  self.label4:setColor(color)
end

function E5BluePanel:input(number)
  self:say("")

  if self:getInteger("blue_engine_on") == 0 then
    self:play("tik")
    self:sayI18n("input_1")

    return
  end

  if self:getInteger("cd") == 0 then
    -- 光盘还没得到，按下去没反应
    self:play("tik")
    self:sayI18n("input_2")

    return
  end

  -- if inputLabel.hidden then
  --   inputLabel.hidden = false
  -- end

  if self:getInteger("glovebox_unlock") ~= 0 then
    -- 如果手套箱已经解锁了，这里就不让再输入了，还需要把之前输入的密码Label text设置为空
    -- inputLabel.text = ""
    self:clearLabel()
    self:play("tik")
    self:sayI18n("input_3")

    return
  end

  -- 如果手套箱没有打开,让输入
  -- inputLabel.textColor = [UIColor whiteColor]

  if self.nowNum == 1 then
    self:clearLabel()
    self:labelColorChange(false)

    self.numOne = number
    self.nowNum = 2

    self.label1:setString(tostring(number))
    self:play("tik")

  elseif self.nowNum == 2 then
    self.numTwo = number
    self.nowNum = 3

    self.label2:setString(tostring(number))
    self:play("tik")

  elseif self.nowNum == 3 then
    self.numThree = number
    self.nowNum = 4

    self.label3:setString(tostring(number))
    self:play("tik")

  elseif self.nowNum == 4 then
    self.numFour = number

    self.label4:setString(tostring(number))

    -- 进入到这里，密码都输入完毕了，对比密码是否正确
    local num1 = self:getInteger("num_one")
    local num2 = self:getInteger("num_two")
    local num3 = self:getInteger("num_three")
    local num4 = self:getInteger("num_four")

    if self.numOne == num1 and self.numTwo == num2 and self.numThree == num3 and self.numFour == num4 then
      -- 密码正确，手套箱解锁，光盘设置为不能使用
      self:play("armopen")
      self:voidItem("cd")
      self:setInteger("glovebox_unlock", 1)
      self:sayI18n("input_4")
    else
      -- 密码不正确 ，将nowNum设置成1，如果再输入重新开始
      self:labelColorChange(true)

      self:play("tik")
      self:sayI18n("input_5")

      self.nowNum = 1
    end
  end
end

return E5BluePanel
