local E5BlueTrunkLock = class("E5BlueTrunkLock", function()
  return BasePlace.new()
end)

function E5BlueTrunkLock:initPhoto()
end

function E5BlueTrunkLock:initButton()
  self:addButton("open", 498, 254, 900, 512)
end

function E5BlueTrunkLock:arrowDown(rect)
  self:switchPlaceZoomOut("BlueTrunkPath")
end

function E5BlueTrunkLock:beforeLoad()
  self:imageOn("0")
end

function E5BlueTrunkLock:afterLoad()

end

function E5BlueTrunkLock:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("BlueTrunkPath/0")
  self:cacheImage("BlueOutRear/2")
end

function E5BlueTrunkLock:beforeUseItem(itemName)
  if itemName == "tool" then
    return true
  end

  return false
end

function E5BlueTrunkLock:afterUseItem(itemName)
  if itemName == "tool" then
    -- 使用工具打开后备厢
    self:imageOn("1")
    self:play("trunkopen")
    self:setInteger("trunk_open", 1)
    self:sayI18n("afterUseItem_1")

    return false
  end

  return true
end

function E5BlueTrunkLock:open(rect)
  if self:imageIsOn("1") then
    self:switchPlaceZoomIn("BlueOutRear", rect)

    return
  end

  if self:getInteger("tool") < 0 then
    self:imageOn("1")
    self:play("trunkopen")
    self:setInteger("trunk_open", 1)
    self:sayI18n("open_1")

    return
  end

  self:sayI18n("open_2")
end

return E5BlueTrunkLock
