local E5Tin = class("E5Tin", function()
  return BasePlace.new()
end)

function E5Tin:initPhoto()
  self:addPhoto("1", 896, 320)
  self:addPhoto("2", 896, 320)
  self:addPhoto("30", 704, 0)
  self:addPhoto("31", 1024, 576)
end

function E5Tin:initButton()
  self:addButton("open", 784, 190, 800, 800)
end

function E5Tin:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "BlueRearRight")
end

function E5Tin:beforeLoad()
  self:imageOn("0")
end

function E5Tin:afterLoad()
  self.click = 0
end

function E5Tin:afterLoad2()
end

function E5Tin:recordLastPlaceName()
  return false
end

function E5Tin:beforeUseItem(itemName)
  if itemName == "tinkey" then
    return not self.insertKey
  end

  return false
end

function E5Tin:afterUseItem(itemName)
  if itemName == "tinkey" then
    -- 使用铁盒钥匙
    self.insertKey = true

    self:hideArrowButton()
    self:imageOn("2")
    self:play("tik")
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E5Tin:open(rect)
  if not self.insertKey then
    self:sayI18n("open_1")

    return
  end

  if self.click == 0 then
    self:imageOn("1")
    self:imageOff("2")
    self:play("tik")
    self:sayI18n("open_2")

    self.click = 1

  elseif self.click == 1 then
    self:imageOff("1")
    self:imageOn("30")
    self:imageOn("31")
    self:play("tryopen")
    self:sayI18n("open_3")

    self.click = 2

  elseif self.click == 2 then
    self:showArrowButton()
    self:imageOff("31")
    self:voidItem("tin")
    self:voidItem("tinkey")
    self:getItem("tool")
    self:sayI18n("open_4")

    self.click = 3

  elseif self.click == 3 then
    self:sayI18n("open_5")
  end
end

return E5Tin
