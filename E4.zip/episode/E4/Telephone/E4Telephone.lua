local E4Telephone = class("E4Telephone", function()
  return BasePlace.new()
end)

function E4Telephone:initPhoto()
  self:addPhoto("1", 768, 0)
  self:addPhoto("5", 768, 0)
  self:addPhoto("6", 768, 0)
  self:addPhoto("h1", 768, 0)
  self:addPhoto("h3", 768, 0)
end

function E4Telephone:initButton()
  self:addButton("clickTelephone", 562, 0, 1482, 1148)
end

function E4Telephone:arrowDown(rect)
  self:switchPlaceZoomOut("BedStand")
end

function E4Telephone:beforeLoad()
  -- 根据电话机的状态，决定显示的底图
  if self:getInteger("wire") < 0 then
    self:imageOn("0")

    if self:getInteger("speak") < 0 or self:getInteger("speak") == 2 then
      -- 电话已经组装好了，可以使用
      self:imageOn("h1")

    else
      self:imageOn("1")
    end

    return
  end

  self:imageOn("16")
end

function E4Telephone:afterLoad()
  self.clickCount = 0
end

function E4Telephone:afterLoad2()
  self:cacheImage("BedStand/0")
end

function E4Telephone:beforeUseItem(itemName)
  if itemName == "wire" and self:imageIsOn("15") then
    return true
  end

  if itemName == "phone" and self:imageIsOn("1") and self:imageIsOn("6") == false then
    return true
  end

  if itemName == "speak" and self:imageIsOn("6") and self:imageIsOn("h1") == false then
    return true
  end

  return false
end

function E4Telephone:afterUseItem(itemName)
  if itemName == "wire" then
    -- 使用了电话线
    self:imageOn("0")
    self:imageOn("1")
    self:say("")

    return false
  end

  if itemName == "phone" then
    self:imageOn("6")
    self:sayI18n("afterUseItem_1")

    return true
  end

  if itemName == "speak" then
    self:imageOn("h1")
    self:imageOff("6")
    self:sayI18n("afterUseItem_3")

    -- 电话组装好之后，道具设为已使用
    self:voidItem("phone")
    self:setInteger("speak", 2)

    return true
  end

  return true
end

function E4Telephone:clickTelephone(rect)
  -- 已经使用过电话线
  if self:getInteger("wire") < 0 then
    if self:getInteger("speak") < 0 or self:getInteger("speak") == 2 then

      if self.clickCount == 0 then
          self:hideArrowButton()
          self:imageOn("h3")
          self:sayI18n("clickTelephone_1")

      elseif self.clickCount == 1 then
        self:sayI18n("clickTelephone_2")

      elseif self.clickCount == 2 then
        self:sayI18n("clickTelephone_3")

      elseif self.clickCount == 3 then
        self:sayI18n("clickTelephone_4")

      elseif self.clickCount == 4 then
        self:sayI18n("clickTelephone_5")

      elseif self.clickCount == 5 then
        self:sayI18n("clickTelephone_6")

      elseif self.clickCount == 6 then
        self:sayI18n("clickTelephone_7")

      elseif self.clickCount == 7 then
        self:sayI18n("clickTelephone_8")

      elseif self.clickCount == 8 then
        self:sayI18n("clickTelephone_9")

      elseif self.clickCount == 9 then
        self:sayI18n("clickTelephone_10")

      elseif self.clickCount == 10 then
        self:sayI18n("clickTelephone_11")

      elseif self.clickCount == 11 then
        self:sayI18n("clickTelephone_12")

      elseif self.clickCount == 12 then
        self:sayI18n("clickTelephone_13")

      elseif self.clickCount == 13 then
        self:imageOn("h1")
        self:imageOff("h3")
        self:sayI18n("clickTelephone_14")

      elseif self.clickCount == 14 then
        self:sayI18n("clickTelephone_15")

      elseif self.clickCount == 15 then
        self:sayI18n("clickTelephone_16")

      elseif self.clickCount == 16 then
          -- 在这里记录已经通话结束
          self:showArrowButton()
          self:voidItem("speak")
          self:sayI18n("clickTelephone_17")

      elseif self.clickCount == 17 then
          self:sayI18n("clickTelephone_18")

      elseif self.clickCount == 18 then
          self:sayI18n("clickTelephone_19")

      elseif self.clickCount == 19 then
          self:sayI18n("clickTelephone_20")
      end

      self.clickCount = self.clickCount + 1

      return
    end

    if self:getInteger("wire") < 0 and self:imageIsOn("6") == false then
      self:sayI18n("clickTelephone_21")

      return
    end

    if self:imageIsOn("6") and self:imageIsOn("5") == false then
      self:sayI18n("clickTelephone_22")

      return
    end

    return
  end

  -- 还没有连接上电话线的时候
  if self:imageIsOn("15") then
    self:imageOn("16")
    self:sayI18n("clickTelephone_24")

    return
  end

  -- 桌子还没拉开的时候
  self:imageOn("15")
  self:sayI18n("clickTelephone_25")
end

return E4Telephone
