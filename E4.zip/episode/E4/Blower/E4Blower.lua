local E4Blower = class("E4Blower", function()
  return BasePlace.new()
end)

function E4Blower:initPhoto()
  self:addPhoto("1", 0, 128)
  self:addPhoto("2", 0, 128)
  self:addPhoto("3", 1088, 0)
  self:addPhoto("4", 960, 0)
end

function E4Blower:initButton()
  self:addButton("openSocket", 1022, 0, 698, 630)
end

function E4Blower:arrowDown(rect)
  if self:getInteger("dryer") == 2 then
    self:setInteger("dryer", 1)
  end

  self:switchPlaceZoomOut("SeeSink")
end

function E4Blower:beforeLoad()
  self:imageOn("0")
end

function E4Blower:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E4Blower:afterLoad2()
  self:cacheImage("SeeSink/0")
end

function E4Blower:beforeUseItem(itemName)
  if itemName == "dryer" and self:imageIsOn("3") then
    return true
  end

  if itemName == "flashshell" and self:imageIsOn("3") and self:imageIsOn("4") then
    return self:getInteger("flashshell") ~= 2
  end

  return false
end

function E4Blower:afterUseItem(itemName)
  if itemName == "dryer" then
    self:imageOn("4")
    self:imageOn("2")
    self:play("tik")
    self:sayI18n("afterUseItem_1")

    return true
  end

  if itemName == "flashshell" then
    if self:getInteger("flashshell") == 2 then
      self:sayI18n("afterUseItem_2")

      return true
    end

    self:disableTouch()
    self:sayI18n("afterUseItem_3")
    self:play("dry")

    self:scheduleOnce(2, function()
      self:enableTouch()
      self:setInteger("flashshell", 2)
      self:sayI18n("afterUseItem_4")
    end)

    return true
  end

  return true
end

function E4Blower:openSocket(rect)
  if self:imageIsOn("3") then
    if self:imageIsOn("4") then
      self:imageOn("1")
      self:imageOn("3")
      self:imageOff("2")
      self:imageOff("4")
      self:sayI18n("openSocket_1")

      return
    end

    self:imageOff("1")
    self:imageOff("2")
    self:imageOff("3")
    self:imageOff("4")
    self:play("tik")
    self:sayI18n("openSocket_2")

    return
  end

  self:imageOn("1")
  self:imageOn("3")
  self:imageOff("2")
  self:imageOff("4")
  self:play("tik")
  self:sayI18n("openSocket_3")
end

return E4Blower
