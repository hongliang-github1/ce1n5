local E4Credit = class("E4Credit", function()
  return BaseCredit.new()
end)

function E4Credit:afterCreate()
  -- 构造滚动字幕
  self:addLabelI18n(1.1, "beforeLoad_1")

  -- TODO 显示通关时间
  -- local timingString  = [self timingString]
  -- local labelStr      = UikitEnhancement:textByI18nDict("beforeLoad_2")

  -- self:addLabelI18n(1, [labelStr stringByAppendingFormat:"%@", timingString)]

  self:addLabelI18n(1, "beforeLoad_3")

  self:addBlank()

  self:addLabelI18n(1, "beforeLoad_4")

  self:addImage("s8")

  self:addBlank()

  self:addLabelI18n(1, "beforeLoad_5")

  self:addLabelI18n(1, "beforeLoad_6")

  self:addLabelI18n(1, "beforeLoad_7")

  self:addLabelI18n(1, "beforeLoad_8")

  self:addLabelI18n(1, "beforeLoad_9")

  self:addLabelI18n(1, "beforeLoad_10")

  -- NSInteger hour = [[NSCalendar currentCalendar] components:NSHourCalendarUnit fromDate:[NSDate date]].hour

  -- if (hour > 0
  --   && hour < 7
  -- ) {
  --   self:addLabelI18n(0.9, "beforeLoad_11")
  -- end

  self:addBlank()

  self:playMusic("credit")
end

return E4Credit
