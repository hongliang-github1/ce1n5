local E4SeeDoor = class("E4SeeDoor", function()
  return BasePlace.new()
end)

function E4SeeDoor:initPhoto()
end

function E4SeeDoor:initButton()
  self:addButton("goHole", 908, 152, 536, 450)
  self:addButton("goDoor", 1110, 606, 612, 542)
end

function E4SeeDoor:arrowLeft(rect)
  self:switchPlaceLeft("Frame")
end

function E4SeeDoor:arrowRight(rect)
  self:switchPlaceRight("DoorRight")
end

function E4SeeDoor:beforeLoad()
  self:imageOn("0")
end

function E4SeeDoor:afterLoad()

end

function E4SeeDoor:afterLoad2()
  self:cacheImage("Frame/0")
  self:cacheImage("DoorRight/0")
end

function E4SeeDoor:beforeUseItem(itemName)
  return false
end

function E4SeeDoor:afterUseItem(itemName)
  return true
end

function E4SeeDoor:goHole(rect)
  self:switchPlaceZoomIn("Hole", rect)
end

function E4SeeDoor:goDoor(rect)
  self:switchPlaceZoomIn("Door", rect)
end

return E4SeeDoor
