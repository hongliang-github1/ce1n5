local E4Sink = class("E4Sink", function()
  return BasePlace.new()
end)

function E4Sink:initPhoto()
  self:addPhoto("1", 1088, 64)
  self:addPhoto("2", 896, 64)
  self:addPhoto("3", 896, 64)
end

function E4Sink:initButton()
  self:addButton("openWater", 768, 0, 862, 1148)
end

function E4Sink:arrowLeft(rect)
  self:switchPlaceZoomOut("SeeSink")
end

function E4Sink:beforeLoad()
  self:imageOn("0")
end

function E4Sink:beforeUnload()
  -- 防止用户没关水龙头，直接退回
  if self.playId then
    self:stopEffect(self.playId)
  end
end

function E4Sink:afterLoad()

end

function E4Sink:afterLoad2()
  self:cacheImage("SeeSink/0")
end

function E4Sink:beforeUseItem(itemName)
  if itemName == "kettle" then
    return true
  end

  return false
end

function E4Sink:afterUseItem(itemName)
  if itemName == "kettle" then
    -- 使用水壶
    if self:getInteger("kettle") == 2 then
      self:sayI18n("afterUseItem_1")

      return true
    end

    if self:imageIsOn("1") then
      -- 水壶已经装满水，将水壶设定为有水状态，值为2
      self:setInteger("kettle", 2)
      self:imageOn("3")
      self:sayI18n("afterUseItem_2")
      
      self.playId = self:play("waterin")
      
      self:disableTouch()
      
      -- 这里如果加水音效已经播放完了，用户还没有拿掉水壶，则设置水壶已加满水，自动关上水龙头
      self:scheduleOnce(4, function()
        self:enableTouch()
        self:openWater(nil)
      end)

    else
      self:imageOn("2")
      self:sayI18n("afterUseItem_3")
    end

    return true
  end

  return true
end

function E4Sink:openWater(rect)
  if self:imageIsOn("1") then
    if self.playId then
      self:stopEffect(self.playId)

      self.playId = nil
    end

    if self:imageIsOn("2") or self:imageIsOn("3") then
      self:imageOff("1")
      self:imageOff("2")
      self:imageOff("3")
      self:sayI18n("openWater_1")

    else
      self:imageOff("1")
      self:imageOff("2")
      self:imageOff("3")
      self:sayI18n("openWater_2")
    end

    return
  end

  if self:imageIsOn("2") then
    -- 水壶已经放上去了，将水壶设定为有水状态，值为2
    self:setInteger("kettle", 2)
    self:imageOn("1")
    self:imageOn("3")
    self:sayI18n("openWater_3")

    self.playId = self:play("waterin")
    
    self:disableTouch()
    
    -- 这里如果加水音效已经播放完了，用户还没有拿掉水壶，则设置水壶已加满水，自动关上水龙头
    self:scheduleOnce(4, function()
      self:enableTouch()
      self:openWater(nil)
    end)

    return
  end

  self:imageOn("1")
  self:sayI18n("openWater_4")

  self.playId = self:play("water", true)
end

return E4Sink
