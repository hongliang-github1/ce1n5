local E4Paper = class("E4Paper", function()
  return BasePlace.new()
end)

function E4Paper:initPhoto()
end

function E4Paper:initButton()
  self:addButton("clickScene", 0, 0, 2044, 1148)
end

function E4Paper:clickDeskCh()
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:setInteger("paper", 2)
    self:sayI18n("clickDeskCh_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:switchPlace("Kettle")

    return
  end
end

function E4Paper:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "Kettle")
end

function E4Paper:beforeLoad()
  self:disableAlwaysUseItem()

  if i18n.getLang() == "chs" then
    self:imageOn("0")
    self:sayI18n("beforeLoad_1")

  else
    self:imageOn("1")
    self:sayI18n("beforeLoad_2")
  end

  if self.lastPlaceName == "Kettle" and self:getInteger("kettle") == 3 and self:getInteger("speak") < 0 then
    self:hideArrowButton()

  else
    self:showArrowButton()
  end
end

function E4Paper:beforeUnload()
  self:enableAlwaysUseItem()
end

function E4Paper:afterLoad()

end

function E4Paper:afterLoad2()
  self:cacheImage("Kettle/0")
end

function E4Paper:recordLastPlaceName()
  return false
end

function E4Paper:beforeUseItem(itemName)
  if itemName == "paper" then
    -- 当前场景下还可以继续使用此道具，解决反复使用此道具状态混乱的问题
    return true
  end

  return false
end

function E4Paper:afterUseItem(itemName)
  if itemName == "paper" then
    -- 啥也不干，就是为了解决场景进来后的状态混乱问题
    return true
  end

  return true
end

function E4Paper:clickScene(rect)
  if self:getInteger("kettle") == 3 and self:getInteger("speak") < 0 then
    if i18n.getLang() == "chs" then
      -- 中文
      self:clickDeskCh()

    else
      -- 英文
      self:clickDeskOther()
    end
  end
end

function E4Paper:clickDeskOther()
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:setInteger("paper", 2)
    self:sayI18n("clickDeskOther_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:switchPlace("Kettle")

    return
  end
end

return E4Paper
