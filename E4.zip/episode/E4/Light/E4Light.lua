local E4Light = class("E4Light", function()
  return BasePlace.new()
end)

function E4Light:initPhoto()
  self:addPhoto("1", 1472, 512)
end

function E4Light:initButton()
  self:addButton("getLamp", 1326, 410, 402, 516)
end

function E4Light:arrowDown(rect)
  self:switchPlaceZoomOut("DoorRight")
end

function E4Light:beforeLoad()
  self:imageOn("0")

  if self:getInteger("wire") == 0 then
    self:imageOn("1")
    self:sayI18n("beforeLoad_1")
  end
end

function E4Light:afterLoad()

end

function E4Light:afterLoad2()
  self:cacheImage("DoorRight/0")
end

function E4Light:beforeUseItem(itemName)
  return false
end

function E4Light:afterUseItem(itemName)
  return true
end

function E4Light:getLamp(rect)
  if self:getInteger("wire") ~= 0 then
    self:sayI18n("getLamp_1")

    return
  end

  self:imageOff("1")
  self:getItem("wire")
  self:sayI18n("getLamp_2")
end

return E4Light
