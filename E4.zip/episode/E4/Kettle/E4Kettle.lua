local E4Kettle = class("E4Kettle", function()
  return BasePlace.new()
end)

function E4Kettle:initPhoto()
  self:addPhoto("1", 256, 256)
  self:addPhoto("2", 832, 128)
  self:addPhoto("3", 768, 192)
end

function E4Kettle:initButton()
  self:addButton("takeKettle", 386, 232, 464, 544)
  self:addButton("clickDesk", 860, 206, 654, 680, false)
  self:addButton("goCup", 0, 260, 378, 514)
end

function E4Kettle:arrowLeft(rect)
  self:switchPlaceZoomOut("DoorRight")
end

function E4Kettle:arrowDown(rect)
  self:switchPlaceDown("Trash")
end

function E4Kettle:beforeLoad()
  self:imageOn("0")

  if self:getInteger("kettle") == 0 then
    self:imageOn("1")
  end

  if self:getInteger("heat") < 0 then
    self:imageOn("2")

    -- 由于图片叠加造成的阴影，这里需要重新贴一次
    if self:getInteger("kettle") == 0 then
      self:imageOn("1")

    else
      self:imageOff("1")
    end
  end

  if self:getInteger("heat") < 0 and self:getInteger("kettle") == 3 then
    self:imageOn("3")
  end  
end

function E4Kettle:afterLoad()
  if self:getInteger("paper") == 2 then
    self:hideArrowButton()
  end
end

function E4Kettle:afterLoad2()
  self:cacheImage("DoorRight/0")
  self:cacheImage("Trash/0")
  self:cacheImage("Cup/0")
end

function E4Kettle:onTouchBegan(touch, event)
  if self:getInteger("kettle") == 3 and self:getInteger("heat") < 0 and self:getInteger("paper") == 2 and self:getInteger("speak") < 0 then
    if i18n.getLang() == "chs" then
      -- 中文情况下
      self:clickDeskCh()

    else
      -- 其他情况下
      self:clickDeskOther()
    end
  end
end

function E4Kettle:beforeUseItem(itemName)
  if itemName == "heat" then
    return true
  end

  if itemName == "kettle" and self:getInteger("heat") < 0 and  self:getInteger("kettle") ~= 3 then
    return true
  end

  return false
end

function E4Kettle:afterUseItem(itemName)
  if itemName == "heat" then
    self:imageOn("2")
    self:sayI18n("afterUseItem_1")

    return false
  end

  if itemName == "kettle" then
    if self:getInteger("kettle") == 2 then
      -- 记录水壶里是烧开的热水
      self:setInteger("kettle", 3)
      self:imageOn("3")
      self:sayI18n("afterUseItem_2")

      return true

    end

    self:sayI18n("afterUseItem_3")

    return true
  end

  return true
end

function E4Kettle:takeKettle(rect)
  if self:getInteger("kettle") == 3 and self:getInteger("heat") < 0 and self:getInteger("paper") == 2 and self:getInteger("speak") < 0 then
    self:onTouchBegan()

    return
  end

  if self:getInteger("kettle") ~= 0 then
    -- 热水壶已经拿了
    self:sayI18n("takeKettle_1")

    return
  end

  -- 热水壶还没有拿走
  self:imageOff("1")
  self:getItem("kettle")
  self:sayI18n("takeKettle_2")
end

function E4Kettle:goCup(rect)
  if self:getInteger("kettle") == 3 and self:getInteger("heat") < 0 and self:getInteger("paper") == 2 and self:getInteger("speak") < 0 then
    self:onTouchBegan()

    return
  end
  self:switchPlaceZoomIn("Cup", rect)
end

function E4Kettle:clickDeskCh()
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskCh_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskCh_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskCh_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskCh_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskCh_5")

    -- 换贴图，把热水壶拿掉
    self:imageOff("3")

    -- 昏迷白屏动画
    self:effectFadeWhite(nil, 1.5, 0, 0, function()
      self:switchPlace("Ending")
    end)
  end
end

function E4Kettle:clickDesk(rect)
  if self:getInteger("kettle") == 3 and self:getInteger("heat") < 0 then
    if self:getInteger("paper") == 2 and self:getInteger("speak") < 0 then
      if i18n.getLang() == "chs" then
        -- 中文情况下
        self:clickDeskCh()

      else
        -- 其他情况下
        self:clickDeskOther()
      end

    else
      local progress = self:nextProgress()

      self:resetProgressIndex()

      if progress == self:nextProgressIndex() then
        self:sayI18n("clickDesk_1")

        return
      end

      if progress == self:nextProgressIndex() then
        self:sayI18n("clickDesk_2")

        return
      end
    end

    return
  end

  if self:getInteger("heat") < 0 then
    self:sayI18n("clickDesk_3")

  else
    self:say("")
  end
end

function E4Kettle:clickDeskOther()
  local progress = self:nextProgress()
  
  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskOther_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskOther_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskOther_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskOther_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskOther_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskOther_6")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskOther_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickDeskOther_8")

    -- 换贴图，把热水壶拿掉
    self:imageOff("3")

    -- 昏迷动画
    self:effectFadeWhite(nil, 1.5, 0, 0, function()
      self:switchPlace("Ending")
    end)
  end
end

return E4Kettle
