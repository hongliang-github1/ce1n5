local E4Door = class("E4Door", function()
  return BasePlace.new()
end)

function E4Door:initPhoto()
  self:addPhoto("1", 640, 832)
end

function E4Door:initButton()
  self:addButton("openDoor", 508, 444, 414, 636)
  self:addButton("goBathroom", 1214, 776, 412, 372)
end

function E4Door:arrowDown(rect)
  self:switchPlaceZoomOut("SeeDoor")
end

function E4Door:beforeLoad()
  self:imageOn("0")
  self.clickCount = 0
end

function E4Door:afterLoad()

end

function E4Door:afterLoad2()
  self:cacheImage("SeeDoor/0")
  self:cacheImage("Bathroom/1")
end

function E4Door:beforeUseItem(itemName)
  return false
end

function E4Door:afterUseItem(itemName)
  return true
end

function E4Door:openDoor(rect)

  if self.clickCount == 0 then
    self:sayI18n("openDoor_1")

  elseif self.clickCount == 1 then
    self:imageOn("1")
    self:play("trydoor")
    self:sayI18n("openDoor_2")

  else
    self:sayI18n("openDoor_3")
  end

  self.clickCount = self.clickCount + 1
end

function E4Door:goBathroom(rect)
  self:switchPlaceZoomIn("Bathroom", rect)
end

return E4Door
