local E4Towel = class("E4Towel", function()
  return BasePlace.new()
end)

function E4Towel:initPhoto()
  self:addPhoto("1", 704, 0)
  self:addPhoto("2", 640, 0)
  self:addPhoto("3", 640, 0)
end

function E4Towel:initButton()
  self:addButton("openRightTowel", 1166, 0, 536, 484)
  self:addButton("openLeftTowel", 604, 0, 556, 484)
end

function E4Towel:arrowDown(rect)
  self:switchPlaceZoomOut("Bathroom")
end

function E4Towel:beforeLoad()
  self:imageOn("0")
end

function E4Towel:afterLoad()

end

function E4Towel:afterLoad2()
  self:cacheImage("Bathroom/1")
end

function E4Towel:beforeUseItem(itemName)
  return false
end

function E4Towel:afterUseItem(itemName)
  return true
end

function E4Towel:openRightTowel(rect)
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:imageOff("2")
    self:imageOff("3")
    self:sayI18n("openRightTowel_1")

    return
  end

  self:imageOn("1")
  self:imageOff("2")
  self:imageOff("3")
  self:sayI18n("openRightTowel_2")
end

function E4Towel:openLeftTowel(rect)
  if self:imageIsOn("2") or self:imageIsOn("3") then
    -- 毛巾掀开，根据道具状态决定是取得道具还是合上毛巾
    if self:getInteger("speak") ~= 0 then
      self:imageOff("1")
      self:imageOff("2")
      self:imageOff("3")
      self:sayI18n("openLeftTowel_1")

      return
    end

    self:imageOn("3")
    self:getItem("speak")
    self:sayI18n("openLeftTowel_2")

    return
  end

  self:imageOff("1")
  self:imageOff("2")
  self:imageOff("3")

  if self:getInteger("speak") ~= 0 then
    -- 道具已经拿过了，里面是空的
    self:imageOn("3")
    self:sayI18n("openLeftTowel_3")

    return
  end

  -- 道具还没拿过，里面有东西
  self:imageOn("2")
  self:sayI18n("openLeftTowel_4")
end

return E4Towel
