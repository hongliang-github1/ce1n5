local E4Trash = class("E4Trash", function()
  return BasePlace.new()
end)

function E4Trash:initPhoto()
end

function E4Trash:initButton()
  self:addButton("getPaper", 612, 148, 664, 678)
end

function E4Trash:arrowUp(rect)
  self:switchPlaceUp("Kettle")
end

function E4Trash:beforeLoad()
  self:imageOn("0")
end

function E4Trash:afterLoad()

end

function E4Trash:afterLoad2()
  self:cacheImage("Kettle/0")
end

function E4Trash:beforeUseItem(itemName)
  return false
end

function E4Trash:afterUseItem(itemName)
  return true
end

function E4Trash:getPaper(rect)
  if self:getInteger("paper") ~= 0 then
    self:sayI18n("getPaper_1")

    return
  end

  self:getItem("paper")
  self:sayI18n("getPaper_2")
end

return E4Trash
