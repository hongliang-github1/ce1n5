local E4DoorRight = class("E4DoorRight", function()
  return BasePlace.new()
end)

function E4DoorRight:initPhoto()
  self:addPhoto("5", 256, 448)
  self:addPhoto("6", 256, 448)
  self:addPhoto("7", 256, 448)
end

function E4DoorRight:initButton()
  self:addButton("curtain", 724, 36, 1056, 798)
  self:addButton("goDesk", 362, 562, 280, 310)
  self:addButton("goTV", 122, 196, 226, 524)
  self:addButton("tableLamp", 356, 274, 340, 254)
end

function E4DoorRight:arrowLeft(rect)
  self:switchPlaceLeft("SeeDoor")
end

function E4DoorRight:arrowRight(rect)
  self:switchPlaceRight("BedStand")
end

function E4DoorRight:beforeLoad()
  self:imageOn("0")

  -- 根据状态贴图
  if self:getInteger("kettle") ~= 0 then
    self:imageOn("7")
  end

  if self:getInteger("heat") < 0 then
    self:imageOn("5")
  end

  if self:getInteger("heat") < 0 and self:getInteger("kettle") == 3 then
    -- 正在烧水
    self:imageOn("6")
  end
end

function E4DoorRight:afterLoad()

end

function E4DoorRight:afterLoad2()
  self:cacheImage("SeeDoor/0")
  self:cacheImage("BedStand/0")
  self:cacheImage("Kettle/0")
end

function E4DoorRight:beforeUseItem(itemName)
  return false
end

function E4DoorRight:afterUseItem(itemName)
  return true
end

function E4DoorRight:curtain(rect)
  self:sayI18n("curtain_1")
end

function E4DoorRight:goDesk(rect)
  self:switchPlaceZoomIn("Kettle", rect)
end

function E4DoorRight:goTV(rect)
  self:switchPlaceZoomIn("Tv", rect)
end

function E4DoorRight:tableLamp(rect)
  self:switchPlaceZoomIn("Light", rect)
end

return E4DoorRight
