local E4Frame = class("E4Frame", function()
  return BasePlace.new()
end)

function E4Frame:initPhoto()
  self:addPhoto("2", 1024, 448)
end

function E4Frame:initButton()
  self:addButton("photoFrame", 998, 460, 316, 308)
end

function E4Frame:arrowLeft(rect)
  self:switchPlaceLeft("Bed")
end

function E4Frame:arrowRight(rect)
  self:switchPlaceRight("SeeDoor")
end

function E4Frame:beforeLoad()
  self:imageOn("0")
  self:imageOn("2")
end

function E4Frame:afterLoad()

end

function E4Frame:afterLoad2()
  self:cacheImage("Bed/0")
  self:cacheImage("SeeDoor/0")
end

function E4Frame:beforeUseItem(itemName)
  return false
end

function E4Frame:afterUseItem(itemName)
  return true
end

function E4Frame:photoFrame(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:sayI18n("photoFrame_3")
    
  else
    -- 相框已开，挂上相框
    self:imageOn("2")
    self:sayI18n("photoFrame_1")
  end

end

return E4Frame
