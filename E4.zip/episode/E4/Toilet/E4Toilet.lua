local E4Toilet = class("E4Toilet", function()
  return BasePlace.new()
end)

function E4Toilet:initPhoto()
  self:addPhoto("2", 576, 576)
end

function E4Toilet:initButton()
  self:addButton("openToilet", 180, 242, 1554, 800)
end

function E4Toilet:arrowRight(rect)
  self:switchPlaceZoomOut("Bathroom")
end

function E4Toilet:beforeLoad()
  self:imageOn("1")
end

function E4Toilet:afterLoad()

end

function E4Toilet:afterLoad2()
  self:cacheImage("Bathroom/1")
  self:cacheImage("0")
end

function E4Toilet:beforeUseItem(itemName)
  return false
end

function E4Toilet:afterUseItem(itemName)
  return true
end

function E4Toilet:openToilet(rect)
  if self:imageIsOn("0") then
    -- 马桶盖已开，根据道具状态决定是取得道具还是关马桶盖
    if self:getInteger("flashshell") ~= 0 then
      self:imageOn("1")
      self:sayI18n("openToilet_1")

      return
    end

    -- 得到道具
    self:imageOff("2")
    self:getItem("flashshell")
    self:sayI18n("openToilet_2")

    return
  end

  self:imageOn("0")

  if self:getInteger("flashshell") ~= 0 then
    self:sayI18n("openToilet_3")

    return
  end

  -- 道具还没拿过，里面有东西
  self:imageOn("2")
  self:sayI18n("openToilet_4")
end

return E4Toilet
