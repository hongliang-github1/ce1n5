local E4Bed = class("E4Bed", function()
  return BasePlace.new()
end)

function E4Bed:initPhoto()
  self:addPhoto("2", 512, 704)
end

function E4Bed:initButton()
  self:addButton("openPillow", 340, 452, 728, 624)
  self:addButton("goStandRight", 1206, 0, 688, 650)
end

function E4Bed:arrowLeft(rect)
  self:switchPlaceLeft("BedStand")
end

function E4Bed:arrowRight(rect)
  self:switchPlaceRight("Frame")
end

function E4Bed:beforeLoad()
  self:imageOn("0")
end

function E4Bed:afterLoad()

end

function E4Bed:afterLoad2()
  self:cacheImage("BedStand/0")
  self:cacheImage("Frame/0")
  self:cacheImage("StandRight/0")
end

function E4Bed:beforeUseItem(itemName)
  return false
end

function E4Bed:afterUseItem(itemName)
  return true
end

function E4Bed:openPillow(rect)
  if self:imageIsOn("1") then
    -- 掀开枕头，根据道具状态决定是取得道具还是合上枕头
    if self:getInteger("phone") ~= 0 then
      self:imageOff("1")
      self:imageOff("2")
      self:sayI18n("openPillow_1")

      return
    end

    -- 道具还没取得，得到道具，改变图片状态
    self:imageOff("2")
    self:getItem("phone")
    self:sayI18n("openPillow_2")

    return
  end

  self:imageOn("1")

  if self:getInteger("phone") ~= 0 then
    -- 道具已经拿过了，里面是空的
    self:imageOff("2")
    self:sayI18n("openPillow_3")

    return
  end

  -- 道具还没拿过，里面有东西
  self:imageOn("2")
  self:sayI18n("openPillow_4")
end

function E4Bed:goStandRight(rect)
  self:switchPlaceZoomIn("StandRight", rect)
end

return E4Bed
