local E4BedDown = class("E4BedDown", function()
  return BasePlace.new()
end)

function E4BedDown:initPhoto()
  self:addPhoto("2", 960, 576)
  self:addPhoto("3", 384, 512)
  self:addPhoto("4", 384, 512)
end

function E4BedDown:initButton()
  self:addButton("lookBedDown", 0, 344, 2044, 508)
end

function E4BedDown:arrowRight(rect)
  self:switchPlaceRight("StandRightDown")
end

function E4BedDown:beforeLoad()
  self:imageOn("0")

  if self:getInteger("heat") == 0 then
    self:imageOn("2")
  end
end

function E4BedDown:afterLoad()

end

function E4BedDown:afterLoad2()
  self:cacheImage("StandRightDown/0")
end

function E4BedDown:beforeUseItem(itemName)
  if itemName == "flash" then
    return true
  end

  return false
end

function E4BedDown:afterUseItem(itemName)
  if itemName == "flash" then
    if self:getInteger("heat") ~= 0 then
      self:imageOn("4")
      self:sayI18n("afterUseItem_1")

    else
      self:imageOn("3")
      self:sayI18n("afterUseItem_2")
    end

    return true
  end

  return true
end

function E4BedDown:lookBedDown(rect)
  if self:imageIsOn("3") or self:imageIsOn("4") then
    if self:getInteger("heat") ~= 0 then
      self:sayI18n("lookBedDown_1")

      return
    end

    -- 得到底座
    self:imageOn("4")
    self:getItem("heat")
    self:sayI18n("lookBedDown_2")

    return
  end

  self:sayI18n("lookBedDown_4")
end

return E4BedDown
