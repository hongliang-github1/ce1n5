local E4Tip = class("E4Tip", function()
  return BaseTip.new()
end)

function E4Tip:getTipAtIndex(index)
  self:resetProgress()

  -- 拿灯头
  if self:nextProgress() == index or (self:getInteger("bulb") == 0) then
    local place1 = self:addPlace("DoorRight")
    local place2 = self:addPlace("Kettle")
    local place3 = self:addPlace("Cup")

    place1:markButton("goDesk")
    place2:markButton("goCup")
    place3:markButton("clickCup")

    self:textI18n("progress_3")

    return self.progress
  end

  -- 拿灯壳
  if self:nextProgress() == index or (self:getInteger("flashshell") == 0) then
    local place1 = self:addPlace("Bathroom")
    local place2 = self:addPlace("Toilet")

    place1:markButton("goToilet")
    place2:markButton("openToilet")

    self:textI18n("progress_4")

    return self.progress
  end

  -- 拿吹风机
  if self:nextProgress() == index or (self:getInteger("dryer") == 0) then
    local place1 = self:addPlace("Bed")
    local place2 = self:addPlace("StandRight")
    local place3 = self:addPlace("StandRightDown")

    place1:markButton("goStandRight")
    place2:markButton("_down")
    place3:markButton("getHairDrier")

    self:textI18n("progress_5")

    return self.progress
  end

  -- 组装手电
  if self:nextProgress() == index or (self:getInteger("flash") == 0) then
    local place1 = self:addPlace("SeeSink")
    local place2 = self:addPlace("Blower")
    local place3 = self:addPlace("Flashlight")

    place1:markButton("goBlower")
    place2:markButton("openSocket")
    place3:markButton("use")
    place3:imageOn("1")
    place3:imageOn("2")

    self:textI18n("progress_6")

    return self.progress
  end

  -- 拿电话线
  if self:nextProgress() == index or (self:getInteger("wire") == 0) then
    local place1 = self:addPlace("DoorRight")
    local place2 = self:addPlace("Light")

    place1:markButton("tableLamp")
    place2:markButton("getLamp")

    self:textI18n("progress_7")

    return self.progress
  end

  -- 拿电话底座
  if self:nextProgress() == index or (self:getInteger("phone") == 0) then
    local place1 = self:addPlace("Bed")

    place1:markButton("openPillow")

    self:textI18n("progress_8")

    return self.progress
  end

  -- 拿话筒
  if self:nextProgress() == index or (self:getInteger("speak") == 0) then
    local place1 = self:addPlace("Bathroom")
    local place2 = self:addPlace("Towel")

    place1:markButton("goTowel")
    place2:markButton("openLeftTowel")

    self:textI18n("progress_9")

    return self.progress
  end

  -- 组装电话
  if self:nextProgress() == index or (self:getInteger("wire") ~= 0 and self:getInteger("phone") ~= 0 and self:getInteger("speak") >= 0) then
    local place1 = self:addPlace("BedStand")
    local place2 = self:addPlace("Telephone")

    place1:markButton("goTelephone")
    place2:markButton("clickTelephone")

    self:textI18n("progress_11")

    return self.progress
  end

  -- 拿水壶底座
  if self:nextProgress() == index or (self:getInteger("heat") == 0) then
    local place1 = self:addPlace("StandRightDown")
    local place2 = self:addPlace("BedDown")

    place1:markButton("goBedDown")
    place2:markButton("lookBedDown")

    self:textI18n("progress_13")

    return self.progress
  end

  -- 拿到废纸
  if self:nextProgress() == index or (self:getInteger("paper") == 0) then
    local place1 = self:addPlace("Kettle")
    local place2 = self:addPlace("Trash")

    place1:markButton("_down")
    place2:markButton("getPaper")

    self:textI18n("progress_14")

    return self.progress
  end

  -- 拿水壶，烧水通关
  if self:nextProgress() == index or (self:getInteger("kettle") >= 0 and self:getInteger("kettle") ~= 3) then
    local place1 = self:addPlace("Kettle")
    local place2 = self:addPlace("Sink")

    place1:markButton("takeKettle")
    place2:markButton("openWater")

    self:textI18n("progress_15")

    return self.progress
  end

  -- 关键剧情提示，醍醐灌顶
  if self:nextProgress() == index or (self:getInteger("kettle") >= 0) then
    local place1 = self:addPlace("Kettle")

    self:addPlace("Paper")

    place1:markButton("clickDesk")

    self:textI18n("progress_16")

    return self.progress
  end

  return self:nextProgress()
end

return E4Tip
