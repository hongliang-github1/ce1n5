local E4Beginning = class("E4Beginning", function()
  return BasePlace.new()
end)

function E4Beginning:initPhoto()
end

function E4Beginning:initButton()
  self:addButton("clickScene", 0, 0, 2044, 1148, false)
end

function E4Beginning:beforeLoad()
  self:imageOn("Bed/0")
end

function E4Beginning:afterLoad()
  self:clickScene(nil)
end

function E4Beginning:afterLoad2()
  self:cacheImage("Door/0")
  self:cacheImage("BedStand/0")
  self:cacheImage("iphone")
  self:cacheImage("SeeDoor/0")
end

function E4Beginning:beforeUseItem(itemName)
  return false
end

function E4Beginning:afterUseItem(itemName)
  return true
end

function E4Beginning:clickScene(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickScene_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickScene_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("Door/0")
    self:sayI18n("clickScene_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickScene_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("BedStand/0")
    self:sayI18n("clickScene_5")
    self:disableTouch()
    
    self.flickerCount = 0

    self.flickerAction = self:schedule(0.2, function()
      self.flickerCount = self.flickerCount + 1

      if self:imageIsOn("BedStand/1_1152_512") then
        self:imageOff("BedStand/1_1152_512")

      else
        self:imageOn("BedStand/1", 1152, 512)
      end

      if self.flickerCount > 6 then
        self:unschedule(self.flickerAction)
        self:enableTouch()
        self:imageOff("BedStand/1_1152_512", true)

        self.flickerAction = nil

        return
      end
    end)

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("clickScene_6")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("iphone")
    self:sayI18n("clickScene_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("SeeDoor/0")
    self:sayI18n("clickScene_8")

    return
  end

  if progress == self:nextProgressIndex() then
    progress = self:nextProgressIndex()

    self:switchPlace("SeeDoor")

    return
  end
end

return E4Beginning
