local E4Bathroom = class("E4Bathroom", function()
  return BasePlace.new()
end)

function E4Bathroom:initPhoto()
end

function E4Bathroom:initButton()
  self:addButton("goToilet", 262, 760, 470, 388)
  self:addButton("goTowel", 226, 0, 664, 474)
  self:addButton("goSeeSink", 1074, 0, 736, 1148)
end

function E4Bathroom:arrowDown(rect)
  self:switchPlaceZoomOut("Door")
end

function E4Bathroom:beforeLoad()
  self:imageOn("1")
end

function E4Bathroom:afterLoad()
  if self.lastPlaceName == "Door" then
    self:sayI18n("afterLoad_1")
  end
end

function E4Bathroom:afterLoad2()
  self:cacheImage("Door/0")
  self:cacheImage("Toilet/1")
end

function E4Bathroom:beforeUseItem(itemName)
  return false
end

function E4Bathroom:afterUseItem(itemName)
  return true
end

function E4Bathroom:goToilet(rect)
  self:switchPlaceZoomIn("Toilet", rect)
end

function E4Bathroom:goTowel(rect)
  self:switchPlaceZoomIn("Towel", rect)
end

function E4Bathroom:goSeeSink(rect)
  self:switchPlaceRight("SeeSink")
end

return E4Bathroom
