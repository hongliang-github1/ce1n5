local E4Tv = class("E4Tv", function()
  return BasePlace.new()
end)

function E4Tv:initPhoto()
  self:addPhoto("0", 0, 0)
end

function E4Tv:initButton()
  self:addButton("lookTv", 232, 128, 1390, 952)
end

function E4Tv:arrowLeft(rect)
  self:switchPlaceZoomOut("DoorRight")
end

function E4Tv:beforeLoad()
  self:imageOn("0")
end

function E4Tv:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E4Tv:afterLoad2()
  self:cacheImage("DoorRight/0")
end

function E4Tv:beforeUseItem(itemName)
  return false
end

function E4Tv:afterUseItem(itemName)
  return true
end

function E4Tv:lookTv(rect)
  self:sayI18n("lookTv_1")
end

return E4Tv
