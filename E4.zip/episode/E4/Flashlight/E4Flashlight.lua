local E4Flashlight = class("E4Flashlight", function()
  return BasePlace.new()
end)

function E4Flashlight:initPhoto()
  self:addPhoto("1", 896, 576)
  self:addPhoto("2", 1088, 256)
end

function E4Flashlight:initButton()
  self:addButton("use", 0, 0, 2044, 1148)
end

function E4Flashlight:arrowDown(rect)
  -- 返回进入当前场景的上一个场景
  self:switchPlaceZoomOut(self.lastPlaceName or "SeeDoor")
end

function E4Flashlight:beforeLoad()
  self:imageOn("0")
  self:imageOn("1")
end

function E4Flashlight:afterLoad()
  self:sayI18n("afterLoad_1")
  self.click = 0
end

function E4Flashlight:afterLoad2()
  self:cacheImage("3")
end

function E4Flashlight:recordLastPlaceName()
  -- 此场景不记录到laseSceneName中
  return false
end

function E4Flashlight:beforeUseItem(itemName)
  -- 解决反复使用,状态混乱的问题
  if itemName == "flashshell" then
    return true
  end

  if itemName == "bulb" then
    return true
  end

  return false
end

function E4Flashlight:afterUseItem(itemName)
  if itemName == "flashshell" then
    -- 啥也不干，就是为了解决场景进来后的状态混乱问题
    return true
  end

  if itemName == "bulb" then
    -- 使用灯泡
    self:imageOn("2")
    self:sayI18n("afterUseItem_3")

    return true
  end

  return true
end

function E4Flashlight:use(rect)
  if self:getInteger("flashshell") == 1 then
    self:sayI18n("use_1")

    return
  end

  if (self:imageIsOn("1") and self:imageIsOn("2")) or self:imageIsOn("3") or self:imageIsOn("4") then
    if self.click == 0 then
      self:sayI18n("use_2")

    elseif self.click == 1 then
      -- 得到手电筒道具
      self:imageOn("3")
      self:imageOff("1")
      self:imageOff("2")
      self:voidItem("bulb")
      self:voidItem("flashshell")
      self:voidItem("dryer")
      self:getItem("flash")
      self:sayI18n("use_3")

    elseif self.click == 2 then
      self:imageOn("4")
      self:sayI18n("use_4")

    else
      self:sayI18n("use_5")
    end

    self.click = self.click + 1

    return
  end

  if self:imageIsOn("2") == false then
    self:sayI18n("use_8")

    return
  end
end

return E4Flashlight
