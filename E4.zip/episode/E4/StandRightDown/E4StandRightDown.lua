local E4StandRightDown = class("E4StandRightDown", function()
  return BasePlace.new()
end)

function E4StandRightDown:initPhoto()
  self:addPhoto("1", 384, 0)
  self:addPhoto("2", 384, 0)
end

function E4StandRightDown:initButton()
  self:addButton("getHairDrier", 434, 0, 1254, 366)
  self:addButton("sayJustSlippers", 714, 538, 716, 406)
  self:addButton("goBedDown", 0, 472, 478, 676)
end

function E4StandRightDown:arrowUp(rect)
  self:switchPlaceUp("StandRight")
end

function E4StandRightDown:beforeLoad()
  self:imageOn("0")

  if self:getInteger("dryer") ~= 0 then
    self:imageOn("2")

  else
    self:imageOn("1")
  end
end

function E4StandRightDown:afterLoad()

end

function E4StandRightDown:afterLoad2()
  self:cacheImage("StandRight/0")
  self:cacheImage("BedDown/0")
end

function E4StandRightDown:beforeUseItem(itemName)
  return false
end

function E4StandRightDown:afterUseItem(itemName)
  return true
end

function E4StandRightDown:getHairDrier(rect)
  if self:getInteger("dryer") ~= 0 then
    self:sayI18n("getHairDrier_1")

    return
  end

  self:imageOn("2")
  self:getItem("dryer")
  self:sayI18n("getHairDrier_2")
end

function E4StandRightDown:sayJustSlippers(rect)
  self:sayI18n("sayJustSlippers_1")
end

function E4StandRightDown:goBedDown(rect)
  self:switchPlaceLeft("BedDown")
end

return E4StandRightDown
