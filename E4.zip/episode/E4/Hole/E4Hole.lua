local E4Hole = class("E4Hole", function()
  return BasePlace.new()
end)

function E4Hole:initPhoto()
  self:addPhoto("1", 896, 0)
end

function E4Hole:initButton()
  self:addButton("lookOut", 818, 0, 336, 280)
end

function E4Hole:arrowDown(rect)
  self:switchPlaceZoomOut("SeeDoor")
end

function E4Hole:beforeLoad()
  self:imageOn("0")
  self:imageOn("1")
end

function E4Hole:afterLoad()

end

function E4Hole:afterLoad2()
  self:cacheImage("SeeDoor/0")
  self:cacheImage("HoleOut/0")
end

function E4Hole:beforeUseItem(itemName)
  return false
end

function E4Hole:afterUseItem(itemName)
  return true
end

function E4Hole:lookOut(rect)
  self:switchPlaceZoomIn("HoleOut", rect)
end

return E4Hole
