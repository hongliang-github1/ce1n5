local E4SeeSink = class("E4SeeSink", function()
  return BasePlace.new()
end)

function E4SeeSink:initPhoto()
end

function E4SeeSink:initButton()
  self:addButton("goBlower", 1440, 0, 514, 354)
  self:addButton("clickWashing", 1158, 536, 454, 358)
  self:addButton("goSink", 602, 672, 556, 476)
  self:addButton("goSink1", 1156, 898, 456, 250, false)
end

function E4SeeSink:arrowLeft(rect)
  self:switchPlaceLeft("Bathroom")
end

function E4SeeSink:beforeLoad()
  self:imageOn("0")
end

function E4SeeSink:afterLoad()

end

function E4SeeSink:afterLoad2()
  self:cacheImage("Bathroom/1")
  self:cacheImage("Blower/0")
  self:cacheImage("Sink/0")
end

function E4SeeSink:beforeUseItem(itemName)
  return false
end

function E4SeeSink:afterUseItem(itemName)
  return true
end

function E4SeeSink:goBlower(rect)
  self:switchPlaceZoomIn("Blower", rect)
end

function E4SeeSink:clickWashing(rect)
  self:sayI18n("clickWashing_1")
end

function E4SeeSink:goSink(rect)
  self:switchPlaceZoomIn("Sink", rect)
end

function E4SeeSink:goSink1(rect)
  self:switchPlaceZoomIn("Sink", rect)
end

return E4SeeSink
