local E4Ending = class("E4Ending", function()
  return BasePlace.new()
end)

function E4Ending:initPhoto()
end

function E4Ending:initButton()
  self:addButton("open", 0, 0, 2044, 1148, false)
end

function E4Ending:beforeLoad()
  self:imageOn("Bed/0")
end

function E4Ending:afterLoad()
  -- 设置已经把热水倒在头上了，水壶使用完毕
  self:voidItem("paper")

  self:sayI18n("afterLoad_1")
end

function E4Ending:afterLoad2()
  self:cacheImage("DoorRight/0")
  self:cacheImage("0")
  self:cacheImage("1")
end

function E4Ending:beforeUseItem(itemName)
  return false
end

function E4Ending:afterUseItem(itemName)
  return true
end

function E4Ending:open(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("open_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("Door/0")
    self:sayI18n("open_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("0")
    self:sayI18n("open_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("open_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:effectFadeBlack(nil, 2, 0, 0, function()
      -- 到这里就算通关了，设置通关标记
      self:imageOn("1")
      self:sayI18n("open_5")
    end)

    return
  end

  if progress == self:nextProgressIndex() then
    -- 黑屏动画
    self:effectFadeBlack(nil, 1.5, 0, 0, function()
      userdata.setEpisodePassed(self.episodeName)

      -- 最后禁用水壶
      self:voidItem("kettle")
      -- TODO 设置通关时间

      -- TODO 进入通关字幕CreditScene
      cc.Director:getInstance():replaceScene(BaseScene.create("CreditScene"))

      -- 保留黑屏状态
      return true
    end)

    return
  end
end

return E4Ending
