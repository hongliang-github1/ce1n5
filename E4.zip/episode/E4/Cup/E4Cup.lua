local E4Cup = class("E4Cup", function()
  return BasePlace.new()
end)

function E4Cup:initPhoto()
  self:addPhoto("0", 0, 0)
  self:addPhoto("1", 896, 192)
  self:addPhoto("2", 896, 64)
  self:addPhoto("3", 1408, 320)
end

function E4Cup:initButton()
  self:addButton("clickTea", 380, 162, 554, 374)
  self:addButton("clickAsh", 382, 540, 554, 388)
  self:addButton("clickCup", 1196, 0, 750, 938)
end

function E4Cup:arrowRight(rect)
  self:switchPlaceZoomOut("Kettle")
end

function E4Cup:beforeLoad()
  self:imageOn("0")
end

function E4Cup:afterLoad()
  self.click = 0
end

function E4Cup:afterLoad2()
  self:cacheImage("Kettle/0")
  self:cacheImage("1")
  self:cacheImage("2")
end

function E4Cup:beforeUseItem(itemName)
  return false
end

function E4Cup:afterUseItem(itemName)
  return true
end

function E4Cup:clickTea(rect)
  self:sayI18n("clickTea_1")
end

function E4Cup:clickAsh(rect)
  self:sayI18n("clickAsh_1")
end

function E4Cup:clickCup(rect)
  if self.click > 4 then
    self.click = 0
  end

  if self.click == 0 then
    self:imageOn("1")
    self:sayI18n("clickCup_1")

  elseif self.click == 1 then
    if self:getInteger("bulb") ~= 0 then
      -- 道具已经拿过了，里面是空的
      self:imageOn("2")
      self:sayI18n("clickCup_2")

    else
      -- 道具还没拿过，里面有东西
      self:imageOn("2")
      self:imageOn("3")
      self:sayI18n("clickCup_3")
    end

  elseif self.click == 2 then
    if self:getInteger("bulb") ~= 0 then
      -- 道具已取得
      self:imageOff("3")
      self:sayI18n("clickCup_4")

    else
      -- 道具还没取得，得到道具，改变图片状态
      self:imageOff("3")
      self:getItem("bulb")
      self:sayI18n("clickCup_5")
    end

  elseif self.click == 3 then
      self:imageOff("2")
      self:sayI18n("clickCup_6")

  elseif self.click == 4 then
      self:imageOff("1")
      self:sayI18n("clickCup_7")
  end

  self.click = self.click + 1
end

return E4Cup
