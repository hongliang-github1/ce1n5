local E4BedStand = class("E4BedStand", function()
  return BasePlace.new()
end)

function E4BedStand:initPhoto()
  self:addPhoto("1", 1152, 512)
end

function E4BedStand:initButton()
  self:addButton("openCurtain", 0, 0, 782, 1148)
  self:addButton("goTelephone", 1038, 302, 684, 390)
  self:addButton("goLeftStand", 1038, 694, 536, 454, false)
end

function E4BedStand:arrowLeft(rect)
  self:switchPlaceLeft("DoorRight")
end

function E4BedStand:arrowRight(rect)
  self:switchPlaceRight("Bed")
end

function E4BedStand:beforeLoad()
  self:imageOn("0")

  -- 如果电话装好了，则显示电话
  if self:getInteger("speak") < 0 or self:getInteger("speak") == 2 then
    self:imageOn("1")
  end
end

function E4BedStand:afterLoad()

end

function E4BedStand:afterLoad2()
  self:cacheImage("DoorRight/0")
  self:cacheImage("Bed/0")

  if self:getInteger("wire") < 0 then
    self:cacheImage("Telephone/0")

  else
    self:cacheImage("Telephone/16")
  end
end

function E4BedStand:beforeUseItem(itemName)
  return false
end

function E4BedStand:afterUseItem(itemName)
  return true
end

function E4BedStand:openCurtain(rect)
  self:sayI18n("openCurtain_1")
end

function E4BedStand:goTelephone(rect)
  self:switchPlaceZoomIn("Telephone", rect)
end

function E4BedStand:goLeftStand(rect)
  self:switchPlaceZoomIn("Telephone", cc.rect(1038, 302, 684, 390))
end

return E4BedStand
