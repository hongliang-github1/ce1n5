local E4StandRight = class("E4StandRight", function()
  return BasePlace.new()
end)

function E4StandRight:initPhoto()
end

function E4StandRight:initButton()
  self:addButton("saySomeDrinks", 602, 220, 992, 786)
end

function E4StandRight:arrowLeft(rect)
  self:switchPlaceZoomOut("Bed")
end

function E4StandRight:arrowDown(rect)
  self:switchPlaceDown("StandRightDown")
end

function E4StandRight:beforeLoad()
  self:imageOn("0")
end

function E4StandRight:afterLoad()

end

function E4StandRight:afterLoad2()
  self:cacheImage("Bed/0")
  self:cacheImage("StandRightDown/0")

  if self:getInteger("dryer") ~= 0 then
    self:cacheImage("StandRightDown/2")

  else
    self:cacheImage("StandRightDown/1")
  end
end

function E4StandRight:beforeUseItem(itemName)
  return false
end

function E4StandRight:afterUseItem(itemName)
  return true
end

function E4StandRight:saySomeDrinks(rect)
  self:sayI18n("saySomeDrinks_1")
end

return E4StandRight
