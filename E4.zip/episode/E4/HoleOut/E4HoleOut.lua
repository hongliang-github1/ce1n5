local E4HoleOut = class("E4HoleOut", function()
  return BasePlace.new()
end)

function E4HoleOut:initPhoto()
end

function E4HoleOut:initButton()
end

function E4HoleOut:arrowDown(rect)
  self:switchPlaceZoomOut("Hole")
end

function E4HoleOut:beforeLoad()
  self:imageOn("0")
end

function E4HoleOut:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E4HoleOut:afterLoad2()
  self:cacheImage("Hole/0")
end

function E4HoleOut:beforeUseItem(itemName)
  return false
end

function E4HoleOut:afterUseItem(itemName)
  return true
end

return E4HoleOut
