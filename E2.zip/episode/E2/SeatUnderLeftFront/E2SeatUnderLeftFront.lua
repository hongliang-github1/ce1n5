local E2SeatUnderLeftFront = class("E2SeatUnderLeftFront", function()
  return BasePlace.new()
end)

function E2SeatUnderLeftFront:initPhoto()
  self:addPhoto("1", 512, 512)
end

function E2SeatUnderLeftFront:initButton()
  self:addButton("key", 0, 0, 1090, 1148)
end

function E2SeatUnderLeftFront:arrowDown(rect)
  self:switchPlaceZoomOut("SeatLeftFront")
end

function E2SeatUnderLeftFront:beforeLoad()
  self:imageOn("0")

  -- 判断要是拿了没有，如果没有，显示出来
  if self:getInteger("key2") == 0 then
    self:imageOn("1")
  end
end

function E2SeatUnderLeftFront:afterLoad()

end

function E2SeatUnderLeftFront:afterLoad2()
  self:cacheImage("SeatLeftFront/0")
end

function E2SeatUnderLeftFront:beforeUseItem(itemName)
  return false
end

function E2SeatUnderLeftFront:afterUseItem(itemName)
  return true
end

function E2SeatUnderLeftFront:key(rect)
  if self:getInteger("key2") ~= 0 then
    -- 已经拿到钥匙的遥控部分了
    self:sayI18n("key_1")

  else
    -- 获得道具
    self:imageOff("1")
    self:getItem("key2")
    self:sayI18n("key_2")
  end
end

return E2SeatUnderLeftFront
