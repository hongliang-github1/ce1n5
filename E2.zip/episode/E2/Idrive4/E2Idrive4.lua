local E2Idrive0 = require_safe("episode/E2/Idrive0/E2Idrive0")

local E2Idrive4 = class("E2Idrive4", function()
  return E2Idrive0.new()
end)

function E2Idrive4:initPhoto()
  self:addPhoto("mapcircle", 878, 422)
  self:addPhoto("mapneedle", 46, 518)
end

function E2Idrive4:beforeLoad()
  self:imageOn("map0")
  self:sayI18n("afterLoad_1")

  self.roundImage  = self:imageOn("mapcircle", 439*2, 211*2)
  self.pin1Image   = self:imageOn("mapneedle", -85, self:getContentSize().height - 440)

  -- 构造圆心和指针，clipLayout是为了让指针在旋转时不伸到iDrive屏幕范围外
  local clipLayout = ccui.Layout:create()
  
  clipLayout:setAnchorPoint(0, 0)
  clipLayout:setPosition(64*2, self:getContentSize().height - 960)
  clipLayout:setContentSize(1792, 768)
  clipLayout:setClippingEnabled(true)

  self.pin1Image:removeFromParent()
  clipLayout:addChild(self.pin1Image)
  self:addChild(clipLayout)

  self.pos = 0
end

function E2Idrive4:afterLoad()
  local rotateAction1 = cc.RotateBy:create(8, 360)
  local rotateAction2 = cc.RotateBy:create(4, 360)
  local repeatAction1 = cc.RepeatForever:create(rotateAction1)
  local repeatAction2 = cc.RepeatForever:create(rotateAction2)

  self.roundImage:runAction(repeatAction1)
  self.pin1Image:runAction(repeatAction2)
end

function E2Idrive4:up(rect)
  self:say("...")
end

function E2Idrive4:down(rect)
  self:say("...")
end

function E2Idrive4:left(rect)
  self:setInteger("last_idrive_pos", 4)
  self:switchPlace("Idrive")
end

function E2Idrive4:right(rect)
  self:say("...")
end

return E2Idrive4
