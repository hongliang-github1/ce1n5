local E2Idrive0 = require_safe("episode/E2/Idrive0/E2Idrive0")

local E2Idrive5 = class("E2Idrive5", function()
  return E2Idrive0.new()
end)

function E2Idrive5:initPhoto()
  self:addPhoto("servicesicon2", 1024, 576)
  self:addPhoto("servicesicon", 64, 192)
end

function E2Idrive5:beforeLoad()
  self:imageOn("Idrive/d10")  
  self:addMenuText()
  
  if not self.fromPlaceName or self.fromPlaceName == "Idrive" then
    self.pos = 1
    
  else
    self.pos = self:getInteger("last_idrive_pos")
  end

  self:imageOn("servicesicon")
  self:imageOn("servicesicon2")
end

function E2Idrive5:afterLoad()
  -- 如果是从GloveBox来的，则炸弹解除
  if self.fromPlaceName == "GloveBox" then
    self:imageOff("Idrive/control" .. "_" .. 752*2 .. "_" .. 368*2)
    self:hideArrowButton()
    self:disableAlwaysUseItem()
    self:disableTouch()

    self.rightLabel1:runAction(cc.Sequence:create(cc.FadeOut:create(1), cc.CallFunc:create(function()
      self:play("item")

      self.rightLabel2:runAction(cc.Sequence:create(cc.FadeIn:create(1), cc.CallFunc:create(function()
        self:enableTouch()
        self:sayI18n("right_2")
        
        self.goEnding = true
      end)))
    end)))
  end

  self:sayI18n("bomb")
end

function E2Idrive5:onTouchBegan(touch, event)
  if self.goEnding then
    self:switchPlace("Ending")
  end
end

function E2Idrive5:up(rect)
  if self.goEnding then
    self:switchPlace("Ending")

  else
    self:sayI18n("bomb")
  end
end

function E2Idrive5:down(rect)
  if self.goEnding then
    self:switchPlace("Ending")

  else
    self:sayI18n("bomb")
  end
end

function E2Idrive5:left(rect)
  if self.goEnding then
    self:switchPlace("Ending")

  else
    self:setInteger("last_idrive_pos", 5)
    self:switchPlace("Idrive")
  end
end

function E2Idrive5:right(rect)
  if self.goEnding then
    self:switchPlace("Ending")

  else
    self:sayI18n("bomb")
  end
end

function E2Idrive5:addMenuText()
  local fontSize = 55

  -- 菜单栏下面的选项
  local x  = 332
  local rx = 1280
  local w  = 1000
  local h  = 60 * 2

  self:createIdriveLabel("BMW 服务", "BMW Services", fontSize, 212, 120*2+110, w, h)
  -- self.leftLabel = self:createIdriveLabel("解除炸弹", "Destination search", fontSize, x, 168*2+115, w, h)
  
  -- 右边菜单
  self:createIdriveLabel("服务状态", "Service status", fontSize, 1162, 123*2+100, 400*2, h, true)
  self.rightLabel1 = self:createIdriveLabel("炸弹已激活", "Bomb actived", fontSize, rx, 338+110, w, h, true)
  self.rightLabel2 = self:createIdriveLabel("炸弹已解除", "Bomb deactived", fontSize, rx-1, 338+110, w, h, true)
  self.rightLabel2:setPositionX(self.rightLabel2:getPositionX() + 1)

  self.rightLabel1:setColor(cc.c3b(255, 0, 0))
  self.rightLabel2:setColor(cc.c3b(0, 255, 0))

  if self.goEnding then
    self.rightLabel1:setOpacity(0)

  else
    self.rightLabel2:setOpacity(0)
  end
end

return E2Idrive5
