local E2Credit = class("E2Credit", function()
  return BaseCredit.new()
end)

function E2Credit:afterCreate()
  -- 构造滚动字幕
  self:addLabelI18n(1.1, "beforeLoad_1")

  -- TODO 显示通关时间
  -- NSString *timingString  = [self timingString]
  -- NSString *labelStr    = UikitEnhancement:textByI18nDict("beforeLoad_2")

  -- self:addLabelI18n(1, [labelStr stringByAppendingFormat:"%@", timingString)]

  self:addLabelI18n(1, "beforeLoad_3")

  self:addBlank()

  self:addLabelI18n(1, "beforeLoad_4")

  self:addImage("bmw")

  self:addBlank()

  self:addLabelI18n(1, "beforeLoad_5")

  self:addLabelI18n(1, "beforeLoad_6")

  self:addLabelI18n(1, "beforeLoad_7")

  self:addLabelI18n(1, "beforeLoad_8")

  self:addLabelI18n(1, "beforeLoad_9")

  self:addLabelI18n(1, "beforeLoad_10")

  self:addLabelI18n(1, "beforeLoad_11")

  self:addLabelI18n(1, "beforeLoad_12")

  self:addLabelI18n(1, "beforeLoad_13")

  self:addLabelI18n(1, "beforeLoad_14")

  self:addLabelI18n(1, "beforeLoad_15")

  self:addLabelI18n(1, "beforeLoad_16")

  self:addLabelI18n(1, "beforeLoad_17")

  self:addLabelI18n(1, "beforeLoad_18")

  self:addLabelI18n(1, "beforeLoad_19")

  self:addLabelI18n(1, "beforeLoad_20")

  self:addLabelI18n(1, "beforeLoad_21")

  self:addLabelI18n(1, "beforeLoad_22")

  self:addBlank()

  self:playMusic("credit")
end

return E2Credit
