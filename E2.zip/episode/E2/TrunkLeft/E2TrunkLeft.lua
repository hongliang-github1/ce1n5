local E2TrunkLeft = class("E2TrunkLeft", function()
  return BasePlace.new()
end)

function E2TrunkLeft:initPhoto()
  self:addPhoto("1", 704, 192)
end

function E2TrunkLeft:initButton()
  self:addButton("open", 0, 0, 2048, 1152, false)
end

function E2TrunkLeft:arrowDown(rect)
  self:switchPlaceZoomOut("OutRear")
end

function E2TrunkLeft:beforeLoad()
  self:imageOn("0")
end

function E2TrunkLeft:afterLoad()

end

function E2TrunkLeft:afterLoad2()
  self:cacheImage("OutRear/0")
end

function E2TrunkLeft:beforeUseItem(itemName)
  return false
end

function E2TrunkLeft:afterUseItem(itemName)
  return true
end

function E2TrunkLeft:open(rect)
  self:sayI18n("click_1")
end

return E2TrunkLeft
