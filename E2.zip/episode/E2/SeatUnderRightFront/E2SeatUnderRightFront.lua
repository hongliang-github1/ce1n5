local E2SeatUnderRightFront = class("E2SeatUnderRightFront", function()
  return BasePlace.new()
end)

function E2SeatUnderRightFront:initPhoto()
end

function E2SeatUnderRightFront:initButton()
  self:addButton("under", 0, 0, 2044, 1148)
end

function E2SeatUnderRightFront:arrowDown(rect)
  self:switchPlaceZoomOut("SeatRightFront")
end

function E2SeatUnderRightFront:beforeLoad()
  self:imageOn("0")
end

function E2SeatUnderRightFront:afterLoad()
  self:cacheImage("SeatRightFront/0")
end

function E2SeatUnderRightFront:afterLoad2()

end

function E2SeatUnderRightFront:beforeUseItem(itemName)
  return false
end

function E2SeatUnderRightFront:afterUseItem(itemName)
  return true
end

function E2SeatUnderRightFront:under(rect)
  self:sayI18n("under_1")
end

return E2SeatUnderRightFront
