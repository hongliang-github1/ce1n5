local E2TrunkMiddle = class("E2TrunkMiddle", function()
  return BasePlace.new()
end)

function E2TrunkMiddle:initPhoto()
  self:addPhoto("1", 0, 0)
  self:addPhoto("2", 960, 704)
end

function E2TrunkMiddle:initButton()
  self:addButton("openTrunk", 392, 246, 1436, 902)
end

function E2TrunkMiddle:arrowDown(rect)
  self:switchPlaceZoomOut("OutRear")
end

function E2TrunkMiddle:beforeLoad()
  self:imageOn("0")
end

function E2TrunkMiddle:afterLoad()
  self:sayI18n("beforeLoad_1")
end

function E2TrunkMiddle:afterLoad2()
  self:cacheImage("OutRear/0")
end

function E2TrunkMiddle:beforeUseItem(itemName)
  return false
end

function E2TrunkMiddle:afterUseItem(itemName)
  return true
end

function E2TrunkMiddle:openTrunk(rect)
  local flash = self:getInteger("flash1")

  if self:imageIsOn("1") then
    -- 已经打开盖板，根据道具状态决定是拿道具还是合上盖板
    if flash ~= 0 then
      self:imageOn("0")
      self:play("light")
      self:sayI18n("openTrunk_1")

    else
      -- 获得道具
      self:imageOff("2")
      self:getItem("flash1")
      self:sayI18n("openTrunk_2")
    end

  else
    -- 打开盖板
    self:imageOn("1")
    self:play("light")

    if flash ~= 0 then
      self:sayI18n("openTrunk_3")

    else
      self:imageOn("2")
      self:sayI18n("openTrunk_4")
    end
  end
end

return E2TrunkMiddle
