local E2Ending = class("E2Ending", function()
  return BasePlace.new()
end)

function E2Ending:initPhoto()
end

function E2Ending:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E2Ending:beforeLoad()
  if self:getInteger("key") < 0 then
    self:imageOn("OutLeftFront/1")
  else
    self:imageOn("OutLeftFront/0")
  end
end

function E2Ending:afterLoad()
  self:click(nil)
end

function E2Ending:beforeUseItem(itemName)
  return false
end

function E2Ending:afterUseItem(itemName)
  return true
end

function E2Ending:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_6")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("police1")
    self:sayI18n("click_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_8")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("police2")
    self:sayI18n("click_9")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_10")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_11")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_12")

    return
  end


  if progress == self:nextProgressIndex() then
    self:sayI18n("click_13")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_14")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 黑屏动画
    self:effectFadeBlack(nil, 1.5, 0, 0, function()
      -- 到这里就算通关了，设置通关标记
      self:voidItem("flash")
      self:voidItem("udisk")
      userdata.setEpisodePassed(self.episodeName)

      -- TODO 设置通关时间

      -- TODO 进入通关字幕CreditScene
      cc.Director:getInstance():replaceScene(BaseScene.create("CreditScene"))

      -- 保留黑屏状态
      return true
    end)

    return
  end
end

return E2Ending
