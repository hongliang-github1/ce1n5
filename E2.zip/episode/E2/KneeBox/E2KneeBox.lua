local E2KneeBox = class("E2KneeBox", function()
  return BasePlace.new()
end)

function E2KneeBox:initPhoto()
  self:addPhoto("2", 1280, 448)
end

function E2KneeBox:initButton()
  self:addButton("openKnee", 426, 0, 1618, 1148)
end

function E2KneeBox:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E2KneeBox:beforeLoad()
  self:imageOn("0")
end

function E2KneeBox:afterLoad()

end

function E2KneeBox:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("2")

  if self:getInteger("key") < 0 then
    self:cacheImage("Drive/2")
  
  else
    self:cacheImage("Drive/0")
  end
end

function E2KneeBox:beforeUseItem(itemName)
  return false
end

function E2KneeBox:afterUseItem(itemName)
  return true
end

function E2KneeBox:openKnee(rect)
  local v = self:getInteger("flash2")

  if self:imageIsOn("1") then
    -- 已经打开了，根据道具状态决定是取得道具还是合上盖板
    if v ~= 0 then
      -- 道具已经取得，合上盖板即可
      self:imageOn("0")
      self:sayI18n("openKnee_1")
      self:play("arm")

    else
      -- 还没拿到道具，获得道具
      self:imageOff("2")
      self:getItem("flash2")
      self:sayI18n("openKnee_2")
    end

  else
    -- 还没打开，现在打开
    self:play("arm")
    self:imageOn("1")

    if v ~= 0 then
      self:sayI18n("openKnee_3")

    else
      self:imageOn("2")
      self:sayI18n("openKnee_4")
    end
  end
end

return E2KneeBox
