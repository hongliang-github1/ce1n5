local E2Idrive0 = require_safe("episode/E2/Idrive0/E2Idrive0")

local E2Idrive7door = class("E2Idrive7door", function()
  return E2Idrive0.new()
end)

function E2Idrive7door:initPhoto()
  self:addPhoto("setting12", 192, 192)
  self:addPhoto("settingen12", 192, 192)
  self:addPhoto("settingicon3", 576, 192)
  self:addPhoto("settingicon4", 64, 576)
end

function E2Idrive7door:beforeLoad()
  self:imageOn("Idrive/d20")
  self:imageOn("settingicon3")
  self:imageOn("settingicon4")
  self:addMenuText()
  
  if not self.fromPlaceName or self.fromPlaceName == "Idrive7" then
    self.pos = 1
    
  else
    self.pos = self:getInteger("last_idrive_pos")
  end

  if i18n.getLang() == "chs" then
    self:imageOn("setting12")

  else
    self:imageOn("settingen12")
  end

  self:imageOn("Idrive/select2", 256, 852 + 336)
  self:updateMenuK()

  if self:getInteger("isAllDoorUnlock") > 0 and self.fromPlaceName == "Idrive7door" then
    self:sayI18n("beforeLoad_1")
  end
end

function E2Idrive7door:up(rect)
  if self.pos <= 1 then
    return
  end
  
  self.pos = self.pos - 1
  
  self:updateMenuK()
end

function E2Idrive7door:down(rect)
  if self.pos >= 5 then
    return
  end
  
  self.pos = self.pos + 1
  
  self:updateMenuK()
end

function E2Idrive7door:left(rect)
  self:setInteger("last_idrive_pos", 7)
  self:switchPlace("Idrive7")
end

function E2Idrive7door:right(rect)
  if self.pos == 1 then
    self:switchPlace("Idrive7doorset")

  else
    self:say("...")
  end
end

function E2Idrive7door:addMenuText()
  local fontSize = 55

  -- 菜单栏下面的选项
  local rx = 752
  local w  = 1000
  local h  = 60 * 2

  self:createIdriveLabel("车门锁", "Door locks", fontSize, 704, 244+100, 400*2, h)
  self:createIdriveLabel("开锁:", "Lock button:", fontSize, rx, 338+110, w, h)
  self:createIdriveLabel("座椅自动调整为上次位置", "Last seat position automatically", fontSize, rx, 424+110, w, h)
  self:createIdriveLabel("自动重锁", "Relock if no door opened", fontSize, rx, 510+110, w, h)
  self:createIdriveLabel("行车后联锁", "Lock after drive away", fontSize, rx, 596+110, w, h)
  self:createIdriveLabel("上锁/解锁时的闪烁信号", "Visual signal for locking/unlocking", fontSize, rx, 682+110, w, h)

  if self:getInteger("isAllDoorUnlock") > 0 then
    self:createIdriveLabel("所有车门", "All doors", fontSize, 660*2, 338+110, w, h)
  
  else
    self:createIdriveLabel("仅驾驶员侧车门", "Driver's door only", fontSize, 660*2, 338+110, w, h)
  end
end


function E2Idrive7door:updateMenuK()
  -- 通过上一次的点，计算出每隔一段时间，重绘一次线的位置
  -- 得到目标的位置
  -- 框体的宽度和高度
  local kwidth  = 1080
  local kheight = 80
  
  -- 框体的坐标
  local kx = 732
  local ky = 0
  
  -- 框的起始支点
  local startkx = 0
  local startky = 0
  
  if self.pos == 1 then
    ky          = 326
    startkx     = 646
    startky     = 548
    self.arc    = 12 * 2
          
  elseif self.pos == 2 then
    ky          = 412
    startkx     = 658
    startky     = 556
    self.arc    = 14 * 2

  elseif self.pos == 3 then
    ky          = 500
    startkx     = 680
    startky     = 572
    self.arc    = 24 * 2

  elseif self.pos == 4 then
    ky          = 584
    startkx     = 698
    startky     = 628
    self.arc    = 0 * 2
          
  elseif self.pos == 5 then
    ky          = 672
    startkx     = 676
    startky     = 680
    self.arc    = 24 * 2
          
  elseif self.pos == 6 then
    ky          = 760
    startkx     = 656
    startky     = 696
    self.arc    = 16 * 2
          
  elseif self.pos == 7 then
    ky          = 848
    startkx     = 642
    startky     = 704
    self.arc    = 14 * 2
  end
  
  local distance  = 10
  self.kSize      = cc.size(kwidth, kheight)
  self.kPoint     = cc.p(kx, ky)
  self.startPoint = cc.p(startkx, startky)
  
  if self.pos == 4 then
    self.endPoint = cc.p(self.kPoint.x, self.kPoint.y + (self.kSize.height / 2))
    
  else
    self.endPoint = cc.p(self.kPoint.x - distance, self.kPoint.y + (self.kSize.height / 2))
  end

  self:redrawRedBox()
end

return E2Idrive7door
