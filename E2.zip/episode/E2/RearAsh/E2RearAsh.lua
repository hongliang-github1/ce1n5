local E2RearAsh = class("E2RearAsh", function()
  return BasePlace.new()
end)

function E2RearAsh:initPhoto()
  self:addPhoto("0", 0, 0)
  self:addPhoto("2", 448, 640)
  self:addPhoto("3", 704, 704)
  self:addPhoto("4", 448, 128)
  self:addPhoto("5", 1024, 192)
  self:addPhoto("left18", 576, 192)
  self:addPhoto("left28", 576, 192)
  self:addPhoto("left38", 576, 192)
  self:addPhoto("right18", 1088, 320)
  self:addPhoto("right28", 1088, 320)
  self:addPhoto("right38", 1088, 320)
end

function E2RearAsh:initButton()
  self:addButton("open", 224, 642, 1482, 506)
  self:addButton("power", 218, 114, 1486, 526)
end

function E2RearAsh:arrowRight(rect)
  self:switchPlaceZoomOut("OutRightRear")
end

function E2RearAsh:beforeLoad()
  self:imageOn("0")

  -- 默认左边的仪表已插入，如果拿过U盘，则什么都不用显示
  if self:getInteger("udisk") == 0 then
    self:imageOn("4")
  end
end

function E2RearAsh:afterLoad()
  -- 预加载图片
  if self:getInteger("udisk") == 0 and self:getInteger("meter") ~= 0 then
    self:imageTexture("left18")
    self:imageTexture("left28")
    self:imageTexture("left38")
    self:imageTexture("right18")
    self:imageTexture("right28")
    self:imageTexture("right38")
  end
end

function E2RearAsh:afterLoad2()
  self:cacheImage("2")
  self:cacheImage("OutRightRear/0")
end

function E2RearAsh:beforeUseItem(itemName)
  if itemName == "meter" then
    return self:imageIsOn("4") and not self:imageIsOn("5") and self:getInteger("udisk") == 0
  end

  return false
end

function E2RearAsh:afterUseItem(itemName)
  if itemName == "meter" then
    -- 两个仪表都插上了，进入拿U盘道具剧情模式
    self:imageOn("5")
    self:say("")

    self.readyOpen = 0

    return true
  end

  return true
end

function E2RearAsh:open(rect)
  if self.readyOpen == 0 then
    -- 刚刚插入12V仪表，开始闪烁动画
    self:blink()

    return
  end

  if self:imageIsOn("2") then
    -- 烟灰盒已经打开，根据U盘道具状态决定是获得道具还是关上烟灰盒
    if self:imageIsOn("3") then
      -- 获得道具
      self:imageOff("3")
      self:voidItem("meter")
      self:getItem("udisk")
      self:sayI18n("open_2")

    else
      self:imageOff("2")
      self:play("rearash")
      self:sayI18n("open_1")
    end

  else
    if self:getInteger("udisk") == 0 then
      -- 还没得到过U盘，烟灰盒打不开，必须通过使用12V仪表才能打开
      self:sayI18n("can_not_open")

    else
      -- 已经得到U盘了，可以打开烟灰盒
      self:imageOn("2")
      self:sayI18n("open_3")
      self:play("rearash")
    end
  end
end

function E2RearAsh:power(rect)
  if self.readyOpen == 0 then
    -- 刚刚插入12V仪表，开始闪烁动画
    self:blink()

    return
  end

  if self:imageIsOn("4") and not self:imageIsOn("5") then
    self:sayI18n("meter_mean")

    return
  end
end

function E2RearAsh:blink()
  self:disableTouch()
  self:play("warning")
  
  self.openAction = self:schedule(0.1, function()
    self.readyOpen = self.readyOpen + 1

    -- 0-0.8秒内是闪烁，0.8-1.3秒内是空置延时，1.3秒后打开盒子
    if self.readyOpen <= 8 then
      if self:imageIsOn("left18") then
        self:imageOff("left18")
        self:imageOff("left28")
        self:imageOff("left38")
        self:imageOff("right18")
        self:imageOff("right28")
        self:imageOff("right38")

      else
        self:imageOn("left18")
        self:imageOn("left28")
        self:imageOn("left38")
        self:imageOn("right18")
        self:imageOn("right28")
        self:imageOn("right38")
      end

    elseif self.readyOpen > 13 then
      -- 可以打开盒子了
      self:unschedule(self.openAction)
      self:enableTouch()
      self:imageOff("4")
      self:imageOff("5")
      self:imageOff("left18")
      self:imageOff("left28")
      self:imageOff("left38")
      self:imageOff("right18")
      self:imageOff("right28")
      self:imageOff("right38")
      self:imageOn("2")
      self:imageOn("3")
      self:play("rearash")

      self.openAction = nil
    end
  end)
end

return E2RearAsh
