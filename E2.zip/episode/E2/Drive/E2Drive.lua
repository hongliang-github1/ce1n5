local E2Drive = class("E2Drive", function()
  return BasePlace.new()
end)

function E2Drive:initPhoto()
end

function E2Drive:initButton()
  self:addButton("openDoor", 0, 506, 406, 478)
  self:addButton("goKneeBox", 412, 528, 404, 516)
  self:addButton("goDashboard", 750, 132, 508, 396)
  self:addButton("goKey", 960, 532, 342, 358)
  self:addButton("goPanel", 1306, 534, 464, 410)
  self:addButton("goIdrive", 1262, 218, 508, 310)
  self:addButton("goGloveBox", 1776, 534, 268, 618)
end

function E2Drive:arrowDown(rect)
  self:switchPlaceZoomOut("RearSeeFront")
end

function E2Drive:beforeLoad()
  if self:getInteger("key") < 0 then
    self:imageOn("2")
  else
    self:imageOn("0")
  end
end

function E2Drive:afterLoad()
end

function E2Drive:afterLoad2()
  -- if self:getInteger("key") < 0 then
  --   self:cacheImage("Dashboard/1")
  
  -- else
  --   self:cacheImage("Dashboard/0")
  -- end

  -- self:cacheImage("KneeBox/0")
  -- self:cacheImage("Keyhole/0")
  self:cacheImage("Panel/0")
  self:cacheImage("Idrive/0")
  -- self:cacheImage("GloveBox/0")
end

function E2Drive:beforeUseItem(itemName)
  return false
end

function E2Drive:afterUseItem(itemName)
  return true
end

function E2Drive:openDoor(rect)
  if self:getInteger("driverDoorOpen") > 0 then
    -- 可以开驾驶员侧车门，询问是否逃跑
    self:play("open")
    self:switchPlace("AskRun")

  else
    self:play("number")
    self:sayI18n("openDoor_1")
  end
end

function E2Drive:goKneeBox(rect)
  self:switchPlaceZoomIn("KneeBox", rect)
end

function E2Drive:goDashboard(rect)
  self:switchPlaceZoomIn("Dashboard", rect)
end

function E2Drive:goKey(rect)
  self:switchPlaceZoomIn("Keyhole", rect)
end

function E2Drive:goPanel(rect)
  self:switchPlaceZoomIn("Panel", rect)
end

function E2Drive:goIdrive(rect)
  -- 进入iDrive视角，车钥匙插入后才能进
  if self:getInteger("key") < 0 then
    self:switchPlaceZoomIn("Idrive", rect)

  else
    self:sayI18n("goIdrive_1")
  end
end

function E2Drive:goGloveBox(rect)
  self:switchPlaceZoomIn("GloveBox", cc.rect(1776, 634, 268, 268))
end

return E2Drive
