local E2OutRear = class("E2OutRear", function()
  return BasePlace.new()
end)

function E2OutRear:initPhoto()
end

function E2OutRear:initButton()
  self:addButton("trunkPlate", 520, 0, 972, 410, false)
  self:addButton("trunkLeft", 338, 416, 410, 360, false)
  self:addButton("trunkRight", 1286, 416, 392, 354, false)
  self:addButton("open", 754, 416, 524, 466)
end

function E2OutRear:arrowLeft(rect)
  self:switchPlaceLeft("OutLeftRear")
end

function E2OutRear:arrowRight(rect)
  self:switchPlaceRight("OutRightRear")
end

function E2OutRear:beforeLoad()
  self:imageOn("0")

  -- 判断如果是从里面退出来的，就打开后备厢
  if self.lastPlaceName == "TrunkLeft" or self.lastPlaceName == "TrunkRight" or self.lastPlaceName == "TrunkMiddle" then
    self:imageOn("1")
  end
end

function E2OutRear:afterLoad()
  if self.lastPlaceName == "OutLeftRear" or self.lastPlaceName == "OutRightRear" then
    self:sayI18n("afterLoad_1")
  end
end

function E2OutRear:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("TrunkLeft/0")
  self:cacheImage("TrunkRight/0")
  self:cacheImage("TrunkMiddle/0")
end

function E2OutRear:beforeUseItem(itemName)
  return false
end

function E2OutRear:afterUseItem(itemName)
  return true
end

function E2OutRear:trunkPlate(rect)
  -- 关着的情况下
  if self:imageIsOn("0") then
    return
  end

  self:imageOn("0")
  self:sayI18n("trunkPlate_1")

  self:play("close")
end

function E2OutRear:trunkLeft(rect)
  if not self:imageIsOn("1") then
    return
  end

  self:switchPlaceZoomIn("TrunkLeft", rect)
end

function E2OutRear:trunkRight(rect)
  if not self:imageIsOn("1") then
    return
  end

  self:switchPlaceZoomIn("TrunkRight", rect)
end

function E2OutRear:open(rect)
  if self:imageIsOn("1") then
    -- 后备厢已经打开了，进入后备厢TrunkMiddle视角
    self:switchPlaceZoomIn("TrunkMiddle", rect)

    return
  end

  if self:getInteger("isAllDoorUnlock") > 0 then
    -- 打开后备厢
    self:imageOn("1")
    self:play("open")
    self:sayI18n("open_1")

  else
    self:sayI18n("open_2")
  end
end

return E2OutRear
