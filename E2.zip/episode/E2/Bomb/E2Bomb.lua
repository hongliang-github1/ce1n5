local E2Bomb = class("E2Bomb", function()
  return BasePlace.new()
end)

function E2Bomb:initPhoto()
end

function E2Bomb:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E2Bomb:beforeLoad()
  self.flickerCount = 0

  -- 先显示车头，默认亮起灯，这样动画时看起来比较正常
  self:imageOn("OutFront/0")
  self:imageTexture("OutFront/1")
end

function E2Bomb:afterLoad()
  self.progress = 0

  -- 暂停背景音乐，显示车头动画，灯闪动几下再爆炸
  self:pauseMusic()

  self.flickerAction = self:schedule(0.12, function()
    self.flickerCount = self.flickerCount + 1

    if self.flickerCount == 1 then
      -- 加声音，预加载爆炸图
      self:disableTouch()
      self:play("warning")
      self:imageTexture("0")
    end

    if self:imageIsOn("OutFront/1_320_320") then
      self:imageOff("OutFront/1_320_320")

    else
      self:imageOn("OutFront/1", 320, 320)
    end

    if self.flickerCount > 8 then
      -- 停止闪烁，开始爆炸
      self:unschedule(self.flickerAction)
      self:enableTouch()
      self:imageOff("OutFront/0")
      self:imageOff("OutFront/1_320_320")
      self:bomb()

      self.flickerAction = nil

      return
    end
  end)
end

function E2Bomb:bomb()
  -- 爆炸
  self:imageOn("0")
  self:stopAllEffects()
  self:play("explode")

  if self.lastPlaceName == "Keyhole" then
    self:sayI18n("bomb_1")

  else
    self:sayI18n("bomb_3")
  end
end

function E2Bomb:recordLastPlaceName()
  return false
end

function E2Bomb:beforeUseItem(itemName)
  return false
end

function E2Bomb:afterUseItem(itemName)
  return true
end

function E2Bomb:click(rect)
  local lastPlaceName = self.lastPlaceName
  self.progress       = self.progress + 1
  
  if self.progress == 1 then
    self:sayI18n("touchesBegan_1")

    return
  end
  
  if self.progress == 2 then
    self:sayI18n("touchesBegan_3")

    return
  end
  
  if self.progress == 3 then
    self:sayI18n("touchesBegan_4")

    return
  end
  
  if self.progress == 4 then
    if lastPlaceName ~= "RearSeeLeft" then
      lastPlaceName = "Drive"
    end

    -- 恢复背景音乐，回到上一场景
    self:resumeMusic()
    self:switchPlace(lastPlaceName)

    return
  end
end

return E2Bomb
