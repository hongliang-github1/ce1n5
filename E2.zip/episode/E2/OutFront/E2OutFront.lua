local E2OutFront = class("E2OutFront", function()
  return BasePlace.new()
end)

function E2OutFront:initPhoto()
  self:addPhoto("1", 320, 320)
end

function E2OutFront:initButton()
  self:addButton("bumper", 296, 292, 1406, 724, false)
end

function E2OutFront:arrowLeft(rect)
  self:switchPlaceLeft("OutRightFront")
end

function E2OutFront:arrowRight(rect)
  self:switchPlaceRight("OutLeftFront")
end

function E2OutFront:beforeLoad()
  self:imageOn("0")

  -- 检查车钥匙是否插入了，插入则开灯
  if self:getInteger("key") < 0 then
    self:imageOn("1")
  end
end

function E2OutFront:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E2OutFront:afterLoad2()
  self:cacheImage("OutRightFront/0")

  if self:getInteger("key") < 0 then
    self:cacheImage("OutLeftFront/1")
  else
    self:cacheImage("OutLeftFront/0")
  end
end

function E2OutFront:beforeUseItem(itemName)
  return false
end

function E2OutFront:afterUseItem(itemName)
  return true
end

function E2OutFront:bumper(rect)
end

return E2OutFront
