local E2Idrive0 = require_safe("episode/E2/Idrive0/E2Idrive0")

local E2Idrive = class("E2Idrive", function()
  return E2Idrive0.new()
end)

function E2Idrive:initPhoto()
  self:addPhoto("miconcd", 512, 512)
  self:addPhoto("miconmap", 512, 512)
  self:addPhoto("miconradio", 512, 512)
  self:addPhoto("miconservice", 512, 512)
  self:addPhoto("miconsetting", 512, 512)
  self:addPhoto("miconstatus", 512, 512)
  self:addPhoto("control", 1624, 736)
  -- self:addPhoto("3", 21*32*2, 5*32*2)
end

function E2Idrive:up(rect)
  if self.pos == 1 then
    return
  end
  
  self.pos = self.pos - 1
  
  self:updateMenuK()
end

function E2Idrive:down(rect)
  if self.pos >= 7 then
    return
  end
  
  self.pos = self.pos + 1

  self:updateMenuK()
end

function E2Idrive:left(rect)
  -- 主菜单左边按钮没用
end

function E2Idrive:right(rect)
  self:setInteger("last_idrive_pos", self.pos)
  self:switchPlace("Idrive" .. self.pos)
end

function E2Idrive:beforeLoad()
  self:imageOn("0")
end

function E2Idrive:afterLoad()
  self:addMenuText()
  
  local fromPlace = self.fromPlaceName

  if fromPlace ~= "Idrive1" and fromPlace ~= "Idrive2" and fromPlace ~= "Idrive3" and fromPlace ~= "Idrive4" and fromPlace ~= "Idrive5" and fromPlace ~= "Idrive6" and fromPlace ~= "Idrive7" then
    self.pos = 1

  else
    self.pos = self:getInteger("last_idrive_pos")

    if self.pos < 1 then
      self.pos = 1
    end
  end

  self:updateMenuK()
  self:sayI18n("afterLoad_1")
end

function E2Idrive:afterLoad2()
  self:cacheImage("Idrive/d10")
  self:cacheImage("Idrive/d20")
end

function E2Idrive:addMenuText()
  -- CD/多媒体
  -- 收音机    ce2_idrive_micon_radio
  -- 导航      ce2_idrive_micon_map
  -- 地图      ce2_idrive_micon_map
  -- BMW服务   ce2_idrive_micon_service
  -- 车辆信息   ce2_idrive_micon_status
  -- 设置      ce2_idrive_micon_setting

  local fontSize = 55

  self:createIdriveLabel("主菜单", "Main menu", fontSize, 348*2, 122*2+75, 600*2, 46*2)
  
  -- 菜单栏，下面的七个选项
  local x  = 433 * 2
  local w  = 600 * 2
  local h  = 70 * 2
  
  self:createIdriveLabel("CD/多媒体", "CD/Multimedia", fontSize, x, 162*2+135, w, h)
  self:createIdriveLabel("收音机", "Radio", fontSize, x, 200*2+143, w, h)
  self:createIdriveLabel("导航", "Navigation", fontSize, x, 238*2+140, w, h)
  self:createIdriveLabel("地图", "Map", fontSize, x, 276*2+140, w, h)
  self:createIdriveLabel("BMW服务", "BMW Service", fontSize, x, 312*2+144, w, h)
  self:createIdriveLabel("车辆信息", "Vehicle information", fontSize, x, 351*2+143, w, h)
  self:createIdriveLabel("设定", "Settings", fontSize, x, 390*2+138, w, h)
end

function E2Idrive:updateMenuK()
  -- 得到目标的位置
  -- 框体的宽度和高度
  local kwidth  = 560 * 2
  local kheight   = 38 * 2
  
  -- 框体的坐标
  local kx    = (374 + 20) * 2
  local ky    = 0
  
  -- 框的起始支点
  local startkx   = 0
  local startky   = 0
  
  if self.pos == 1 then
    ky       = (150 + 10) * 2
    startkx  = (316 + 20) * 2
    startky  = (248 + 15) * 2
    self.arc = 14 * 2
    
    -- 设置左边原点的图片
    self:imageOn("miconcd")
    self:imageOff("miconradio")
    self:imageOff("miconmap")
    self:imageOff("miconservice")
    self:imageOff("miconstatus")

  elseif self.pos == 2 then
    ky       = (186 + 12) * 2
    startkx  = (324 + 20) * 2
    startky  = (252 + 16) * 2
    self.arc = 17 * 2
    
    -- 设置左边原点的图片
    self:imageOff("miconcd")
    self:imageOn("miconradio")
    self:imageOff("miconmap")
    self:imageOff("miconservice")
    self:imageOff("miconstatus")
      
  elseif self.pos == 3 then
    ky       = (222 + 14) * 2
    startkx  = (332 + 20) * 2
    startky  = (262 + 17) * 2
    self.arc = 30 * 2
    
    -- 设置左边原点的图片
    self:imageOff("miconcd")
    self:imageOff("miconradio")
    self:imageOn("miconmap")
    self:imageOff("miconservice")
    self:imageOff("miconstatus")
      
  elseif self.pos == 4 then
    ky       = (256 + 18) * 2
    startkx  = (340 + 20) * 2
    startky  = (280 + 18) * 2
    self.arc = 0 * 2
    
    -- 设置左边原点的图片
    self:imageOff("miconcd")
    self:imageOff("miconradio")
    self:imageOn("miconmap")
    self:imageOff("miconservice")
    self:imageOff("miconstatus")
      
  elseif self.pos == 5 then
    ky       = (292 + 18) * 2
    startkx  = (340 + 20) * 2
    startky  = (304 + 19) * 2
    self.arc = 0 * 2
    
    -- 设置左边原点的图片
    self:imageOff("miconcd")
    self:imageOff("miconradio")
    self:imageOff("miconmap")
    self:imageOn("miconservice")
    self:imageOff("miconstatus")
      
  elseif self.pos == 6 then
    ky       = (326 + 22) * 2
    startkx  = (332 + 20) * 2
    startky  = (322 + 20) * 2
    self.arc = 25 * 2
    
    -- 设置左边原点的图片
    self:imageOff("miconcd")
    self:imageOff("miconradio")
    self:imageOff("miconmap")
    self:imageOff("miconservice")
    self:imageOn("miconstatus")
      
  elseif self.pos == 7 then
    ky       = (362 + 26) * 2
    startkx  = (324 + 20) * 2
    startky  = (330 + 21) * 2
    self.arc = 16 * 2
    
    -- 设置左边原点的图片
    self:imageOff("miconcd")
    self:imageOff("miconradio")
    self:imageOff("miconmap")
    self:imageOff("miconservice")
    self:imageOff("miconstatus")
  end
  
  -- 框的x到endPoint的距离
  local distance  = 10
  self.kSize      = cc.size(kwidth, kheight)
  self.kPoint     = cc.p(kx, ky)
  self.startPoint = cc.p(startkx, startky)
  
  if self.pos == 4 or self.pos == 5 then
    self.endPoint = cc.p(self.kPoint.x, self.kPoint.y + (self.kSize.height / 2))
    
  else
    self.endPoint = cc.p(self.kPoint.x - distance, self.kPoint.y + (self.kSize.height / 2))
  end
  
  self:redrawRedBox()
end

return E2Idrive
