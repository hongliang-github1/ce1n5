local E2Keyhole = class("E2Keyhole", function()
  return BasePlace.new()
end)

function E2Keyhole:initPhoto()
  self:addPhoto("1", 576, 640)
  self:addPhoto("2", 1664, 704)
  self:addPhoto("3", 1664, 832)
  self:addPhoto("4", 1664, 960)
end

function E2Keyhole:initButton()
  self:addButton("key", 496, 490, 740, 658)
  self:addButton("engine", 496, 0, 812, 484)
end

function E2Keyhole:arrowDown(rect)
   self:switchPlaceZoomOut("Drive")
end

function E2Keyhole:beforeLoad()
  self:imageOn("0")

  -- 检查钥匙是否插入了，如果插入了，就设置1显示
  if self:getInteger("key") < 0 then
    self:imageOn("1")
  end
end

function E2Keyhole:afterLoad()
end

function E2Keyhole:afterLoad()
  self:cacheImage("Bomb/0")
  self:cacheImage("OutFront/0")
  self:cacheImage("OutFront/1")

  if self:getInteger("key") < 0 then
    self:cacheImage("Drive/2")
  
  else
    self:cacheImage("Drive/0")
  end
end

function E2Keyhole:beforeUseItem(itemName)
  if itemName == "key" then
    return true
  end

  return false
end

function E2Keyhole:afterUseItem(itemName)
  self:imageOn("1")
  self:sayI18n("afterUseItem_1")
  self:play("key")

  return false
end

function E2Keyhole:key(rect)
  if self:getInteger("key") >= 0 then
    self:sayI18n("key_1")

    return
  end

  self:sayI18n("key_2")
end

function E2Keyhole:engine(rect)
  if self:getInteger("key") >= 0 then
    self:sayI18n("engine_1")

    return
  end

  self:play("start")
  self:hideArrowButton()
  self:disableTouch()

  self:scheduleOnce(0.8, function()
    self:enableTouch()
    self:switchPlace("Bomb")
  end)
end

return E2Keyhole
