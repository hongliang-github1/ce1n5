local E2GloveBox = class("E2GloveBox", function()
  return BasePlace.new()
end)

function E2GloveBox:initPhoto()
  self:addPhoto("1", 832, 384)
  self:addPhoto("2", 0, 0)
  self:addPhoto("3", 384, 384)
  self:addPhoto("4", 1152, 576)
  self:addPhoto("l3", 448, 384)
end

function E2GloveBox:initButton()
  self:addButton("open", 170, 120, 1588, 814)
end

function E2GloveBox:arrowLeft(rect)
  self:switchPlaceZoomOut("Drive")
end

function E2GloveBox:beforeLoad()
  -- 根据状态显示图片
  self:imageOn("0")
end

function E2GloveBox:afterLoad()
end

function E2GloveBox:afterLoad2()
  self:cacheImage("2")
  self:cacheImage("l2")
  if self:getInteger("key") < 0 then
    self:cacheImage("Drive/2")
  
  else
    self:cacheImage("Drive/0")
  end
end

function E2GloveBox:beforeUseItem(itemName)
  if itemName == "key1" and self:getInteger("unlockGloveBox") == 0 then
    return true
  end

  if itemName == "flash" then
    -- 已经用过手电了就不用再用一次了，U盘用过了也就不用再用手电了
    if self:getInteger("udisk") < 0 then
      return false
    end

    return self.opened and not self.flashed
  end

  if itemName == "udisk" then
    -- 没用过手电之前不能用U盘

    return self.opened and self.flashed
  end

  return false
end

function E2GloveBox:afterUseItem(itemName)
  if itemName == "key1" then
    -- 使用钥匙金属部分打开手套箱
    self:imageOn("1")
    self:sayI18n("afterUseItem_1")
    self:play("light")

    return true
  end

  -- 使用手电
  if itemName == "flash" then
    -- 变化场景
    self:imageOn("l2")
    self:sayI18n("afterUseItem_2")

    self.flashed = true

    return true
  end

  -- 使用U盘
  if itemName == "udisk" then
    -- 变化场景
    self:imageOn("l3")
    self:play("light")
    self:sayI18n("afterUseItem_3")
    self:hideArrowButton()
    self:disableAlwaysUseItem()

    self.goEnding = true

    return true
  end

  return true
end

function E2GloveBox:open(rect)
  if self.goEnding then
    -- U盘插入了，跳转到iDrive解除炸弹界面
    self:switchPlace("Idrive5")
    
    return
  end

  -- 没解锁情况
  if self:getInteger("unlockGloveBox") == 0 then
    if not self:imageIsOn("1") then
      self:sayI18n("open_1")

      return
    end
  end

  -- 解锁过了，判断手套箱是打开的还是关着的，关着的就打开，打开的就判断是否有道具没有拿，没拿就拿道具，拿了就关上
  if not self.opened then
    -- 打开，根据是否那过道具，显示对应的图片
    if self:imageIsOn("1") then
      self:imageOff("1")
      self:setInteger("unlockGloveBox", 1)
    end

    self:imageOn("2")
    self:play("rearash")

    self.opened = true

    -- 判断u盘是否用过，如果u盘用过了，这里需要把u盘插上
    if self:getInteger("udisk") < 0 then
      self:imageOn("3")
    end

    if self:getInteger("blue") == 0 then
      self:imageOn("4")
      self:sayI18n("open_2")

    else
      self:sayI18n("open_3")
    end

    return
  end

  -- 当前已打开，判断是否应该跳转至iDrive炸弹解锁的通关剧情
  if self:getInteger("udisk") < 0 then
    -- TODO
    self:switchPlace("Idrive7")

    return
  end

  -- 当前已打开，判断是否拿过香水道具
  if self:getInteger("blue") ~= 0 then
    -- 拿了道具，直接关掉
    self:sayI18n("open_4")

    if self.flashed then
      self:imageOff("l3")

    else
      self:imageOff("3")
    end

    self.opened  = false
    self.flashed = false

    self:play("rearash")
    self:imageOn("0")

  else
    -- 拿香水道具
    self:imageOff("4")
    self:getItem("blue")
    self:sayI18n("open_5")
  end
end

return E2GloveBox
