local E2TrunkRight = class("E2TrunkRight", function()
  return BasePlace.new()
end)

function E2TrunkRight:initPhoto()
  self:addPhoto("1", 768, 320)
end

function E2TrunkRight:initButton()
  self:addButton("package", 466, 134, 1582, 1014, false)
end

function E2TrunkRight:arrowDown(rect)
  self:switchPlaceZoomOut("OutRear")
end

function E2TrunkRight:beforeLoad()
  self:imageOn("0")
end

function E2TrunkRight:afterLoad()
end

function E2TrunkRight:afterLoad2()
  self:cacheImage("OutRear/0")
end

function E2TrunkRight:beforeUseItem(itemName)
  return false
end

function E2TrunkRight:afterUseItem(itemName)
  return true
end

function E2TrunkRight:package(rect)
  self:sayI18n("click_1")
end

return E2TrunkRight
