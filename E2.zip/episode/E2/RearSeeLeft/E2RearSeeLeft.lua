local E2RearSeeLeft = class("E2RearSeeLeft", function()
  return BasePlace.new()
end)

function E2RearSeeLeft:initPhoto()
  self:addPhoto("1", 64, 320)
  self:addPhoto("2", 896, 896)
  self:addPhoto("3", 576, 0)
  self:addPhoto("4", 64, 0)
end

function E2RearSeeLeft:initButton()
  self:addButton("door", 1222, 326, 514, 510)
  self:addButton("goOut", 642, 0, 574, 810, false)
  self:addButton("arm", 0, 342, 634, 808)
  self:addButton("item", 640, 816, 558, 334, false)
end

function E2RearSeeLeft:arrowRight(rect)
  self:switchPlaceRight("RearSeeFront")
end

function E2RearSeeLeft:beforeLoad()
  -- 设置状态
  self:imageOn("0")
end

function E2RearSeeLeft:afterLoad()

end

function E2RearSeeLeft:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("3")
  self:cacheImage("4")

  if self:getInteger("key") < 0 then
    self:cacheImage("RearSeeFront/5")
  
  else
    self:cacheImage("RearSeeFront/4")
  end
end

function E2RearSeeLeft:beforeUseItem(itemName)
  return false
end

function E2RearSeeLeft:afterUseItem(itemName)
  return true
end

function E2RearSeeLeft:arm(rect)
  -- 注意判断当前门是否是关着的，如果门没有关着，就需要切换图片
  if self:imageIsOn("1") or self:imageIsOn("4") then
    -- 关闭扶手
    if self:imageIsOn("3") or self:imageIsOn("4") then
      self:imageOff("4")
      self:imageOn("3")

    else
      self:imageOff("1")
    end

    if self:imageIsOn("2") then
      self:imageOff("2")
    end

    self:sayI18n("arm_1")
    self:play("rearcup")

    return
  end

  -- 打开扶手
  if self:imageIsOn("3") or self:imageIsOn("4") then
    self:imageOff("3")
    self:imageOn("4")

  else
    self:imageOn("1")
  end

  -- 判断当前道具是否存在
  if self:getInteger("key1") ~= 0 then
    self:sayI18n("arm_2")

  else
    self:imageOn("2")
    self:sayI18n("arm_3")
  end

  self:play("rearcup")
end

function E2RearSeeLeft:door(rect)
  if self:getInteger("isAllDoorUnlock") == 0 then
    self:play("number")
    self:sayI18n("door_1")

    return
  end

  if self:imageIsOn("3") or self:imageIsOn("4") then
    -- 关门 需要判断扶手是否打开，如果扶手打开，切换图片不一样
    if not self:imageIsOn("4") and not self:imageIsOn("1") then
      self:imageOff("3")

    else
      self:imageOff("4")
      self:imageOn("1")

      -- 如果钥匙存在，这个时候会被盖住，需要再显示一次
      if self:getInteger("key1") == 0 then
        self:imageOn("2")
      end
    end

    self:play("close")
    self:sayI18n("door_2")

  else
    -- 开门
    if not self:imageIsOn("4") and not self:imageIsOn("1") then
      self:imageOn("3")

    else
      self:imageOff("1")
      self:imageOn("4")

      -- 如果钥匙存在，这个时候会被盖住，需要再显示一次
      if self:getInteger("key1") == 0 then
        self:imageOn("2")
      end
    end

    self:play("open")
    self:sayI18n("door_3")
  end
end

function E2RearSeeLeft:goOut(rect)
  if self:imageIsOn("3") or self:imageIsOn("4") then
    -- 询问是否逃跑
    self:switchPlace("AskRun")
  end
end

function E2RearSeeLeft:item(rect)
  -- 如果扶手没有打开，不做操作
  if not self:imageIsOn("4") and not self:imageIsOn("1") then
    return
  end

  if self:getInteger("key1") ~= 0 then
    self:sayI18n("item_1")

    return
  end

  self:imageOff("2")
  self:getItem("key1")
  self:sayI18n("item_2")
end

return E2RearSeeLeft
