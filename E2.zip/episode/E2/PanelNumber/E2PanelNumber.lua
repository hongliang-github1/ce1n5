local E2PanelNumber = class("E2PanelNumber", function()
  return BasePlace.new()
end)

function E2PanelNumber:initPhoto()
end

function E2PanelNumber:initButton()
  self:addButton("code1", 0, 422, 214, 416, false)
  self:addButton("code2", 218, 424, 262, 416, false)
  self:addButton("code3", 482, 424, 258, 418, false)
  self:addButton("code4", 742, 422, 266, 420, false)
  self:addButton("code5", 1012, 422, 256, 420, false)
  self:addButton("code6", 1272, 420, 268, 424, false)
  self:addButton("code7", 1542, 420, 276, 426, false)
  self:addButton("code8", 1820, 418, 224, 428, false)
end

function E2PanelNumber:arrowDown(rect)
  self:switchPlaceZoomOut("Panel")
end

function E2PanelNumber:beforeLoad()
  self:imageOn("0")

  -- 创建3个显示密码的数字Label
  local fontSize = 50 * 2

  if self.gamingScene and self.gamingScene.labelSay then
    fontSize = math.ceil(self.gamingScene.labelSay:getFontSize() * 2.25)
  end

  local label1 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label2 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label3 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  label1:setColor(cc.c4b(255, 255, 255, 255))
  label2:setColor(cc.c4b(255, 255, 255, 255))
  label3:setColor(cc.c4b(255, 255, 255, 255))
  label1:setAnchorPoint(0, 0)
  label2:setAnchorPoint(0, 0)
  label3:setAnchorPoint(0, 0)
  label1:setPosition(0, 0)
  label2:setPosition(0, 0)
  label3:setPosition(0, 0)

  self.label1 = label1
  self.label2 = label2
  self.label3 = label3

  self:addChild(label1)
  self:addChild(label2)
  self:addChild(label3)

  -- 这3个Label的位置以Label2居中为准，先计算Label2的位置
  local bgSize    = self:getContentSize()
  local labelSize = label1:getContentSize()
  local x         = bgSize.width / 2 - labelSize.width / 2
  local y         = bgSize.height - 300

  label1:setPosition(x - labelSize.width, y)
  label2:setPosition(x, y)
  label3:setPosition(x + labelSize.width, y)

  -- 定义blue.png叠在图片上的坐标数组
  self.blueTable = {
    cc.p(-26*2, 254*2),
    cc.p(94*2, 254*2),
    cc.p(232*2, 254*2),
    cc.p(370*2, 254*2),
    cc.p(500*2, 254*2),
    cc.p(626*2, 254*2),
    cc.p(776*2, 254*2),
    cc.p(908*2, 254*2),
  }
end

function E2PanelNumber:afterLoad()
end

function E2PanelNumber:afterLoad2()
  self:cacheImage("Panel/0")
end

function E2PanelNumber:beforeUnload()
  self.label1:setVisible(false)
  self.label2:setVisible(false)
  self.label3:setVisible(false)
end

function E2PanelNumber:beforeUseItem(itemName)
  -- 可以使用蓝色药水
  if itemName == "blue" then
    return self:getInteger("driverDoorOpen") == 0
  end

  return false
end

function E2PanelNumber:afterUseItem(itemName)
  local p1 = self:getInteger("isLockPassword1")
  local p2 = self:getInteger("isLockPassword2")
  local p3 = self:getInteger("isLockPassword3")

  if itemName == "blue" then
    -- 使用蓝色药水，显示数字
    self.blueUsed = true

    self:imageOn("blue", self.blueTable[p1].x, self.blueTable[p1].y)
    self:imageOn("blue", self.blueTable[p2].x, self.blueTable[p2].y)
    self:imageOn("blue", self.blueTable[p3].x, self.blueTable[p3].y)

    self:sayI18n("afterUseItem_2")
    self:play("item")

    return true
  end

  return true
end

function E2PanelNumber:code1(rect)
  self:press(1)
end

function E2PanelNumber:code2(rect)
  self:press(2)
end

function E2PanelNumber:code3(rect)
  self:press(3)
end

function E2PanelNumber:code4(rect)
  self:press(4)
end

function E2PanelNumber:code5(rect)
  self:press(5)
end

function E2PanelNumber:code6(rect)
  self:press(6)
end

function E2PanelNumber:code7(rect)
  self:press(7)
end

function E2PanelNumber:code8(rect)
  self:press(8)
end

function E2PanelNumber:press(n)
  -- 如果driverDoorOpen已经大于0，则说明已经解锁过了
  if self:getInteger("driverDoorOpen") > 0 then
    self:sayI18n("press_1")

    return
  end

  if not self.blueUsed then
    -- 只要药水没有泼，就不让点击
    self:sayI18n("press_2")

    return
  end

  local p1 = self:getInteger("isLockPassword1")
  local p2 = self:getInteger("isLockPassword2")
  local p3 = self:getInteger("isLockPassword3")

  if self.input1 ~= nil then
    if self.input2 ~= nil then
      -- 当前n是第三位，判断是否与密码相等
      self.label3:setString(tostring(n))

      if p1 == self.input1 and p2 == self.input2 and p3 == n then
        -- 密码相等，车门自动解锁
        self:sayI18n("press_3")
        self:setInteger("driverDoorOpen", 1)
        self:voidItem("blue")
        self:play("open")

      else
        -- 密码不相等，等待用户重新输入
        self.input1 = nil
        self.input2 = nil

        self.label1:setColor(cc.c4b(255, 0, 0, 255))
        self.label2:setColor(cc.c4b(255, 0, 0, 255))
        self.label3:setColor(cc.c4b(255, 0, 0, 255))

        self:sayI18n("press_4")
        self:play("number")
      end

    else
      -- 当前输入的是第二位
      self.input2 = n

      self.label2:setString(tostring(n))
      self.label3:setString("")
    end

  else
    -- 当前输入的是第一位
    self.input1 = n
    self.input2 = nil

    self.label1:setColor(cc.c4b(255, 255, 255, 255))
    self.label2:setColor(cc.c4b(255, 255, 255, 255))
    self.label3:setColor(cc.c4b(255, 255, 255, 255))
    self.label1:setString(tostring(n))
    self.label2:setString("")
    self.label3:setString("")
  end
end

return E2PanelNumber
