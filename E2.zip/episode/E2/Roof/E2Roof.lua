local E2Roof = class("E2Roof", function()
  return BasePlace.new()
end)

function E2Roof:initPhoto()
  self:addPhoto("2", 1024, 320)
end

function E2Roof:initButton()
  self:addButton("open", 0, 0, 2044, 1148)
end

function E2Roof:arrowDown(rect)
  self:switchPlaceZoomOut("OutRightFront")
end

function E2Roof:beforeLoad()
  self:imageOn("0")
end

function E2Roof:afterLoad()

end

function E2Roof:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("3")
  self:cacheImage("OutRightFront/0")
end

function E2Roof:beforeUseItem(itemName)
  return false
end

function E2Roof:afterUseItem(itemName)
  return true
end

function E2Roof:open(rect)
  local meter = self:getInteger("meter")

  if not self:imageIsOn("0") then
    if meter ~= 0 then
      self:imageOn("0")
      self:sayI18n("open_1")
      self:play("roofwindow")

    else
      -- 获得数字仪表道具
      self:imageOff("2")
      self:imageOn("3")
      self:getItem("meter")
      self:sayI18n("open_2")
    end

  else
    if meter ~= 0 then
      self:imageOn("3")
      self:sayI18n("open_3")
      self:play("roofwindow")

    else
      self:imageOn("1")
      self:imageOn("2")
      self:sayI18n("open_4")
      self:play("roofwindow")
    end
  end
end

return E2Roof
