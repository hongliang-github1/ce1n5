local E2OutLeftRear = class("E2OutLeftRear", function()
  return BasePlace.new()
end)

function E2OutLeftRear:initPhoto()
end

function E2OutLeftRear:initButton()
  self:addButton("open", 514, 42, 566, 830)
  self:addButton("close", 110, 44, 392, 832, false)
end

function E2OutLeftRear:arrowLeft(rect)
  self:switchPlaceLeft("OutLeftFront")
end

function E2OutLeftRear:arrowRight(rect)
  self:switchPlaceRight("OutRear")
end

function E2OutLeftRear:beforeLoad()
  -- 判断如果是从里面退出来的，就打开车门
  if self.fromPlaceName == "AskRun" then
    self:imageOn("3")

    return
  end

  self:imageOn("1")
end

function E2OutLeftRear:afterLoad()
end

function E2OutLeftRear:afterLoad2()
  if self.fromPlaceName == "AskRun" then
    self:cacheImage("1")
  
  else
    self:cacheImage("3")
  end

  if self:getInteger("key") < 0 then
    self:cacheImage("OutLeftFront/1")
  else
    self:cacheImage("OutLeftFront/0")
  end
  
  self:cacheImage("OutRear/0")
  self:cacheImage("RearSeeLeft/0")
  
end

function E2OutLeftRear:beforeUseItem(itemName)
  return false
end

function E2OutLeftRear:afterUseItem(itemName)
  return true
end

function E2OutLeftRear:open(rect)
  if self:imageIsOn("3") then
    -- 门已开，进入车内后座向左看视角
    self:switchPlaceZoomIn("RearSeeLeft", cc.rect(258 * 2, 134 * 2, 281 * 2, 251 * 2))

  else
    -- 门还没开，判断是否可以开门
    if self:getInteger("isAllDoorUnlock") > 0 then
      -- 开门
      self:imageOn("3")
      self:sayI18n("open_1")

      self:play("open")

    else
      self:sayI18n("open_2")
    end
  end
end

function E2OutLeftRear:close(rect)
  if self:imageIsOn("3") then
    -- 关车门
    self:imageOn("1")
    self:sayI18n("close_1")

    self:play("close")
  end
end

return E2OutLeftRear
