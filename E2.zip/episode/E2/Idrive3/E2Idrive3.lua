local E2Idrive0 = require_safe("episode/E2/Idrive0/E2Idrive0")

local E2Idrive3 = class("E2Idrive3", function()
  return E2Idrive0.new()
end)

function E2Idrive3:initPhoto()
  self:addPhoto("navigationicon2", 1024, 576)
  self:addPhoto("navigationicon", 64, 192)
end

function E2Idrive3:beforeLoad()
  self:imageOn("Idrive/d10")  
  self:addMenuText()
  
  if not self.fromPlaceName or self.fromPlaceName == "Idrive" then
    self.pos = 1
    
  else
    self.pos = self:getInteger("last_idrive_pos")
  end

  self:imageOn("navigationicon")
  self:imageOn("navigationicon2")
  self:imageOn("Idrive/select1", 128*2, 336 + (self.pos-1) * 86)
  self:updateMenuK()
end

function E2Idrive3:up(rect)
  if self.pos <= 1 then
    return
  end
  
  if self.pos == 4 then
    self.pos = 1
  
  else
    self.pos = self.pos - 1
  end
  
  self:updateMenuK()
end

function E2Idrive3:down(rect)
  if self.pos >= 7 then
    return
  end
  
  if self.pos == 1 then
    self.pos = 4
    
  else
    self.pos = self.pos + 1
  end
  
  self:updateMenuK()
end

function E2Idrive3:left(rect)
  self:setInteger("last_idrive_pos", 3)
  self:switchPlace("Idrive")
end

function E2Idrive3:right(rect)
  self:say("...")
end

function E2Idrive3:addMenuText()
  local fontSize = 55

  -- 菜单栏下面的选项
  local x  = 332
  local rx = 1280
  local w  = 1000
  local h  = 60 * 2

  self:createIdriveLabel("导航菜单", "Navigation", fontSize, 212, 120*2+110, w, h)
  self:createIdriveLabel("目的地搜索", "Destination search", fontSize, x, 168*2+115, w, h)
  self:createIdriveLabel("改变路线", "Change route", fontSize, x, 210*2+115, w, h, true)
  self:createIdriveLabel("路线信息", "Route profile", fontSize, x, 254*2+115, w, h, true)
  self:createIdriveLabel("旅程规划", "Journey planner", fontSize, x, 299*2+105, w, h)
  self:createIdriveLabel("旅程列表", "Journey list", fontSize, x, 690+105, w, h)
  self:createIdriveLabel("编辑标记点", "Edit mem. points", fontSize, x, 778+105, w, h)
  self:createIdriveLabel("导航设置", "Navigation settings", fontSize, x, 866+105, w, h)
  
  -- 右边菜单
  self:createIdriveLabel("目的地搜索", "Dest. search", fontSize, 1162, 123*2+100, 400*2, h, true)
  self:createIdriveLabel("快速目的地选单", "Quicklist", fontSize, rx, 338+110, w, h, true)
  self:createIdriveLabel("附近的兴趣点", "Points of interest in vicinity", fontSize, rx, 424+110, w, h, true)
  self:createIdriveLabel("搜索兴趣点", "Points of interest", fontSize, rx, 510+110, w, h, true)
  self:createIdriveLabel("按电话号码搜索", "Phone number", fontSize, rx, 596+110, w, h, true)
  self:createIdriveLabel("搜索(A-Z)", "A-Z search", fontSize, rx, 682+110, w, h, true)
  self:createIdriveLabel("目的地历史记录", "Last destinations", fontSize, rx, 768+110, w, h, true)
  self:createIdriveLabel("地址查询", "Address search", fontSize, rx, 854+110, w, h, true)
end

function E2Idrive3:updateMenuK()
  -- 得到目标的位置
  -- 框体的宽度和高度
  local kwidth  = 656
  local kheight = 80
  
  -- 框体的坐标
  local kx = 118*2
  local ky = 0
  
  -- 框的起始支点
  local startkx = 0
  local startky = 0
  
  if self.pos == 1 then
    ky       = 163*2
    startkx  = 75*2
    startky  = 274*2
    self.arc = 12*2
        
  elseif self.pos == 2 then
    ky       = 206*2
    startkx  = 162
    startky  = 556
    self.arc = 14*2
          
  elseif self.pos == 3 then
    ky          = 250*2
    startkx     = 184
    startky     = 572
    self.arc    = 24*2
          
  elseif self.pos == 4 then
    ky          = 584
    startkx     = 101*2
    startky     = 314*2
    self.arc    = 0
          
  elseif self.pos == 5 then
    ky          = 672
    startkx     = 90*2
    startky     = 340*2
    self.arc    = 24*2
          
  elseif self.pos == 6 then
    ky          = 380*2
    startkx     = 80*2
    startky     = 696
    self.arc    = 16*2
          
  elseif self.pos == 7 then
    ky          = 424*2
    startkx     = 73*2
    startky     = 704
    self.arc    = 14*2
  end

  local distance  = 10
  self.kSize      = cc.size(kwidth, kheight)
  self.kPoint     = cc.p(kx, ky)
  self.startPoint = cc.p(startkx, startky)
  
  if self.pos == 4 then
    self.endPoint = cc.p(self.kPoint.x, self.kPoint.y + (self.kSize.height / 2))
    
  else
    self.endPoint = cc.p(self.kPoint.x - distance, self.kPoint.y + (self.kSize.height / 2))
  end

  self:redrawRedBox()
end

return E2Idrive3
