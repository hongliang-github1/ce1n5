local E2OutRightFront = class("E2OutRightFront", function()
  return BasePlace.new()
end)

function E2OutRightFront:initPhoto()
end

function E2OutRightFront:initButton()
  self:addButton("open", 354, 446, 448, 298)
  self:addButton("roof", 108, 32, 530, 316)
  self:addButton("seat", 350, 748, 468, 304)
  self:addButton("close", 992, 356, 502, 304, false)
end

function E2OutRightFront:arrowLeft(rect)
  self:switchPlaceLeft("OutRightRear")
end

function E2OutRightFront:arrowRight(rect)
  self:switchPlaceRight("OutFront")
end

function E2OutRightFront:beforeLoad()
  if self.lastPlaceName == "FromtArm" or self.lastPlaceName == "Roof" or self.lastPlaceName == "SeatRightFront" then
    self:imageOn("1")

    return
  end

  self:imageOn("0")
end

function E2OutRightFront:afterLoad()
end

function E2OutRightFront:afterLoad2()
  self:cacheImage("OutRightRear/1")
  self:cacheImage("OutFront/0")
  self:cacheImage("Roof/0")
  self:cacheImage("SeatRightFront/0")
end

function E2OutRightFront:beforeUseItem(itemName)
  return false
end

function E2OutRightFront:afterUseItem(itemName)
  return true
end

function E2OutRightFront:open(rect)
  if self:imageIsOn("1") then
    -- 门已经打开了，什么都不干

  else
    -- 门还没开，开门
    if self:getInteger("isAllDoorUnlock") > 0 then
      self:imageOn("1")
      self:sayI18n("open_1")

      self:play("open")

    else
      self:sayI18n("open_2")
    end
  end
end

function E2OutRightFront:roof(rect)
  if self:imageIsOn("1") then
    self:switchPlaceZoomIn("Roof", rect)
  end
end

function E2OutRightFront:seat(rect)
  if self:imageIsOn("1") then
    self:switchPlaceZoomIn("SeatRightFront", rect)
  
  else
    self:open(self.buttonTable["open"])
  end
end

function E2OutRightFront:close(rect)
  if self:imageIsOn("1") then
    -- 关门
    self:imageOn("0")
    self:sayI18n("close_1")

    self:play("close")
  end
end

return E2OutRightFront
