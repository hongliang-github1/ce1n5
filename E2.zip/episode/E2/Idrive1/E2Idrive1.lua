local E2Idrive0 = require_safe("episode/E2/Idrive0/E2Idrive0")

local E2Idrive1 = class("E2Idrive1", function()
  return E2Idrive0.new()
end)

function E2Idrive1:initPhoto()
  self:addPhoto("cd1", 1152, 192)
  self:addPhoto("cdicon2", 1024, 576)
  self:addPhoto("cdicon", 64, 192)
  self:addPhoto("cd2", 192, 192)
  self:addPhoto("cd3", 768, 320)
  self:addPhoto("cdcht2", 192, 192)
  self:addPhoto("cden2", 192, 192)
  self:addPhoto("cdicon3", 576, 192)
  self:addPhoto("cdicon4", 64, 576)
end

function E2Idrive1:beforeLoad()
  self:imageOn("Idrive/d10")  
  self:addMenuText()
  
  if not self.fromPlaceName or self.fromPlaceName == "Idrive" then
    self.pos = 1
    
  else
    self.pos = self:getInteger("last_idrive_pos")
  end
  
  self:imageOn("cdicon")
  self:imageOn("cdicon2")
  self:imageOn("cd1")
  self:imageOn("Idrive/select1", 128*2, 336 + ((self.pos-1) * 86))
  self:updateMenuK()
end

function E2Idrive1:up(rect)
  if self.pos == 1 then
    return
  end
  
  self.pos = self.pos - 1
  
  self:updateMenuK()
end

function E2Idrive1:down(rect)
  if self.pos >= 4 then
    return
  end
  
  self.pos = self.pos + 1
  
  self:updateMenuK()
end

function E2Idrive1:left(rect)
  self:setInteger("last_idrive_pos", 1)
  self:switchPlace("Idrive")
end

function E2Idrive1:right(rect)
  self:say("...")
  -- self:switchPlace([NSString stringWithFormat:"Idrive1j%d", self.pos)]
end

function E2Idrive1:addMenuText()
  local fontSize = 55

  -- 菜单栏下面的选项
  local x  = 166 * 2
  local w  = 600 * 2
  local h  = 70 * 2

  self:createIdriveLabel("CD/多媒体", "CD/Multimedia", fontSize, 106*2, 114*2+143, w, h)
  self:createIdriveLabel("CD/DVD", "CD/DVD", fontSize, x, 166*2+140, w, h)
  self:createIdriveLabel("音乐收藏", "Music collection", fontSize, x, 209*2+140, w, h)
  self:createIdriveLabel("外部设备", "External devices", fontSize, x, 253*2+140, w, h)
  self:createIdriveLabel("音色", "Tone", fontSize, x, 295*2+135, w, h)
end

function E2Idrive1:updateMenuK()
  -- 得到目标的位置
  -- 框体的宽度和高度
  local kwidth  = 656
  local kheight = 80
  
  -- 框体的坐标
  local kx = 118*2
  local ky = 0
  
  -- 框的起始支点
  local startkx = 0
  local startky = 0
  
  if self.pos == 1 then
    ky       = 163*2
    startkx  = 75*2
    startky  = 274*2
    self.arc = 12*2
        
  elseif self.pos == 2 then
    ky       = 206*2
    startkx  = 162
    startky  = 556
    self.arc = 14*2
          
  elseif self.pos == 3 then
    ky          = 250*2
    startkx     = 184
    startky     = 572
    self.arc    = 24*2
          
  elseif self.pos == 4 then
    ky          = 584
    startkx     = 101*2
    startky     = 314*2
    self.arc    = 0
          
  elseif self.pos == 5 then
    ky          = 672
    startkx     = 90*2
    startky     = 340*2
    self.arc    = 24*2
          
  elseif self.pos == 6 then
    ky          = 380*2
    startkx     = 80*2
    startky     = 696
    self.arc    = 16*2
          
  elseif self.pos == 7 then
    ky          = 424*2
    startkx     = 73*2
    startky     = 704
    self.arc    = 14*2
  end

  local distance  = 10
  self.kSize      = cc.size(kwidth, kheight)
  self.kPoint     = cc.p(kx, ky)
  self.startPoint = cc.p(startkx, startky)
  
  if self.pos == 4 then
    self.endPoint = cc.p(self.kPoint.x, self.kPoint.y + (self.kSize.height / 2))
    
  else
    self.endPoint = cc.p(self.kPoint.x - distance, self.kPoint.y + (self.kSize.height / 2))
  end

  self:redrawRedBox()
end

return E2Idrive1
