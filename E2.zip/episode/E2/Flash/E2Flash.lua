local E2Flash = class("E2Flash", function()
  return BasePlace.new()
end)

function E2Flash:initPhoto()
  self:addPhoto("1", 576, 64)
  self:addPhoto("2", 640, 64)
  self:addPhoto("3", 576, 64)
end

function E2Flash:initButton()
  self:addButton("getFlash", 0, 0, 2044, 1148, false)
end

function E2Flash:arrowDown(rect)
  local placeName = self.lastPlaceName

  if placeName == nil then
    placeName = "RearSeeFront"
  end

  self:switchPlaceZoomOut(placeName)
end

function E2Flash:beforeLoad()
  self:imageOn("0")
end

function E2Flash:afterLoad()
  self.clickSum = 0
end

function E2Flash:recordLastPlaceName()
  return false
end

function E2Flash:beforeUseItem(itemName)
  if itemName == "flash2" then
    if self.useFlash then
      -- 如果已经使用过手电筒底座了就不能在当前场景下再次使用
      return false
    end

    return true
  end

  return false
end

function E2Flash:afterUseItem(itemName)
  if itemName == "flash2" then
    -- 使用钥匙的金属部分
    self:sayI18n("afterUseItem_1")

    -- 设置两个道具摆在一起的图片
    self:imageOn("1")
    self.useFlash = true

    -- 设置箭头隐藏
    self:hideArrowButton()
    self:disableAlwaysUseItem()

    return true
  end

  return true
end

function E2Flash:getFlash(rect)
  if not self.useFlash then
    self:sayI18n("getFlash_1")

    return
  end

  self.clickSum = self.clickSum + 1

  if self.clickSum == 1 then
    -- 设置两个钥匙拼在一起的图片
    self:sayI18n("getFlash_2")
    self:imageOn("2")

    return
  end

  if self.clickSum == 2 then
    -- 得到完整车钥匙，设置两个道具都已经不能使用了，恢复显示箭头按钮
    self:voidItem("flash2")
    self:voidItem("flash1")
    self:imageOn("3")
    self:getItem("flash")
    self:sayI18n("getFlash_3")
    self:showArrowButton()
  end
end

return E2Flash
