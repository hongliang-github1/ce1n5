local E2OutRightRear = class("E2OutRightRear", function()
  return BasePlace.new()
end)

function E2OutRightRear:initPhoto()
end

function E2OutRightRear:initButton()
  self:addButton("open", 500, 68, 1004, 820)
  self:addButton("close", 1530, 64, 360, 826, false)
end

function E2OutRightRear:arrowLeft(rect)
  self:switchPlaceLeft("OutRear")
end

function E2OutRightRear:arrowRight(rect)
  self:switchPlaceRight("OutRightFront")
end

function E2OutRightRear:beforeLoad()
  if self.lastPlaceName == "RearAsh" then
    self:imageOn("0")

    return
  end

  self:imageOn("1")
end

function E2OutRightRear:afterLoad()
end

function E2OutRightRear:afterLoad2()
  if self.lastPlaceName == "RearAsh" then
    self:cacheImage("1")
  
  else
    self:cacheImage("0")
  end
  
  self:cacheImage("RearAsh/0")
end

function E2OutRightRear:beforeUseItem(itemName)
  return false
end

function E2OutRightRear:afterUseItem(itemName)
  return true
end

function E2OutRightRear:open(rect)
  if self:imageIsOn("0") then
    -- 门已开，进入后座烟灰盒视角
    self:switchPlaceZoomIn("RearAsh", rect)

  else
    -- 门还没开，判断是否可以开门
    if self:getInteger("isAllDoorUnlock") > 0 then
      -- 开门
      self:imageOn("0")
      self:sayI18n("open_1")
      self:play("open")

    else
      self:sayI18n("open_2")
    end
  end
end

function E2OutRightRear:close(rect)
  if self:imageIsOn("0") then
    -- 关门
    self:imageOn("1")
    self:sayI18n("close_1")
    self:play("close")
  end
end

return E2OutRightRear
