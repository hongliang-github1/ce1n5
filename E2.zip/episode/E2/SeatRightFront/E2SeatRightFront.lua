local E2SeatRightFront = class("E2SeatRightFront", function()
  return BasePlace.new()
end)

function E2SeatRightFront:initPhoto()
end

function E2SeatRightFront:initButton()
  self:addButton("under", 828, 630, 838, 504)
end

function E2SeatRightFront:arrowDown(rect)
  self:switchPlaceZoomOut("OutRightFront")
end

function E2SeatRightFront:beforeLoad()
  self:imageOn("0")
end

function E2SeatRightFront:afterLoad()
  self:cacheImage("OutRightFront/0")
  
  self:cacheImage("SeatUnderRightFront/0")
  
end

function E2SeatRightFront:beforeUseItem(itemName)
  return false
end

function E2SeatRightFront:afterUseItem(itemName)
  return true
end

function E2SeatRightFront:under(rect)
  self:switchPlaceZoomIn("SeatUnderRightFront", rect)
end

return E2SeatRightFront
