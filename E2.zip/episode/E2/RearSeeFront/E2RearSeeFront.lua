local E2RearSeeFront = class("E2RearSeeFront", function()
  return BasePlace.new()
end)

function E2RearSeeFront:initPhoto()
  self:addPhoto("8", 1088, 640)
end

function E2RearSeeFront:initButton()
  self:addButton("rearLeft", 0, 396, 634, 756)
  self:addButton("drive", 636, 392, 898, 756)
  self:addButton("light", 1050, 0, 240, 388)
end

function E2RearSeeFront:beforeLoad()
  -- 场景状态：黑灯0
  if self:getInteger("lamp") == 0 then
    self:imageOn("4")
    self:sayI18n("beforeLoad_1")

    return
  end

  -- 检查是否插入了车钥匙，如果车钥匙已插入则直接设置10就可以了
  if self:getInteger("key") < 0 then
    self:imageOn("10")

    return
  end

  -- 还没插钥匙
  self:imageOn("5")
end

function E2RearSeeFront:afterLoad()
end

function E2RearSeeFront:afterLoad2()
  self:cacheImage("5")

  self:cacheImage("RearSeeLeft/0")
  if self:getInteger("key") < 0 then
    self:cacheImage("Drive/2")
  
  else
    self:cacheImage("Drive/0")
  end
end

function E2RearSeeFront:beforeUseItem(itemName)
  return false
end

function E2RearSeeFront:afterUseItem(itemName)
  return true
end

function E2RearSeeFront:rearLeft(rect)
  if self:getInteger("lamp") < 1 then
    self:sayI18n("rearLeft_1")

  else
    self:switchPlaceLeft("RearSeeLeft")
  end
end

function E2RearSeeFront:drive(rect)
  if self:getInteger("lamp") < 1 then
    self:sayI18n("drive_1")

  else
    self:switchPlaceZoomIn("Drive", rect)
  end
end

function E2RearSeeFront:light(rect)
  if self:getInteger("lamp") < 1 then
    -- 开灯
    self:imageOn("5")
    self:sayI18n("light_1")

    self:setInteger("lamp", 1)

  else
    self:sayI18n("light_2")
  end
end

return E2RearSeeFront
