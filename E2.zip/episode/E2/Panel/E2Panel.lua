local E2Panel = class("E2Panel", function()
  return BasePlace.new()
end)

function E2Panel:initPhoto()
  self:addPhoto("1", 704, 256)
end

function E2Panel:initButton()
  self:addButton("number", 306, 500, 1376, 460)
end

function E2Panel:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E2Panel:beforeLoad()
  self:imageOn("0")
end

function E2Panel:afterLoad()
end

function E2Panel:afterLoad2()
  if self:getInteger("key") < 0 then
    self:cacheImage("Drive/2")
  
  else
    self:cacheImage("Drive/0")
  end

  self:cacheImage("PanelNumber/0")
end

function E2Panel:beforeUseItem(itemName)
  return false
end

function E2Panel:afterUseItem(itemName)
  return true
end

function E2Panel:number(rect)
  self:switchPlaceZoomIn("PanelNumber", cc.rect(281 * 2, 293 * 2, 490 * 2, 152 * 2))
end

return E2Panel
