local E2AskRun = class("E2AskRun", function()
  return BasePlace.new()
end)

function E2AskRun:initPhoto()
end

function E2AskRun:initButton()
end

function E2AskRun:beforeLoad()
  -- 创建Label
  local bgSize   = self:getContentSize()
  local fontSize = 75

  if self.gamingScene and self.gamingScene.labelSay then
    fontSize = math.ceil(self.gamingScene.labelSay:getFontSize() * 1.5)
  end

  label = cc.Label:createWithSystemFont(self.i18nTable["label"], "Helvetica", fontSize, cc.size(bgSize.width, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  label:setColor(cc.c4b(255, 255, 255, 255))
  label:setAnchorPoint(0.5, 0.5)
  label:setPositionX(bgSize.width / 2)
  label:setPositionY(bgSize.height - label:getContentSize().height / 2)
  self:addChild(label)

  -- 创建按钮
  local buttonRun = cc.ControlButton:create(self.i18nTable["button_run"], "Helvetica", fontSize)

  buttonRun:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  buttonRun:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  buttonRun:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  buttonRun:setAnchorPoint(0.5, 0.5)
  buttonRun:setPositionX(bgSize.width / 2)
  buttonRun:setPositionY(label:getPositionY() - label:getContentSize().height / 2 - buttonRun:getContentSize().height * 4)
  self:addChild(buttonRun)

  local buttonStay = cc.ControlButton:create(self.i18nTable["button_stay"], "Helvetica", fontSize)

  buttonStay:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  buttonStay:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  buttonStay:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  buttonStay:setAnchorPoint(0.5, 0.5)
  buttonStay:setPositionX(bgSize.width / 2)
  buttonStay:setPositionY(buttonRun:getPositionY() - buttonRun:getContentSize().height / 2 - buttonStay:getContentSize().height * 2)
  self:addChild(buttonStay)

  -- 控件创建完成，统一调整垂直居中
  local boxUp      = label:getPositionY() + label:getContentSize().height / 2
  local boxDown    = buttonStay:getPositionY() - buttonStay:getContentSize().height / 2
  local boxCenterY = (boxUp - boxDown) / 2
  local diff       = boxCenterY - bgSize.height / 2

  label:setPositionY(label:getPositionY() + diff)
  buttonRun:setPositionY(buttonRun:getPositionY() + diff)
  buttonStay:setPositionY(buttonStay:getPositionY() + diff)

  -- 绑定按钮事件
  buttonRun:registerControlEventHandler(function(button, eventType)
    self:goRun()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  buttonStay:registerControlEventHandler(function(button, eventType)
    self:goStay()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
end

function E2AskRun:afterLoad()
end

function E2AskRun:afterLoad2()
  self:cacheImage("Bomb/0")
  self:cacheImage("OutFront/0")
  self:cacheImage("OutFront/1")
end

function E2AskRun:recordLastPlaceName()
  return false
end

function E2AskRun:beforeUseItem(itemName)
  return false
end

function E2AskRun:afterUseItem(itemName)
  return true
end

function E2AskRun:goRun()
  -- 逃跑，判断炸弹是否已拆除，如果已拆则进入结束情节
  if self:getInteger("udisk") < 0 then
    self:switchPlace("Ending")

  else
    -- 进入炸弹爆炸情节
    self:switchPlace("Bomb")
  end
end

function E2AskRun:goStay()
  self:sayI18n("look_1")

  -- 判断是从哪个门出来的
  if self.lastPlaceName == "RearSeeLeft" then
    self:switchPlace("OutLeftRear")

  else
    self:switchPlace("OutLeftFront")
  end
end

return E2AskRun
