local E2Tip = class("E2Tip", function()
  return BaseTip.new()
end)

function E2Tip:getTipAtIndex(index)
  self:resetProgress()

  -- 刚进来，还没开灯
  if self:nextProgress() == index or (self:getInteger("lamp") == 0) then
    local place1 = self:addPlace("RearSeeFront")

    place1:markButton("light")

    self:textI18n("progress_1")

    return self.progress
  end

  -- 还没拿到车钥匙的金属部分
  if self:nextProgress() == index or (self:getInteger("key1") == 0) then
    local place1 = self:addPlace("RearSeeFront")
    local place2 = self:addPlace("RearSeeLeft")

    place1:markButton("rearLeft")
    place2:markButton("arm")

    self:textI18n("progress_2")

    return self.progress
  end

  -- 还没拿到蓝色药水
  if self:nextProgress() == index or (self:getInteger("blue") == 0) then
    local place1 = self:addPlace("RearSeeFront")
    local place2 = self:addPlace("Drive")
    local place3 = self:addPlace("GloveBox")

    place1:markButton("drive")
    place2:markButton("goGloveBox")
    place3:markButton("open")

    self:textI18n("progress_3")

    return self.progress
  end

  -- 没有解锁驾驶位的门
  if self:nextProgress() == index or (self:getInteger("driverDoorOpen") == 0) then
    local place1 = self:addPlace("Drive")
    local place2 = self:addPlace("Panel")

    self:addPlace("PanelNumber")
    place1:markButton("goPanel")
    place2:markButton("number")

    self:textI18n("progress_6")

    return self.progress
  end

  -- 如果没有拿到遥控部分
  if self:nextProgress() == index or (self:getInteger("key2") == 0) then
    local place1 = self:addPlace("Drive")
    local place2 = self:addPlace("OutLeftFront")
    local place3 = self:addPlace("SeatLeftFront")

    place1:markButton("openDoor")
    place2:markButton("seat")
    place3:markButton("under")

    self:textI18n("progress_7")

    return self.progress
  end

  -- 没有组装钥匙
  if self:nextProgress() == index or (self:getInteger("key") == 0) then

    self:addPlace("Key")

    self:textI18n("progress_8")

    return self.progress
  end

  -- 车没通电
  if self:nextProgress() == index or (self:getInteger("key") > 0) then
    local place1 = self:addPlace("Drive")
    local place2 = self:addPlace("Keyhole")

    place1:markButton("goKey")
    place2:markButton("key")

    self:textI18n("progress_9")

    return self.progress
  end

  -- 没有设置所有车门都可以出去
  if self:nextProgress() == index or (self:getInteger("isAllDoorUnlock") == 0) then
    local place1 = self:addPlace("Drive")
    local place2 = self:addPlace("Idrive7door")

    place1:markButton("goIdrive")

    self:textI18n("progress_11")

    return self.progress
  end

  -- 仪表还没拿到呢，先去拿仪表
  if self:nextProgress() == index or (self:getInteger("meter") == 0) then
    local place1 = self:addPlace("OutRightFront")
    self:addPlace("Roof")

    place1:imageOn("1")
    place1:markButton("roof")

    self:textI18n("progress_12")

    return self.progress
  end

  -- 手电筒盖子没有得到
  if self:nextProgress() == index or (self:getInteger("flash2") == 0) then
    local place1 = self:addPlace("Drive")
    local place2 = self:addPlace("KneeBox")

    place1:markButton("goKneeBox")
    place2:markButton("openKnee")

    self:textI18n("progress_13")

    return self.progress
  end

  -- 手电还没取得，先去拿手电
  if self:nextProgress() == index or (self:getInteger("flash1") == 0) then
    local place1 = self:addPlace("OutRear")
    local place2 = self:addPlace("TrunkMiddle")

    place1:imageOn("1")

    place1:markButton("open")
    place2:markButton("openTrunk")

    self:textI18n("progress_14")

    return self.progress
  end

  -- 没有得到完整的手电筒
  if self:nextProgress() == index or (self:getInteger("flash") == 0) then
    self:addPlace("Flash")

    self:textI18n("progress_15")

    return self.progress
  end

  -- 去后座烟灰盒使用仪表得到U盘
  if self:nextProgress() == index or (self:getInteger("udisk") == 0) then
    local place1 = self:addPlace("OutRightRear")
    local place2 = self:addPlace("RearAsh")

    place1:imageOn("0")
    place1:markButton("open")
    place2:markButton("power")

    self:textI18n("progress_20")

    return self.progress
  end

  -- 使用U盘
  if self:nextProgress() == index or (self:getInteger("udisk") ~= -1) then
    local place1 = self:addPlace("Drive")
    local place2 = self:addPlace("GloveBox")

    place1:markButton("goGloveBox")
    place2:markButton("open")

    self:textI18n("progress_24")

    return self.progress
  end

  return self:nextProgress()
end

return E2Tip
