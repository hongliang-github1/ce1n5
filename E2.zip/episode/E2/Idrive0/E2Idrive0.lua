local E2Idrive0 = class("E2Idrive0", function()
  return BasePlace.new()
end)

function E2Idrive0:arrowDown(rect)
  self:setInteger("last_idrive_pos", 1)
  self:switchPlaceZoomOut("Drive")
end

function E2Idrive0:initButton()
  self:addButton("up", 1632-120, 688, 362, 162, false)
  self:addButton("down", 1648-120, 1002, 342, 142, false)
  self:addButton("left", 1506-120, 850, 310, 150, false)
  self:addButton("right", 1820-120, 850, 314, 150, false)

  self:imageOn("Idrive/control", 752*2, 368*2):setLocalZOrder(9999)

  self.redBoxAnimate = 4
end

function E2Idrive0:recordLastPlaceName()
  return false
end

function E2Idrive0:createIdriveLabel(text_cn, text_en, fontSize, x, y, w, h, shadow)
  -- 先根据x和y坐标构造出key，尝试拿到上次的Label，如果不存在则建立新的UILabel
  -- 如果该UILabel已经创建过，则不再创建新的，而是直接使用上次的Label
  local labelName = "label_" .. x .. "_" .. y .. "_" .. w .. "_" .. h
  local label     = self:getChildByName(labelName)

  if label == nil then
    label = cc.Label:createWithSystemFont(text_cn, "Helvetica", fontSize, cc.size(w, h), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    
    label:setName(labelName)
    label:setAnchorPoint(0, 0)
  end

  label:setPosition(x, self:getContentSize().height - y)

  if i18n.getLang() ~= "chs" then
    label:setString(text_en)
  end

  if shadow then
    -- 添加阴影
    label:setColor(cc.c4b(88, 112, 160, 255))
    label:enableShadow(cc.c4b(0, 50, 149, 190), cc.size(ui.deviceToCanvas(1), ui.deviceToCanvas(1)), ui.deviceToCanvas(2))
    
  else
    label:setColor(cc.c4b(255, 255, 255, 255))
  end

  self:addChild(label)

  return label
end

-- 画红线和红框，变化的过程用动画来表达
function E2Idrive0:redrawRedBox()
  -- 得到上一次的位置 计算两个点之间的差距，然后根据延时，不断的调用方法进行绘制
  -- 如果是第一次画，则不做动画，直接画
  if self.oldStartPoint == nil then
    self:redrawRedBoxDo(self.startPoint, self.endPoint, self.kPoint, self.kSize, self.arc)

    self.oldStartPoint = self.startPoint
    self.oldEndPoint   = self.endPoint
    self.oldKPoint     = self.kPoint
    self.oldArc        = self.arc

    return
  end

  -- 开始动画
  self:disableTouch()

  self:redrawRedBoxDo(self.startPoint, self.endPoint, self.kPoint, self.kSize, self.arc)

  self.oldStartPoint = self.startPoint
  self.oldEndPoint   = self.endPoint
  self.oldKPoint     = self.kPoint
  self.oldArc        = self.arc
  
  self:enableTouch()
  
  -- self.redBoxCount  = 0
  -- self.redBoxAction = self:schedule(1/60, function()
  --   self.redBoxCount = self.redBoxCount + 1

  --   -- 这里从1到redBoxAnimate，用新的位置减去老的位置，除以redBoxAnimate乘以redBoxCount，得到的结果加到老数据上面
  --   local startPoint = cc.p(self.oldStartPoint.x + (self.startPoint.x - self.oldStartPoint.x) / self.redBoxAnimate * self.redBoxCount, self.oldStartPoint.y + (self.startPoint.y - self.oldStartPoint.y) / self.redBoxAnimate * self.redBoxCount)
    
  --   local endPoint   = cc.p(self.oldEndPoint.x + (self.endPoint.x - self.oldEndPoint.x) / self.redBoxAnimate * self.redBoxCount, self.oldEndPoint.y + (self.endPoint.y - self.oldEndPoint.y) / self.redBoxAnimate * self.redBoxCount)
    
  --   local kPoint   = cc.p(self.oldKPoint.x + (self.kPoint.x - self.oldKPoint.x) / self.redBoxAnimate * self.redBoxCount, self.oldKPoint.y + (self.kPoint.y - self.oldKPoint.y) / self.redBoxAnimate * self.redBoxCount)
    
  --   local arc    = self.oldArc + (self.arc - self.oldArc) / self.redBoxAnimate * self.redBoxCount
    
  --   self:redrawRedBoxDo(startPoint, endPoint, kPoint, self.kSize, arc)

  --   if self.redBoxCount >= self.redBoxAnimate then
  --     -- 动画结束
  --     self:enableTouch()
  --     self:unschedule(self.redBoxAction)
      
  --     self.redBoxAction  = nil
  --     self.oldStartPoint = self.startPoint
  --     self.oldEndPoint   = self.endPoint
  --     self.oldKPoint     = self.kPoint
  --     self.oldArc        = self.arc

  --     return
  --   end
  -- end)
end

function E2Idrive0:redrawRedBoxDo(startPoint, endPoint, kPoint, kSize, arc)
  local drawNode   = self:getChildByName("drawNode_box")

  if drawNode == nil then
    drawNode = cc.DrawNode:create()
    
    drawNode:setName("drawNode_box")
    drawNode:setLocalZOrder(999)
    self:addChild(drawNode)
  end

  drawNode:clear()

  -- 整个绘制由一个原点、一条斜线、一条弧和一个矩形构成
  local radius  = 10
  local rectArc = ui.deviceToCanvas(4)
  local color   = cc.c4f(1, 136/255, 114/255, 1)
  local height  = self:getContentSize().height
  startPoint    = cc.p(startPoint.x, height - startPoint.y)
  endPoint      = cc.p(endPoint.x, height - endPoint.y)
  kPoint        = cc.p(kPoint.x, height - kPoint.y)

  -- 画原点
  drawNode:drawDot(startPoint, radius, color)

  -- 画斜线
  local points = { startPoint, endPoint }
  drawNode:drawSegment(startPoint, endPoint, 2, color)

  -- 画短直线
  -- TODO 目前还不会画圆弧（弧度在arc值中），实现并不完美
  drawNode:drawSegment(endPoint, cc.p(kPoint.x, kPoint.y - kSize.height / 2), 2, color)
  -- CGContextAddArcToPoint(ctfCricle, self.endPoint.x, self.endPoint.y, self.kPoint.x, self.endPoint.y, self.arc);

  -- 画红框
  ui.drawNodeRoundRect(drawNode, cc.rect(kPoint.x, kPoint.y, kSize.width, kSize.height), 2, rectArc, color)
end

return E2Idrive0
