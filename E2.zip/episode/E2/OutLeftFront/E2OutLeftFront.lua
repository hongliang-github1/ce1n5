local E2OutLeftFront = class("E2OutLeftFront", function()
  return BasePlace.new()
end)

function E2OutLeftFront:initPhoto()
end

function E2OutLeftFront:initButton()
  self:addButton("seat", 1214, 606, 740, 468)
  self:addButton("drive", 1302, 236, 662, 364)
end

function E2OutLeftFront:arrowLeft(rect)
  self:switchPlaceLeft("OutFront")
end

function E2OutLeftFront:arrowRight(rect)
  self:switchPlaceRight("OutLeftRear")
end

function E2OutLeftFront:beforeLoad()
  if self:getInteger("key") < 0 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E2OutLeftFront:afterLoad()
end

function E2OutLeftFront:afterLoad2()
  self:cacheImage("OutFront/0")
  self:cacheImage("OutLeftRear/1")
  self:cacheImage("SeatLeftFront/0")

  if self:getInteger("key") < 0 then
    self:cacheImage("Drive/2")
  
  else
    self:cacheImage("Drive/0")
  end
end

function E2OutLeftFront:beforeUseItem(itemName)
  return false
end

function E2OutLeftFront:afterUseItem(itemName)
  return true
end

function E2OutLeftFront:seat(rect)
  self:switchPlaceZoomIn("SeatLeftFront", rect)
end

function E2OutLeftFront:drive(rect)
  self:switchPlaceZoomIn("Drive", rect)
end

return E2OutLeftFront
