local E2Idrive0 = require_safe("episode/E2/Idrive0/E2Idrive0")

local E2Idrive6 = class("E2Idrive6", function()
  return E2Idrive0.new()
end)

function E2Idrive6:initPhoto()
  self:addPhoto("status10", 192, 192)
  self:addPhoto("status2", 704, 384)
  self:addPhoto("status3", 320, 256)
end

function E2Idrive6:beforeLoad()
  self:imageOn("status0")
  self:imageOn("status10")
  self:imageOn("status2")
  self:imageOn("status3")
  self:addMenuText()
end

function E2Idrive6:afterLoad()
end

function E2Idrive6:up(rect)
  self:say("...")
end

function E2Idrive6:down(rect)
  self:say("...")
end

function E2Idrive6:left(rect)
  self:setInteger("last_idrive_pos", 6)
  self:switchPlace("Idrive")
end

function E2Idrive6:right(rect)
  self:say("...")
end

function E2Idrive6:addMenuText()
  local fontSize = 55

  -- 菜单栏下面的选项
  local x  = 332
  local rx = 1280
  local w  = 1000
  local h  = 120

  self:createIdriveLabel("车辆状态", "Vehicle status", fontSize, 320, 244+105, w, h):setLocalZOrder(9)
end

return E2Idrive6
