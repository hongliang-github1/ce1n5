local E2Beginning = class("E2Beginning", function()
  return BasePlace.new()
end)

function E2Beginning:initPhoto()
end

function E2Beginning:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E2Beginning:beforeLoad()
  -- 第一次玩，生成密码
  if userdata.getEpisodeLastPlace(userdata.currentEpisode) == "" then
    local p1 = math.random(8)
    local p2 = nil
    local p3 = nil

    repeat
      p2 = math.random(8)
    until p2 ~= p1

    repeat
      p3 = math.random(8)
    until p3 ~= p1 and p3 ~= p2

    self:setInteger("isLockPassword1", p1)
    self:setInteger("isLockPassword2", p2)
    self:setInteger("isLockPassword3", p3)
  end

  self:imageOn("trip")
end

function E2Beginning:afterLoad()
  self:click(nil)
end

function E2Beginning:afterLoad2()
  self:cacheImage("road")
  self:cacheImage("forest")
  self:cacheImage("RearSeeFront/0")
  self:cacheImage("RearSeeFront/4")

  if self:getInteger("lamp") == 0 then
    self:cacheImage("RearSeeFront/4")

  elseif self:getInteger("key") < 0 then
    self:cacheImage("RearSeeFront/10")
  
  else
    self:cacheImage("RearSeeFront/5")
  end
end

function E2Beginning:beforeUseItem(itemName)
  return false
end

function E2Beginning:afterUseItem(itemName)
  return true
end

function E2Beginning:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("road")
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("forest")
    self:sayI18n("click_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_6")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_8")

    -- 睡着动画
    self.alphaLayer = self:effectFadeBlack(nil, 1.5, 0, 0, function()
      -- 保留黑屏状态
      return true
    end)

    return
  end

  if progress == self:nextProgressIndex() then
    self:play("open")
    self:sayI18n("click_9")

    return
  end

  if progress == self:nextProgressIndex() then
    self:play("start")
    self:sayI18n("click_10")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_11")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("RearSeeFront/0")
    self:sayI18n("click_12")

    -- 醒来动画
    local fadeAction = cc.FadeOut:create(1.5)
    local doneAction = cc.CallFunc:create(function()
      self:enableTouch()
      self.alphaLayer:removeFromParent(true)

      self.alphaLayer = nil
    end)

    self:disableTouch()
    self.alphaLayer:runAction(cc.Sequence:create(fadeAction, doneAction))

    return
  end

  if progress == self:nextProgressIndex() then
    local image      = self:imageOn("RearSeeFront/4", 0)
    local fadeAction = cc.FadeIn:create(1)

    image:setOpacity(0)
    self:sayI18n("click_13")

    self:disableTouch()
    image:runAction(cc.Sequence:create(fadeAction, cc.CallFunc:create(function()
      self:enableTouch()
    end)))

    return
  end

  if progress == self:nextProgressIndex() then
    progress = 0

    self:switchPlace("RearSeeFront")

    return
  end
end

return E2Beginning
