local E2Key = class("E2Key", function()
  return BasePlace.new()
end)

function E2Key:initPhoto()
  self:addPhoto("1", 768, 448)
  self:addPhoto("2", 896, 448)
  self:addPhoto("3", 896, 448)
end

function E2Key:initButton()
  self:addButton("getKey", 0, 0, 2044, 1148, false)
end

function E2Key:arrowDown(rect)
  local placeName = self.lastPlaceName

  if placeName == nil then
    placeName = "Drive"
  end

  self:switchPlaceZoomOut(placeName)
end

function E2Key:beforeLoad()
  self:imageOn("0")
end

function E2Key:afterLoad()
  self.clickSum = 0
end

function E2Key:recordLastPlaceName()
  return false
end

function E2Key:beforeUseItem(itemName)
  if itemName == "key1" then
    if self.useKey then
      -- 如果已经使用过金属钥匙了就不能在当前场景下再次使用
      return false
    end

    return true
  end

  return false
end

function E2Key:afterUseItem(itemName)
  if itemName == "key1" then
    -- 使用钥匙的金属部分
    self:sayI18n("afterUseItem_1")
    self:imageOn("1")
    self:hideArrowButton()
    self:disableAlwaysUseItem()

    self.useKey = true

    return true
  end

  return true
end

function E2Key:getKey(rect)
  if not self.useKey then
    self:sayI18n("getKey_1")

    return
  end

  -- 使用钥匙之后，要移除掉1
  if self:imageIsOn("1") then
    self:imageOff("1")
  end

  self.clickSum = self.clickSum + 1

  if self.clickSum == 1 then
    -- 设置两个钥匙拼在一起的图片
    self:sayI18n("getKey_2")
    self:imageOn("2")

    return
  end

  if self.clickSum == 2 then
    -- 得到完整车钥匙，设置两个道具都已经不能使用了
    self:voidItem("key1")
    self:voidItem("key2")
    self:imageOn("3")
    self:imageOff("2")
    self:getItem("key")
    self:sayI18n("getKey_3")
    self:showArrowButton()
  end
end

return E2Key
