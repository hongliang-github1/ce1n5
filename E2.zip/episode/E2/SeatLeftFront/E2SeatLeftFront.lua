local E2SeatLeftFront = class("E2SeatLeftFront", function()
  return BasePlace.new()
end)

function E2SeatLeftFront:initPhoto()
end

function E2SeatLeftFront:initButton()
  self:addButton("under", 192, 670, 792, 478)
end

function E2SeatLeftFront:arrowDown(rect)
  self:switchPlaceZoomOut("OutLeftFront")
end

function E2SeatLeftFront:beforeLoad()
  self:imageOn("0")
end

function E2SeatLeftFront:afterLoad()
end

function E2SeatLeftFront:afterLoad2()
  if self:getInteger("key") < 0 then
    self:cacheImage("OutLeftFront/1")
  else
    self:cacheImage("OutLeftFront/0")
  end

  if self:getInteger("key") < 0 then
    self:cacheImage("OutLeftFront/1")
  else
    self:cacheImage("OutLeftFront/0")
  end
  
  self:cacheImage("SeatUnderLeftFront/0")
  
end

function E2SeatLeftFront:beforeUseItem(itemName)
  return false
end

function E2SeatLeftFront:afterUseItem(itemName)
  return true
end

function E2SeatLeftFront:under(rect)
  self:switchPlaceZoomIn("SeatUnderLeftFront", rect)
end

return E2SeatLeftFront
