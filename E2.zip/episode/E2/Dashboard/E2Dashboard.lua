local E2Dashboard = class("E2Dashboard", function()
  return BasePlace.new()
end)

function E2Dashboard:initPhoto()
  self:addPhoto("lblue", 896, 192)
  self:addPhoto("lgreen", 704, 192)
  self:addPhoto("lorange", 1024, 192)
end

function E2Dashboard:initButton()
end

function E2Dashboard:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E2Dashboard:beforeLoad()
  -- 是否开启示宽灯或者大灯 如果开启使用1,否则使用0
  if self:getInteger("key") < 0 then
    self:imageOn("1")
  else
    self:imageOn("0")
  end
end

function E2Dashboard:afterLoad()

end

function E2Dashboard:afterLoad2()
  if self:getInteger("key") < 0 then
    self:cacheImage("Drive/2")
  
  else
    self:cacheImage("Drive/0")
  end
end

function E2Dashboard:beforeUseItem(itemName)
  return false
end

function E2Dashboard:afterUseItem(itemName)
  return true
end

return E2Dashboard
