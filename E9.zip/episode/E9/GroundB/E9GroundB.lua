local E9GroundB = class("E9GroundB", function()
  return BasePlace.new()
end)

function E9GroundB:initPhoto()
  self:addPhoto("2", 512, 640)
  self:addPhoto("3", 576, 768)
end

function E9GroundB:initButton()
  self:addButton("open", 342, 60, 1112, 1088)
end

function E9GroundB:arrowLeft(rect)
  self:switchPlaceLeft("WallDrawer")
end

function E9GroundB:beforeLoad()
  self:imageOn("0")
end

function E9GroundB:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9GroundB:afterLoad2()  
  self:cacheImage("1")
  self:cacheImage("WallDrawer/0")
end

function E9GroundB:beforeUseItem(itemName)
  return false
end

function E9GroundB:afterUseItem(itemName)
  return true
end

function E9GroundB:open(rect)
  if self:imageIsOn("1") then
    -- 拿道具，如果没有道具则关柜门
    if self:getInteger("remoter") == 0 and "ground_b" == self:getString("remoter_pos") then
      self:imageOff("2")
      self:getItem("remoter")
      self:sayI18n("open_1")
      
      return
    end
    
    if self:getInteger("paper") == 0 and "ground_b" == self:getString("paper_pos") then
      self:imageOff("3")
      self:getItem("paper")
      self:sayI18n("open_2")
      
      return
    end
    
    -- 关上抽屉
    self:imageOff("2")
    self:imageOff("3")
    self:imageOn("0")
    self:play("cabinet")
    self:sayI18n("open_3")
    
    return
  end
  
  -- 打开柜门
  self:imageOn("1")
  self:play("cabinet")
  
  -- 这里随机出现控制器或者纸
  if self:getInteger("remoter") == 0 and "ground_b" == self:getString("remoter_pos") then
    self:imageOn("2")
    self:sayI18n("open_4")
    
    return
  end
  
  if self:getInteger("paper") == 0 and "ground_b" == self:getString("paper_pos") then
    self:imageOn("3")
    self:sayI18n("open_5")
    
    return
  end
  
  self:sayI18n("open_6")
end

return E9GroundB
