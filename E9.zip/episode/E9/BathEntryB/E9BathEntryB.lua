local E9BathEntryB = class("E9BathEntryB", function()
  return BasePlace.new()
end)

function E9BathEntryB:initPhoto()
  self:addPhoto("1", 128, 576)
  self:addPhoto("2", 128, 960)
  self:addPhoto("3", 192, 768)
end

function E9BathEntryB:initButton()
  self:addButton("goTub", 122, 656, 884, 414)
end

function E9BathEntryB:arrowDown(rect)
  self:switchPlaceZoomOut("WayLeft")
end

function E9BathEntryB:arrowLeft(rect)
  self:switchPlaceLeft("BathSeeA")
end

function E9BathEntryB:arrowRight(rect)
  self:switchPlaceRight("BathEntryA")
end

function E9BathEntryB:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("tub_screen_on") == 1 then
    self:imageOn("1")
  end
  
  if self:getInteger("tub_handle_switch") > 0 then
    self:imageOn("2")
    self:imageOn("3")
  end
end

function E9BathEntryB:afterLoad()
  if "BathDoorB" == self.lastPlaceName or "WayLeft" == self.lastPlaceName then
    if self:getInteger("first_entry_bath") > 0 then
      self:sayI18n("afterLoad_1")
      
    else
      self:setInteger("first_entry_bath", 1)
      self:sayI18n("afterLoad_2")
    end
  end
end

function E9BathEntryB:afterLoad2()  
  self:cacheImage("WayLeft/0")
  self:cacheImage("BathSeeA/0")
  self:cacheImage("BathEntryA/0")
  self:cacheImage("Tub/0")
end

function E9BathEntryB:beforeUseItem(itemName)
  return false
end

function E9BathEntryB:afterUseItem(itemName)
  return true
end

function E9BathEntryB:goTub(rect)
  self:switchPlaceZoomIn("Tub", rect)
end

return E9BathEntryB
