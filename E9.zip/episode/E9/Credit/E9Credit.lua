local E9Credit = class("E9Credit", function()
  return BaseCredit.new()
end)

function E9Credit:afterCreate()
  -- 构造滚动字幕
  self:addLabelI18n(1.1, "beforeLoad_2")
  
  -- 显示通关时间
  -- NSString *timingString  = [self timingString]
  -- NSString *labelStr    = UikitEnhancement:textByI18nDict("beforeLoad_3")
  
  -- self:addLabelI18n(1, [labelStr stringByAppendingFormat:"%@", timingString)]
  
  self:addLabelI18n(1, "beforeLoad_4")
  
  self:addBlank()
  
  self:addLabelI18n(1, "beforeLoad_5")
  
  self:addImage("hotel")
  
  self:addBlank()
  
  self:addLabelI18n(1, "beforeLoad_6")
  
  self:addLabelI18n(1, "beforeLoad_7")
  
  self:addLabelI18n(1, "beforeLoad_8")
  
  self:addLabelI18n(1, "beforeLoad_9")
  
  self:addLabelI18n(1, "beforeLoad_10")
  
  self:addBlank()
  
  self:playMusic("credit")
end

return E9Credit
