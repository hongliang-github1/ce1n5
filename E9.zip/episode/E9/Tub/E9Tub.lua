local E9Tub = class("E9Tub", function()
  return BasePlace.new()
end)

function E9Tub:initPhoto()
  self:addPhoto("80", 320, 384)
  self:addPhoto("screen", 768, 0)
end

function E9Tub:initButton()
  self:addButton("goTubHandle", 52, 442, 358, 360)
  self:addButton("goTubKeypad", 574, 102, 242, 236)
end

function E9Tub:arrowDown(rect)
  self:switchPlaceZoomOut("BathEntryB")
end

function E9Tub:beforeLoad()
  self:imageOn("0")
end

function E9Tub:afterLoad()

end

function E9Tub:afterLoad2()
  e9.removeCacheBed(self)
  
  self:cacheImage("BathEntryB/0")
  self:cacheImage("TubHandle/0")
  self:cacheImage("TubKeypad/0")
end

function E9Tub:beforeUnload()

end

function E9Tub:beforeUseItem(itemName)
  return false
end

function E9Tub:afterUseItem(itemName)
  return true
end

function E9Tub:goTubHandle(rect)
  self:switchPlaceZoomIn("TubHandle", rect)
end

function E9Tub:goTubKeypad(rect)
  self:switchPlaceZoomIn("TubKeypad", rect)
end

return E9Tub
