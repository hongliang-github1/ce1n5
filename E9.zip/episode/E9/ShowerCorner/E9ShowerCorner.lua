local E9ShowerCorner = class("E9ShowerCorner", function()
  return BasePlace.new()
end)

function E9ShowerCorner:initPhoto()
  self:addPhoto("3", 512, 512)
end

function E9ShowerCorner:initButton()
  self:addButton("getKettle", 400, 430, 536, 524)
end

function E9ShowerCorner:arrowDown(rect)
  self:switchPlaceZoomOut("Shower")
end

function E9ShowerCorner:beforeLoad()
  self:imageOn("0")

  if self:getInteger("kettle") == 0 then
    self:imageOn("3")
  end
end

function E9ShowerCorner:afterLoad()
  if self:imageIsOn("3") then
    self:sayI18n("afterLoad_1")
  end
end

function E9ShowerCorner:afterLoad2()  
  self:cacheImage("Shower/0")
end

function E9ShowerCorner:beforeUseItem(itemName)
  return false
end

function E9ShowerCorner:afterUseItem(itemName)
  return true
end

function E9ShowerCorner:getKettle(rect)
  if self:getInteger("kettle") ~= 0 then
    self:sayI18n("getItem_4")
    
    return
  end

  -- 拿道具
  self:imageOff("3")
  self:getItem("kettle")
  self:sayI18n("getItem_1")

end

return E9ShowerCorner
