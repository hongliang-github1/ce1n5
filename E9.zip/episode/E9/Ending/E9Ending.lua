local E9Ending = class("E9Ending", function()
  return BasePlace.new()
end)

function E9Ending:initPhoto()
end

function E9Ending:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E9Ending:beforeLoad()
  -- 先显示关着的状态，黑屏
  self:imageOn("Door/2")
  
  self.blackLayer = self:createLayerColor(cc.c4b(0, 0, 0, 255))

  self.blackLayer:setOpacity(255)
end

function E9Ending:afterLoad()
  if self.tipMode then
    return
  end

  -- 屏幕恢复，再开门
  local fadeAction = cc.FadeOut:create(2)
  local doneAction = cc.CallFunc:create(function()
    self:enableTouch()
    self.blackLayer:removeFromParent(true)

    self.blackLayer = nil

    self:imageOn("Door/6")
    self:click(nil)
  end)

  self:disableTouch()
  self.blackLayer:runAction(cc.Sequence:create(fadeAction, doneAction))
end

function E9Ending:afterLoad2()
end

function E9Ending:beforeUseItem(itemName)
  return false
end

function E9Ending:afterUseItem(itemName)
  return true
end

function E9Ending:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:play("doorknob")
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOff("Door/2")
    self:imageOn("Outside/0")
    self:imageOn("Outside/3")
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_3")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:effectFadeBlack(nil, 1.5, 0, 0, function()
      userdata.setEpisodePassed(self.episodeName)

      -- TODO 设置通关时间

      -- TODO 进入通关字幕CreditScene
      cc.Director:getInstance():replaceScene(BaseScene.create("CreditScene"))

      -- 保留黑屏状态
      return true
    end)
    
    return
  end
end

return E9Ending
