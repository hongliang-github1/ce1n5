local E9SwitchB = class("E9SwitchB", function()
  return BasePlace.new()
end)

function E9SwitchB:initPhoto()
  self:addPhoto("1", 768, 448)
end

function E9SwitchB:initButton()
  self:addButton("open", 676, 394, 490, 472)
end

function E9SwitchB:arrowDown(rect)
  self:switchPlaceZoomOut("Mirror")
end

function E9SwitchB:beforeLoad()
  self:imageOn("0")
end

function E9SwitchB:afterLoad()

end

function E9SwitchB:afterLoad2()
  self:cacheImage("Mirror/0")
end

function E9SwitchB:beforeUseItem(itemName)
  return false
end

function E9SwitchB:afterUseItem(itemName)
  return true
end

function E9SwitchB:open(rect)
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:play("airswitch")
    self:sayI18n("open_1")
    
    return
  end
  
  self:imageOn("1")
  self:play("airswitch")
  self:sayI18n("open_2")
end

return E9SwitchB
