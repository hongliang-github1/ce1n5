local E9ToiletTrash = class("E9ToiletTrash", function()
  return BasePlace.new()
end)

function E9ToiletTrash:initPhoto()
  self:addPhoto("1", 896, 576)
end

function E9ToiletTrash:initButton()
  self:addButton("goToiletTrash", 734, 348, 532, 598)
end

function E9ToiletTrash:arrowDown(rect)
  self:switchPlaceZoomOut("Toilet")
end

function E9ToiletTrash:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("spray") == 0 then
    self:imageOn("1")
  end
end

function E9ToiletTrash:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9ToiletTrash:afterLoad2()
  self:cacheImage("ToiletTrashNear/0")
  self:cacheImage("Toilet/0")
end

function E9ToiletTrash:beforeUseItem(itemName)
  return false
end

function E9ToiletTrash:afterUseItem(itemName)
  return true
end

function E9ToiletTrash:goToiletTrash(rect)
  self:switchPlaceZoomIn("ToiletTrashNear", rect)
end

return E9ToiletTrash
