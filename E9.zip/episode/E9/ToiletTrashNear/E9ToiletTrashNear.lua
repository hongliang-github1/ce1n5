local E9ToiletTrashNear = class("E9ToiletTrashNear", function()
  return BasePlace.new()
end)

function E9ToiletTrashNear:initPhoto()
  self:addPhoto("1", 832, 640)
end

function E9ToiletTrashNear:initButton()
  self:addButton("click", 464, 232, 1036, 916)
end

function E9ToiletTrashNear:arrowDown(rect)
  self:switchPlaceZoomOut("ToiletTrash")
end

function E9ToiletTrashNear:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("spray") == 0 then
    self:imageOn("1")
  end
end

function E9ToiletTrashNear:afterLoad()
  if self:imageIsOn("1") then
    self:sayI18n("afterLoad_1")
    
  else
    self:sayI18n("afterLoad_2")
  end
end

function E9ToiletTrashNear:afterLoad2()
  self:cacheImage("ToiletTrash/0")
end

function E9ToiletTrashNear:beforeUseItem(itemName)
  return false
end

function E9ToiletTrashNear:afterUseItem(itemName)
  return true
end

function E9ToiletTrashNear:click(rect)
  if self:getInteger("spray") == 0 then
    self:imageOff("1")
    self:getItem("spray")
    self:sayI18n("click_1")
    
    return
  end
  
  self:sayI18n("click_2")
end

return E9ToiletTrashNear
