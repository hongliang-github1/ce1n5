local E9Kettle = class("E9Kettle", function()
  return BasePlace.new()
end)

function E9Kettle:initPhoto()
end

function E9Kettle:initButton()
  self:addButton("click", 0, 0, 2044, 1148)
end

function E9Kettle:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "Entry")
end

function E9Kettle:beforeLoad()
  self:imageOn("0")
end

function E9Kettle:afterLoad()
  self:click(nil)
end

function E9Kettle:afterLoad2()
end

function E9Kettle:recordLastPlaceName()
  return false
end

function E9Kettle:beforeUseItem(itemName)
  return false
end

function E9Kettle:afterUseItem(itemName)
  return true
end

function E9Kettle:click(rect)
  -- 根据水壶里热水的状态，水壶里是热水
  if self:getInteger("kettle_hot_water") == 2 then
    self:say(self.i18nTable["table_1"] .. " (" .. self:getInteger("kettle_level") .. " ml)")

    return
  end
  
  self:sayI18n("click_1")
end

return E9Kettle
