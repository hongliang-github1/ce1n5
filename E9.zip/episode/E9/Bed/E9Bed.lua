local E9Bed = class("E9Bed", function()
  return BasePlace.new()
end)

function E9Bed:initPhoto()
end

function E9Bed:initButton()
  self:addButton("pillow", 280, 0, 1600, 538)
  self:addButton("nothing", 738, 540, 656, 384)
end

function E9Bed:arrowDown(rect)
  self:switchPlaceZoomOut("Entry")
end

function E9Bed:beforeLoad()
  self:imageOn("0")
end

function E9Bed:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9Bed:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("2")

  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")
    
  else
    self:cacheImage("Entry/50")
  end
end

function E9Bed:beforeUseItem(itemName)
  return false
end

function E9Bed:afterUseItem(itemName)
  return true
end

function E9Bed:pillow(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("pillow_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:sayI18n("pillow_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("0")
    self:sayI18n("pillow_3")
    
    self.progress = nil
    
    return
  end
end

function E9Bed:nothing(rect)
  self:sayI18n("nothing_1")
end

return E9Bed
