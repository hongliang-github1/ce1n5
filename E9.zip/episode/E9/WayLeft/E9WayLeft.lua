local E9WayLeft = class("E9WayLeft", function()
  return BasePlace.new()
end)

function E9WayLeft:initPhoto()
  self:addPhoto("1", 1216, 0)
  self:addPhoto("2", 1216, 0)
end

function E9WayLeft:initButton()
  self:addButton("open", 1256, 150, 392, 976)
  self:addButton("goFlowerB", 672, 474, 550, 674)
end

function E9WayLeft:arrowRight(rect)
  self:switchPlaceRight("Wall")
end

function E9WayLeft:arrowDown(rect)
  self:switchPlaceZoomOut("Entry")
end

function E9WayLeft:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_b_open") == 1 then
    if self:getInteger("room_brighter") == 0 then
      self:imageOn("1")
      
    else
      self:imageOn("2")
    end
  end
end

function E9WayLeft:afterLoad()

end

function E9WayLeft:afterLoad2()
  e9.removeCacheBath(self)
  
  self:cacheImage("WayB1/0")
  
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")
    
  else
    self:cacheImage("Entry/50")
  end
  
  self:cacheImage("BathEntryB/0")
  self:cacheImage("BathDoorB/0")
end

function E9WayLeft:beforeUseItem(itemName)
  return false
end

function E9WayLeft:afterUseItem(itemName)
  return true
end

function E9WayLeft:open(rect)
  -- 门帘已经打开之后，则直接进入浴室，而不再通过BathDoorA中转
  if self:imageIsOn("2") then
    self:switchPlaceZoomIn("BathEntryB", cc.rect(642 * 2, 188 * 2, 206 * 2, 242 * 2))
    
  else
    self:switchPlaceZoomIn("BathDoorB", cc.rect(642 * 2, 188 * 2, 206 * 2, 242 * 2))
  end
end

function E9WayLeft:goFlowerB(rect)
  self:switchPlaceZoomIn("FlowerB", rect)
end

return E9WayLeft
