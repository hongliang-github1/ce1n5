local E9FlowerB = class("E9FlowerB", function()
  return BasePlace.new()
end)

function E9FlowerB:initPhoto()
  self:addPhoto("2", 1280, 768)
  self:addPhoto("3", 1280, 768)
end

function E9FlowerB:initButton()
  self:addButton("open", 860, 348, 800, 800)
end

function E9FlowerB:arrowDown(rect)
  local pName = "WayA2"

  if "WayLeft" == self.lastPlaceName then
    pName = self.lastPlaceName
  end

  self:switchPlaceZoomOut(pName)
end

function E9FlowerB:beforeLoad()
  self:imageOn("0")
end

function E9FlowerB:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9FlowerB:afterLoad2()  
  self:cacheImage("1")
end

function E9FlowerB:beforeUseItem(itemName)
  return false
end

function E9FlowerB:afterUseItem(itemName)
  return true
end

function E9FlowerB:open(rect)
  if self:imageIsOn("1") then
    -- 如果有道具，则拿道具
    if self:getInteger("b330") == 0 and self:getString("b3_pos") == "flower_b" then
      self:imageOff("3")
      self:getItem("b330")
      self:sayI18n("open_1")
      
      return
    end
    
    if self:getInteger("b600") == 0 and self:getString("b6_pos") == "flower_b" then
      self:imageOff("2")
      self:getItem("b600")
      self:sayI18n("open_2")
      
      return
    end
    
    -- 关上帘子
    self:imageOn("0")
    self:imageOff("2")
    self:imageOff("3")
    self:play("beadcurtain")
    self:sayI18n("open_3")
    
    return
  end
  
  -- 拉开帘子
  self:imageOn("1")
  self:play("beadcurtain")
  
  -- 这里随机显示b330或b600瓶子
  if self:getInteger("b330") == 0 and self:getString("b3_pos") == "flower_b" then
    self:imageOn("3")
    self:sayI18n("open_4")
    
    return
  end
  
  if self:getInteger("b600") == 0 and self:getString("b6_pos") == "flower_b" then
    self:imageOn("2")
    self:sayI18n("open_5")
    
    return
  end
  
  self:sayI18n("open_6")
end

return E9FlowerB
