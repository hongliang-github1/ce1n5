local E9BathSeeB = class("E9BathSeeB", function()
  return BasePlace.new()
end)

function E9BathSeeB:initPhoto()
  self:addPhoto("1", 576, 320)
  self:addPhoto("2", 1280, 384)
end

function E9BathSeeB:initButton()
  self:addButton("goMirror", 888, 348, 588, 534)
  self:addButton("goShower", 1510, 350, 400, 536)
  self:addButton("goSpray", 352, 362, 242, 210)
  self:addButton("goYellow", 226, 644, 354, 224)
end

function E9BathSeeB:arrowRight(rect)
  self:switchPlaceRight("BathSeeA")
end

function E9BathSeeB:arrowLeft(rect)
  self:switchPlaceLeft("BathEntryA")
end

function E9BathSeeB:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_a_open") == 1 then
    self:imageOn("1")
  end
  
  if self:getInteger("bath_door_b_open") == 1 then
    self:imageOn("2")
  end
end

function E9BathSeeB:afterLoad()

end

function E9BathSeeB:afterLoad2()
  e9.removeCacheBed(self)
  
  self:cacheImage("BathSeeA/0")
  self:cacheImage("BathEntryA/0")
  self:cacheImage("Mirror/0")
  self:cacheImage("Shower/0")
  self:cacheImage("Spray/0")
  self:cacheImage("Yellow/0")
end

function E9BathSeeB:beforeUseItem(itemName)
  return false
end

function E9BathSeeB:afterUseItem(itemName)
  return true
end

function E9BathSeeB:goMirror(rect)
  self:switchPlaceZoomIn("Mirror", rect)
end

function E9BathSeeB:goShower(rect)
  self:switchPlaceZoomIn("Shower", rect)
end

function E9BathSeeB:goSpray(rect)
  self:switchPlaceZoomIn("Spray", rect)
end

function E9BathSeeB:goYellow(rect)
  self:switchPlaceZoomIn("Yellow", rect)
end

return E9BathSeeB
