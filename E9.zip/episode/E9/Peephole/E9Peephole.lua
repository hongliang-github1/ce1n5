local E9Peephole = class("E9Peephole", function()
  return BasePlace.new()
end)

function E9Peephole:initPhoto()
end

function E9Peephole:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E9Peephole:arrowDown(rect)
  self:switchPlaceZoomOut("Door")
end

function E9Peephole:beforeLoad()
  self:imageOn("0")
end

function E9Peephole:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9Peephole:afterLoad2()  
  self:cacheImage("1" .. i18n.getLang())

  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Door/0")

  else    
    self:cacheImage("Door/2")
  end
end

function E9Peephole:beforeUseItem(itemName)
  return false
end

function E9Peephole:afterUseItem(itemName)
  return true
end

function E9Peephole:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:hideArrowButton()
    self:imageOn("1" .. i18n.getLang())
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    -- 对话结束，回到Door
    self:switchPlaceZoomOut("Door")
    
    return
  end
end

return E9Peephole
