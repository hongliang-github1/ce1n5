local E9WallPlug = class("E9WallPlug", function()
  return BasePlace.new()
end)

function E9WallPlug:initPhoto()
  self:addPhoto("1", 576, 448)
  self:addPhoto("2", 576, 256)
  self:addPhoto("3", 576, 256)
end

function E9WallPlug:initButton()
  self:addButton("click", 580, 278, 1004, 812)
end

function E9WallPlug:arrowDown(rect)
  self:switchPlaceZoomOut("WayA2")
end

function E9WallPlug:beforeLoad()
  self:imageOn("0")
end

function E9WallPlug:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9WallPlug:afterLoad2()  
  self:cacheImage("WayA2/0")
end

function E9WallPlug:beforeUseItem(itemName)
  if "kettle" == itemName and not self:imageIsOn("2") then
    return true
  end
  
  return false
end

function E9WallPlug:afterUseItem(itemName)
  if "kettle" == itemName then
    self:imageOn("2")
    self:sayI18n("afterUseItem_2")
    
    return true
  end
  
  return true
end

function E9WallPlug:click(rect)
  if self:imageIsOn("3") then
    self:sayI18n("click_1")
    
    return
  end
  
  if self:imageIsOn("2") then
    self:imageOn("3")
    self:play("kettle")
    self:sayI18n("click_2")
    
    return
  end
  
  self:sayI18n("click_4")
end

return E9WallPlug
