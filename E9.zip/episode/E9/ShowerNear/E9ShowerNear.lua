local E9ShowerNear = class("E9ShowerNear", function()
  return BasePlace.new()
end)

function E9ShowerNear:initPhoto()
end

function E9ShowerNear:initButton()
  self:addButton("click", 364, 142, 1260, 1006)
end

function E9ShowerNear:arrowDown(rect)
  self:switchPlaceZoomOut("Shower")
end

function E9ShowerNear:beforeLoad()
  self:imageOn("0")
end

function E9ShowerNear:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9ShowerNear:afterLoad2()
  self:cacheImage("Shower/0")
end

function E9ShowerNear:beforeUseItem(itemName)
  return false
end

function E9ShowerNear:afterUseItem(itemName)
  return true
end

function E9ShowerNear:click(rect)
  self:sayI18n("click_1")
end

return E9ShowerNear
