local E9Entry = class("E9Entry", function()
  return BasePlace.new()
end)

function E9Entry:initPhoto()
  self:addPhoto("13", 1280, 704)
  self:addPhoto("33", 1280, 704)
  self:addPhoto("43", 1280, 704)
  self:addPhoto("53", 1280, 704)
end

function E9Entry:initButton()
  self:addButton("goBed", 892, 756, 438, 280, false)
  self:addButton("goBed1", 596, 758, 294, 278, false)
  self:addButton("goBedLeft", 742, 474, 190, 280)
  self:addButton("goBedRight", 1334, 464, 260, 468)
  self:addButton("goSofa", 0, 648, 356, 370)
  self:addButton("goWayRight", 1604, 354, 304, 580)
  self:addButton("goWayLeft", 466, 184, 274, 570)
  self:addButton("goWayLeft1", 742, 186, 122, 286, false)
  self:addButton("goBed2", 934, 612, 400, 144)
end

function E9Entry:nothing()
  -- 灯没打开，哪也去不了，只能转身使用房卡开灯
  self:sayI18n("nothing_1")
end

function E9Entry:arrowRight(rect)
  self:switchPlaceRight("Door")
end

function E9Entry:beforeLoad()
  -- 房间灯还没有打开
  if self:getInteger("room_switch") == 0 then
    self:imageOn("0")
    
    return
  end

  self:imageOn("50")
    
  -- -- 右边台灯这里根据状态显示控制器
  -- if self:getInteger("remoter") < 0 then
  --   self:imageOn("53")
  -- end

  
  -- -- 右边台灯这里根据状态显示控制器
  -- if self:getInteger("remoter") < 0 then
  --   self:imageOn("13")
  -- end
end

function E9Entry:afterLoad()
  -- 门被自然关上，再也打不开了。手机没信号，无法联络外界，只能自己想办法
  if "Outside"  == self.lastPlaceName then
    -- 播放门被关上的音效
    self:play("doorknob")
    self:sayI18n("afterLoad_1")
  end
end

function E9Entry:afterLoad2()
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("50")
  end

  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Door/0")
    
  else  
    self:cacheImage("Door/2")
  end

  self:cacheImage("Bed/0")
end

function E9Entry:beforeUseItem(itemName)
  return false
end

function E9Entry:afterUseItem(itemName)
  return true
end

function E9Entry:goBed(rect)
  -- 灯没打开，哪也去不了，只能转身使用房卡开灯
  if self:getInteger("room_switch") == 0 then
    self:nothing()
    
    return
  end
  
  self:switchPlaceZoomIn("Bed", cc.rect(417 * 2, 346 * 2, 340, 290))
end

function E9Entry:goBed1(rect)
  self:goBed(nil)
end

function E9Entry:goBed2(rect)
  self:goBed(nil)
end

function E9Entry:goBedLeft(rect)
  -- 灯没打开，哪也去不了，只能转身使用房卡开灯
  if self:getInteger("room_switch") == 0 then
    self:nothing()
    
    return
  end
  
  self:switchPlaceZoomIn("BedLeft", rect)
end

function E9Entry:goBedRight(rect)
  -- 灯没打开，哪也去不了，只能转身使用房卡开灯
  if self:getInteger("room_switch") == 0 then
    self:nothing()
    
    return
  end
  
  self:switchPlaceZoomIn("BedRight", rect)
end

function E9Entry:goSofa(rect)
  -- 灯没打开，哪也去不了，只能转身使用房卡开灯
  if self:getInteger("room_switch") == 0 then
    self:nothing()
    
    return
  end
  
  self:switchPlaceZoomIn("Sofa", rect)
end

function E9Entry:goWayRight(rect)
  -- 灯没打开，哪也去不了，只能转身使用房卡开灯
  if self:getInteger("room_switch") == 0 then
    self:nothing()
    
    return
  end
  
  self:switchPlaceZoomIn("WayRight", rect)
end

function E9Entry:goWayLeft(rect)
  -- 灯没打开，哪也去不了，只能转身使用房卡开灯
  if self:getInteger("room_switch") == 0 then
    self:nothing()
    
    return
  end
  
  self:switchPlaceZoomIn("WayLeft", cc.rect(260 * 2, 203 * 2, 152 * 2, 192 * 2))
end

function E9Entry:goWayLeft1(rect)
  -- 灯没打开，哪也去不了，只能转身使用房卡开灯
  if self:getInteger("room_switch") == 0 then
    self:nothing()
    
    return
  end
  
  self:switchPlaceZoomIn("WayLeft", cc.rect(260 * 2, 203 * 2, 152 * 2, 192 * 2))
end

return E9Entry
