local E9BathDoorB = class("E9BathDoorB", function()
  return BasePlace.new()
end)

function E9BathDoorB:initPhoto()
  self:addPhoto("1", 576, 0)
  self:addPhoto("2", 576, 0)
end

function E9BathDoorB:initButton()
  self:addButton("open", 710, 0, 730, 1040)
end

function E9BathDoorB:arrowDown(rect)
  self:switchPlaceZoomOut("WayLeft")
end

function E9BathDoorB:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_b_open") == 1 then
    if self:getInteger("room_brighter") == 0 then
      self:imageOn("1")
      
    else
      self:imageOn("2")
    end
  end
end

function E9BathDoorB:afterLoad()
  if "Remoter" == self.lastSceneName and self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")
    
  elseif self:getInteger("bath_door_b_open") < 1 then
    self:sayI18n("afterLoad_2")
  end
end

function E9BathDoorB:afterLoad2()
  self:cacheImage("WayLeft/0")
  self:cacheImage("BathEntryB/0")
end

function E9BathDoorB:beforeUseItem(itemName)
  return false
end

function E9BathDoorB:afterUseItem(itemName)
  return true
end

function E9BathDoorB:open(rect)
  -- 门帘已经打开之后
  if self:getInteger("bath_door_b_open") == 1 then
    -- 如果还没有使灯变的更亮，那么进入全黑场景
    if self:getInteger("room_brighter") == 0 then
      self:switchPlaceZoomIn("BathBlack", cc.rect(704, 276, 736, 504))
      
      return
    end
    
    -- 进入浴室
    self:switchPlaceZoomIn("BathEntryB", cc.rect(704, 276, 736, 504))
    
    return
  end
  
  -- 开门帘
  self:setInteger("bath_door_b_open", 1)
  
  -- 当灯还没更亮的时候
  if self:getInteger("room_brighter") == 0 then
    self:imageOn("1")
    self:sayI18n("open_1")
    
    return
  end
  
  self:imageOn("2")
  self:sayI18n("open_2")
end

return E9BathDoorB
