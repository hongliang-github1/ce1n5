local E9Paper = class("E9Paper", function()
  return BasePlace.new()
end)

function E9Paper:initPhoto()
  self:addPhoto("1", 384, 128)
  self:addPhoto("2", 960, 128)
  self:addPhoto("3", 0, 192)
  self:addPhoto("4chs", 256, 448)
  self:addPhoto("4en", 256, 448)
  self:addPhoto("ml1050", 320, 448)
  self:addPhoto("ml1140", 320, 448)
  self:addPhoto("ml1380", 320, 448)
  self:addPhoto("ml1410", 320, 448)
  self:addPhoto("ml1710", 320, 448)
  self:addPhoto("ml1740", 320, 448)
  self:addPhoto("ml1860", 320, 448)
  self:addPhoto("ml810", 320, 448)
  self:addPhoto("ml870", 320, 448)
end

function E9Paper:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E9Paper:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "Entry")
end

function E9Paper:beforeLoad()
  self:imageOn("0")
  
  -- 如果已经使用过纸巾得到字符密码了，那么就直接显示出来
  if self:getInteger("tissue") < 0 then
    if "chs" == i18n.getLang() then
      self:imageOn("4chs")
      
    else
      self:imageOn("4en")
    end
    
    self:imageOn("ml" .. self:getString("paper_password"))
  end
end

function E9Paper:afterLoad()
  if self:imageIsOn("4chs") or self:imageIsOn("4en") then
    self:sayI18n("afterLoad_1")
    
    return
  end

  self:sayI18n("afterLoad_2")
end

function E9Paper:afterLoad2()
end

function E9Paper:recordLastPlaceName()
  return false
end

function E9Paper:beforeUseItem(itemName)
  if "tissue" == itemName then
    return not self.tissued
  end
  
  return false
end

function E9Paper:afterUseItem(itemName)
  if "tissue" == itemName then
    self.tissued = true
    
    self:imageOn("1")

    if self:getInteger("tissue_sprayed") > 0 then
      self:sayI18n("afterUseItem_1")

    else
      self:sayI18n("afterUseItem_2")
    end
    
    return true
  end
  
  return true
end

function E9Paper:click(rect)
  -- 如果擦的纸已经使用过了，直接提示
  if self:getInteger("tissue") < 0 then
    self:sayI18n("click_2")
  
    return
  end

  if self.tissued then
    -- 如果还没往左边擦，先往左边擦
    if not self.lefted then
      self:imageOff("1")
      self:imageOn("3")

      self.lefted = true

      return
    end

    -- 如果还没往右边擦，再往右边擦一下
    if not self.righted then
      self:imageOff("3")
      self:imageOn("2")
      self:sayI18n("handleSwipeFrom_4")

      self.righted = true
      

      return
    end

    -- 都擦过了，先拿开纸巾，然后判断是不是需要显示数字
    self.tissued = false
    self.lefted  = false
    self.righted = false

    self:imageOff("2")
    self:sayI18n("handleSwipeFrom_1")

    -- 纸没有喷雾，提示没效果，如果喷雾过了，提示上面的数字
    if self:getInteger("tissue_sprayed") ~= 1 then
      self:sayI18n("handleSwipeFrom_3")

      return
    end

    -- 禁止屏幕点击，开始动画
    self:disableTouch()

    if "chs" == i18n.getLang() then
      self.imageView1 = self:imageOn("4chs", nil, nil, 0)
      
    else
      self.imageView1 = self:imageOn("4en", nil, nil, 0)
    end

    self.imageView2 = self:imageOn("ml" .. self:getString("paper_password"), nil, nil, 0)

    local action  = cc.FadeIn:create(3)
    local action2 = cc.FadeIn:create(3)

    self.imageView1:runAction(action)

    self.imageView2:runAction(cc.Sequence:create(action2, cc.CallFunc:create(function()
      self:voidItem("tissue")
      self:sayI18n("handleSwipeFrom_2")
      self:enableTouch()
    end)))
    
    return
  end
  
  self:sayI18n("click_3")
end

return E9Paper
