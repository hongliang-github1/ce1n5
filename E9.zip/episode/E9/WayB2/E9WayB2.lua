local E9WayB2 = class("E9WayB2", function()
  return BasePlace.new()
end)

function E9WayB2:initPhoto()
end

function E9WayB2:initButton()
  self:addButton("goWayB3", 632, 0, 816, 1148)
  self:addButton("goFlowerA", 84, 454, 466, 694)
end

function E9WayB2:arrowDown(rect)
  self:switchPlaceZoomOut("WayB1")
end

function E9WayB2:beforeLoad()
  self:imageOn("0")
end

function E9WayB2:afterLoad()
  
end

function E9WayB2:afterLoad2()
  self:cacheImage("WayB1/0")
  self:cacheImage("WayB3/3")
end

function E9WayB2:beforeUseItem(itemName)
  return false
end

function E9WayB2:afterUseItem(itemName)
  return true
end

function E9WayB2:goWayB3(rect)
  self:switchPlaceZoomIn("WayB3", cc.rect(316 * 2, 181 * 2, 409 * 2, 235 * 2))
end

function E9WayB2:goFlowerA(rect)
  self:switchPlaceZoomIn("FlowerA", rect)
end

return E9WayB2
