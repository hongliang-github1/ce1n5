local E9Remoter = class("E9Remoter", function()
  return BasePlace.new()
end)

function E9Remoter:initPhoto()
  self:addPhoto("2", 960, 256)
  self:addPhoto("3", 960, 256)
  self:addPhoto("4", 896, 768)
end

function E9Remoter:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E9Remoter:animate()
  -- 以BathDoorB的门为主，如果只有BathDoorA的门打开了，那么就用A的图，否则用B的图
  if self:getInteger("bath_door_a_open") == 1 and self:getInteger("bath_door_b_open") == 0 then
    self.animateProgress = self.animateProgress + 1
    
    if 1 == self.animateProgress then
      self:imageOn("BathDoorA/0")
      self:imageOn("BathDoorA/1")
      
      self:scheduleOnce(0.5, function()
        self:animate()
      end)

      self:say("")
      
      return
    end
    
    if 2 == self.animateProgress then
      self:switchPlace("BathDoorA")
      
      return
    end
    
    return
  end
  
  self.animateProgress = self.animateProgress + 1
  
  if 1 == self.animateProgress then
    self:imageOn("BathDoorB/0")
    self:imageOn("BathDoorB/1")
    self:setInteger("bath_door_b_open", 1)
    
    self:scheduleOnce(0.5, function()
      self:animate()
    end)

    self:say("")
    
    return
  end
  
  if 2 == self.animateProgress then
    self:switchPlace("BathDoorB")

    return
  end
end

function E9Remoter:arrowDown(rect)
  self:switchPlaceZoomOut("BedRight")
end

function E9Remoter:beforeLoad()
  self:imageOn("0")
end

function E9Remoter:afterLoad()
  if "LightPlug" == self.lastPlaceName then
    self.animateProgress = 0
    
    self:hideArrowButton()
    self:sayI18n("afterLoad_1")
    
  else
    self:sayI18n("afterLoad_2")
  end
end

function E9Remoter:afterLoad2()  
  if self:getInteger("room_brighter") ~= 0 then
    self:cacheImage("1")
  end

  self:cacheImage("BathDoorA/0")
  self:cacheImage("BathDoorB/0")
  self:cacheImage("BedRight/1")
end

function E9Remoter:beforeUseItem(itemName)
  return false
end

function E9Remoter:afterUseItem(itemName)
  return true
end

function E9Remoter:click(rect)
  -- 当房间的灯光还没有增强的时候
  if self:getInteger("room_brighter") == 0 then
    if self.touched then
      -- 开始亮灯剧情
      self:setInteger("room_brighter", 1)
      self:disableTouch()
      self:animate()
      
    else
      self:play("keypad")
      self:sayI18n("click_1")
      
      self.touched = true
    end
    
    return
  end
  
  -- 拿电池
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    
    if self:getInteger("battery") == 0 then
      self:imageOn("3")
      self:sayI18n("click_3")
      
      return
    end
    
    self:sayI18n("click_4")
    
    return
  end
  
  -- 如果已经拿了电池了，就不继续往下走了
  if self:getInteger("battery") ~= 0 then
    self:sayI18n("click_5")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOff("3")
    self:imageOn("4")
    self:sayI18n("click_6")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOff("4")
    self:getItem("battery")
    self:sayI18n("click_7")
    
    return
  end
end

return E9Remoter
