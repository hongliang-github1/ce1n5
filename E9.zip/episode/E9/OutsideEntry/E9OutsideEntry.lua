local E9OutsideEntry = class("E9OutsideEntry", function()
  return BasePlace.new()
end)

function E9OutsideEntry:initPhoto()
end

function E9OutsideEntry:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E9OutsideEntry:beforeLoad()
  self:imageOn("Entry/0")
end

function E9OutsideEntry:afterLoad()
  self:click(nil)
end

function E9OutsideEntry:afterLoad2()
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Door/0")

  else    
    self:cacheImage("Door/2")
  end
end

function E9OutsideEntry:beforeUseItem(itemName)
  return false
end

function E9OutsideEntry:afterUseItem(itemName)
  return true
end

function E9OutsideEntry:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOff("Entry/0")
    self:imageOn("Door/0")
    self:play("cabinet")
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_3")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:switchPlace("Door")
    
    return
  end
end

return E9OutsideEntry
