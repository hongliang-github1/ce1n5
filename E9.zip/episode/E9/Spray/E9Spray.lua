local E9Spray = class("E9Spray", function()
  return BasePlace.new()
end)

function E9Spray:initPhoto()
  self:addPhoto("1", 1344, 192)
  self:addPhoto("2", 1344, 0)
  self:addPhoto("a1", 1344, 0)
  self:addPhoto("b1", 1344, 0)
end

function E9Spray:initButton()
  self:addButton("goSprayNear", 1284, 120, 366, 400)
end

function E9Spray:arrowDown(rect)
  self:switchPlaceZoomOut("BathSeeB")
end

function E9Spray:beforeLoad()
  self:imageOn("0")
  
  -- 当电池和喷雾剂都已经安装到喷雾装置，灯才亮着
  if self:getInteger("battery") < 0 and self:getInteger("spray") < 0 then
    self:imageOn("1")
  end
end

function E9Spray:afterLoad()
  if self:imageIsOn("1") then
    self:sayI18n("afterLoad_1")
    
  elseif "SprayNear" ~= self.lastPlaceName then
    self:sayI18n("afterLoad_2")
  end
end

function E9Spray:afterLoad2()
  self:cacheImage("BathSeeB/0")
  self:cacheImage("SprayNear/0")
end

function E9Spray:beforeUseItem(itemName)
  return false
end

function E9Spray:afterUseItem(itemName)
  return true
end

function E9Spray:goSprayNear(rect)
  -- 打开盖子之后、或者电池和喷雾剂都使用了才可以进入近景视角
  if self:imageIsOn("2") or self:imageIsOn("b1") or self:imageIsOn("a1") or (self:getInteger("battery") < 0 and self:getInteger("spray") < 0) then
    
    self:switchPlaceZoomIn("SprayNear", rect)
    
    return
  end
  
  -- 打开盖子
  if self:getInteger("battery") < 0 then
    self:imageOn("b1")
    self:play("kettle")
    self:sayI18n("goSprayNear_1")
  
  elseif self:getInteger("spray") < 0 then
    self:imageOn("a1")
    self:play("kettle")
    self:sayI18n("goSprayNear_2")
    
  else
    self:imageOn("2")
    self:play("kettle")
    self:sayI18n("goSprayNear_3")
  end
end

return E9Spray
