local E9BathDoorA = class("E9BathDoorA", function()
  return BasePlace.new()
end)

function E9BathDoorA:initPhoto()
  self:addPhoto("1", 640, 0)
  self:addPhoto("2", 640, 0)
end

function E9BathDoorA:initButton()
  self:addButton("open", 686, 0, 706, 1042)
end

function E9BathDoorA:arrowDown(rect)
  self:switchPlaceZoomOut("WayRight")
end

function E9BathDoorA:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_a_open") == 1 then
    if self:getInteger("room_brighter") == 0 then
      self:imageOn("1")
      
    else
      self:imageOn("2")
    end
  end
end

function E9BathDoorA:afterLoad()
  if "Remoter" == self.lastPlaceName and self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")
    
  elseif self:getInteger("bath_door_b_open") < 1 then
    self:sayI18n("afterLoad_2")
  end
end

function E9BathDoorA:afterLoad2()
  self:cacheImage("WayRight/0")
  self:cacheImage("BathEntryA/0")
end

function E9BathDoorA:beforeUseItem(itemName)
  return false
end

function E9BathDoorA:afterUseItem(itemName)
  return true
end

function E9BathDoorA:open(rect)
  -- 门帘已经打开之后
  if self:getInteger("bath_door_a_open") == 1 then
    -- 如果还没有使灯变的更亮，那么进入全黑场景
    if self:getInteger("room_brighter") == 0 then
      self:switchPlaceZoomIn("BathBlack", cc.rect(344 * 2, 120 * 2, 353 * 2, 345 * 2))
      
      return
    end
    
    -- 进入浴室
    self:switchPlaceZoomIn("BathEntryA", cc.rect(344 * 2, 120 * 2, 353 * 2, 345 * 2))
    
    return
  end
  
  -- 开门帘
  self:setInteger("bath_door_a_open", 1)
  
  -- 当灯还没更亮的时候
  if self:getInteger("room_brighter") == 0 then
    self:imageOn("1")
    self:sayI18n("open_1")
    
    return
  end
  
  self:imageOn("2")
  self:sayI18n("open_2")
end

return E9BathDoorA
