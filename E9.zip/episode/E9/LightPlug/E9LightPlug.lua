local E9LightPlug = class("E9LightPlug", function()
  return BasePlace.new()
end)

function E9LightPlug:initPhoto()
  self:addPhoto("2", 0, 0)
end

function E9LightPlug:initButton()
  self:addButton("click", 480, 220, 800, 800)
  self:addButton("remoter", 0, 0, 474, 1116, false)
end

function E9LightPlug:arrowDown(rect)
  if self:getInteger("remoter") < 0 then
    -- 跳转到灯光控制器单独界面，一通乱点打开了浴室的灯
    self:switchPlace("Remoter")
    
    return
  end
  
  self:switchPlaceZoomOut("BedRight")
end

function E9LightPlug:beforeLoad()
  self:imageOn("1")
end

function E9LightPlug:afterLoad()
  
end

function E9LightPlug:afterLoad2()  
  self:cacheImage("Remoter/0")
  self:cacheImage("BedRight/1")
end

function E9LightPlug:beforeUseItem(itemName)
  if "remoter" == itemName and self:imageIsOn("1") then
    return true
  end
  
  return false
end

function E9LightPlug:afterUseItem(itemName)
  if "remoter" == itemName then
    self:imageOn("2")
    self:play("airswitch")
    self:sayI18n("afterUseItem_1")
    
    return false
  end
  
  return true
end

function E9LightPlug:click(rect)
  if self:getInteger("remoter") < 0 then
    -- 跳转到灯光控制器单独界面，一通乱点打开了浴室的灯
    self:switchPlace("Remoter")
    
    return
  end

  self:sayI18n("click_1")
    
end

function E9LightPlug:remoter(rect)
  if self:imageIsOn("2") then
    self:click(nil)
    
    return
  end
end

return E9LightPlug
