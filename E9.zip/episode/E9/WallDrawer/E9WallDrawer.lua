local E9WallDrawer = class("E9WallDrawer", function()
  return BasePlace.new()
end)

function E9WallDrawer:initPhoto()
  self:addPhoto("1", 0, 384)
  self:addPhoto("2", 704, 576)
  self:addPhoto("3", 768, 640)
end

function E9WallDrawer:initButton()
  self:addButton("open", 550, 326, 1078, 784)
  self:addButton("goGroundA", 0, 416, 528, 624)
  self:addButton("goGroundB", 1666, 146, 378, 694)
end

function E9WallDrawer:arrowUp(rect)
  self:switchPlaceUp("Wall")
end

function E9WallDrawer:beforeLoad()
  self:imageOn("0")
end

function E9WallDrawer:afterLoad()
end

function E9WallDrawer:afterLoad2()  
  self:cacheImage("1")
  self:cacheImage("GroundA/0")
  self:cacheImage("GroundA/1")
  self:cacheImage("GroundB/0")
  self:cacheImage("GroundB/1")
  self:cacheImage("Wall/0")
end

function E9WallDrawer:beforeUseItem(itemName)
  return false
end

function E9WallDrawer:afterUseItem(itemName)
  return true
end

function E9WallDrawer:open(rect)
  -- 还没打开柜子，先打开
  if not self:imageIsOn("1") then
    -- 打开抽屉
    self:imageOn("1")
    self:play("drawer")
    
    -- 这里随机出现控制器或者纸
    if self:getInteger("remoter") == 0 and "wall_drawer" == self:getString("remoter_pos") then
      self:imageOn("2")
      self:sayI18n("handleSwipeFrom_1")
      
      return
    end
    
    if self:getInteger("paper") == 0 and "wall_drawer" == self:getString("paper_pos") then
      self:imageOn("3")
      self:sayI18n("handleSwipeFrom_2")
      
      return
    end
    
    self:sayI18n("handleSwipeFrom_3")

  else
    -- 有道具就拿道具，没有道具就关闭
    if self:getInteger("remoter") == 0 and "wall_drawer" == self:getString("remoter_pos") then
      self:imageOff("2")
      self:getItem("remoter")
      self:sayI18n("open_1")

      return
    end

    if self:getInteger("paper") == 0 and "wall_drawer" == self:getString("paper_pos") then
      self:imageOff("3")
      self:getItem("paper")
      self:sayI18n("open_2")
      
      return
    end

    -- 关闭抽屉
    self:imageOff("1")
    self:play("drawer")
    self:sayI18n("handleSwipeFrom_4")
  end
end

function E9WallDrawer:goGroundA(rect)
  self:switchPlaceLeft("GroundA")
end

function E9WallDrawer:goGroundB(rect)
  self:switchPlaceRight("GroundB")
end

return E9WallDrawer
