local E9MirrorFog = class("E9MirrorFog", function()
  return BasePlace.new()
end)

function E9MirrorFog:initPhoto()
  self:addPhoto("4", 0, 0)
  self:addPhoto("5", 0, 0)
  self:addPhoto("6", 0, 0)
  self:addPhoto("n10", 768, 448)
  self:addPhoto("n11", 768, 448)
  self:addPhoto("n12", 768, 448)
  self:addPhoto("n13", 768, 448)
  self:addPhoto("n14", 768, 448)
  self:addPhoto("n15", 768, 448)
  self:addPhoto("n16", 768, 448)
  self:addPhoto("n17", 768, 448)
  self:addPhoto("n18", 768, 448)
  self:addPhoto("n19", 768, 448)
  self:addPhoto("n20", 896, 448)
  self:addPhoto("n21", 896, 448)
  self:addPhoto("n22", 896, 448)
  self:addPhoto("n23", 896, 448)
  self:addPhoto("n24", 896, 448)
  self:addPhoto("n25", 896, 448)
  self:addPhoto("n26", 896, 448)
  self:addPhoto("n27", 896, 448)
  self:addPhoto("n28", 896, 448)
  self:addPhoto("n29", 896, 448)
  self:addPhoto("n30", 1024, 448)
  self:addPhoto("n31", 1024, 448)
  self:addPhoto("n32", 1024, 448)
  self:addPhoto("n33", 1024, 448)
  self:addPhoto("n34", 1024, 448)
  self:addPhoto("n35", 1024, 448)
  self:addPhoto("n36", 1024, 448)
  self:addPhoto("n37", 1024, 448)
  self:addPhoto("n38", 1024, 448)
  self:addPhoto("n39", 1024, 448)
  self:addPhoto("n40", 1152, 448)
  self:addPhoto("n41", 1152, 448)
  self:addPhoto("n42", 1152, 448)
  self:addPhoto("n43", 1152, 448)
  self:addPhoto("n44", 1152, 448)
  self:addPhoto("n45", 1152, 448)
  self:addPhoto("n46", 1152, 448)
  self:addPhoto("n47", 1152, 448)
  self:addPhoto("n48", 1152, 448)
  self:addPhoto("n49", 1152, 448)
  self:addPhoto("n50", 1344, 448)
  self:addPhoto("n51", 1344, 448)
  self:addPhoto("n52", 1344, 448)
  self:addPhoto("n53", 1344, 448)
  self:addPhoto("n54", 1344, 448)
  self:addPhoto("n55", 1344, 448)
  self:addPhoto("n56", 1344, 448)
  self:addPhoto("n57", 1344, 448)
  self:addPhoto("n58", 1344, 448)
  self:addPhoto("n59", 1344, 448)
end

function E9MirrorFog:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E9MirrorFog:beforeLoad()
  self:imageOn("Mirror/0")
end

function E9MirrorFog:afterLoad()
  if self.tipMode then
    return
  end
  
  -- 起雾走剧情
  self:disableTouch()
  
  -- 记录过用户知道怎么让镜子起雾，给tip用
  if self:getInteger("mirror_fogged") < 1 then
    self:setInteger("mirror_fogged", 1)
  end

  -- 根据雾的浓雾走不同的剧情
  local paperNumber = tonumber(self:getString("paper_password"))
  local kettleLevel = self:getInteger("kettle_level")
  
  if kettleLevel < paperNumber then
    self.imageView4 = self:imageOn("4", nil, nil, 0)
    local action    = cc.FadeIn:create(2)

    self.imageView4:runAction(cc.Sequence:create(action, cc.CallFunc:create(function()
      self:sayI18n("afterLoad_1")
      -- 记录当前状态为轻雾
      self.lowFog = true

      -- 走完剧情之后，重置状态
      self:setInteger("kettle_level", 0)
      self:enableTouch()
    end)))
  
    return
  end
  
  if kettleLevel == paperNumber then
    self.imageView5  = self:imageOn("5", nil, nil, 0)
    self.n1ImageView = self:imageOn("n1" .. self:getInteger("num1"), nil, nil, 0)
    self.n2ImageView = self:imageOn("n2" .. self:getInteger("num2"), nil, nil, 0)
    self.n3ImageView = self:imageOn("n3" .. self:getInteger("num3"), nil, nil, 0)
    self.n4ImageView = self:imageOn("n4" .. self:getInteger("num4"), nil, nil, 0)
    self.n5ImageView = self:imageOn("n5" .. self:getInteger("num5"), nil, nil, 0)

    local fadeTime = 1.5
    local image5ViewAction = cc.FadeIn:create(fadeTime)

    self.n1ImageView:runAction(cc.FadeTo:create(fadeTime, 51))
    self.n2ImageView:runAction(cc.FadeTo:create(fadeTime, 51))
    self.n3ImageView:runAction(cc.FadeTo:create(fadeTime, 51))
    self.n4ImageView:runAction(cc.FadeTo:create(fadeTime, 51))
    self.n5ImageView:runAction(cc.FadeTo:create(fadeTime, 51))

    self.imageView5:runAction(cc.Sequence:create(image5ViewAction, cc.CallFunc:create(function()
      self.n1ImageView:runAction(cc.FadeTo:create(fadeTime, 255))
      self.n2ImageView:runAction(cc.FadeTo:create(fadeTime, 255))
      self.n3ImageView:runAction(cc.FadeTo:create(fadeTime, 255))
      self.n4ImageView:runAction(cc.FadeTo:create(fadeTime, 255))
      self.n5ImageView:runAction(cc.Sequence:create(cc.FadeTo:create(fadeTime, 255), cc.CallFunc:create(function()
        self:sayI18n("afterLoad_2")

        -- 记录当前状态为中雾
        self.inFog = true
        
        -- 走完剧情之后，重置状态，记录出现过密码了
        self:setInteger("kettle_level", 0)
        
        if self:getInteger("mirror_fog_tipped") < 1 then
          self:setInteger("mirror_fog_tipped", 1)
        end
        
        self:enableTouch()
      end)))      
    end)))
    
    return
  end
  
  if kettleLevel > paperNumber then    
    self.imageView6 = self:imageOn("6", nil, nil, 0)
    local action    = cc.FadeIn:create(2)

    self.imageView6:runAction(cc.Sequence:create(action, cc.CallFunc:create(function()
      self:sayI18n("afterLoad_3")
      -- 记录当前状态为浓雾
      self.highFog = true

      -- 走完剧情之后，重置状态
      self:setInteger("kettle_level", 0)
      self:enableTouch()
    end)))
    
    return
  end
end

function E9MirrorFog:afterLoad2()  
  self:cacheImage("4")
  self:cacheImage("5")
  self:cacheImage("6")
  self:cacheImage("Mirror/0")
end

function E9MirrorFog:beforeUseItem(itemName)
  return false
end

function E9MirrorFog:afterUseItem(itemName)
  return true
end

function E9MirrorFog:click(rect)
  -- 镜子上的雾逐渐消掉
  self:disableTouch()

  if self.lowFog == true then
    self:sayI18n("click_1")
    self.imageView4:setOpacity(255)

    local action = cc.FadeOut:create(2)

    self.imageView4:runAction(cc.Sequence:create(action, cc.CallFunc:create(function()
      self:enableTouch()
      self:switchPlace("Mirror")
    end)))
    
    return
  end
  
  if self.inFog == true then
    self:sayI18n("click_2")

    local fadeTime = 1.5
    local image5ViewAction = cc.FadeTo:create(fadeTime, 178)

    self.n1ImageView:runAction(cc.FadeOut:create(fadeTime))
    self.n2ImageView:runAction(cc.FadeOut:create(fadeTime))
    self.n3ImageView:runAction(cc.FadeOut:create(fadeTime))
    self.n4ImageView:runAction(cc.FadeOut:create(fadeTime))
    self.n5ImageView:runAction(cc.FadeOut:create(fadeTime))

    self.imageView5:runAction(cc.Sequence:create(image5ViewAction, cc.CallFunc:create(function()
      self.imageView5:runAction(cc.Sequence:create(cc.FadeTo:create(fadeTime, 0), cc.CallFunc:create(function()
        self:enableTouch()
        self:switchPlace("Mirror")
      end)))      
    end)))
    
    return
  end
  
  if self.highFog == true then
    self:sayI18n("click_3")
    
    self.imageView6:setOpacity(255)

    local action = cc.FadeOut:create(2)

    self.imageView6:runAction(cc.Sequence:create(action, cc.CallFunc:create(function()
      self:enableTouch()
      self:switchPlace("Mirror")
    end)))
    
    return
  end
end

return E9MirrorFog
