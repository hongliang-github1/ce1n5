local E9TubHandle = class("E9TubHandle", function()
  return BasePlace.new()
end)

function E9TubHandle:initPhoto()
  self:addPhoto("1", 704, 256)
  self:addPhoto("2", 704, 256)
  self:addPhoto("3", 704, 256)
  self:addPhoto("4", 704, 256)
  self:addPhoto("5", 704, 256)
  self:addPhoto("6", 704, 256)
  self:addPhoto("7", 704, 256)
  self:addPhoto("8", 704, 256)
  self:addPhoto("9", 704, 256)
end

function E9TubHandle:initButton()
  -- 如果开门密码已经输入过了，只显示click按钮，否则只显示点击开关的区域
  if self:getInteger("get_door_key") == 1 then
    self:addButton("click", 0, 0, 2044, 1148, false)
  else
    self:addButton("handle", 644, 188, 770, 526)
  end
end

function E9TubHandle:arrowDown(rect)
  self:switchPlaceZoomOut("Tub")
end

function E9TubHandle:beforeLoad()
  self:imageOn("0")
  self:sayI18n("beforeLoad_1")
end

function E9TubHandle:afterLoad()
  if self:getInteger("get_door_key") == 0 or self.tipMode then
    -- 不走动画剧情，或者是在tip模式下，接下来就什么都不做
    
    return
  end
  
  self:say("")
  self:hideArrowButton()
  self:disableTouch()

  self:scheduleTimes(0.2, 9, function(index)
    self:open(index)
  end)
end

function E9TubHandle:afterLoad2()
  self:cacheImage("Tub/0")
end

function E9TubHandle:beforeUseItem(itemName)
  return false
end

function E9TubHandle:afterUseItem(itemName)
  return true
end

function E9TubHandle:open(count)
  if count == 1 then
    -- 开关扭动的声音
    self:play("bathfaucet")
  end
  
  if count >= 9 then
    -- 停止之后，说一句话，点击之后，再跳转
    self:setInteger("tub_handle_can_open", 0)
    self:setInteger("tub_handle_switch", 1)
    self:enableTouch()
    self:sayI18n("open_1")
    
    return
  end

  self:imageOn(tostring(count))
end

function E9TubHandle:handle(rect)
  -- 可以开的时候，点击就无效了
  if self:getInteger("tub_handle_can_open") == 0 then
    self:sayI18n("handle_1")
  end
end

function E9TubHandle:click(rect)
  -- 黑屏动画
  self:effectFadeBlack(nil, 1, 0, 0, function()
    self:switchPlace("Ending")
  end)
end

return E9TubHandle
