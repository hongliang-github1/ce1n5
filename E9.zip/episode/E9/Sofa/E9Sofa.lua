local E9Sofa = class("E9Sofa", function()
  return BasePlace.new()
end)

function E9Sofa:initPhoto()
  self:addPhoto("1", 128, 768)
  self:addPhoto("2", 128, 768)
end

function E9Sofa:initButton()
  if self:getString("b6_pos") == "sofa" or self:getString("b3_pos") == "sofa" then
    self:addButton("getBnum", 312, 742, 308, 320)
  
  else
    self:addButton("getBnum", 312, 742, 308, 320, false)
  end
  
  self:addButton("sofa", 654, 108, 1330, 800)
end

function E9Sofa:arrowDown(rect)
  self:switchPlaceZoomOut("Entry")
end

function E9Sofa:beforeLoad()
  self:imageOn("0")
  
  -- 这里随机显示b330或b600瓶子
  if self:getInteger("b330") == 0 and self:getString("b3_pos") == "sofa" then
    self:imageOn("1")
    
    return
  end
  
  if self:getInteger("b600") == 0 and self:getString("b6_pos") == "sofa" then
    self:imageOn("2")
  end
end

function E9Sofa:afterLoad()
  if self:imageIsOn("1") or self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")
    
  else
    self:sayI18n("afterLoad_2")
  end
end

function E9Sofa:afterLoad2()  
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")
    
  else
    self:cacheImage("Entry/50")
  end
end

function E9Sofa:beforeUseItem(itemName)
  return false
end

function E9Sofa:afterUseItem(itemName)
  return true
end

function E9Sofa:getBnum(rect)
  -- 拿道具
  if self:getInteger("b330") == 0 and self:getString("b3_pos") == "sofa" then
    self:imageOff("1")
    self:getItem("b330")
    self:sayI18n("getItem_1")
    
    return
  end
  
  if self:getInteger("b600") == 0 and self:getString("b6_pos") == "sofa" then
    self:imageOff("2")
    self:getItem("b600")
    self:sayI18n("getItem_2")
    
    return
  end
  
  if self:getString("b6_pos") == "sofa" or self:getString("b3_pos") == "sofa" then
    self:sayI18n("getItem_3")
  end
end

function E9Sofa:sofa(rect)
  self:sayI18n("sofa_1")
end

return E9Sofa
