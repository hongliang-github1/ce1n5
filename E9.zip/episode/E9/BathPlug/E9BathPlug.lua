local E9BathPlug = class("E9BathPlug", function()
  return BasePlace.new()
end)

function E9BathPlug:initPhoto()
  self:addPhoto("1", 896, 192)
  self:addPhoto("3", 896, 128)
  self:addPhoto("40", 896, 0)
  self:addPhoto("41", 1344, 320)
  self:addPhoto("6", 704, 320)
  self:addPhoto("m0", 192, 0)
  self:addPhoto("m2", 192, 0)
  self:addPhoto("m5", 192, 0)
  self:addPhoto("m7", 192, 0)
end

function E9BathPlug:initButton()
  if self:getInteger("bath_plug_button_showed") > 0 then
    self:addButton("open", 824, 198, 404, 284, false)
  else
    self:addButton("open", 824, 198, 404, 284)
  end
  
  self:addButton("b600ChangeB330", 210, 0, 326, 792, false)
  self:addButton("kettleChangeB330", 1258, 0, 574, 786, false)
  self:addButton("b330Change", 740, 472, 266, 308, false)
end

function E9BathPlug:arrowDown(rect)
  self:switchPlaceZoomOut("BathSeeA")
end

function E9BathPlug:beforeLoad()
  -- 初始化动画的总count
  self.animationCount  = 60
  self.count           = 0
  self.sayKettle       = 0
  self.labelColorCount = 0

  self:imageOn("0")

  self:sayI18n("open_1")
  
  -- 禁用随时可以使用的道具，不然再次使用水壶会乱套
  self:disableAlwaysUseItem()
end

-- 这个方法初始化各种按钮和lable
function E9BathPlug:initLabelButton()
  -- 添加一堆按钮和label
  local bgSize   = self:getContentSize()
  local fontSize = 50

  -- b600 Label
  self.b600Label = cc.Label:createWithSystemFont(self:getInteger("b600_level") .. " ml", "Helvetica", fontSize, cc.size(320, 120), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  local labelY = bgSize.height - 650 - self.b600Label:getContentSize().height / 2

  self.b600Label:setColor(cc.c4b(255, 255, 255, 255))
  self.b600Label:setAnchorPoint(0.5, 0.5)
  self.b600Label:setPositionX(220 + 160)
  self.b600Label:setPositionY(labelY)
  self.b600Label:setLocalZOrder(101)
  self:addChild(self.b600Label)

  self.b600LabelLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 128))
  self.b600LabelLayer:setTouchEnabled(false)
  self.b600LabelLayer:setPosition(220, labelY - 60)
  self.b600LabelLayer:setContentSize(self.b600Label:getContentSize())
  self.b600LabelLayer:setLocalZOrder(100)
  self:addChild(self.b600LabelLayer)

  -- b600加满按钮
  self.b6f      = cc.ControlButton:create(self.i18nTable["fill"], "Helvetica", fontSize)
  local buttonY = bgSize.height - 794 - self.b6f:getContentSize().height / 2

  self.b6f:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  self.b6f:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  self.b6f:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  self.b6f:setAnchorPoint(0.5, 0.5)
  self.b6f:setPositionX(210 + self.b6f:getContentSize().width / 2)
  self.b6f:setPositionY(buttonY)
  self.b6f:setLocalZOrder(101)
  self:addChild(self.b6f)
  -- 绑定按钮事件
  self.b6f:registerControlEventHandler(function(button, eventType)
    self:b600Fill()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
  
  -- b6倒水按钮
  self.b6c = cc.ControlButton:create(self.i18nTable["clear"], "Helvetica", fontSize)

  self.b6c:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  self.b6c:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  self.b6c:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  self.b6c:setAnchorPoint(0.5, 0.5)
  self.b6c:setPositionX(430 + self.b6f:getContentSize().width / 2)
  self.b6c:setPositionY(buttonY)
  self.b6c:setLocalZOrder(101)
  self:addChild(self.b6c)
  -- 绑定按钮事件
  self.b6c:registerControlEventHandler(function(button, eventType)
    self:b600Clear()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)


  -- b330 Label
  self.b330Label = cc.Label:createWithSystemFont(self:getInteger("b330_level") .. " ml", "Helvetica", fontSize, cc.size(320, 120), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  self.b330Label:setColor(cc.c4b(255, 255, 255, 255))
  self.b330Label:setAnchorPoint(0.5, 0.5)
  self.b330Label:setPositionX(718 + 160)
  self.b330Label:setPositionY(labelY)
  self.b330Label:setLocalZOrder(101)
  self:addChild(self.b330Label)

  self.b330LabelLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 128))
  self.b330LabelLayer:setTouchEnabled(false)
  self.b330LabelLayer:setPosition(718, labelY - 60)
  self.b330LabelLayer:setContentSize(self.b330Label:getContentSize())
  self.b330LabelLayer:setLocalZOrder(100)
  self:addChild(self.b330LabelLayer)

  -- b330加满按钮
  self.b3f = cc.ControlButton:create(self.i18nTable["fill"], "Helvetica", fontSize)

  self.b3f:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  self.b3f:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  self.b3f:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  self.b3f:setAnchorPoint(0.5, 0.5)
  self.b3f:setPositionX(710 + self.b3f:getContentSize().width / 2)
  self.b3f:setPositionY(buttonY)
  self.b3f:setLocalZOrder(101)
  self:addChild(self.b3f)
  -- 绑定按钮事件
  self.b3f:registerControlEventHandler(function(button, eventType)
    self:b330Fill()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- b330倒水按钮
  self.b3c = cc.ControlButton:create(self.i18nTable["clear"], "Helvetica", fontSize)

  self.b3c:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  self.b3c:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  self.b3c:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  self.b3c:setAnchorPoint(0.5, 0.5)
  self.b3c:setPositionX(920 + self.b3c:getContentSize().width / 2)
  self.b3c:setPositionY(buttonY)
  self.b3c:setLocalZOrder(101)
  self:addChild(self.b3c)
  -- 绑定按钮事件
  self.b3c:registerControlEventHandler(function(button, eventType)
    self:b330Clear()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- kettle Label
  self.kettleLabel = cc.Label:createWithSystemFont(self:getInteger("kettle_level") .. " ml", "Helvetica", fontSize, cc.size(320, 120), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  self.kettleLabel:setColor(cc.c4b(255, 255, 255, 255))
  self.kettleLabel:setAnchorPoint(0.5, 0.5)
  self.kettleLabel:setPositionX(1356 + 160)
  self.kettleLabel:setPositionY(labelY)
  self.kettleLabel:setLocalZOrder(101)
  self:addChild(self.kettleLabel)

  self.kettleLabelLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 128))
  self.kettleLabelLayer:setTouchEnabled(false)
  self.kettleLabelLayer:setPosition(1356, labelY - 60)
  self.kettleLabelLayer:setContentSize(self.kettleLabel:getContentSize())
  self.kettleLabelLayer:setLocalZOrder(100)
  self:addChild(self.kettleLabelLayer)

  -- kettle烧水按钮
  self.kb = cc.ControlButton:create(self.i18nTable["boiling"], "Helvetica", fontSize)

  self.kb:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  self.kb:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  self.kb:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  self.kb:setAnchorPoint(0.5, 0.5)
  self.kb:setPositionX(1350 + self.kb:getContentSize().width / 2)
  self.kb:setPositionY(buttonY)
  self.kb:setLocalZOrder(101)
  self:addChild(self.kb)
  -- 绑定按钮事件
  self.kb:registerControlEventHandler(function(button, eventType)
    self:kettleBoiling()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- kettle倒水按钮
  self.kc = cc.ControlButton:create(self.i18nTable["clear"], "Helvetica", fontSize)

  self.kc:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  self.kc:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  self.kc:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  self.kc:setAnchorPoint(0.5, 0.5)
  self.kc:setPositionX(1570 + self.kc:getContentSize().width / 2)
  self.kc:setPositionY(buttonY)
  self.kc:setLocalZOrder(101)
  self:addChild(self.kc)
  -- 绑定按钮事件
  self.kc:registerControlEventHandler(function(button, eventType)
    self:kettleClear()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- 添加完各种button和label之后，先设置成都隐藏
  self.kettleLabel:setVisible(false)
  self.kettleLabelLayer:setVisible(false)
  self.kc:setVisible(false)
  self.kb:setVisible(false)

  self.b330Label:setVisible(false)
  self.b330LabelLayer:setVisible(false)
  self.b3c:setVisible(false)
  self.b3f:setVisible(false)

  self.b600Label:setVisible(false)
  self.b600LabelLayer:setVisible(false)
  self.b6c:setVisible(false)
  self.b6f:setVisible(false)
end

function E9BathPlug:initChangeButton()
  -- b6 往 b3 倒水
  local sprite     = ccui.Scale9Sprite:create(self:imagePath("MS2"), cc.rect(0, 0, 256, 64), cc.rect(0, 0, 256, 64))  
  local b600ToB330 = cc.ControlButton:create(sprite)
  self.b600ToB330  = b600ToB330

  b600ToB330:setAnchorPoint(0.5, 0.5)
  b600ToB330:setPreferredSize(cc.size(260, 100))
  b600ToB330:setPositionX(640)
  b600ToB330:setPositionY(650)
  b600ToB330:setLocalZOrder(101)
  self:addChild(b600ToB330)

  -- 绑定按钮事件
  self.b600ToB330:registerControlEventHandler(function(button, eventType)
    self:handleB600OrB330From("right")
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- b3 往 b6 倒水
  sprite           = ccui.Scale9Sprite:create(self:imagePath("MS3"), cc.rect(0, 0, 256, 64), cc.rect(0, 0, 256, 64))  
  local b330ToB600 = cc.ControlButton:create(sprite)
  self.b330ToB600  = b330ToB600

  b330ToB600:setAnchorPoint(0.5, 0.5)
  b330ToB600:setPreferredSize(cc.size(260, 100))
  b330ToB600:setPositionX(640)
  b330ToB600:setPositionY(500)
  b330ToB600:setLocalZOrder(101)
  self:addChild(b330ToB600)

  -- 绑定按钮事件
  self.b330ToB600:registerControlEventHandler(function(button, eventType)
    self:handleB600OrB330From("left")
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- b3 往 kettle 倒水
  sprite             = ccui.Scale9Sprite:create(self:imagePath("SK2"), cc.rect(0, 0, 320, 64), cc.rect(0, 0, 320, 64))  
  local b330ToKettle = cc.ControlButton:create(sprite)
  self.b330ToKettle  = b330ToKettle

  b330ToKettle:setAnchorPoint(0.5, 0.5)
  b330ToKettle:setPreferredSize(cc.size(360, 100))
  b330ToKettle:setPositionX(1140)
  b330ToKettle:setPositionY(650)
  b330ToKettle:setLocalZOrder(101)
  self:addChild(b330ToKettle)

  -- 绑定按钮事件
  self.b330ToKettle:registerControlEventHandler(function(button, eventType)
    self:handleB330OrKettleFrom("right")
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- kettle 往 b3 倒水
  sprite             = ccui.Scale9Sprite:create(self:imagePath("SK3"), cc.rect(0, 0, 320, 64), cc.rect(0, 0, 320, 64))  
  local kettleToB330 = cc.ControlButton:create(sprite)
  self.kettleToB330  = kettleToB330

  kettleToB330:setAnchorPoint(0.5, 0.5)
  kettleToB330:setPreferredSize(cc.size(360, 100))
  kettleToB330:setPositionX(1140)
  kettleToB330:setPositionY(500)
  kettleToB330:setLocalZOrder(101)
  self:addChild(kettleToB330)

  -- 绑定按钮事件
  self.kettleToB330:registerControlEventHandler(function(button, eventType)
    self:handleB330OrKettleFrom("left")
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- -- b6 往 kettle 倒水
  sprite             = ccui.Scale9Sprite:create(self:imagePath("MK2"), cc.rect(0, 0, 1024, 128), cc.rect(0, 0, 1024, 128))  
  local b600ToKettle = cc.ControlButton:create(sprite)
  self.b600ToKettle  = b600ToKettle

  b600ToKettle:setAnchorPoint(0.5, 0.5)
  b600ToKettle:setPreferredSize(cc.size(1024, 250))
  b600ToKettle:setPositionX(900)
  b600ToKettle:setPositionY(1000)
  b600ToKettle:setLocalZOrder(101)
  self:addChild(b600ToKettle)

  -- 绑定按钮事件
  self.b600ToKettle:registerControlEventHandler(function(button, eventType)
    self:handleB600OrKettleFrom("right")
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  -- kettle 往 b6 倒水
  sprite             = ccui.Scale9Sprite:create(self:imagePath("MK3"), cc.rect(0, 0, 1024, 128), cc.rect(0, 0, 1024, 128))  
  local kettleToB600 = cc.ControlButton:create(sprite)
  self.kettleToB600  = kettleToB600

 kettleToB600:setAnchorPoint(0.5, 0.5)
 kettleToB600:setPreferredSize(cc.size(980, 250))
 kettleToB600:setPositionX(900)
 kettleToB600:setPositionY(850)
 kettleToB600:setLocalZOrder(101)
 self:addChild(kettleToB600)

 -- 绑定按钮事件
 self.kettleToB600:registerControlEventHandler(function(button, eventType)
   self:handleB600OrKettleFrom("left")
 end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

 -- 设置全部隐藏
 self.b600ToB330:setVisible(false)
 self.b330ToB600:setVisible(false)
 self.b330ToKettle:setVisible(false)
 self.kettleToB330:setVisible(false)
 self.b600ToKettle:setVisible(false)
 self.kettleToB600:setVisible(false)
end

function E9BathPlug:showCustomButtonStyle(button)
  if button == nil then
    return
  end

  local sprite = cc.Sprite:create("Gaming/circle.png")

  -- sprite:setScale(0.7)
  sprite:setName("button_style_")
  sprite:setAnchorPoint(0.5, 0.5)
  -- print(button:getPositionX())

  local y = button:getPositionY() - button:getContentSize().height

  if button == self.b600ToKettle then
    y = button:getPositionY()
  end

  sprite:setPosition(button:getPositionX(), y)
  -- sprite:setVisible(false)
  sprite:setLocalZOrder(9999)
  
  self:addChild(sprite)

  local action1 = cc.FadeTo:create(1.5, 100)
  local action2 = cc.FadeTo:create(1.5, 255)

  -- local action1 = cc.ScaleTo:create(1, 1.2)
  -- local action2 = cc.ScaleTo:create(1, 1)
  local action3 = cc.Sequence:create(action1, action2)

  sprite:runAction(cc.RepeatForever:create(action3))
end

function E9BathPlug:updateB600Image()
  -- 判断脉动瓶子现在的水位状态，如果是空的就用0，少于一半就用2，多余一半用5，满了用7
  local mLevel = self:getInteger("b600_level")
  
  if mLevel == 0 then
    self:imageOn("m0")
  
  elseif mLevel > 0 and mLevel < 300 then
    self:imageOn("m2")
  
  elseif mLevel >= 300 and mLevel < 600 then
    self:imageOn("m5")
  
  else
    self:imageOn("m7")
  end 
end

function E9BathPlug:afterLoad()
  if self.tipMode then
    return
  end
  
  -- -- 如果水壶里的水在水池边已经倒掉拉，那里这里使用时要重新归0
  if self:getInteger("kettle_hot_water") == 0 then
    self:setInteger("kettle_level", 0)
  end
  
    -- 添加一堆按钮和label
  self:initLabelButton()
  self:initChangeButton()

  -- 如果已经知道瓶子都摆过了，这里进来直接显示所有的瓶子
  if self:getInteger("bath_plug_button_showed") > 0 then
    self:imageOn("40")
    self:imageOn("6")
    
    self:updateB600Image()
    self.useB600ed = true
    self.useHeated = true

    self:say("")
  end

  self:showView()
end

function E9BathPlug:afterLoad2()  
  self:cacheImage("BathSeeA/0")
end

function E9BathPlug:beforeUnload()
  self.kettleLabel:setVisible(false)
  self.kettleLabelLayer:setVisible(false)
  self.kc:setVisible(false)
  self.kb:setVisible(false)

  self.b330Label:setVisible(false)
  self.b330LabelLayer:setVisible(false)
  self.b3c:setVisible(false)
  self.b3f:setVisible(false)

  self.b600Label:setVisible(false)
  self.b600LabelLayer:setVisible(false)
  self.b6c:setVisible(false)
  self.b6f:setVisible(false)
  
  self:setInteger("b600_level", 0)
  self:setInteger("b330_level", 0)
end

function E9BathPlug:beforeUseItem(itemName)
  if "kettle" == itemName and not self:imageIsOn("40") and self.opened == true then
    return true
  end
  
  if "b330" == itemName and self.useHeated == true and not self:imageIsOn("6") then
    return true
  end
  
  if "b600" == itemName and self.useHeated == true then
    return not self.useB600ed
  end
  
  return false
end

function E9BathPlug:afterUseItem(itemName)

  if "kettle" == itemName then
    self:imageOn("40")
    self:sayI18n("open_2")

    self.useHeated = true
    
    -- 如果在使用水壶之前，已经使用过7喜罐子，则把图片重新加一下，防止水壶图片遮盖住7喜图片
    if self:imageIsOn("6") then
      self:imageOn("6")
    end
    
    -- 水壶放上去的时候直接显示操作界面，显示哪些按钮在showView里判断
    self:showView()
    
    return true
  end

  if "b330" == itemName then
    self:imageOn("6")
    
    -- 当水壶、7喜、脉动都使用了之后，显示操作界面
    if self:imageIsOn("40") and self:imageIsOn("6") and self.useB600ed == true then
      -- 如果先拿出脉动，然后拿出七喜
      self:sayI18n("afterUseItem_3")
    
      self:showView()
      
      return true
    end
    
    self:sayI18n("afterUseItem_4")
    
    return true
  end
  
  if "b600" == itemName then
    self:updateB600Image()
    self.useB600ed = true
    
    -- 当水壶、7喜、脉动都使用了之后，显示操作界面
    if self:imageIsOn("40") and self:imageIsOn("6") and self.useB600ed == true then
      -- 如果先拿出七喜，然后拿出脉动
      self:sayI18n("afterUseItem_5")
    
      self:showView()
      
      return true
    end
    
    -- 如果只是拿出了脉动，没有拿出七喜
    self:sayI18n("afterUseItem_6")
    
    return true
  end
  
  return true
end

function E9BathPlug:showView()
  -- 当水壶、7喜、脉动都使用了之后，显示全部的操作界面
  if self:imageIsOn("40") and self:imageIsOn("6") and self.useB600ed == true then    
    -- 记录用户懂得怎么烧水
    if self:getInteger("bath_plug_button_showed") < 1 then
      self:setInteger("bath_plug_button_showed", 1)
      self:play("item")
    end
    
    self.kettleLabel:setVisible(true)
    self.kettleLabelLayer:setVisible(true)
    self.kc:setVisible(true)
    self.kb:setVisible(true)
         
    self.b330Label:setVisible(true)
    self.b330LabelLayer:setVisible(true)
    self.b3c:setVisible(true)
    self.b3f:setVisible(true)

    self.b600Label:setVisible(true)
    self.b600LabelLayer:setVisible(true)
    self.b6c:setVisible(true)
    self.b6f:setVisible(true)

    self.b600ToB330:setVisible(true)
    self.b330ToB600:setVisible(true)
    self.b330ToKettle:setVisible(true)
    self.kettleToB330:setVisible(true)
    self.b600ToKettle:setVisible(true)
    self.kettleToB600:setVisible(true)

    -- 清除原来开关上的提示样式
    local node = self:getChildByName("button_style_open")

    if node then
      node:setVisible(false)
    end

    -- 显示提示样式
    self:showCustomButtonStyle(self.kb)
    -- self:showCustomButtonStyle(self.kb)
    -- self:showCustomButtonStyle(self.b3c)
    -- self:showCustomButtonStyle(self.b3f)
    -- self:showCustomButtonStyle(self.b6c)
    self:showCustomButtonStyle(self.b6f)

    -- self:showCustomButtonStyle(self.b600ToB330)
    -- self:showCustomButtonStyle(self.b330ToB600)
    -- self:showCustomButtonStyle(self.b330ToKettle)
    -- self:showCustomButtonStyle(self.kettleToB330)
    self:showCustomButtonStyle(self.b600ToKettle)
    -- self:showCustomButtonStyle(self.kettleToB600)
    
    -- 检查壶里是否有热水，如果是热水显示红色的字，否则显示白色的字
    local kettleColor = cc.c4b(255, 255, 255, 255)

    if self:getInteger("kettle_hot_water") == 2 then
      kettleColor = cc.c4b(255, 0, 0, 255)
    end

    self.kettleLabel:setColor(kettleColor)
    
    return
  end

  self.kettleLabel:setVisible(false)
  self.kettleLabelLayer:setVisible(false)
  self.kc:setVisible(false)
  self.kb:setVisible(false)

  self.b330Label:setVisible(false)
  self.b330LabelLayer:setVisible(false)
  self.b3c:setVisible(false)
  self.b3f:setVisible(false)

  self.b600Label:setVisible(false)
  self.b600LabelLayer:setVisible(false)
  self.b6c:setVisible(false)
  self.b6f:setVisible(false)

  self.b600ToB330:setVisible(false)
  self.b330ToB600:setVisible(false)
  self.b330ToKettle:setVisible(false)
  self.kettleToB330:setVisible(false)
  self.b600ToKettle:setVisible(false)
  self.kettleToB600:setVisible(false)
end

function E9BathPlug:open(rect)
  -- 如果三个道具都放上来了，这个方法就不触发了
  if self:imageIsOn("40") and self:imageIsOn("6") and self.useB600ed == true then
    return
  end

  -- 盖子还没打开
  if not self.opened then
    self.opened = true
    
    self:imageOn("1")
    self:play("floorsocket")
    self:sayI18n("handleSwipeFrom_1")

    return
  end
  
  -- 水壶也放上去了
  if self:imageIsOn("40") then
    self:sayI18n("open_3")

    return
  end
  
  self:sayI18n("open_5")
end

function E9BathPlug:handleB600OrB330From(way)
  if way == "right" then
    -- 瓶子里没有水
    if self:getInteger("b600_level") == 0 then
      self:sayI18n("handleB600OrB330From_1")
      
      return
    end
    
    -- 如果罐子里满水的，那么不让倒
    if self:getInteger("b330_level") >= 330 then
      self:sayI18n("handleB600OrB330From_2")
      
      return
    end
    
    -- 得到现在三个容器里装的水的数据
    self.beforeM = self:getInteger("b600_level")
    self.beforeS = self:getInteger("b330_level")
    self.beforeK = self:getInteger("kettle_level")
    
    -- 往罐子里加水
    self:play("basindrain")
    
    -- 该往罐子里加多少
    local num = 330 - self:getInteger("b330_level")
    
    if self:getInteger("b600_level") <= num then
      self:setInteger("b330_level", self:getInteger("b600_level") + self:getInteger("b330_level"))
      self:setInteger("b600_level", 0)
      self:sayI18n("handleB600OrB330From_3")
      
    elseif self:getInteger("b600_level") > num then
      self:setInteger("b330_level", self:getInteger("b330_level") + num)
      self:setInteger("b600_level", self:getInteger("b600_level") - num)
      self:sayI18n("handleB600OrB330From_4")
    end
    
    self:arrowFlicker(self.b600ToB330)
    
    return
  end

  if way == "left" then
    -- 罐子里没有水
    if self:getInteger("b330_level") == 0 then
      self:sayI18n("handleB600OrB330From_5")
      
      return
    end
    
    -- 如果瓶子里满水的，那么不让倒
    if self:getInteger("b600_level") >= 600 then
      self:sayI18n("handleB600OrB330From_6")
      
      return
    end
    
    -- 得到现在三个容器里装的水的数据
    self.beforeM = self:getInteger("b600_level")
    self.beforeS = self:getInteger("b330_level")
    self.beforeK = self:getInteger("kettle_level")
    
    -- 往瓶子里加水
    self:play("basindrain")
    
    -- 该往瓶子里加多少
    local num = 600 - self:getInteger("b600_level")
    
    if self:getInteger("b330_level") <= num then
      self:setInteger("b600_level", self:getInteger("b600_level") + self:getInteger("b330_level"))
      self:setInteger("b330_level", 0)
      self:sayI18n("handleB600OrB330From_7")
      
    elseif self:getInteger("b330_level") > num then
      self:setInteger("b600_level", self:getInteger("b600_level") + num)
      self:setInteger("b330_level", self:getInteger("b330_level") - num)
      self:sayI18n("handleB600OrB330From_8")
    end
    
    -- 开始箭头动画
    self:arrowFlicker(self.b330ToB600)
  end
end

function E9BathPlug:handleB330OrKettleFrom(way)
  -- 不管往哪个方向，只要水壶的水烧开了，只能倒掉
  if self:getInteger("kettle_hot_water") == 2 then
    self:sayI18n("handleB330OrKettleFrom_1")
    
    return
  end
  
  if way == "right" then
    -- 罐子里没有水
    if self:getInteger("b330_level") == 0 then
      self:sayI18n("handleB330OrKettleFrom_2")
      
      return
    end
    
    -- 水壶容量为2000限制，如果往里倒的时候，发现会超过2000，那么就不让倒
    if (self:getInteger("b330_level") + self:getInteger("kettle_level")) > 2000 then
      self:sayI18n("handleB330OrKettleFrom_3")
      
      return
    end
    
    -- 得到现在三个容器里装的水的数据
    self.beforeM = self:getInteger("b600_level")
    self.beforeS = self:getInteger("b330_level")
    self.beforeK = self:getInteger("kettle_level")
    
    -- 将水倒入水壶里，清空瓶子里的水
    self:setInteger("kettle_level", self:getInteger("kettle_level") + self:getInteger("b330_level"))
    self:setInteger("b330_level", 0)
    
    self:play("basindrain")
    self:sayI18n("handleB330OrKettleFrom_4")
    
    -- 开始箭头动画
    self:arrowFlicker(self.b330ToKettle)
    
    return
  end
  
  if way == "left" then
    -- 水壶里没有水
    if self:getInteger("kettle_level") == 0 then
      self:sayI18n("handleB330OrKettleFrom_5")
      
      return
    end
    
    -- 罐子里满水
    if self:getInteger("b330_level") >= 330 then
      self:sayI18n("handleB330OrKettleFrom_6")
      
      return
    end
    
    -- 得到现在三个容器里装的水的数据
    self.beforeM = self:getInteger("b600_level")
    self.beforeS = self:getInteger("b330_level")
    self.beforeK = self:getInteger("kettle_level")
    
    -- 往七喜罐子里倒水
    self:play("basindrain")
    
    -- 该往罐子里加多少
    local num = 330 - self:getInteger("b330_level")
    
    if self:getInteger("kettle_level") <= num then
      -- 水壶里的水量小于等于该加的量，那么水壶清空，罐子里的水量就是水壶里的水量
      self:setInteger("b330_level", self:getInteger("kettle_level") + self:getInteger("b330_level"))
      self:setInteger("kettle_level", 0)
      self:sayI18n("handleB330OrKettleFrom_7")
      
    elseif self:getInteger("kettle_level") > num then
      -- 水壶里的水量大于该加的量，那么水壶剩余的就是水壶现有的减去该加的，罐子里的水量就为罐子里原本剩余量加上该加的
      self:setInteger("b330_level", self:getInteger("b330_level") + num)
      self:setInteger("kettle_level", self:getInteger("kettle_level") - num)
      self:sayI18n("handleB330OrKettleFrom_8")
    end
    
    -- 开始箭头动画
    self:arrowFlicker(self.kettleToB330)
  end
end

function E9BathPlug:handleB600OrKettleFrom(way)
  -- 不管往哪个方向，只要水壶的水烧开了，只能倒掉
  if self:getInteger("kettle_hot_water") == 2 then
    self:sayI18n("handleB600OrKettleFrom_1")
    
    return
  end
  
  if way == "right" then
    -- 瓶子里没有水
    if self:getInteger("b600_level") == 0 then
      self:sayI18n("handleB600OrKettleFrom_2")
      
      return
    end
    
    -- 水壶容量为2000限制，如果往里倒的时候，发现会超过2000，那么就不让倒
    if (self:getInteger("b600_level") + self:getInteger("kettle_level")) > 2000 then
      self:sayI18n("handleB600OrKettleFrom_3")
      
      return
    end
    
    -- 得到现在三个容器里装的水的数据
    self.beforeM = self:getInteger("b600_level")
    self.beforeS = self:getInteger("b330_level")
    self.beforeK = self:getInteger("kettle_level")
    
    -- 将水倒入水壶里，清空瓶子里的水
    self:setInteger("kettle_level", self:getInteger("kettle_level") + self:getInteger("b600_level"))
    self:setInteger("b600_level", 0)
    self:play("basindrain")
    self:sayI18n("handleB600OrKettleFrom_4")
    
    -- 开始箭头动画
    self:arrowFlicker(self.b600ToKettle)
    
    return
  end
  
  if way == "left" then
    -- 水壶里没有水
    if self:getInteger("kettle_level") == 0 then
      self:sayI18n("handleB600OrKettleFrom_5")
      
      return
    end
    
    -- 瓶子里满水
    if self:getInteger("b600_level") == 600 then
      self:sayI18n("handleB600OrKettleFrom_6")
      
      return
    end
    
    -- 得到现在三个容器里装的水的数据
    self.beforeM = self:getInteger("b600_level")
    self.beforeS = self:getInteger("b330_level")
    self.beforeK = self:getInteger("kettle_level")
    
    -- 往瓶子里倒水
    self:play("basindrain")
    
    -- 该往瓶子里加多少
    local num = 600 - self:getInteger("b600_level")
    
    if self:getInteger("kettle_level") <= num then
      -- 水壶里的水量小于等于该加的量，那么水壶清空，罐子里的水量就是水壶里的水量
      self:setInteger("b600_level", self:getInteger("kettle_level") + self:getInteger("b600_level"))
      self:setInteger("kettle_level", 0)
      self:sayI18n("handleB600OrKettleFrom_7")
      
    elseif self:getInteger("kettle_level") > num then
      -- 水壶里的水量大于该加的量，那么水壶剩余的就是水壶现有的减去该加的，罐子里的水量就为罐子里原本剩余量加上该加的
      self:setInteger("b600_level", self:getInteger("b600_level") + num)
      self:setInteger("kettle_level", self:getInteger("kettle_level") - num)
      self:sayI18n("handleB600OrKettleFrom_8")
    end
    
    -- 开始箭头动画
    self:arrowFlicker(self.kettleToB600)
  end
end

function E9BathPlug:arrowFlicker(button)
  if button == nil then
    return
  end
  
  -- 动画之前，设置一些参数
  if self.count == 0 then
    self.count = self.count + 1
    
    -- 如果出现不同的数据了，那么那个数据有出现不同，就设置那个Label可以开始动画
    if self.beforeM ~= self:getInteger("b600_level") then
      self.isChangeM = true
    end
    
    if self.beforeS ~= self:getInteger("b330_level") then
      self.isChangeS = true
    end
    
    if self.beforeK ~= self:getInteger("kettle_level") then
      self.isChangeK = true
    end
    
    button:setVisible(false)
    self:disableTouch()

    self:scheduleOnce(0.02, function()
      self:arrowFlicker(button)
    end)
    
    return
  end

  -- 当count大于等于self.animationCount的时候，就停止闪烁
  if self.count >= self.animationCount then
    self.isChangeM = false
    self.isChangeS = false
    self.isChangeK = false
    self.count     = 0
    
    self:updateCapacity()
    self:enableTouch()
    
    return
  end
  
  -- 开始闪烁，判断self.a1是否打开，如果self.a1是显示的就隐藏，否则就显示
  if self.count % 10 == 0 then
    if button:isVisible() then
      button:setVisible(false)
    
    else
      button:setVisible(true)
    end
  end
  
  -- 如果m容器被改变
  if self.isChangeM then
    local isPlus   = self:getInteger("b600_level") > self.beforeM
    local ml  = 0
    
    -- 如果是增加了
    if isPlus then
      ml = self.beforeM + (self:getInteger("b600_level") - self.beforeM) / self.animationCount * self.count
      
    else
      -- 如果是减少了
      ml = self.beforeM - (self.beforeM - self:getInteger("b600_level")) / self.animationCount * self.count
    end

    ml = math.floor(ml)
    
    self.b600Label:setString(ml .. " ml")
  end
  
  if self.isChangeS then
    local isPlus   = self:getInteger("b330_level") > self.beforeS
    local ml  = 0
    
    -- 如果是增加了
    if isPlus then
      ml = self.beforeS + (self:getInteger("b330_level") - self.beforeS) / self.animationCount * self.count
      
    else
      -- 如果是减少了
      ml = self.beforeS - (self.beforeS - self:getInteger("b330_level")) / self.animationCount * self.count
    end

    ml = math.floor(ml)
    
    self.b330Label:setString(ml .. " ml")
  end
  
  if self.isChangeK then
    local isPlus   = self:getInteger("kettle_level") > self.beforeK
    local ml  = 0
    
    -- 如果是增加了
    if isPlus then
      ml = self.beforeK + (self:getInteger("kettle_level") - self.beforeK) / self.animationCount * self.count
      
    else
      -- 如果是减少了
      ml = self.beforeK - (self.beforeK - self:getInteger("kettle_level")) / self.animationCount * self.count
    end
    
    ml = math.floor(ml)

    self.kettleLabel:setString(ml .. " ml")
  end
  
  self.count = self.count + 1

  self:scheduleOnce(0.02, function()
    self:arrowFlicker(button)
  end)
end

function E9BathPlug:kettleClear(rect)
  -- 水壶里没有水
  if self:getInteger("kettle_level") == 0 then
    self:sayI18n("kettleClear_1")
    
    return
  end
  
  -- 把水壶里的水清空
  self.beforeK   = self:getInteger("kettle_level")
  self.isChangeK = true
  
  self:setInteger("kettle_level", 0)
  self:setInteger("kettle_hot_water", 0)
  self:play("bottlewatering")
  self:sayI18n("kettleClear_2")
  
  self:fillWaterAnimation()
end

function E9BathPlug:kettleBoiling(rect)
  -- 水壶里没有水
  if self:getInteger("kettle_level") == 0 then
    self:sayI18n("kettleBoiling_1")
    
    return
  end

  -- 已经是热水了，不用烧
  if self:getInteger("kettle_hot_water") == 2 then
    self:sayI18n("handleB330OrKettleFrom_1")
    
    return
  end
  
  self:imageOn("41")
  self:play("kettle")
  self:showView()
  self:sayI18n("kettleBoiling_2")
  
  self:hideArrowButton()
  self:disableTouch()
  
  -- 调用动画
  self:delay()
end

function E9BathPlug:delay()
  if self.labelColorCount == 0 then
    self.isPlayWaterBoiled = false
  end
  
  self.labelColorCount = self.labelColorCount + 1
  
  if self.labelColorCount >= 3 and not self.isPlayWaterBoiled then
    self.isPlayWaterBoiled = true

    self:play("waterboiled")
    self:scheduleOnce(2, function()
      -- 沸腾的音效播放完了
      self:sayI18n("delay_1")

      -- 记录水壶里的水是开水状态，并且记录用户曾经烧过水，知道怎么烧水了（给tip用）
      self:setInteger("kettle_hot_water", 2)
      
      if self:getInteger("kettle_boiled_once") < 1 then
        self:setInteger("kettle_boiled_once", 1)
      end

      self.labelColorCount = 0

      self.kettleLabel:setColor(cc.c4b(255, 0, 0, 255))
      self:showArrowButton()
      self:imageOff("41")
      self:play("kettle")
      self:enableTouch()
    end)
  end

  -- 设置水壶label下面的颜色渐变
  self.kettleLabel:setColor(cc.c4b(255, 255 - 255 / 10 * self.labelColorCount , 255 - 255 / 10 * self.labelColorCount, 255))
  
  if self.labelColorCount < 10 then
    self:scheduleOnce(0.2, function()
      self:delay()
    end)
  end
end

function E9BathPlug:b330Clear(rect)
  -- 有水的情况下，直接清空7喜罐子里的水
  if self:getInteger("b330_level") > 0 then
    -- 设置原来的水位
    self.beforeS   = self:getInteger("b330_level")
    self.isChangeS   = true
    
    self:setInteger("b330_level", 0)
    self:play("bottlewatering")
    self:sayI18n("b330Clear_1")
    
    -- 这里开始做延时动画
    self:fillWaterAnimation()
    
    return
  end
  
  self:sayI18n("b330Clear_2")
end

function E9BathPlug:b330Fill(rect)
  -- 当瓶子里的水没满的时候就可以加满
  if self:getInteger("b330_level") < 330 then
    -- 设置原来的水位
    self.beforeS   = self:getInteger("b330_level")
    self.isChangeS   = true
    
    self:setInteger("b330_level", 330)
    self:play("basindrain")
    self:sayI18n("b330Fill_2")
    
    -- 这里开始做延时动画
    self:fillWaterAnimation()
    
    return
  end
  
  self:sayI18n("b330Fill_3")
end

function E9BathPlug:b600Clear(rect)
  -- 有水的情况下，直接清空脉动瓶子里的水
  if self:getInteger("b600_level") > 0 then
    -- 设置原来的水位
    self.beforeM   = self:getInteger("b600_level")
    self.isChangeM   = true
    
    self:setInteger("b600_level", 0)
    self:play("bottlewatering")
    self:sayI18n("b600Clear_1")
    
    -- 这里开始做延时动画
    self:fillWaterAnimation()
    
    return
  end
  
  self:sayI18n("b600Clear_2")
end

function E9BathPlug:b600Fill(rect)
  -- 当瓶子里的水没满的时候
  if self:getInteger("b600_level") < 600 then
    -- 设置原来的水位
    self.beforeM   = self:getInteger("b600_level")
    self.isChangeM = true
    
    self:setInteger("b600_level", 600)
    self:play("basindrain")
    self:sayI18n("b600Fill_2")
    
    -- 这里开始做延时动画
    self:fillWaterAnimation()
    
    return
  end
  
  self:sayI18n("b600Fill_3")
end

function E9BathPlug:fillWaterAnimation()
  if self.count == 0 then
    self.count = self.count + 1
    
    self:disableTouch()
    self:scheduleOnce(0.02, function()
      self:fillWaterAnimation()
    end)
    
    return
  end
  
  -- 当count大于等于self.animationCount的时候，就停止
  if self.count >= self.animationCount then
    self.count     = 0
    self.isChangeM = false
    self.isChangeS = false
    self.isChangeK = false
    
    self:updateCapacity()
    self:enableTouch()
    
    return
  end

  -- 如果M需要改变，那么改变M
  if self.isChangeM then
    local isPlus = self:getInteger("b600_level") > self.beforeM
    local ml     = 0
    
    -- 如果是增加了
    if isPlus then
      ml = self.beforeM + (self:getInteger("b600_level") - self.beforeM) / self.animationCount * self.count
      
    else
      -- 如果是减少了
      ml = self.beforeM - (self.beforeM - self:getInteger("b600_level")) / self.animationCount * self.count
    end

    ml = math.floor(ml)
    
    self.b600Label:setString(ml .. " ml")

  elseif self.isChangeS then
    local isPlus = self:getInteger("b330_level") > self.beforeS
    local ml     = 0
    
    -- 如果是增加了
    if isPlus then
      ml = self.beforeS + (self:getInteger("b330_level") - self.beforeS) / self.animationCount * self.count
      
    else
      -- 如果是减少了
      ml = self.beforeS - (self.beforeS - self:getInteger("b330_level")) / self.animationCount * self.count
    end

    ml = math.floor(ml)
    
    self.b330Label:setString(ml .. " ml")

  elseif self.isChangeK then
    local isPlus = self:getInteger("kettle_level") > self.beforeK
    local ml     = 0
    
    -- 如果是增加了
    if isPlus then
      ml = self.beforeK + (self:getInteger("kettle_level") - self.beforeK) / self.animationCount * self.count
      
    else
      -- 如果是减少了
      ml = self.beforeK - (self.beforeK - self:getInteger("kettle_level")) / self.animationCount * self.count
    end

    ml = math.floor(ml)
    
    self.kettleLabel:setString(ml .. " ml")
  end
  
  self.count = self.count + 1
  
  self:scheduleOnce(0.02, function()
    self:fillWaterAnimation()
  end)
end

function E9BathPlug:updateCapacity()
  -- 更新容量
   self.kettleLabel:setString(self:getInteger("kettle_level") .. " ml")
   self.b600Label:setString(self:getInteger("b600_level") .. " ml")
   self.b330Label:setString(self:getInteger("b330_level") .. " ml")
  
  -- 如果水壶里加的有水，则记录一个变量来控制，用在Sink往水池里倒水喷烟雾用
  if self:getInteger("kettle_level") ~= 0 and self:getInteger("kettle_hot_water") ~= 2 then
    self:setInteger("kettle_hot_water", 1)
  end
  
  self:updateB600Image()
  
  self:showView()
end

function E9BathPlug:b600ChangeB330(rect)
  if not self.useHeated or not self.useB600ed then
    return
  end
  
  if self:imageIsOn("40") and self:imageIsOn("6") and self.useB600ed then
    self:sayI18n("b330Change_1")
  
  else
    self:sayI18n("afterUseItem_6")
  end
end

function E9BathPlug:b330Change(rect)
  if not self.useHeated or not self:imageIsOn("6") then
    return
  end

  if self:imageIsOn("40") and self:imageIsOn("6") and self.useB600ed then
    self:sayI18n("b330Change_1")
  
  else
    self:sayI18n("afterUseItem_4")
  end
end

function E9BathPlug:kettleChangeB330(rect)
  if not self.useHeated then
    return
  end

  if self:imageIsOn("40") and self:imageIsOn("6") and self.useB600ed then
    self:sayI18n("b330Change_1")
  
  else
    self:sayI18n("open_3")
  end
end

return E9BathPlug
