local E9Door = class("E9Door", function()
  return BasePlace.new()
end)

function E9Door:initPhoto()
  self:addPhoto("4", 768, 768)
  self:addPhoto("6", 0, 0)
end

function E9Door:initButton()
  self:addButton("open", 660, 516, 540, 632)
  self:addButton("goPeephole", 1512, 0, 408, 274)
  self:addButton("openLamp", 348, 82, 268, 224)
end

function E9Door:switchImage()
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOff("4")
    
    self:scheduleOnce(0.2, function()
      self:switchImage()
    end)

    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("4")
    self:scheduleOnce(0.3, function()
      self:switchImage()
    end)

    return
  end
  
  if progress == self:nextProgressIndex() then
    self.progress = nil

    self:imageOff("4")
    self:enableTouch()
    
    return
  end
end

function E9Door:arrowLeft(rect)
  self:switchPlaceLeft("Entry")
end

function E9Door:beforeLoad()
  if self:getInteger("room_switch") == 0 then
    self:imageOn("0")
    
    return
  end
  
  self:imageOn("2")
end

function E9Door:afterLoad()
  if "OutsideEntry" == self.lastPlaceName then
    self:sayI18n("afterLoad_1")
  end
end

function E9Door:afterLoad2()  
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")
    
  else
    self:cacheImage("Entry/50")
  end

  self:cacheImage("Peephole/0")
end

function E9Door:beforeUseItem(itemName)
  if "card" == itemName and self:getInteger("room_switch") == 0 then
    return true
  end
  
  return false
end

function E9Door:afterUseItem(itemName)
  if "card" == itemName then
    self:imageOn("2")
    self:setInteger("room_switch", 1)
    self:play("item")
    self:sayI18n("afterUseItem_1")
    
    return false
  end
  
  return true
end

function E9Door:open(rect)
  -- 还没有使用房卡开灯
  if self:getInteger("room_switch") == 0 then
    self:play("doorknob")
    self:sayI18n("open_1")
    
    return
  end
  
  -- 灯已经打开，尝试开门
  self:imageOn("4")
  self:play("doorknob")
  self:sayI18n("open_2")
  
  self:disableTouch()
  self:switchImage()

end

function E9Door:goPeephole(rect)
  self:switchPlaceZoomIn("Peephole", rect)
end

function E9Door:openLamp(rect)
  if self:getInteger("room_switch") == 0 then
    self:sayI18n("openLamp_1")
    
    return
  end
  
  self:sayI18n("openLamp_2")
end

return E9Door
