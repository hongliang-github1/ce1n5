local E9BedRight = class("E9BedRight", function()
  return BasePlace.new()
end)

function E9BedRight:initPhoto()
  self:addPhoto("2", 448, 512)
end

function E9BedRight:initButton()
  self:addButton("openLamp", 410, 0, 462, 424)
  self:addButton("paper", 884, 298, 398, 394)
  self:addButton("click", 278, 504, 598, 644)
end

function E9BedRight:arrowDown(rect)
  self:switchPlaceZoomOut("Entry")
end

function E9BedRight:beforeLoad()
  self:imageOn("1")
  
  if self:getInteger("remoter") < 0 then
    self:imageOn("2")
  end
end

function E9BedRight:afterLoad()

end

function E9BedRight:afterLoad2()
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")
    
  else
    self:cacheImage("Entry/50")
  end

  self:cacheImage("Remoter/0")
  self:cacheImage("LightPlug/1")
end

function E9BedRight:beforeUseItem(itemName)
  return false
end

function E9BedRight:afterUseItem(itemName)
  return true
end

function E9BedRight:click(rect)
  -- 已经使用过灯光调节器
  if self:getInteger("remoter") < 0 then
    self:switchPlaceZoomIn("Remoter", cc.rect(226 * 2, 241 * 2, 180 * 2, 151 * 2))
    
    return
  end
  
  self:switchPlaceZoomIn("LightPlug", rect)
end

function E9BedRight:openLamp(rect)
  self:sayI18n("openLamp_1")
end

function E9BedRight:paper(rect)  
  if self:getInteger("tissue") == 0 then
    self:getItem("tissue")
    self:sayI18n("paper_2")

    return
  end

  self:sayI18n("paper_3")
end

return E9BedRight
