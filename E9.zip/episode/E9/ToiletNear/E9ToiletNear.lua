local E9ToiletNear = class("E9ToiletNear", function()
  return BasePlace.new()
end)

function E9ToiletNear:initPhoto()
end

function E9ToiletNear:initButton()
  self:addButton("click", 516, 138, 1020, 886)
end

function E9ToiletNear:arrowDown(rect)
  self:switchPlaceZoomOut("Toilet")
end

function E9ToiletNear:beforeLoad()
  self:imageOn("0")
end

function E9ToiletNear:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9ToiletNear:afterLoad2()
  self:cacheImage("Toilet/0")
end

function E9ToiletNear:beforeUseItem(itemName)
  return false
end

function E9ToiletNear:afterUseItem(itemName)
  return true
end

function E9ToiletNear:click(rect)
  self:sayI18n("click_1")
end

return E9ToiletNear
