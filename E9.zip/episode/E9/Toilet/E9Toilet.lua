local E9Toilet = class("E9Toilet", function()
  return BasePlace.new()
end)

function E9Toilet:initPhoto()
end

function E9Toilet:initButton()
  self:addButton("goToiletTrash", 472, 512, 362, 400)
  self:addButton("goToiletNear", 854, 536, 492, 352)
end

function E9Toilet:arrowDown(rect)
  self:switchPlaceZoomOut("BathSeeA")
end

function E9Toilet:beforeLoad()
  self:imageOn("0")
end

function E9Toilet:afterLoad()
  self:sayI18n("afterLoad_1")

end

function E9Toilet:afterLoad2()
  self:cacheImage("BathSeeA/0")
  self:cacheImage("ToiletTrash/0")
  self:cacheImage("ToiletNear/0")
end

function E9Toilet:beforeUseItem(itemName)
  return false
end

function E9Toilet:afterUseItem(itemName)
  return true
end

function E9Toilet:goToiletTrash(rect)
  self:switchPlaceZoomIn("ToiletTrash", rect)
end

function E9Toilet:goToiletNear(rect)
  self:switchPlaceZoomIn("ToiletNear", rect)
end

return E9Toilet
