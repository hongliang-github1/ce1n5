local E9Mirror = class("E9Mirror", function()
  return BasePlace.new()
end)

function E9Mirror:initPhoto()
  self:addPhoto("1", 0, 0)
  self:addPhoto("2", 1664, 0)
end

function E9Mirror:initButton()
  self:addButton("goSink", 848, 696, 598, 452)
  self:addButton("goSwitchA", 514, 564, 332, 414)
  self:addButton("goSwitchB", 1860, 524, 184, 330)
  self:addButton("click", 738, 2, 814, 692)
end

function E9Mirror:arrowDown(rect)
  self:switchPlaceZoomOut("BathSeeB")
end

function E9Mirror:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_a_open") == 1 then
    self:imageOn("1")
  end
  
  if self:getInteger("bath_door_b_open") == 1 then
    self:imageOn("2")
  end
end

function E9Mirror:afterLoad()

end

function E9Mirror:afterLoad2()
  self:cacheImage("BathSeeB/0")
  self:cacheImage("Sink/0")
end

function E9Mirror:beforeUseItem(itemName)
  return false
end

function E9Mirror:afterUseItem(itemName)
  return true
end

function E9Mirror:goSink(rect)
  self:switchPlaceZoomIn("Sink", rect)
end

function E9Mirror:goSwitchA(rect)
  self:switchPlaceZoomIn("SwitchA", rect)
end

function E9Mirror:goSwitchB(rect)
  self:switchPlaceZoomIn("SwitchB", rect)
end

function E9Mirror:click(rect)
  -- 正常情况下
  self:sayI18n("click_1")
end

return E9Mirror
