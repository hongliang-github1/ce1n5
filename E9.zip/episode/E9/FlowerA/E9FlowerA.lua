local E9FlowerA = class("E9FlowerA", function()
  return BasePlace.new()
end)

function E9FlowerA:initPhoto()
  self:addPhoto("2", 704, 768)
  self:addPhoto("3", 704, 768)
end

function E9FlowerA:initButton()
  self:addButton("open", 428, 348, 800, 800)
end

function E9FlowerA:arrowDown(rect)
  local pName = "WayB2"

  if self.lastPlaceName == "WayRight" then
    pName = "WayRight"
  end

  self:switchPlaceZoomOut(pName)
end

function E9FlowerA:beforeLoad()
  self:imageOn("0")
end

function E9FlowerA:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9FlowerA:afterLoad2() 
  self:cacheImage("1")
end

function E9FlowerA:beforeUseItem(itemName)
  return false
end

function E9FlowerA:afterUseItem(itemName)
  return true
end

function E9FlowerA:open(rect)
  if self:imageIsOn("1") then
    -- 如果有道具，则拿道具
    if self:getInteger("b330") == 0 and self:getString("b3_pos") == "flower_a" then
      self:imageOff("3")
      self:getItem("b330")
      self:sayI18n("open_1")
      
      return
    end
    
    if self:getInteger("b600") == 0 and self:getString("b6_pos") == "flower_a" then
      self:imageOff("2")
      self:getItem("b600")
      self:sayI18n("open_2")
      
      return
    end
    
    -- 关上帘子
    self:imageOn("0")
    self:imageOff("2")
    self:imageOff("3")
    self:play("beadcurtain")
    self:sayI18n("open_3")
    
    return
  end
  
  -- 拉开帘子
  self:imageOn("1")
  self:play("beadcurtain")
  
  -- 这里随机显示b330或b600瓶子
  if self:getInteger("b330") == 0 and self:getString("b3_pos") == "flower_a" then
    self:imageOn("3")
    self:sayI18n("open_4")
    
    return
  end
  
  if self:getInteger("b600") == 0 and self:getString("b6_pos") == "flower_a" then
    self:imageOn("2")
    self:sayI18n("open_5")
    
    return
  end
  
  self:sayI18n("open_6")
end

return E9FlowerA
