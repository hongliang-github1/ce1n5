local E9BathBlack = class("E9BathBlack", function()
  return BasePlace.new()
end)

function E9BathBlack:initPhoto()
end

function E9BathBlack:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E9BathBlack:arrowDown(rect)
  local pName = "BathDoorB"

  if "BathDoorA" == self.lastPlaceName then
    pName = "BathDoorA"
  end

  self:switchPlace(pName)
end

function E9BathBlack:beforeLoad()

end

function E9BathBlack:afterLoad()
  -- 当灯还没有变得更亮的时候，不管从BathDoorA进来还是BathDoorB进来都是到这里
  self:click(nil)
end

function E9BathBlack:afterLoad2()
end

function E9BathBlack:beforeUseItem(itemName)
  return false
end

function E9BathBlack:afterUseItem(itemName)
  return true
end

function E9BathBlack:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:arrowDown(nil)
    
    return
  end
end

return E9BathBlack
