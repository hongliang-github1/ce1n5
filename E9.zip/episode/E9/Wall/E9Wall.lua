local E9Wall = class("E9Wall", function()
  return BasePlace.new()
end)

function E9Wall:initPhoto()
  self:addPhoto("1", 960, 512)
  self:addPhoto("2", 960, 0)
end

function E9Wall:initButton()
  self:addButton("goWallDrawer", 1022, 852, 644, 296)
  self:addButton("flower", 964, 578, 436, 270)
  self:addButton("frame", 902, 0, 380, 412)
  self:addButton("goWayA2", 1434, 0, 610, 840)
end

function E9Wall:arrowLeft(rect)
  self:switchPlaceLeft("WayLeft")
end

function E9Wall:arrowRight(rect)
  self:switchPlaceRight("WayRight")
end

function E9Wall:beforeLoad()
  self:imageOn("0")
  self:imageOn("2")
end

function E9Wall:afterLoad()
  if self:getInteger("wall_visited") < 1 then
    self:setInteger("wall_visited", 1)
  end
end

function E9Wall:afterLoad2()  
  self:cacheImage("WayRight/0")
  self:cacheImage("WallDrawer/0")
  self:cacheImage("WayA2/0")
end

function E9Wall:beforeUseItem(itemName)
  return false
end

function E9Wall:afterUseItem(itemName)
  return true
end

function E9Wall:goWallDrawer(rect)
  self:switchPlaceDown("WallDrawer")
end

function E9Wall:flower(rect)
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:sayI18n("flower_1")
    
    return
  end
  
  self:imageOn("1")
  self:sayI18n("flower_2")
end

function E9Wall:frame(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:sayI18n("frame_1")
    
    return
  end
  
  self:imageOn("2")
  self:sayI18n("frame_2")
end

function E9Wall:goWayA2(rect)
  self:switchPlaceZoomIn("WayA2", cc.rect(719 * 2, 75 * 2, 303 * 2, 284 * 2))
end

return E9Wall
