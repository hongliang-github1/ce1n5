local E9WayB3 = class("E9WayB3", function()
  return BasePlace.new()
end)

function E9WayB3:initPhoto()
end

function E9WayB3:initButton()
  self:addButton("tv", 778, 360, 402, 380)
end

function E9WayB3:arrowUp(rect)
  self:switchPlaceZoomIn("Entry", cc.rect(312 * 2, 117 * 2, 361 * 2, 342 * 2))
end

function E9WayB3:arrowDown(rect)
  self:switchPlaceZoomOut("WayB2")
end

function E9WayB3:beforeLoad()
  self:imageOn("3")
end

function E9WayB3:afterLoad()

end

function E9WayB3:afterLoad2()
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")
    
  else
    self:cacheImage("Entry/50")
  end

  self:cacheImage("WayB2/0")
end

function E9WayB3:beforeUseItem(itemName)
  return false
end

function E9WayB3:afterUseItem(itemName)
  return true
end

function E9WayB3:tv(rect)
  self:sayI18n("tv_1")
end

return E9WayB3
