local E9Outside = class("E9Outside", function()
  return BasePlace.new()
end)

function E9Outside:initPhoto()
  self:addPhoto("1", 1216, 768)
  self:addPhoto("2", 768, 128)
  self:addPhoto("3", 768, 128)
end

function E9Outside:initButton()
  self:addButton("open", 772, 144, 786, 1004)
end

function E9Outside:beforeLoad()
  self:imageOn("0")
end

function E9Outside:afterLoad()
  self:sayI18n("afterLoad_1")

  self.useCard = false
end

function E9Outside:afterLoad2()
end

function E9Outside:afterUnload()
  self:cacheImageRemove("0")
  self:cacheImageRemove("1")
  self:cacheImageRemove("2")
  self:cacheImageRemove("3")
end

function E9Outside:beforeUseItem(itemName)
  if "card" == itemName then
    return true
  end

  return false
end

function E9Outside:afterUseItem(itemName)
  if "card" == itemName then
    -- 使用房卡开门
    self:imageOn("1")
    self:sayI18n("afterUseItem_1")

    self.useCard = true

    return true
  end

  return true
end

function E9Outside:open(rect)
  if not self.useCard then
    -- 还没有使用房卡
    self:play("doorknob")
    self:sayI18n("open_1")

    return
  end

  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:imageOff("1")
    self:play("item")
    self:sayI18n("open_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("3")
    self:imageOff("2")
    self:sayI18n("open_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:setInteger("outside_entry_in", 1)
    self:switchPlaceZoomIn("OutsideEntry", cc.rect(386 * 2, 184 * 2, 394 * 2, 335 * 2))

    return
  end
end

return E9Outside
