local E9Beginning = class("E9Beginning", function()
  return BasePlace.new()
end)

function E9Beginning:initPhoto()
end

function E9Beginning:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E9Beginning:beforeLoad()
  -- 第一次玩，生成道具随机位置
  if userdata.getEpisodeLastPlace(userdata.currentEpisode) == "" then
  
    --三个地方随机生成两个道具，一个b6，一个b3  
    local b63Array = { "sofa", "flower_a", "flower_b" }
    local b6random = math.random(3)
    local b3random = math.random(3)

    while b6random == b3random do
      -- 两个瓶子不能在一起
      b3random = math.random(3)
    end

    self:setString("b6_pos", b63Array[b6random])
    self:setString("b3_pos", b63Array[b3random])

    -- 生成灯光控制器和白纸
    local rpArray = { "wall_drawer", "ground_b" }
    local rrandom = math.random(2)
    local prandom = 2
    if rrandom == 2 then
      prandom = 1
    end

    self:setString("remoter_pos", rpArray[rrandom])
    self:setString("paper_pos", rpArray[prandom])

    -- 生成白纸上的密码
    local paperArray = { "810", "870", "1050", "1140", "1380", "1410", "1710", "1740", "1860"}
    self:setString("paper_password", paperArray[math.random(9)])

    -- 生成浴室镜子上显示的密码
    local num1 = math.random(9)
    local num2 = math.random(9)
    local num3 = math.random(9)
    local num4 = math.random(9)
    local num5 = math.random(9)

    self:setInteger("num1", num1)
    self:setInteger("num2", num2)
    self:setInteger("num3", num3)
    self:setInteger("num4", num4)
    self:setInteger("num5", num5)
  end

  self:imageOn("0")
end

function E9Beginning:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9Beginning:afterLoad2()
  self:cacheImage("Outside/0")
end

function E9Beginning:afterUnload()
  self:cacheImageRemove("Outside/0")
end

function E9Beginning:beforeUseItem(itemName)
  return false
end

function E9Beginning:afterUseItem(itemName)
  return true
end

function E9Beginning:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:getItem("card")
    
    return
  end
    
  if progress == self:nextProgressIndex() then
    self:switchPlace("Outside")
    
    return
  end
end

return E9Beginning
