local E9WayB1 = class("E9WayB1", function()
  return BasePlace.new()
end)

function E9WayB1:initPhoto()
  self:addPhoto("1", 320, 0)
  self:addPhoto("2", 320, 0)
end

function E9WayB1:initButton()
  self:addButton("goWayB2", 456, 0, 822, 1080)
end

function E9WayB1:arrowLeft(rect)
  self:switchPlaceLeft("WayLeft")
end

function E9WayB1:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_a_open") == 1 then
    if self:getInteger("room_brighter") == 0 then
      self:imageOn("1")
      
    else
      self:imageOn("2")
    end
  end
end

function E9WayB1:afterLoad()
  -- 记录来过WayB1，给tip用的
  if self:getInteger("way_b1_visited") < 1 then
    self:setInteger("way_b1_visited", 1)
  end
end

function E9WayB1:afterLoad2()
  self:cacheImage("WayLeft/0")
  self:cacheImage("WayB2/0")
end

function E9WayB1:beforeUseItem(itemName)
  return false
end

function E9WayB1:afterUseItem(itemName)
  return true
end

function E9WayB1:goWayB2(rect)
  self:switchPlaceZoomIn("WayB2", cc.rect(358 * 2, 165 * 2, 220 * 2, 272 * 2))
end

return E9WayB1
