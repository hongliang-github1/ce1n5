local E9GroundA = class("E9GroundA", function()
  return BasePlace.new()
end)

function E9GroundA:initPhoto()
end

function E9GroundA:initButton()
  self:addButton("open", 694, 58, 968, 952)
end

function E9GroundA:arrowRight(rect)
  self:switchPlaceRight("WallDrawer")
end

function E9GroundA:beforeLoad()
  self:imageOn("0")
end

function E9GroundA:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E9GroundA:afterLoad2()  
  self:cacheImage("1")
  self:cacheImage("WallDrawer/0")
end

function E9GroundA:beforeUseItem(itemName)
  return false
end

function E9GroundA:afterUseItem(itemName)
  return true
end

function E9GroundA:open(rect)
  if self:imageIsOn("1") then
    -- 关上柜门
    self:imageOn("0")
    self:play("cabinet")
    self:sayI18n("open_1")
    
    return
  end
  
  -- 打开柜门
  self:imageOn("1")
  self:play("cabinet")
  
  self:sayI18n("open_2")
end

return E9GroundA
