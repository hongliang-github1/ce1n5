local E9Sink = class("E9Sink", function()
  return BasePlace.new()
end)

function E9Sink:initPhoto()
  self:addPhoto("1", 832, 576)
  self:addPhoto("2", 1472, 512)
  self:addPhoto("3", 384, 320)
  self:addPhoto("41", 832, 576)
end

function E9Sink:initButton()
  self:addButton("click", 730, 476, 492, 320)
  self:addButton("open", 1576, 500, 314, 384)
end

function E9Sink:arrowDown(rect)
  local pName = "Mirror"

  if self.lastPlaceName == "BathSeeA" then
    pName = self.lastPlaceName
  end

  self:switchPlaceZoomOut(pName)
end

function E9Sink:beforeLoad()
  self:imageOn("0")

  if self:getInteger("sink_full_water") == 1 then
    self:imageOn("3")
    self:sayI18n("beforeLoad_1")

    return
  end

  self.coverOpen = true

  self:imageOn("1")
  self:sayI18n("beforeLoad_2")
end

function E9Sink:afterLoad()

end

function E9Sink:afterLoad2()
  self:cacheImage("MirrorFog/4")
end

function E9Sink:beforeUseItem(itemName)
  -- 这了kettle_hot_water代表水壶里水的状态，0为空水壶，1为装满水，但是是冷水，2为满水，但是是热水
  if "kettle" == itemName then
    return true
  end

  return false
end

function E9Sink:afterUseItem(itemName)
  if "kettle" == itemName then
    -- 水壶里没有水，不能倒
    if self:getInteger("kettle_hot_water") <= 0 then
      self:sayI18n("afterUseItem_1")

      return true
    end

    -- 水池里有水，则不让往倒水
    if self:getInteger("sink_full_water") == 1 then
      self:sayI18n("afterUseItem_2")

      return true
    end

    self:imageOn("40")

    -- 开始倒水，干掉无用的图片
    if self:imageIsOn("2") then
      self:imageOff("2")
    end

    if self.coverOpen == true then
      self:imageOn("41")
      self:imageOff("1")
    end

    if self:getInteger("kettle_hot_water") == 2 then
      self:sayI18n("afterUseItem_3")

    else
      self:sayI18n("afterUseItem_4")
    end

    self:disableTouch()

    -- 播放音效
    self:play("basindrain")

    self:scheduleOnce(1, function()
      self:imageOn("0")

      -- 水池底盖没有打开的情况下，水倒完之后，则水池有水
      if self.coverOpen == false then
        -- 水池里水满了
        self:imageOn("3")
        self:setInteger("sink_full_water", 1)

        -- 水都倒出来之后，如果倒的是热水，记录水池里倒满了热水
        if self:getInteger("kettle_hot_water") == 2 then
          -- 是开水，跳转到MirrorFog直接走起雾显示密码的剧情
          self:switchPlace("MirrorFog")

        else
          -- 不是开水，是凉水，没什么反应
          self:sayI18n("afterUseItem_5")
        end

      else
        self:imageOn("1")
        self:sayI18n("afterUseItem_6")
      end

      -- 设置水壶里没热水了
      self:setInteger("kettle_hot_water", 0)
      self:enableTouch()
    end)

    return true
  end

  return true
end

function E9Sink:click(rect)
  -- 正在倒水
  if self:imageIsOn("40") then
    -- 在往水池里倒水的时候，什么都不做
    return
  end

  -- 关上水池底盖
  if self.coverOpen == true then
    self:imageOff("1")
    self:imageOff("41")
    self:play("plug")
    self:sayI18n("click_1")

    self.coverOpen = false

    return
  end

  -- 打开水池底盖
  self.coverOpen = true

  -- 水池里有水，放掉水
  if self:imageIsOn("3") then
    self:imageOff("3")
    self:imageOn("1")
    self:play("plug")
    self:sayI18n("click_2")

    -- 水池里没水了
    self:setInteger("sink_full_water", 0)

    return
  end

  self:imageOn("1")
  self:play("plug")
  self:sayI18n("click_3")
end

function E9Sink:open(rect)
  if self:imageIsOn("40") then
    -- 在往水池里倒水的时候，什么都不做
    return
  end

  if self:imageIsOn("2") then
    self:imageOff("2")
    self:play("airswitch")
    self:sayI18n("open_1")

    return
  end

  self:imageOn("2")
  self:play("airswitch")
  self:sayI18n("open_2")
end

return E9Sink
