local E9WayA1 = class("E9WayA1", function()
  return BasePlace.new()
end)

function E9WayA1:initPhoto()
  self:addPhoto("1", 1344, 0)
  self:addPhoto("2", 1344, 0)
end

function E9WayA1:initButton()
  self:addButton("goWall", 852, 104, 534, 702)
end

function E9WayA1:arrowUp(rect)
  self:switchPlaceZoomIn("WayA2", cc.rect(539 * 2, 121 * 2, 234 * 2, 275 * 2))
end

function E9WayA1:arrowDown(rect)
  self:switchPlaceZoomOut("WayRight")
end

function E9WayA1:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_b_open") == 1 then
    if self:getInteger("room_brighter") == 0 then
      self:imageOn("1")
      
    else
      self:imageOn("2")
    end
  end
end

function E9WayA1:afterLoad()

end

function E9WayA1:afterLoad2()
  self:cacheImage("WayA2/0")
  self:cacheImage("WayRight/0")
  self:cacheImage("Wall/0")
end

function E9WayA1:beforeUseItem(itemName)
  return false
end

function E9WayA1:afterUseItem(itemName)
  return true
end

function E9WayA1:goWall(rect)
  self:switchPlaceZoomIn("Wall", rect)
end

return E9WayA1
