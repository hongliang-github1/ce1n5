local E9TubKeypad = class("E9TubKeypad", function()
  return BasePlace.new()
end)

function E9TubKeypad:initPhoto()
end

function E9TubKeypad:initButton()
  self:addButton("volumeUp", 720, 296, 168, 166, false)
  self:addButton("volumeDown", 720, 464, 168, 138, false)
  self:addButton("channelUp", 892, 294, 154, 168, false)
  self:addButton("channelDown", 892, 464, 156, 138, false)
  self:addButton("makeupLight", 720, 606, 166, 130, false)
  self:addButton("underwaterLight", 892, 606, 156, 130, false)
  self:addButton("ceilingLight", 720, 740, 164, 146, false)
  self:addButton("massageLight", 890, 740, 160, 148, false)
  self:addButton("number1", 1050, 294, 158, 164, false)
  self:addButton("number2", 1212, 294, 170, 164, false)
  self:addButton("number3", 1386, 294, 154, 164, false)
  self:addButton("number4", 1052, 462, 158, 140, false)
  self:addButton("number5", 1216, 462, 166, 140, false)
  self:addButton("number6", 1386, 462, 158, 140, false)
  self:addButton("number7", 1052, 606, 160, 130, false)
  self:addButton("number8", 1218, 606, 160, 132, false)
  self:addButton("number9", 1382, 606, 158, 134, false)
  self:addButton("tv", 1056, 740, 156, 150, false)
  self:addButton("number0", 1218, 742, 158, 146, false)
  self:addButton("back", 1380, 744, 160, 144, false)
  self:addButton("show", 720, 24, 824, 228, false)
end

function E9TubKeypad:num(i)
    if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end

  -- 还没得到镜子玻璃的提示，点了没反应
  if self:getInteger("mirror_fog_tipped") == 0 then
    self:sayI18n("num_1")
    
    return
  end
  
  self:say("")
  self:play("keypad")
  
  self.password = self.password .. tostring(i)

  if self.passwordString == nil then
    self.passwordString = tostring(i)
  
  else
    self.passwordString = self.passwordString .. " " .. tostring(i)
  end

  self.label:setString(self.passwordString)
  self.label:setColor(cc.c4b(255, 255, 255, 255))
  
  -- 满足密码长度，做判断

  if string.len(self.password) >= 5 then
    local doorKey = tostring(self:getInteger("num1")) .. tostring(self:getInteger("num2")) .. tostring(self:getInteger("num3")) .. tostring(self:getInteger("num4")) .. tostring(self:getInteger("num5"))

    if self.password == doorKey then
      -- 密码正确
      self:hideArrowButton()
      self:sayI18n("open_1")
      self:voidItem("paper")
      self:setInteger("get_door_key", 1)

      self:play("item")

      return
    end

    -- 如果密码不正确
    self.label:setColor(cc.c4b(255, 0, 0, 255))
    self.passwordString = nil
    self.password       = ""

    self:sayI18n("input_2")
  end
end

function E9TubKeypad:arrowDown(rect)
  self:switchPlaceZoomOut("Tub")
end

function E9TubKeypad:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("get_door_key") == 0 then
    self.password  = ""
    local fontSize = 150

    self:addButton("show", 720, 24, 824, 228, false)

    local label1 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(824, 228), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

    label1:setColor(cc.c4b(255, 255, 255, 255))
    label1:setAnchorPoint(0, 0)
    label1:setPosition(0, 0)

    self.label = label1

    self:addChild(label1)

    -- 计算四个label的位置，居中为准，分别向两边延伸
    local bgSize    = self:getContentSize()
    local labelSize = label1:getContentSize()

    label1:setPosition(720, bgSize.height - 24 - labelSize.height)
  end
end

function E9TubKeypad:afterLoad()
  if self:getInteger("mirror_fog_tipped") == 0 then
    self:sayI18n("afterLoad_3")
    
  elseif self:getInteger("get_door_key") == 1 then
    self:sayI18n("afterLoad_1")
    
  else
    self:sayI18n("afterLoad_2")
  end
end

function E9TubKeypad:afterLoad2()
  self:cacheImage("Tub/0")
  self:cacheImage("TubHandle/0")
end

function E9TubKeypad:beforeUnload()
  if self.label ~= nil then
    self.label:setVisible(false)
  end
end

function E9TubKeypad:beforeUseItem(itemName)
  return false
end

function E9TubKeypad:afterUseItem(itemName)
  return true
end

function E9TubKeypad:volumeUp(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end

  self:sayI18n("volumeUp_1")
end

function E9TubKeypad:volumeDown(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("volumeDown_1")
end

function E9TubKeypad:channelUp(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("channelUp_1")
end

function E9TubKeypad:channelDown(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("channelDown_1")
end

function E9TubKeypad:makeupLight(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("makeupLight_1")
end

function E9TubKeypad:underwaterLight(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("underwaterLight_1")
end

function E9TubKeypad:ceilingLight(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("ceilingLight_1")
end

function E9TubKeypad:massageLight(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("massageLight_1")
end

function E9TubKeypad:number1(rect)
  self:num("1")
end

function E9TubKeypad:number2(rect)
  self:num("2")
end

function E9TubKeypad:number3(rect)
  self:num("3")
end

function E9TubKeypad:number4(rect)
  self:num("4")
end

function E9TubKeypad:number5(rect)
  self:num("5")
end

function E9TubKeypad:number6(rect)
  self:num("6")
end

function E9TubKeypad:number7(rect)
  self:num("7")
end

function E9TubKeypad:number8(rect)
  self:num("8")
end

function E9TubKeypad:number9(rect)
  self:num("9")
end

function E9TubKeypad:tv(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("tv_1")
end

function E9TubKeypad:number0(rect)
  self:num("0")
end

function E9TubKeypad:back(rect)
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)

    return
  end
  
  self:sayI18n("back_1")
end

function E9TubKeypad:show(rect)
  -- 此方法只是用来画区域，没有其他作用
  if self:getInteger("get_door_key") == 1 then
    self:onTouchBegan(nil, nil)
  end
end

function E9TubKeypad:onTouchBegan(touch, event)
  if self:getInteger("get_door_key") == 1 then
    self:switchPlace("TubHandle")
  end
end

return E9TubKeypad
