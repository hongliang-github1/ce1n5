local E9Tip = class("E9Tip", function()
  return BaseTip.new()
end)

function E9Tip:getTipAtIndex(index)
  self:resetProgress()

  -- 获得838房卡，虽然这一步基本不会被执行，但还是防止有些用户在Beginning的时候就使用提示
  if self:nextProgress() == index or (self:getInteger("card") == 0) then
    self:addPlace("Beginning")

    self:textI18n("progress_1")

    return self.progress
  end

  -- 在838房间门外使用房卡开门
  if self:nextProgress() == index or (self:getInteger("outside_entry_in") < 1) then
    self:addPlace("Outside")

    self:textI18n("progress_2")

    return self.progress
  end

  -- 进入房间内再次使用房卡通电
  if self:nextProgress() == index or (self:getInteger("room_switch") == 0) then
    self:addPlace("Door"):markButton("openLamp")

    self:textI18n("progress_3")

    return self.progress
  end
  
  -- 还没去墙后面看过，提示去看看
  if self:nextProgress() == index or (self:getInteger("wall_visited") < 1) then
    self:addPlace("Entry"):markButton("goWayRight")
    self:addPlace("WayRight"):markButton("_left")
    self:addPlace("Wall")
    
    self:textI18n("progress_4")
    
    return self.progress
  end

  -- 拿灯光控制器，可能在抽屉里，也可能在B地柜里
  if self:nextProgress() == index or (self:getInteger("remoter") == 0) then
    self:addPlace("Wall"):markButton("goWallDrawer")
    
    if "wall_drawer" == self:getString("remoter_pos") then
      self:addPlace("WallDrawer"):markButton("open")
      
      self:textI18n("progress_5")
      
    else
      self:addPlace("WallDrawer"):markButton("goGroundB")
      self:addPlace("GroundB"):markButton("open")

      self:textI18n("progress_6")
    end
    
    return self.progress
  end
  
  -- 接入灯光控制器
  if self:nextProgress() == index or (self:getInteger("remoter") > 0
      or self:getInteger("room_brighter") == 0) then
    self:addPlace("BedRight"):markButton("click")
    self:addPlace("LightPlug"):markButton("click")
    
    self:textI18n("progress_8")
    
    return self.progress
  end
  
  -- 去浴室探索
  if self:nextProgress() == index or (self:getInteger("first_entry_bath") == 0) then
    self:addPlace("Entry"):markButton("goWayLeft")
    self:addPlace("WayLeft"):markButton("open")

    self:addPlace("BathEntryB")
    
    self:textI18n("progress_9")
    
    return self.progress
  end
  
  -- 去捡瓶子烧开水，先捡脉动瓶子
  if self:nextProgress() == index or (self:getInteger("b600") == 0) then
    local pos = self:getString("b6_pos")
    
    if "sofa" == pos then
      self:addPlace("Entry"):markButton("goSofa")
      self:addPlace("Sofa"):markButton("getBnum")
      
      self:textI18n("progress_10")
      
    elseif "flower_a" == pos then
      self:addPlace("Entry"):markButton("goWayRight")
      self:addPlace("WayRight"):markButton("goFlowerA")
      self:addPlace("FlowerA"):markButton("open")
      
      self:textI18n("progress_11")
      
    else
      self:addPlace("Entry"):markButton("goWayLeft")
      self:addPlace("WayLeft"):markButton("goFlowerB")
      self:addPlace("FlowerB"):markButton("open")
      
      self:textI18n("progress_12")
    end
    
    return self.progress
  end
  
  -- 再捡7喜易拉罐
  if self:nextProgress() == index or (self:getInteger("b330") == 0) then
    local pos = self:getString("b3_pos")
    
    if "sofa" == pos then
      self:addPlace("Entry"):markButton("goSofa")
      self:addPlace("Sofa"):markButton("getBnum")
      
      self:textI18n("progress_13")
      
    elseif "flower_a" == pos then
      self:addPlace("Entry"):markButton("goWayRight")
      self:addPlace("WayRight"):markButton("goFlowerA")
      self:addPlace("FlowerA"):markButton("open")
      
      self:textI18n("progress_14")
      
    else
      self:addPlace("Entry"):markButton("goWayLeft")
      self:addPlace("WayLeft"):markButton("goFlowerB")
      self:addPlace("FlowerB"):markButton("open")
      
      self:textI18n("progress_15")
    end
    
    return self.progress
  end
  
  -- 再去拿水壶
  if self:nextProgress() == index or (self:getInteger("kettle") == 0) then
    self:addPlace("BathEntryA"):markButton("_right")
    self:addPlace("BathSeeB"):markButton("goShower")
    self:addPlace("Shower"):markButton("goShowerCorner")
    
    self:textI18n("progress_19")
    
    return self.progress
  end
  
  -- 至此，水壶、水壶底座、脉动瓶子、7喜易拉罐已经都得到，去BathPlug烧水（注意，此时可能浴缸还没出水、白纸上的文字还没浮现）
  if self:nextProgress() == index or (self:getInteger("mirror_fog_tipped") == 0
      and self:getInteger("bath_plug_button_showed") == 0) then
    self:addPlace("BathEntryB"):markButton("_left")
    self:addPlace("BathSeeA"):markButton("goBathPlug")
    self:addPlace("BathPlug"):markButton("open")
    
    self:textI18n("progress_25")
    
    return self.progress
  end
  
  -- 已经烧过开水了，还不知道开水能做什么
  if self:nextProgress() == index or (self:getInteger("mirror_fogged") == 0) then
    self:addPlace("BathSeeA"):markButton("goSink")
    self:addPlace("Sink"):markButton("click")
    
    self:textI18n("progress_34")
    
    return self.progress
  end
  
  -- -- 至此，用户知道怎么烧水了，也知道开水要往水池里倒了，但还不知道要烧多少水，接下来去搞神秘白纸。先去拿白纸，可能在抽屉里，也可能在B地柜里
  if self:nextProgress() == index or (self:getInteger("paper") == 0) then
    self:addPlace("Wall"):markButton("goWallDrawer")
    
    if "wall_drawer" == self:getString("paper_pos") then
      self:addPlace("WallDrawer"):markButton("open")
      
      self:textI18n("progress_35")
      
    else
      self:addPlace("WallDrawer"):markButton("goGroundB")
      self:addPlace("GroundB"):markButton("open")

      self:textI18n("progress_36")
    end
    
    return self.progress
  end

  -- 再去拿电池
  if self:nextProgress() == index or (self:getInteger("battery") == 0) then
    self:addPlace("Entry"):markButton("goBedRight")
    self:addPlace("BedRight"):markButton("click")
    
    self:textI18n("progress_37")
    
    return self.progress
  end
  
  -- 去拿纸巾
  if self:nextProgress() == index or (self:getInteger("tissue") == 0) then
    self:addPlace("Entry"):markButton("goBedRight")
    self:addPlace("BedRight"):markButton("paper")
    
    self:textI18n("progress_38")
    
    return self.progress
  end
  
  -- 去垃圾桶处拿喷雾瓶
  if self:nextProgress() == index or (self:getInteger("spray") == 0) then
    self:addPlace("BathEntryB"):markButton("_left")
    self:addPlace("BathSeeA"):markButton("goToilet")
    self:addPlace("Toilet"):markButton("goToiletTrash")
    
    self:textI18n("progress_39")
    
    return self.progress
  end
  
  -- 喷雾瓶、纸巾、白纸、电池都齐了，先装电池
  if self:nextProgress() == index or (self:getInteger("battery") > 0) then
    self:addPlace("BathSeeB"):markButton("goSpray")
    self:addPlace("Spray"):markButton("goSprayNear")
    self:addPlace("SprayNear"):markButton("click")
    
    self:textI18n("progress_40")
    
    return self.progress
  end

  -- 再装喷雾瓶子
  if self:nextProgress() == index or (self:getInteger("spray") > 0) then
    self:addPlace("Spray"):markButton("goSprayNear")
    self:addPlace("SprayNear"):markButton("click")
    
    self:textI18n("progress_41")
    
    return self.progress
  end
  
  -- 让喷雾装置喷纸巾
  if self:nextProgress() == index or (self:getInteger("tissue_sprayed") == 0) then
    self:addPlace("SprayNear"):imageOn("1")
    
    self:textI18n("progress_42")
    
    return self.progress
  end
  
  -- 用纸巾擦白纸，浮现文字
  if self:nextProgress() == index or (self:getInteger("tissue") > 0) then
    self:addPlace("Paper"):imageOn("1")
    
    self:textI18n("progress_43")
    
    return self.progress
  end
  
  -- 已经得知开水容量，但还没有烧出等量的开水，给出烧水数字提示
  local paperNumber = tonumber(self:getString("paper_password"))
  local paperTip    = nil

  if paperNumber == 810 then
    paperTip = "810 = 600 + 210. 210 = 270 - (330-270). 270 = 600 - 330."
  
  elseif paperNumber == 870 then
    paperTip = "870 = 600 + 270. 270 = 600 - 330."

  elseif paperNumber == 1050 then
    paperTip = "1050 = 330*3 + 60. 60 = 330 + 330 - 600"

  elseif paperNumber == 1140 then
    paperTip = "1140 = 600 + 270*2. 270 = 600 - 330."

  elseif paperNumber == 1380 then
    paperTip = "1380 = 330*4 + 60. 60 = 330 + 330 - 600"

  elseif paperNumber == 1410 then
    paperTip = "1410 = 600 + 270*3. 270 = 600 - 330."

  elseif paperNumber == 1710 then
    paperTip = "1710 = 330*5 + 60. 60 = 330 + 330 - 600"

  elseif paperNumber == 1710 then
    paperTip = "1740 = 600*2 + 270*2. 270 = 600 - 330."

  elseif paperNumber == 1860 then
    paperTip = "1860 = 330*4 + 270*2. 270 = 600 - 330."
  end

  -- 去烧水
  if self:nextProgress() == index or (self:getInteger("mirror_fog_tipped") == 0 and (
        self:getInteger("kettle_level") ~= paperNumber or self:getInteger("kettle_hot_water") ~= 2
      )) then
    self:addPlace("Paper")
    self:addPlace("BathSeeA"):markButton("goBathPlug")
    self:addPlace("BathPlug"):markButton("open")

    self:text(self.i18nTable["progress_53"] .. paperTip)
    
    return self.progress
  end
  
  -- 去让镜子起雾，得知密码
  if self:nextProgress() == index or (self:getInteger("mirror_fog_tipped") == 0) then
    self:addPlace("BathSeeA"):markButton("goSink")
    self:addPlace("Sink"):markButton("click")
    
    self:textI18n("progress_44")
    
    return self.progress
  end
  
  -- 输入镜子上的口令
  if self:nextProgress() == index or true then
    self:addPlace("Tub"):markButton("goTubKeypad")
    self:addPlace("TubKeypad")

    self:text(self.i18nTable["progress_54"] .. paperTip)
    
    return self.progress
  end
  
  return self:nextProgress()
end

return E9Tip
