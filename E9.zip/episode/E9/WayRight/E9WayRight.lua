local E9WayRight = class("E9WayRight", function()
  return BasePlace.new()
end)

function E9WayRight:initPhoto()
  self:addPhoto("1", 256, 0)
  self:addPhoto("2", 256, 0)
end

function E9WayRight:initButton()
  self:addButton("open", 530, 158, 488, 990)
  self:addButton("goFlowerA", 1056, 568, 520, 580)
end

function E9WayRight:arrowLeft(rect)
  self:switchPlaceLeft("Wall")
end

function E9WayRight:arrowDown(rect)
  self:switchPlaceZoomOut("Entry")
end

function E9WayRight:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_a_open") == 1 then
    if self:getInteger("room_brighter") == 0 then
      self:imageOn("1")
      
    else
      self:imageOn("2")
    end
  end
end

function E9WayRight:afterLoad()

end

function E9WayRight:afterLoad2()
  e9.removeCacheBath(self)
  
  self:cacheImage("Wall/0")

  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")

  else    
    self:cacheImage("Entry/50")
  end
    
  self:cacheImage("BathEntryA/0")
  self:cacheImage("BathDoorA/0")
end

function E9WayRight:beforeUseItem(itemName)
  return false
end

function E9WayRight:afterUseItem(itemName)
  return true
end

function E9WayRight:open(rect)
  -- 门帘已经打开之后，则直接进入浴室，而不再通过BathDoorA中转
  if self:imageIsOn("2") then
    self:switchPlaceZoomIn("BathEntryA", cc.rect(267 * 2, 203 * 2, 232 * 2, 236 * 2))

  else
    self:switchPlaceZoomIn("BathDoorA", cc.rect(264 * 2, 169 * 2, 247 * 2, 201 * 2))
  end
end

function E9WayRight:goFlowerA(rect)
  self:switchPlaceZoomIn("FlowerA", rect)
end

return E9WayRight
