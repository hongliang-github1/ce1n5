local E9SwitchA = class("E9SwitchA", function()
  return BasePlace.new()
end)

function E9SwitchA:initPhoto()
  self:addPhoto("1", 448, 512)
end

function E9SwitchA:initButton()
  self:addButton("open", 436, 560, 538, 460)
  self:addButton("dryer", 1070, 82, 666, 898)
end

function E9SwitchA:arrowDown(rect)
  self:switchPlaceZoomOut("Mirror")
end

function E9SwitchA:beforeLoad()
  self:imageOn("0")
end

function E9SwitchA:afterLoad()

end

function E9SwitchA:afterLoad2()
  self:cacheImage("Mirror/0")
end

function E9SwitchA:beforeUseItem(itemName)
  return false
end

function E9SwitchA:afterUseItem(itemName)
  return true
end

function E9SwitchA:open(rect)
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:play("airswitch")
    self:sayI18n("open_1")
    
    return
  end
  
  self:imageOn("1")
  self:play("airswitch")
  self:sayI18n("open_2")
end

function E9SwitchA:dryer(rect)
  self:sayI18n("dryer_1")
end

return E9SwitchA
