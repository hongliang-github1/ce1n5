local E9BathSeeA = class("E9BathSeeA", function()
  return BasePlace.new()
end)

function E9BathSeeA:initPhoto()
  self:addPhoto("1", 1280, 448)
  self:addPhoto("2", 1856, 320)
end

function E9BathSeeA:initButton()
  self:addButton("goToilet", 846, 662, 372, 328)
  self:addButton("goBathPlug", 450, 996, 216, 148)
  self:addButton("goSink", 1416, 684, 298, 254)
end

function E9BathSeeA:arrowLeft(rect)
  self:switchPlaceLeft("BathSeeB")
end

function E9BathSeeA:arrowRight(rect)
  self:switchPlaceRight("BathEntryB")
end

function E9BathSeeA:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("bath_door_a_open") == 1 then
    self:imageOn("1")
  end
  
  if self:getInteger("bath_door_b_open") == 1 then
    self:imageOn("2")
  end
end

function E9BathSeeA:afterLoad()

end

function E9BathSeeA:afterLoad2()
  e9.removeCacheBed(self)
  
  self:cacheImage("Toilet/0")
  self:cacheImage("BathSeeB/0")
  self:cacheImage("BathEntryB/0")
end

function E9BathSeeA:beforeUseItem(itemName)
  return false
end

function E9BathSeeA:afterUseItem(itemName)
  return true
end

function E9BathSeeA:goToilet(rect)
  self:switchPlaceZoomIn("Toilet", rect)
end

function E9BathSeeA:goSink(rect)
  self:switchPlaceZoomIn("Sink", rect)
end

function E9BathSeeA:goBathPlug(rect)
  self:switchPlaceZoomIn("BathPlug", rect)
end

return E9BathSeeA
