local E9SprayNear = class("E9SprayNear", function()
  return BasePlace.new()
end)

function E9SprayNear:initPhoto()
  self:addPhoto("1", 448, 192)
  self:addPhoto("3", 704, 0)
  self:addPhoto("a1", 896, 256)
  self:addPhoto("a2", 1664, 320)
  self:addPhoto("b1", 768, 512)
  self:addPhoto("b2", 1600, 512)
  self:addPhoto("f", 704, 0)
end

function E9SprayNear:initButton()
  self:addButton("click", 574, 132, 800, 1016)
end

function E9SprayNear:sprayDone()
  local action = cc.FadeOut:create(0.2)

  self.fImageView:runAction(cc.Sequence:create(action, cc.CallFunc:create(function()
    -- 动画结束，设置发动参数为1
    self:enableTouch()
    self:imageOff("f")
    self.fImageView:setOpacity(255)
    
  end)))
end

function E9SprayNear:arrowDown(rect)
  self:switchPlaceZoomOut("Spray")
end

function E9SprayNear:beforeLoad()
  if self:getInteger("battery") < 0 and self:getInteger("spray") < 0 then
    self:imageOn("0")
    
    return
  end
  
  self:imageOn("2")
  
  if self:getInteger("battery") < 0 then
    self:imageOn("b1")
    self:imageOn("b2")
    
    return
  end
  
  if self:getInteger("spray") < 0 then
    self:imageOn("a1")
    self:imageOn("a2")
  end
end

function E9SprayNear:afterLoad()
  if self:imageIsOn("0") then
    self:sayI18n("afterLoad_1")
    
  else
    self:sayI18n("afterLoad_2")
  end
end

function E9SprayNear:afterLoad2()
  self:cacheImage("Spray/0")
end

function E9SprayNear:beforeUseItem(itemName)
  if "battery" == itemName then
    return true
  end
  
  if "spray" == itemName then
    return true
  end

  if "tissue" == itemName and self:imageIsOn("0") and not self:imageIsOn("3") then
    return true
  end
  
  return false
end

function E9SprayNear:afterUseItem(itemName)
  if "battery" == itemName then
    if self:getInteger("spray") < 0 then
      self:imageOn("3")
      self:imageOff("a1")
      self:imageOff("a2")
      self:play("item")
      self:sayI18n("afterUseItem_1")
      
      return false
    end
    
    self:imageOn("b1")
    self:imageOn("b2")
    self:play("item")
    self:sayI18n("afterUseItem_2")
    
    return false
  end
  
  if "spray" == itemName then
    if self:getInteger("battery") < 0 then
      self:imageOn("3")
      self:imageOff("b1")
      self:imageOff("b2")
      self:play("item")
      self:sayI18n("afterUseItem_3")
      
      return false
    end
    
    self:imageOn("a1")
    self:imageOn("a2")
    self:play("item")
    self:sayI18n("afterUseItem_4")
    
    return false
  end
  
  if "tissue" == itemName then
    self:imageOn("1")
    self:hideArrowButton()
    self:sayI18n("afterUseItem_5")
    
    self.shouldSpray        = false
    self.shouldRemoveTissue = false
    
    return true
  end
  
  return true
end

function E9SprayNear:click(rect)
  -- 该喷雾了
  if self.shouldSpray then
    self.shouldSpray = false
    
    self:play("spray")
    self:imageOn("f")

    if self.fImageView == nil then
      self.fImageView = self:imageIsOn("f")
    end
    
    self:disableTouch()
    self:scheduleOnce(0.1, function()
      self:sprayDone()
    end)

    self:sayI18n("click_1")

    return
  end
  
  -- 已经安装上电池和喷雾剂的情况
  if self:imageIsOn("0") then
    -- 已经放上纸巾的情况
    if self:imageIsOn("1") then
      if self.shouldRemoveTissue then
        -- 拿下纸巾
        self:imageOff("1")
        self:play("item")
        self:setInteger("tissue_sprayed", 1)
        self:showArrowButton()
        self:sayI18n("click_2")
        
      else
        -- 喷气
        self:play("spray")
        self:sayI18n("click_3")
        
        self.shouldRemoveTissue = true
      end
      
      return
    end
    
    -- 关上盖子
    if self:imageIsOn("3") then
      self:imageOff("3")
      self:play("kettle")
      self:sayI18n("click_4")
      
      -- 下一次点击则喷雾
      self.shouldSpray = true
      
      return
    end
    
    -- 打开盖子
    self:imageOn("3")
    self:play("kettle")
    self:sayI18n("click_5")
    
    return
  end
  
  -- 电池和喷雾剂都安装上去了，则合上盖子
  if self:getInteger("battery") < 0 and self:getInteger("spray") < 0 then
    self:imageOn("0")
    self:imageOff("3")
    self:play("kettle")
    self:sayI18n("click_6")
    
    -- 下一次点击则喷雾
    self.shouldSpray = true

    return
  end
  
  if self:getInteger("battery") < 0 then
    self:sayI18n("click_7")
    
    return
  end
  
  if self:getInteger("spray") < 0 then
    self:sayI18n("click_8")
    
    return
  end
  
  self:sayI18n("click_9")
end

return E9SprayNear
