local E9WayA2 = class("E9WayA2", function()
  return BasePlace.new()
end)

function E9WayA2:initPhoto()
  self:addPhoto("4", 832, 0)
end

function E9WayA2:initButton()
  self:addButton("open", 688, 0, 688, 1148)
  self:addButton("goPlug", 100, 832, 392, 316)
  self:addButton("goFlowerB", 1472, 284, 512, 864)
end

function E9WayA2:arrowDown(rect)
  self:switchPlaceZoomOut("Wall")
end

function E9WayA2:beforeLoad()
  self:imageOn("0")
end

function E9WayA2:afterLoad()
  
end

function E9WayA2:afterLoad2()  
  self:cacheImage("Wall/0")
  self:cacheImage("WayA3/3")
  self:cacheImage("WallPlug/0")
end

function E9WayA2:beforeUseItem(itemName)
  return false
end

function E9WayA2:afterUseItem(itemName)
  return true
end

function E9WayA2:open(rect)
  self:switchPlaceZoomIn("WayA3", cc.rect(329 * 2, 159 * 2, 347 * 2, 248 * 2))
end

function E9WayA2:goPlug(rect)
  self:switchPlaceZoomIn("WallPlug", rect)
end

function E9WayA2:goFlowerB(rect)
  self:switchPlaceZoomIn("FlowerB", cc.rect(735 * 2, 343 * 2, 259 * 2, 230 * 2))
end

return E9WayA2
