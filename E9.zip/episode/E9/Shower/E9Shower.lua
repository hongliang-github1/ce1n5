local E9Shower = class("E9Shower", function()
  return BasePlace.new()
end)

function E9Shower:initPhoto()
end

function E9Shower:initButton()
  self:addButton("goShowerCorner", 208, 408, 472, 584)
  self:addButton("goShowerNear", 686, 270, 598, 776)
end

function E9Shower:arrowDown(rect)
  self:switchPlaceZoomOut("BathSeeB")
end

function E9Shower:beforeLoad()
  self:imageOn("0")
end

function E9Shower:afterLoad()

end

function E9Shower:afterLoad2()
  self:cacheImage("BathSeeB/0")
  self:cacheImage("ShowerCorner/0")
  self:cacheImage("ShowerNear/0")
end

function E9Shower:beforeUseItem(itemName)
  return false
end

function E9Shower:afterUseItem(itemName)
  return true
end

function E9Shower:goShowerCorner(rect)
  self:switchPlaceZoomIn("ShowerCorner", rect)
end

function E9Shower:goShowerNear(rect)
  self:switchPlaceZoomIn("ShowerNear", rect)
end

return E9Shower
