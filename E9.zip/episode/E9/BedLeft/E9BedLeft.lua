local E9BedLeft = class("E9BedLeft", function()
  return BasePlace.new()
end)

function E9BedLeft:initPhoto()
end

function E9BedLeft:initButton()
  self:addButton("open", 866, 0, 744, 546)
end

function E9BedLeft:arrowDown(rect)
  self:switchPlaceZoomOut("Entry")
end

function E9BedLeft:beforeLoad()
  -- 灯已经打开了
  self:imageOn("3")
end

function E9BedLeft:afterLoad()

end

function E9BedLeft:afterLoad2()  
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")
    
  else
    self:cacheImage("Entry/50")
  end
end

function E9BedLeft:beforeUseItem(itemName)
  return false
end

function E9BedLeft:afterUseItem(itemName)
  return true
end

function E9BedLeft:open(rect)
  self:sayI18n("open_1")
end

return E9BedLeft
