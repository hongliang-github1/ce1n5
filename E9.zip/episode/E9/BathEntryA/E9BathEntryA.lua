local E9BathEntryA = class("E9BathEntryA", function()
  return BasePlace.new()
end)

function E9BathEntryA:initPhoto()
  self:addPhoto("1", 64, 640)
end

function E9BathEntryA:initButton()
end

function E9BathEntryA:arrowLeft(rect)
  self:switchPlaceLeft("BathEntryB")
end

function E9BathEntryA:arrowRight(rect)
  self:switchPlaceRight("BathSeeB")
end

function E9BathEntryA:arrowDown(rect)
  self:switchPlaceZoomOut("WayRight")
end

function E9BathEntryA:beforeLoad()
  self:imageOn("0")
  
  -- 根据电视机的状态显示图片
  if self:getInteger("tub_screen_on") == 1 then
    self:imageOn("1")
  end
end

function E9BathEntryA:afterLoad()
  if "BathDoorA" == self.lastPlaceName or "WayRight" == self.lastPlaceName then
    if self:getInteger("first_entry_bath") > 0 then
      self:sayI18n("afterLoad_1")
      
    else
      self:setInteger("first_entry_bath", 1)
      self:sayI18n("afterLoad_2")
    end
  end
end

function E9BathEntryA:afterLoad2()
  self:cacheImage("BathEntryB/0")
  self:cacheImage("BathSeeB/0")
  self:cacheImage("WayRight/0")
end

function E9BathEntryA:beforeUseItem(itemName)
  return false
end

function E9BathEntryA:afterUseItem(itemName)
  return true
end

return E9BathEntryA
