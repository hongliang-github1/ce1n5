local E9WayA3 = class("E9WayA3", function()
  return BasePlace.new()
end)

function E9WayA3:initPhoto()
end

function E9WayA3:initButton()
  self:addButton("goDoor", 452, 224, 366, 678)
  self:addButton("tv", 998, 336, 410, 372)
end

function E9WayA3:arrowUp(rect)
  self:switchPlaceZoomIn("Entry", cc.rect(414 * 2, 131 * 2, 333 * 2, 301 * 2))
end

function E9WayA3:arrowDown(rect)
  self:switchPlaceZoomOut("WayA2")
end

function E9WayA3:beforeLoad()
  -- 根据状态显示底图
  self:imageOn("3")
end

function E9WayA3:afterLoad()

end

function E9WayA3:afterLoad2()  
  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Entry/0")
    
  else
    self:cacheImage("Entry/50")
  end

  self:cacheImage("WayA2/0")

  if self:getInteger("room_switch") == 0 then
    self:cacheImage("Door/0")

  else    
    self:cacheImage("Door/2")
  end
end

function E9WayA3:beforeUseItem(itemName)
  return false
end

function E9WayA3:afterUseItem(itemName)
  return true
end

function E9WayA3:goDoor(rect)
  self:switchPlaceZoomIn("Door", rect)
end

function E9WayA3:tv(rect)
  self:sayI18n("tv_1")
end

return E9WayA3
