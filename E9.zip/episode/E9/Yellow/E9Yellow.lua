local E9Yellow = class("E9Yellow", function()
  return BasePlace.new()
end)

function E9Yellow:initPhoto()
end

function E9Yellow:initButton()
  self:addButton("click", 576, 518, 968, 630)
end

function E9Yellow:arrowDown(rect)
  self:switchPlaceZoomOut("BathSeeB")
end

function E9Yellow:beforeLoad()
  self:imageOn("0")
end

function E9Yellow:afterLoad()

end

function E9Yellow:afterLoad2()
  self:cacheImage("BathSeeB/0")
end

function E9Yellow:beforeUseItem(itemName)
  return false
end

function E9Yellow:afterUseItem(itemName)
  return true
end

function E9Yellow:click(rect)
  self:sayI18n("click_1")
end

return E9Yellow
