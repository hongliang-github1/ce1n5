local E3AtmKeyboard = class("E3AtmKeyboard", function()
  return BasePlace.new()
end)

function E3AtmKeyboard:initPhoto()
end

function E3AtmKeyboard:initButton()
  self:addButton("num1", 1020, 94, 242, 236, false)
  self:addButton("num2", 1262, 94, 242, 236, false)
  self:addButton("num3", 1506, 94, 242, 236, false)
  self:addButton("num4", 1022, 328, 242, 236, false)
  self:addButton("num5", 1262, 330, 242, 236, false)
  self:addButton("num6", 1506, 330, 242, 236, false)
  self:addButton("num7", 1026, 564, 242, 236, false)
  self:addButton("num8", 1270, 568, 242, 236, false)
  self:addButton("num9", 1512, 570, 242, 236, false)
  self:addButton("num0", 1274, 806, 242, 236, false)
  self:addButton("numd", 1030, 802, 242, 236, false)
  self:addButton("numc", 1516, 806, 242, 236, false)
  self:addButton("nop", 194, 60, 800, 1024, false)
end

function E3AtmKeyboard:num(i)
  self:say("")
  self:play("click")

  if #self.password >= 8 then
    -- 已经超出位数了，什么都不做

    return
  end

  self.password = self.password .. i

  -- 把当前输入内容设置到label上
  self.label:setColor(cc.c4b(255, 255, 255, 255))
  self.label:setString(self.password)
end

function E3AtmKeyboard:arrowDown(rect)
  self:switchPlaceZoomOut("Atm")
end

function E3AtmKeyboard:beforeLoad()
  self:imageOn("0")

  if self:getInteger("atm_unlock") < 1 then
    -- 创建显示输入内容的label
    local fontSize = 50 * 2
    local label    = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2 * 8, fontSize * 1.2), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    label:setColor(cc.c4b(255, 255, 255, 255))
    label:setAnchorPoint(0, 0)
    label:setPosition(0, 0)

    self.label = label

    self:addChild(label)

    -- 设置label位置
    local bgSize    = self:getContentSize()
    local labelSize = label:getContentSize()
    local x         = 200
    local y         = bgSize.height / 2 - labelSize.height / 2

    label:setPosition(x, y)
  end
end

function E3AtmKeyboard:afterLoad()
  self.password = ""
end

function E3AtmKeyboard:beforeUnload()
end

function E3AtmKeyboard:recordLastPlaceName()
  return false
end

function E3AtmKeyboard:beforeUseItem(itemName)
  return false
end

function E3AtmKeyboard:afterUseItem(itemName)
  return true
end

function E3AtmKeyboard:num1(rect)
  self:num("1")
end

function E3AtmKeyboard:num2(rect)
  self:num("2")
end

function E3AtmKeyboard:num3(rect)
  self:num("3")
end

function E3AtmKeyboard:num4(rect)
  self:num("4")
end

function E3AtmKeyboard:num5(rect)
  self:num("5")
end

function E3AtmKeyboard:num6(rect)
  self:num("6")
end

function E3AtmKeyboard:num7(rect)
  self:num("7")
end

function E3AtmKeyboard:num8(rect)
  self:num("8")
end

function E3AtmKeyboard:num9(rect)
  self:num("9")
end

function E3AtmKeyboard:num0(rect)
  self:num("0")
end

function E3AtmKeyboard:numd(rect)
  self:num(".")
end

function E3AtmKeyboard:numc(rect)
  -- 检查密码是否正确，如果已经解锁了，则什么都不做，回到atm场景
  if self:getInteger("atm_unlock") > 0 then
    self:switchPlaceZoomOut("Atm")

    return
  end

  if self.password == self:getString("atm_password") then
    -- 密码正确，立刻回atm场景
    self:play("shift")
    self:setInteger("atm_unlock", 1)
    self:switchPlace("Atm")

    return
  end

  -- 密码不正确
  self:play("dblclick")
  self:sayI18n("numc_1")

  self.label:setColor(cc.c4b(255, 0, 0, 255))
  self.password = ""
end

function E3AtmKeyboard:nop(rect)
  self:sayI18n("nop_1")
end

return E3AtmKeyboard
