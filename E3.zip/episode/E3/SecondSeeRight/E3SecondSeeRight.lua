local E3SecondSeeRight = class("E3SecondSeeRight", function()
  return BasePlace.new()
end)

function E3SecondSeeRight:initPhoto()
end

function E3SecondSeeRight:initButton()
  self:addButton("open", 522, 482, 232, 318)
  self:addButton("goOut", 754, 104, 512, 792, false)
  self:addButton("close", 1268, 450, 252, 330, false)
end

function E3SecondSeeRight:arrowLeft(rect)
  self:switchPlaceLeft("SecondRight")
end

function E3SecondSeeRight:arrowRight(rect)
  self:switchPlaceRight("SeeThirdFar")
end

function E3SecondSeeRight:beforeLoad()
  if self:getInteger("car_locked") == 0 then
    -- 还没开始逃脱剧情，车门是开着的，不准去别的视角
    self:imageOn("1")

  else
    if self:getInteger("second_right_door_open") > 0 then
      -- 从二排右视角开门而来，门是开着的
      self:imageOn("1")
      self:setInteger("second_right_door_open", 0)
      self:sayI18n("beforeLoad_1")

    else
      self:imageOn("2")
    end
  end
end

function E3SecondSeeRight:afterLoad()
  if self:getInteger("car_locked") == 0 then
    self:hideArrowButton()
    
    self:sayI18n("afterLoad_1")
  end
end

function E3SecondSeeRight:afterLoad2()
  self:cacheImage("SeeThirdFar/1")
end

function E3SecondSeeRight:beforeUseItem(itemName)
  return false
end

function E3SecondSeeRight:afterUseItem(itemName)
  return true
end

function E3SecondSeeRight:open(rect)
  if self:getInteger("car_locked") == 0 then
    -- 车门开着，还没进入逃脱剧情，点哪都是走对话流程
    self:onTouchBegan(nil)

    return
  end

  if self:imageIsOn("2") then
    if self:getInteger("engine_start") > 0 then
      -- 开门
      self:play("door")
      self:imageOn("1")
      self:sayI18n("open_1")

    else
      -- 门打不开
      self:play("frontdoor")
      self:sayI18n("open_2")
    end

    return
  end
end

function E3SecondSeeRight:goOut(rect)
  if self:getInteger("car_locked") == 0 then
    -- 车门开着，还没进入逃脱剧情，点哪都是走对话流程
    self:onTouchBegan(nil)

    return
  end

  if self:imageIsOn("1") then
    -- 去外面
    self:switchPlaceZoomIn("OutRight", rect)

    return
  end
end

function E3SecondSeeRight:close(rect)
  if self:getInteger("car_locked") == 0 then
    -- 车门开着，还没进入逃脱剧情，点哪都是走对话流程
    self:onTouchBegan(nil)

    return
  end

  if self:imageIsOn("1") then
    -- 关门
    self:play("door")
    self:imageOn("2")
    self:sayI18n("close_1")

    return
  end
end

function E3SecondSeeRight:onTouchBegan(touch, event)
  if self:getInteger("car_locked") > 0 then
    return
  end

  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("touchesBegan_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("touchesBegan_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("touchesBegan_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("touchesBegan_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:switchPlaceZoomIn("OutRight", self.buttonTable["goOut"])

    return
  end
end

return E3SecondSeeRight
