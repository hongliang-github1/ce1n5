local E3Nikon = class("E3Nikon", function()
  return BasePlace.new()
end)

function E3Nikon:initPhoto()
  self:addPhoto("2", 704, 256)
  self:addPhoto("3", 768, 384)
end

function E3Nikon:initButton()
  self:addButton("assembly", 0, 0, 2044, 1148, false)
end

function E3Nikon:beforeLoad()
  self:imageOn("1")
  self:imageOn("3")
end

function E3Nikon:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3Nikon:beforeUnload()
end

function E3Nikon:recordLastPlaceName()
  return false
end

function E3Nikon:beforeUseItem(itemName)
  return false
end

function E3Nikon:afterUseItem(itemName)
  return true
end

function E3Nikon:assembly(rect)
  if self:getInteger("nikon") ~= 0 then
    self:switchPlace(self.fromPlaceName or "Drive")

    return
  end

  if self:imageIsOn("3") then
    self:imageOn("2")
    self:imageOff("3")
    self:sayI18n("assembly_1")

    return
  end

  if self:imageIsOn("2") then
    self:imageOff("2")
    self:sayI18n("assembly_2")

    return
  end

  self:getItem("nikon")
  self:sayI18n("assembly_3")
end

return E3Nikon
