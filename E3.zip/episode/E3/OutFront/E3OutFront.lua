local E3OutFront = class("E3OutFront", function()
  return BasePlace.new()
end)

function E3OutFront:initPhoto()
  self:addPhoto("3", 704, 576)
end

function E3OutFront:initButton()
end

function E3OutFront:arrowLeft(rect)
  self:switchPlaceLeft("OutRight")
end

function E3OutFront:arrowRight(rect)
  self:switchPlaceRight("OutLeft")
end

function E3OutFront:beforeLoad()
  self:imageOn("1")

  if self:getInteger("engine_start") > 0 then
    self:imageOn("3")
  end
end

function E3OutFront:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3OutFront:afterLoad2()
  self:cacheImage("OutLeft/1")
end

function E3OutFront:beforeUseItem(itemName)
  return false
end

function E3OutFront:afterUseItem(itemName)
  return true
end

return E3OutFront
