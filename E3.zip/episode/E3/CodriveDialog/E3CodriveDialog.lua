local E3CodriveDialog = class("E3CodriveDialog", function()
  return BasePlace.new()
end)

function E3CodriveDialog:initPhoto()
end

function E3CodriveDialog:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E3CodriveDialog:beforeLoad()
  self:disableAlwaysUseItem()
  self:imageOn("Codrive/2")
end

function E3CodriveDialog:afterLoad()
  self:click(nil)
end

function E3CodriveDialog:afterLoad2()
  e3.removeCacheOut(self)
  
  self:cacheImage("Codrive/1")
end

function E3CodriveDialog:beforeUnload()
end

function E3CodriveDialog:beforeUseItem(itemName)
  return false
end

function E3CodriveDialog:afterUseItem(itemName)
  return true
end

function E3CodriveDialog:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 黑屏，显示30分钟后
    self:effectFadeBlack("30minutes", 2, 3, 2, function()
      self:sayI18n("click_3")
    end)

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("Iphone/0")
    self:sayI18n("click_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_6")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_8")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("Codrive/2")
    self:sayI18n("click_9")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("Codrive/2")
    self:sayI18n("click_10")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 进入副驾驶视角
    self:setInteger("car_locked", 1)
    self:switchPlace("Codrive")

    return
  end
end

return E3CodriveDialog
