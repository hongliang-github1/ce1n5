local E3Key = class("E3Key", function()
  return BasePlace.new()
end)

function E3Key:initPhoto()
  self:addPhoto("2", 896, 576)
  self:addPhoto("3", 1024, 576)
end

function E3Key:initButton()
  self:addButton("open", 492, 104, 1078, 958)
end

function E3Key:arrowDown(rect)
  self:switchPlaceZoomOut("Panel")
end

function E3Key:beforeLoad()
  self:imageOn("1")

  if self:getInteger("engine_start") > 0 or self:getInteger("nikon") < 0 then
    self:imageOn("2")
  end
end

function E3Key:afterLoad()
  self:sayI18n("afterLoad_1")

  -- 从aux place转过来后，进入动画过程
  if self.fromPlaceName == "FrontAux" then
    self:imageOff("2")
    self:imageOff("3")
    self:hideArrowButton()
    self:disableTouch()

    self.flickerCount = 0
  
    self.flickerAction = self:schedule(0.2, function()
      self.flickerCount = self.flickerCount + 1

      if self.flickerCount == 1 then
        -- 预加载启动按钮图片
        self:imageTexture("2")
        self:imageTexture("3")
      end

      if self:imageIsOn("2") and self:imageIsOn("3") then
        self:imageOff("2")
        self:imageOff("3")

      else
        self:imageOn("2")
        self:imageOn("3")
      end

      if self.flickerCount > 3 then
        -- 停止闪烁，保持绿灯亮
        self:unschedule(self.flickerAction)
        self:enableTouch()
        self:imageOn("2")

        self.flickerAction = nil

        return
      end
    end)
  end
end

function E3Key:afterLoad2()
  self:cacheImage("Panel/1")
end

function E3Key:beforeUseItem(itemName)
  return false
end

function E3Key:afterUseItem(itemName)
  return true
end

function E3Key:open(rect)
  if self:imageIsOn("2") and self:getInteger("engine_start") > 0 then
    self:sayI18n("open_1")

    return
  end

  if self:getInteger("nikon") < 0 then
    -- 尼康usb已经插入aux接口了，可以发动车了，设置状态，进入仪表启动界面
    self:setInteger("engine_start", 1)
    self:play("dblclick")
    self:switchPlace("DoorOpenDialog")

    return
  end

  -- 不能启动，黄灯闪
  self:play("engine_fail")
  self:imageOn("3")
  self:hideArrowButton()
  self:disableTouch()
  self:sayI18n("open_2")

  self.flickerCount  = 0  
  self.flickerAction = self:schedule(0.2, function()
    self.flickerCount = self.flickerCount + 1

    if self.flickerCount == 1 then
      -- 预加载启动按钮图片
      self:imageTexture("3")
    end

    if self:imageIsOn("3") then
      self:imageOff("3")

    else
      self:imageOn("3")
    end

    if self.flickerCount > 3 then
      -- 停止闪烁
      self:unschedule(self.flickerAction)
      self:showArrowButton()
      self:enableTouch()
      self:imageOff("3")

      self.flickerAction = nil

      return
    end
  end)
end

return E3Key
