local E3FrontArm = class("E3FrontArm", function()
  return BasePlace.new()
end)

function E3FrontArm:initPhoto()
  self:addPhoto("2", 704, 192)
  self:addPhoto("3", 896, 320)
  self:addPhoto("5", 896, 320)
end

function E3FrontArm:initButton()
  self:addButton("open", 670, 582, 638, 564)
  self:addButton("aux", 682, 40, 630, 540)
end

function E3FrontArm:arrowUp(rect)
  self:switchPlaceZoomOut("SecondLeft")
end

function E3FrontArm:beforeLoad()
  self:imageOn("1")

  if self.fromPlaceName == "FrontAux" then
    -- 从FrontAux视角而来，扶手箱是打开的，根据道具状态决定是否显示尼康u盘
    self:imageOn("2")
  
    if self:getInteger("nikon") < 0 then
      self:imageOn("3")
    end
  end
end

function E3FrontArm:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3FrontArm:afterLoad2()
  self:cacheImage("FrontAux/1")
end

function E3FrontArm:beforeUseItem(itemName)
  return false
end

function E3FrontArm:afterUseItem(itemName)
  return true
end

function E3FrontArm:open(rect)
  if not self:imageIsOn("2") then
    -- 还没打开，现在打开
    self:play("glove_open")
    self:imageOn("2")

    if self:getInteger("nikon") < 0 then
      self:imageOn("3")
    end

    self:sayI18n("open_2")

    return
  end

  -- 扶手箱开了，里面没东西
  self:sayI18n("open_3")
end

function E3FrontArm:aux(rect)
  if not self:imageIsOn("2") then
    -- 还没打开，现在打开
    self:open(self.buttonTable["open"])

    return
  end

  -- 扶手箱打开了
  if self:imageIsOn("3") or self:imageIsOn("5") then
    -- 进入aux视角
    self:switchPlaceZoomIn("FrontAux", rect)

    return
  end

  -- 扶手箱开了，掀开黑色盖板
  self:play("click")
  self:imageOn("5")
  self:sayI18n("aux_1")
end

return E3FrontArm
