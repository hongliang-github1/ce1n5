local E3Dashboard = class("E3Dashboard", function()
  return BasePlace.new()
end)

function E3Dashboard:initPhoto()
  self:addPhoto("d", 832, 576)
  self:addPhoto("l6", 1600, 256)
  self:addPhoto("p1", 704, 192)
end

function E3Dashboard:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E3Dashboard:showPin()
  -- 如果还没设置，先把图片设置上
  self:imageOn("3", 1256, 118)
  self:imageOn("3", 106, 158)
end

function E3Dashboard:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E3Dashboard:afterShowArrowButton()
  if self.justStart then
    self.hideArrowButton()
  end
end

function E3Dashboard:beforeLoad()
  self.justStart = false

  if self:getInteger("engine_start") > 0 then
    self:imageOn("2")
    self:imageOn("p1")
    self:imageOn("l6")
    self:showPin()

  else
    self:imageOn("1")
  end
end

function E3Dashboard:afterLoad()
  if self.fromPlaceName == "Key" then
    -- 刚刚启动，走启动动画
    self:disableTouch()
    self:hideArrowButton()

  else
    if self:imageIsOn("1") then
      self:sayI18n("afterLoad_1")

    else
      self:sayI18n("afterLoad_2")
    end
  end
end

function E3Dashboard:click(rect)
  if self.justStart then
    -- 车刚发动，进入到自动开门剧情
    self:switchPlace("DoorOpenDialog")

    return
  end

  -- 平时什么都不做
  self:sayI18n("click_1")
end

return E3Dashboard
