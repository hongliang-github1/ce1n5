local E3PanelAir = class("E3PanelAir", function()
  return BasePlace.new()
end)

function E3PanelAir:initPhoto()
  self:addPhoto("2", 320, 64)
  self:addPhoto("3", 320, 256)
  self:addPhoto("4", 704, 192)
  self:addPhoto("5", 960, 384)
  self:addPhoto("6", 1088, 192)
  self:addPhoto("7", 1472, 64)
  self:addPhoto("8", 1472, 256)
  self:addPhoto("9", 0, 704)
  self:addPhoto("a2", 448, 832)
  self:addPhoto("d1", 704, 1024)
  self:addPhoto("d2", 704, 1024)
  self:addPhoto("dot0", 320, 1024)
  self:addPhoto("dot5", 320, 1024)
  self:addPhoto("on", 256, 832)
  self:addPhoto("s1", 576, 1024)
  self:addPhoto("s2", 576, 1024)
  self:addPhoto("s3", 576, 1024)
  self:addPhoto("s4", 576, 1024)
  self:addPhoto("s5", 576, 1024)
  self:addPhoto("s6", 576, 1024)
  self:addPhoto("s7", 576, 1024)
  self:addPhoto("s8", 576, 960)
  self:addPhoto("b0", 320, 1024)
  self:addPhoto("b1", 320, 1024)
  self:addPhoto("b2", 320, 1024)
  self:addPhoto("b3", 320, 1024)
  self:addPhoto("b4", 320, 1024)
  self:addPhoto("b5", 320, 1024)
  self:addPhoto("b6", 320, 1024)
  self:addPhoto("b7", 320, 1024)
  self:addPhoto("b8", 320, 1024)
  self:addPhoto("b9", 320, 1024)
  self:addPhoto("i1", 1216, 832)
  self:addPhoto("i2", 1216, 960)
  self:addPhoto("i3", 1280, 896)
  self:addPhoto("i4", 1152, 832)
  self:addPhoto("l1", 320, 1024)
  self:addPhoto("l2", 320, 1024)
  self:addPhoto("l3", 320, 1024)
end

function E3PanelAir:initButton()
  self:addButton("power", 228, 0, 340, 196, false)
  self:addButton("airAuto", 254, 200, 314, 226, false)
  self:addButton("lock", 938, 482, 302, 236, false)
  self:addButton("unlock", 630, 482, 302, 238, false)
  self:addButton("tempHigh", 570, 0, 196, 182, false)
  self:addButton("tempLow", 1102, 0, 186, 186, false)
  self:addButton("rear", 778, 330, 316, 148, false)
  self:addButton("loop", 1290, 190, 398, 220, false)
  self:addButton("airAc", 1290, 0, 398, 188, false)
  self:addButton("modeUp", 768, 0, 330, 196, false)
  self:addButton("modeDown", 772, 194, 322, 136, false)
  self:addButton("glassHeatFront", 570, 184, 206, 218, false)
  self:addButton("glassHeatRear", 1098, 188, 190, 226, false)
  self:addButton("redTriangle", 240, 434, 390, 268, false)
  self:addButton("nothing", 1250, 414, 326, 252, false)
  self:addButton("volumeUp", 1692, 0, 352, 212, false)
  self:addButton("volumeDown", 1692, 216, 352, 238, false)
end

function E3PanelAir:arrowDown(rect)
  self:switchPlaceZoomOut("Panel")
end

function E3PanelAir:beforeLoad()
  self:imageOn("1")
end

function E3PanelAir:afterLoad()
  -- 屏幕还没打开
  self:sayI18n("afterLoad_2")
end

function E3PanelAir:beforeUseItem(itemName)
  return false
end

function E3PanelAir:afterUseItem(itemName)
  return true
end

return E3PanelAir
