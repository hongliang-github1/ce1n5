local E3DriveDialog = class("E3DriveDialog", function()
  return BasePlace.new()
end)

function E3DriveDialog:initPhoto()
end

function E3DriveDialog:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E3DriveDialog:beforeLoad()
  self:disableAlwaysUseItem()
  self:imageOn("Drive/1")
end

function E3DriveDialog:afterLoad()
  self:click(nil)
end

function E3DriveDialog:beforeUnload()
end

function E3DriveDialog:beforeUseItem(itemName)
  return false
end

function E3DriveDialog:afterUseItem(itemName)
  return true
end

function E3DriveDialog:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:switchPlaceZoomOut("OutDrive")

    return
  end
end

return E3DriveDialog
