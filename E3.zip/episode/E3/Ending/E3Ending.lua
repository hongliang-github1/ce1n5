local E3Ending = class("E3Ending", function()
  return BasePlace.new()
end)

function E3Ending:initPhoto()
end

function E3Ending:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E3Ending:beforeLoad()
  self:imageOn("Beginning/go")
end

function E3Ending:afterLoad()
  self:click(nil)
end

function E3Ending:afterLoad2()
  e3.removeCacheIn(self)
  e3.removeCacheOut(self)

  self:cacheImage("road")
  self:cacheImage("s8")
  self:cacheImage("bed")
  self:cacheImage("door")
end

function E3Ending:beforeUseItem(itemName)
  return false
end

function E3Ending:afterUseItem(itemName)
  return true
end

function E3Ending:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOn("Beginning/go")
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("Park/1")
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("road")
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_6")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_8")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("s8")
    self:sayI18n("click_9")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_10")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_11")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("bed")
    self:sayI18n("click_12")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_13")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("door")
    self:sayI18n("click_14")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_15")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 黑屏动画
    self:effectFadeBlack(nil, 1.5, 0, 0, function()
      -- 到这里就算通关了，设置通关标记
      userdata.setEpisodePassed(self.episodeName)

      -- TODO 设置通关时间

      -- TODO 进入通关字幕CreditScene
      cc.Director:getInstance():replaceScene(BaseScene.create("CreditScene"))

      -- 保留黑屏状态
      return true
    end)

    return
  end
end

return E3Ending
