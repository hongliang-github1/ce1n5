local E3RightSeatUnder = class("E3RightSeatUnder", function()
  return BasePlace.new()
end)

function E3RightSeatUnder:initPhoto()
  self:addPhoto("2", 640, 512)
end

function E3RightSeatUnder:initButton()
  self:addButton("getCat", 354, 308, 1254, 534)
end

function E3RightSeatUnder:arrowUp(rect)
  self:switchPlaceUp("SecondRightSeatBack")
end

function E3RightSeatUnder:beforeLoad()
  self.tomHere = self:getString("right") == "tom"

  self:imageOn("1")

  if self:getInteger("tom") == 0 and self.tomHere then
    self:imageOn("2")
  end
end

function E3RightSeatUnder:afterLoad()
  if self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3RightSeatUnder:beforeUseItem(itemName)
  return false
end

function E3RightSeatUnder:afterUseItem(itemName)
  return true
end

function E3RightSeatUnder:getCat(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:getItem("tom")
    self:sayI18n("getCat_1")

  else
    self:sayI18n("getCat_3")
  end
end

return E3RightSeatUnder
