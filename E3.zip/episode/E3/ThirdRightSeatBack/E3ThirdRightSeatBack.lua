local E3ThirdRightSeatBack = class("E3ThirdRightSeatBack", function()
  return BasePlace.new()
end)

function E3ThirdRightSeatBack:initPhoto()
  self:addPhoto("2", 576, 0)
  self:addPhoto("3", 512, 192)
end

function E3ThirdRightSeatBack:initButton()
  self:addButton("getItem1", 448, 22, 1178, 708)
end

function E3ThirdRightSeatBack:arrowDown(rect)
  self:switchPlaceZoomOut("ThirdSeeFront")
end

function E3ThirdRightSeatBack:beforeLoad()
  self:imageOn("1")
end

function E3ThirdRightSeatBack:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3ThirdRightSeatBack:beforeUseItem(itemName)
  return false
end

function E3ThirdRightSeatBack:afterUseItem(itemName)
  return true
end

function E3ThirdRightSeatBack:getItem1(rect)
  -- 没东西
  self:play("click")
  self:sayI18n("getItem_5")
end

return E3ThirdRightSeatBack
