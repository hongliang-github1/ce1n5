local E3Knee = class("E3Knee", function()
  return BasePlace.new()
end)

function E3Knee:initPhoto()
  self:addPhoto("3", 960, 448)
end

function E3Knee:initButton()
  self:addButton("open", 128, 132, 1688, 978)
end

function E3Knee:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E3Knee:beforeLoad()
  self:imageOn("1")
end

function E3Knee:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3Knee:afterLoad2()
  self:cacheImage("2")
end

function E3Knee:beforeUseItem(itemName)
  return false
end

function E3Knee:afterUseItem(itemName)
  return true
end

function E3Knee:open(rect)
  if self:imageIsOn("3") then
    self:imageOff("3")

    return
  end

  if self:imageIsOn("2") then
    self:play("glove_close")
    self:imageOff("2")
    self:imageOn("1")
    self:sayI18n("open_2")

    return
  end

  -- 打开
  self:play("glove_open")
  self:imageOn("2")

  self:sayI18n("open_4")
end

return E3Knee
