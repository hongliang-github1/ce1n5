local E3Park = class("E3Park", function()
  return BasePlace.new()
end)

function E3Park:initPhoto()
  self:addPhoto("4", 640, 576)
  self:addPhoto("5", 1024, 576)
end

function E3Park:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E3Park:beforeLoad()
  self:imageOn("0")
end

function E3Park:afterLoad()
  self:click(nil)
end

function E3Park:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("3")
  self:cacheImage("OutRight/1")
end

function E3Park:afterUnload()
  self:cacheImageRemove("Beginning/2c")
  self:cacheImageRemove("Beginning/board")
  self:cacheImageRemove("Beginning/go")
  self:cacheImageRemove("Beginning/key")
  self:cacheImageRemove("0")
  self:cacheImageRemove("1")
  self:cacheImageRemove("3")
end

function E3Park:beforeUseItem(itemName)
  return false
end

function E3Park:afterUseItem(itemName)
  return true
end

function E3Park:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("3")
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:disableTouch()

    self.flickerCount  = 0
    self.flickerAction = self:schedule(0.2, function()
      self.flickerCount = self.flickerCount + 1

      if self.flickerCount == 1 then
        -- 播放声音，预加载前后车灯图片
        self:imageTexture("4")
        self:imageTexture("5")
      end

      if self:imageIsOn("4") and self:imageIsOn("5") then
        self:imageOff("4")
        self:imageOff("5")

      else
        self:imageOn("4")
        self:imageOn("5")
      end

      if self.flickerCount > 4 then
        -- 停止闪烁
        self:unschedule(self.flickerAction)
        self:enableTouch()
        self:imageOff("4")
        self:imageOff("5")
        self:sayI18n("click_6")

        self.flickerAction = nil
      end
    end)
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:switchPlaceZoomIn("OutRight", cc.rect(680, 520, 600, 300))

    return
  end
end

return E3Park
