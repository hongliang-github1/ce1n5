local E3ThirdLeftSlot = class("E3ThirdLeftSlot", function()
  return BasePlace.new()
end)

function E3ThirdLeftSlot:initPhoto()
  self:addPhoto("2", 896, 768)
end

function E3ThirdLeftSlot:initButton()
  self:addButton("getBattery", 656, 548, 754, 546)
end

function E3ThirdLeftSlot:arrowRight(rect)
  self:switchPlaceRight("ThirdSeeFront")
end

function E3ThirdLeftSlot:beforeLoad()
  self:imageOn("1")

  if self:getInteger("battery1") == 0 then
    self:imageOn("2")
  end
end

function E3ThirdLeftSlot:afterLoad()
  if self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3ThirdLeftSlot:beforeUseItem(itemName)
  return false
end

function E3ThirdLeftSlot:afterUseItem(itemName)
  return true
end

function E3ThirdLeftSlot:getBattery(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:getItem("battery1")
    self:sayI18n("getBattery_1")

  else
    self:sayI18n("getBattery_2")
  end
end

return E3ThirdLeftSlot
