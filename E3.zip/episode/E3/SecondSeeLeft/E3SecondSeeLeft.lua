local E3SecondSeeLeft = class("E3SecondSeeLeft", function()
  return BasePlace.new()
end)

function E3SecondSeeLeft:initPhoto()
end

function E3SecondSeeLeft:initButton()
  self:addButton("open", 1346, 398, 234, 344)
  self:addButton("close", 552, 378, 276, 348, false)
  self:addButton("goOut", 832, 6, 510, 822, false)
end

function E3SecondSeeLeft:arrowLeft(rect)
  self:switchPlaceLeft("SeeThirdFar")
end

function E3SecondSeeLeft:arrowRight(rect)
  self:switchPlaceRight("SecondLeft")
end

function E3SecondSeeLeft:beforeLoad()
  if self:getInteger("car_locked") == 0 then
    -- 还没开始逃脱剧情，车门是开着的，不准去别的视角
    self:imageOn("1")

  else
    if self:getInteger("second_left_door_open") > 0 then
      -- 从二排左视角开门而来，门是开着的
      self:imageOn("1")
      self:setInteger("second_left_door_open", 0)
      self:sayI18n("beforeLoad_1")

    else
      self:imageOn("2")
    end
  end
end

function E3SecondSeeLeft:afterLoad()
  if self:getInteger("car_locked") == 0 then
    self:hideArrowButton()

    self:sayI18n("afterLoad_1")
  end
end

function E3SecondSeeLeft:afterLoad2()
  self:cacheImage("SeeThirdFar/1")
end

function E3SecondSeeLeft:beforeUseItem(itemName)
  return false
end

function E3SecondSeeLeft:afterUseItem(itemName)
  return true
end

function E3SecondSeeLeft:open(rect)
  if self:getInteger("car_locked") == 0 then
    -- 车门开着，还没进入逃脱剧情，点哪都是走对话流程
    self:onTouchBegan(nil)

    return
  end

  if self:imageIsOn("2") then
    if self:getInteger("engine_start") > 0 then
      -- 开门
      self:play("door")
      self:imageOn("1")
      self:sayI18n("open_1")

    else
      -- 门打不开
      self:play("frontdoor")
      self:sayI18n("open_2")
    end

    return
  end
end

function E3SecondSeeLeft:goOut(rect)
  if self:getInteger("car_locked") == 0 then
    -- 车门开着，还没进入逃脱剧情，点哪都是走对话流程
    self:onTouchBegan(nil)

    return
  end

  if self:imageIsOn("1") then
    self:switchPlaceZoomIn("OutLeft", rect)

    return
  end
end

function E3SecondSeeLeft:close(rect)
  if self:getInteger("car_locked") == 0 then
    -- 车门开着，还没进入逃脱剧情，点哪都是走对话流程
    self:onTouchBegan(nil)

    return
  end

  if self:imageIsOn("1") then
    -- 关门
    self:play("door")
    self:imageOn("2")
    self:sayI18n("close_1")

    return
  end
end

function E3SecondSeeLeft:onTouchBegan(touch, event)
  if self:getInteger("car_locked") ~= 0 then
    return
  end

  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("touchesBegan_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("touchesBegan_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("touchesBegan_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("touchesBegan_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:switchPlaceZoomIn("OutLeft", self.buttonTable["goOut"])

    return
  end
end

return E3SecondSeeLeft
