local E3DoorOpenDialog = class("E3DoorOpenDialog", function()
  return BasePlace.new()
end)

function E3DoorOpenDialog:initPhoto()
end

function E3DoorOpenDialog:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E3DoorOpenDialog:beforeLoad()
  self:disableAlwaysUseItem()
  self:play("door")
  self:imageOn("SecondSeeRight/1")
end

function E3DoorOpenDialog:afterLoad()
end

function E3DoorOpenDialog:afterLoad2()
  e3.removeCacheIn(self)

  self:cacheImage("OutRight/1")
end

function E3DoorOpenDialog:beforeUnload()
end

function E3DoorOpenDialog:beforeUseItem(itemName)
  return false
end

function E3DoorOpenDialog:afterUseItem(itemName)
  return true
end

function E3DoorOpenDialog:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("OutRight/1")
    self:imageOn("OutRight/5", 320, 320)
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("OutRight/1")
    self:imageOn("OutRight/5", 320, 320)
    self:sayI18n("click_6")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 切入车外右场景
    self:switchPlace("OutRight")

    return
  end
end

return E3DoorOpenDialog
