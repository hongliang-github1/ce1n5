local E3Codrive = class("E3Codrive", function()
  return BasePlace.new()
end)

function E3Codrive:initPhoto()
end

function E3Codrive:initButton()
  self:addButton("goGloveBox", 720, 700, 698, 448)
  self:addButton("openDoor", 1494, 532, 352, 392)
end

function E3Codrive:arrowLeft(rect)
  self:switchPlaceLeft("Drive")
end

function E3Codrive:arrowRight(rect)
  self:switchPlaceRight("SeeCodrive")
end

function E3Codrive:arrowDown(rect)
  self:switchPlaceZoomOut("SecondLeft")
end

function E3Codrive:beforeLoad()
  if self:getInteger("engine_start") > 0 then
    self:imageOn("1")

  else
    self:imageOn("2")
  end
end

function E3Codrive:afterLoad()
  if self.fromPlaceName == "CodriveDialog" then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3Codrive:afterLoad2()
  self:cacheImage("Drive/1")
  self:cacheImage("SecondLeft/1")
  self:cacheImage("GloveBox/1")
end

function E3Codrive:beforeUseItem(itemName)
  return false
end

function E3Codrive:afterUseItem(itemName)
  return true
end

function E3Codrive:goGloveBox(rect)
  self:switchPlaceZoomIn("GloveBox", rect)
end

function E3Codrive:openDoor(rect)
  if self:getInteger("engine_start") > 0 then
    -- 开门出去
    self:play("frontdoor")
    self:setInteger("front_right_door_open",1)
    self:switchPlaceRight("SeeCodrive")

  else
    self:play("frontdoor")
    self:sayI18n("openDoor_1")
  end
end

return E3Codrive
