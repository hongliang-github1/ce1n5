local E3OutTankSwitch = class("E3OutTankSwitch", function()
  return BasePlace.new()
end)

function E3OutTankSwitch:initPhoto()
  self:addPhoto("2", 960, 704)
end

function E3OutTankSwitch:initButton()
  self:addButton("open", 724, 528, 870, 620)
end

function E3OutTankSwitch:arrowUp(rect)
  self:switchPlaceZoomOut("OutDriveUnder")
end

function E3OutTankSwitch:beforeLoad()
  self:imageOn("1")
end

function E3OutTankSwitch:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3OutTankSwitch:beforeUseItem(itemName)
  return false
end

function E3OutTankSwitch:afterUseItem(itemName)
  return true
end

function E3OutTankSwitch:open(rect)
  self:disableTouch()
  self:play("hood")
  self:imageOn("2")
  self:setInteger("tank_open", 1)
  self:sayI18n("open_1")
  self:scheduleOnce(0.35, function()
    self:imageOff("2")
    self:enableTouch()
  end)
end

return E3OutTankSwitch
