local E3ThirdSeeTrunk = class("E3ThirdSeeTrunk", function()
  return BasePlace.new()
end)

function E3ThirdSeeTrunk:initPhoto()
  self:addPhoto("2", 576, 640)
end

function E3ThirdSeeTrunk:initButton()
  self:addButton("getATM", 648, 600, 622, 550)
end

function E3ThirdSeeTrunk:arrowUp(rect)
  self:switchPlaceUp("SeeThirdNear")
end

function E3ThirdSeeTrunk:beforeLoad()
  self:imageOn("1")

  if self:getInteger("atm") == 0 then
    self:imageOn("2")
  end
end

function E3ThirdSeeTrunk:afterLoad()
  if self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3ThirdSeeTrunk:beforeUseItem(itemName)
  return false
end

function E3ThirdSeeTrunk:afterUseItem(itemName)
  return true
end

function E3ThirdSeeTrunk:getATM(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:getItem("atm")
    self:sayI18n("getATM_1")

  else
    self:sayI18n("getATM_2")
  end
end

return E3ThirdSeeTrunk
