local E3TankNear = class("E3TankNear", function()
  return BasePlace.new()
end)

function E3TankNear:initPhoto()
  self:addPhoto("3", 256, 128)
  self:addPhoto("4", 512, 384)
end

function E3TankNear:initButton()
  self:addButton("getDataLines", 194, 110, 784, 888, false)
  self:addButton("open", 980, 176, 810, 972)
end

function E3TankNear:arrowDown(rect)
  self:switchPlaceZoomOut("Tank")
end

function E3TankNear:beforeLoad()
  self:imageOn("1")

  if self:getInteger("tank_open") > 0 then
    self:imageOn("3")
    self:imageOn("4")
  end
end

function E3TankNear:afterLoad()
  if self:imageIsOn("4") then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3TankNear:beforeUseItem(itemName)
  return false
end

function E3TankNear:afterUseItem(itemName)
  return true
end

function E3TankNear:getDataLines(rect)
  if self:imageIsOn("4") then
    self:imageOff("4")
    self:getItem("wire")
    self:sayI18n("getDataLines_1")

  elseif self:imageIsOn("3") then
    self:sayI18n("getDataLines_2")
  end
end

function E3TankNear:open(rect)
  if self:imageIsOn("3") or self:imageIsOn("4") then
    self:sayI18n("open_1")

  else
    self:play("click")
    self:sayI18n("open_2")
  end
end

return E3TankNear
