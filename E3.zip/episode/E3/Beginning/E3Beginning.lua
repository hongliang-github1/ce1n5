local E3Beginning = class("E3Beginning", function()
  return BasePlace.new()
end)

function E3Beginning:initPhoto()
end

function E3Beginning:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E3Beginning:beforeLoad()
  -- 第一次玩，生成道具随机位置和ATM密码
  if userdata.getEpisodeLastPlace(userdata.currentEpisode) == "" then
    -- 螺丝刀可能随机出现在第二排左右椅背
    local seats  = { "second_left", "second_right" }
    local random = math.random(2)

    for i, seat in ipairs(seats) do
      if i == random then
        self:setString(seat, "screwdriver")

      else
        self:setString(seat, "")
      end
    end

    -- 汤姆猫可能随机出现在第二排左右座椅下方
    local seat_unders = { "left", "right" }
    random            = math.random(2)

    for i, seat_under in ipairs(seat_unders) do
      if i == random then
        self:setString(seat_under, "tom")

      else
        self:setString(seat_under, "")
      end
    end

    -- ATM密码为随机8位数字
    local p1           = math.random(10) - 1
    local p2           = math.random(10) - 1
    local p3           = math.random(10) - 1
    local p4           = math.random(10) - 1
    local p5           = math.random(10) - 1
    local p6           = math.random(10) - 1
    local p7           = math.random(10) - 1
    local p8           = math.random(10) - 1
    local atm_password = p1 .. p2 .. p3 .. p4 .. p5 .. p6 .. p7 .. p8

    self:setString("atm_password", atm_password)
  end

  self:imageOn("board")
end

function E3Beginning:afterLoad()
  self:click(nil)
end

function E3Beginning:afterLoad2()
  self:cacheImage("2c")
  self:cacheImage("key")
  self:cacheImage("go")
  self:cacheImage("Park/0")
end

function E3Beginning:beforeUseItem(itemName)
  return false
end

function E3Beginning:afterUseItem(itemName)
  return true
end

function E3Beginning:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("2c")
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("key")
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("go")
    self:sayI18n("click_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_8")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 黑屏动画
    self:effectFadeBlack(nil, 1.5, 0, 0, function()
      self:switchPlace("Park")
    end)

    return
  end
end

return E3Beginning
