local E3FrontFloorSlot = class("E3FrontFloorSlot", function()
  return BasePlace.new()
end)

function E3FrontFloorSlot:initPhoto()
  self:addPhoto("2", 512, 576)
  self:addPhoto("3", 640, 0)
  self:addPhoto("4", 768, 0)
  self:addPhoto("5", 768, 0)
  self:addPhoto("6", 640, 0)
  self:addPhoto("8", 640, 0)
end

function E3FrontFloorSlot:initButton()
  self:addButton("openSlot1", 548, 0, 920, 556)
  self:addButton("openSlot2", 548, 560, 924, 588)
end

function E3FrontFloorSlot:arrowDown(rect)
  self:switchPlaceZoomOut("SecondRight")
end

function E3FrontFloorSlot:beforeLoad()
  self:imageOn("1")

  if self:getInteger("called") > 0 then
    self:imageOn("2")
    self:imageOn("8")
  end
end

function E3FrontFloorSlot:afterLoad()
  if self:imageIsOn("8") then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3FrontFloorSlot:beforeUseItem(itemName)
  if itemName == "charger" then
    return self:imageIsOn("4")
  end

  if itemName == "wire" then
    return self:imageIsOn("5")
  end

  return false
end

function E3FrontFloorSlot:afterUseItem(itemName)
  if itemName == "charger" then
    self:imageOn("5")
    self:imageOff("4")
    self:sayI18n("afterUseItem_1")

    return true
  end

  if itemName == "wire" then
    self:imageOn("6")
    self:imageOff("5")
    self:sayI18n("afterUseItem_2")

    return true
  end

  return true
end

function E3FrontFloorSlot:openSlot1(rect)
  if self:imageIsOn("8") then
    -- 正在给iPhone充电
    if self.charged then
      self:switchPlace("Iphone")

    else
      self.charged = true

      self:sayI18n("openSlot1_1")
    end

    return
  end

  if self:imageIsOn("6") then
    -- 等待用iPhone
    self:imageOn("8")
    self:sayI18n("openSlot1_2")

    return
  end

  if self:imageIsOn("5") then
    -- 等待用数据线
    self:sayI18n("openSlot1_3")

    return
  end

  if self:imageIsOn("4") then
    -- 等待用充电器，盖子盖上
    self:play("click")
    self:imageOff("4")
    self:sayI18n("openSlot1_4")

    return
  end

  if self:imageIsOn("3") then
    -- 开盖
    self:play("click")
    self:imageOn("4")
    self:sayI18n("openSlot1_5")

    return
  end

  self:play("glove_open")
  self:imageOn("3")
  self:sayI18n("openSlot1_6")
end

function E3FrontFloorSlot:openSlot2(rect)
  if self:imageIsOn("2") then
    -- 已经打开了，关上
    self:play("glove_close")
    self:imageOff("2")
    self:sayI18n("openSlot2_1")

    return
  end

  if self:imageIsOn("8") then
    -- 正在给iPhone充电，按slot1处理
    self:openSlot1(self.buttonTable["openSlot1"])

    return
  end

  -- 打开
  self:play("glove_open")
  self:imageOn("2")
  self:sayI18n("openSlot2_2")

  return
end

return E3FrontFloorSlot
