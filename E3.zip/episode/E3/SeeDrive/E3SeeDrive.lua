local E3SeeDrive = class("E3SeeDrive", function()
  return BasePlace.new()
end)

function E3SeeDrive:initPhoto()
end

function E3SeeDrive:initButton()
  self:addButton("open", 1164, 374, 700, 384)
  self:addButton("goOut", 554, 132, 604, 630, false)
end

function E3SeeDrive:arrowRight(rect)
  self:switchPlaceRight("Drive")
end

function E3SeeDrive:beforeLoad()
  if self:getInteger("front_left_door_open") > 0 then
    -- 从驾驶位视角开门而来，门是开着的
    self:imageOn("1")
    self:setInteger("front_left_door_open", 0)
    self:sayI18n("beforeLoad_1")

  else
    self:imageOn("2")
  end
end

function E3SeeDrive:afterLoad()

end

function E3SeeDrive:beforeUseItem(itemName)
  return false
end

function E3SeeDrive:afterUseItem(itemName)
  return true
end

function E3SeeDrive:open(rect)
  if self:imageIsOn("1") then
    -- 车门现在是开着的，关上
    self:play("frontdoor")
    self:imageOn("2")
    self:sayI18n("open_1")

    return
  end

  -- 车门是关着的，判断能不能开
  if self:getInteger("engine_start") > 0 then
    -- 开门
    self:play("frontdoor")
    self:imageOn("1")
    self:sayI18n("open_2")

  else
    -- 门打不开
    self:play("frontdoor")
    self:sayI18n("open_3")
  end
end

function E3SeeDrive:goOut(rect)
  if not self:imageIsOn("1") then
    -- 开车门去
    self:open(self.buttonTable["open"])

    return
  end

  -- 去车外
  self:switchPlaceZoomIn("OutDrive", rect)
end

return E3SeeDrive
