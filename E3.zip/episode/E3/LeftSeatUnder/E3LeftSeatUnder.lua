local E3LeftSeatUnder = class("E3LeftSeatUnder", function()
  return BasePlace.new()
end)

function E3LeftSeatUnder:initPhoto()
  self:addPhoto("2", 832, 448)
end

function E3LeftSeatUnder:initButton()
  self:addButton("getCat", 542, 254, 1014, 594)
end

function E3LeftSeatUnder:arrowUp(rect)
  self:switchPlaceUp("SecondLeftSeatBack")
end

function E3LeftSeatUnder:beforeLoad()
  self.tomHere = self:getString("left") == "tom"

  self:imageOn("1")

  if self:getInteger("tom") == 0 and self.tomHere then
    self:imageOn("2")
  end
end

function E3LeftSeatUnder:afterLoad()
  if self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3LeftSeatUnder:beforeUseItem(itemName)
  return false
end

function E3LeftSeatUnder:afterUseItem(itemName)
  return true
end

function E3LeftSeatUnder:getCat(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:getItem("tom")
    self:sayI18n("getCat_1")

  else
    self:sayI18n("getCat_3")
  end
end

return E3LeftSeatUnder
