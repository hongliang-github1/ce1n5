local E3Iphone = class("E3Iphone", function()
  return BasePlace.new()
end)

function E3Iphone:initPhoto()
end

function E3Iphone:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E3Iphone:beforeLoad()
  self:disableAlwaysUseItem()
  self:imageOn("0")
end

function E3Iphone:afterLoad()
  self:click(nil)
end

function E3Iphone:afterLoad2()
  self:cacheImage("Ending/road")
end

function E3Iphone:beforeUnload()
  -- 记录用户已经与小华通过话，下次再来时对话就不同了
  if self:getInteger("called") < 1 then
    self:setInteger("called", 1)
  end
end

function E3Iphone:beforeUseItem(itemName)
  return false
end

function E3Iphone:afterUseItem(itemName)
  return true
end

function E3Iphone:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:hideArrowButton()
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("1" .. i18n:getLang())
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("2" .. i18n:getLang())
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_6")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_8")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_9")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_10")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_12")
    self:switchPlace("Ending")

    return
  end
end

return E3Iphone
