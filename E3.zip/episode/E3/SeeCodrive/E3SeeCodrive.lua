local E3SeeCodrive = class("E3SeeCodrive", function()
  return BasePlace.new()
end)

function E3SeeCodrive:initPhoto()
end

function E3SeeCodrive:initButton()
  self:addButton("open", 532, 364, 500, 382)
  self:addButton("goOut", 1038, 92, 454, 860, false)
end

function E3SeeCodrive:arrowLeft(rect)
  self:switchPlaceLeft("Codrive")
end

function E3SeeCodrive:beforeLoad()
  if self:getInteger("front_right_door_open") > 0 then
    -- 从副驾驶位视角开门而来，门是开着的
    if self:getInteger("engine_start") > 0 then
      self:imageOn("3")

    else
      self:imageOn("2")
    end

    self:setInteger("front_right_door_open", 0)
    self:sayI18n("beforeLoad_1")

  else
    if self:getInteger("engine_start") > 0 then
      self:imageOn("4")

    else
      self:imageOn("1")
    end
  end
end

function E3SeeCodrive:afterLoad()

end

function E3SeeCodrive:beforeUseItem(itemName)
  return false
end

function E3SeeCodrive:afterUseItem(itemName)
  return true
end

function E3SeeCodrive:open(rect)
  if self:imageIsOn("2") or self:imageIsOn("3") then
    -- 车门现在是开着的，关上
    self:play("frontdoor")
    if self:getInteger("engine_start") > 0 then
      self:imageOn("4")

    else
      self:imageOn("1")
    end

    self:sayI18n("open_1")

    return
  end

  -- 车门是关着的，判断能不能开
  if self:imageIsOn("4") then
    -- 开门
    self:play("frontdoor")
    self:imageOn("3")
    self:sayI18n("open_2")

  else
    -- 门打不开
    self:play("frontdoor")
    self:sayI18n("open_3")
  end
end

function E3SeeCodrive:goOut(rect)
  if not self:imageIsOn("2") and not self:imageIsOn("3") then
    -- 开车门去
    self:open(self.buttonTable["open"])

    return
  end

  -- 去车外
  self:switchPlaceZoomIn("OutRight", rect)
end

return E3SeeCodrive
