local E3SecondLeftSeatBack = class("E3SecondLeftSeatBack", function()
  return BasePlace.new()
end)

function E3SecondLeftSeatBack:initPhoto()
  self:addPhoto("2", 768, 512)
  self:addPhoto("3", 576, 448)
end

function E3SecondLeftSeatBack:initButton()
  self:addButton("getItem1", 582, 420, 922, 416)
  self:addButton("under", 526, 838, 998, 310)
end

function E3SecondLeftSeatBack:arrowDown(rect)
  self:switchPlaceZoomOut("SecondLeft")
end

function E3SecondLeftSeatBack:beforeLoad()
  self.screwdriverHere = self:getString("second_left") == "screwdriver"

  self:imageOn("1")
end

function E3SecondLeftSeatBack:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3SecondLeftSeatBack:afterLoad2()
  self:cacheImage("LeftSeatUnder/1")
end

function E3SecondLeftSeatBack:beforeUseItem(itemName)
  return false
end

function E3SecondLeftSeatBack:afterUseItem(itemName)
  return true
end

function E3SecondLeftSeatBack:getItem1(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:getItem("screwdriver")
    self:sayI18n("getItem_1")

    return
  end

  if self:getInteger("screwdriver") == 0 and self.screwdriverHere then
    -- 还没拿过螺丝刀，掏出螺丝刀
    self:imageOn("2")
    self:play("click")
    self:sayI18n("getItem_3")

    return
  end

  -- 没东西
  self:play("click")
  self:sayI18n("getItem_5")
end

function E3SecondLeftSeatBack:under(rect)
  self:switchPlaceDown("LeftSeatUnder")
end

return E3SecondLeftSeatBack
