local E3Tank = class("E3Tank", function()
  return BasePlace.new()
end)

function E3Tank:initPhoto()
  self:addPhoto("2", 1152, 448)
  self:addPhoto("3", 960, 448)
  self:addPhoto("4", 960, 448)
end

function E3Tank:initButton()
  self:addButton("openCover", 964, 446, 450, 338)
end

function E3Tank:arrowLeft(rect)
  self:switchPlaceZoomOut("OutLeft")
end

function E3Tank:beforeLoad()
  self:imageOn("1")

  if self:getInteger("tank_open") > 0 then
    self:imageOn("2")

    if self.fromPlaceName == "TankNear" then
      if self:getInteger("wire") ~= 0 then
        self:imageOn("3")

      else
        self:imageOn("4")
      end
    end
  end
end

function E3Tank:afterLoad()
  if self:imageIsOn("2") and self.fromPlaceName ~= "TankNear" then
    self:sayI18n("afterLoad_1")
  end
end

function E3Tank:afterLoad2()
  self:cacheImage("TankNear/1")
end

function E3Tank:beforeUseItem(itemName)
  return false
end

function E3Tank:afterUseItem(itemName)
  return true
end

function E3Tank:openCover(rect)
  if not self:imageIsOn("2") and not self:imageIsOn("3") and not self:imageIsOn("4") then
    -- 油箱盖还没解锁，打不开，直接去近景视角
    self:switchPlaceZoomIn("TankNear", rect)

    return
  end

  if self:imageIsOn("4") then
    -- 进入油箱近景视角
    self:switchPlaceZoomIn("TankNear", rect)

    return
  end

  if self:imageIsOn("3") then
    -- 关上油箱盖
    self:imageOff("2")
    self:imageOff("3")
    self:setInteger("tank_open", 0)
    self:play("hood")
    self:sayI18n("openCover_1")

    return
  end

  if self:imageIsOn("2") then
    -- 打开油箱
    self:play("hood")

    if self:getInteger("wire") > 0 then
      self:imageOn("3")
      self:sayI18n("openCover_2")

    else
      self:imageOn("4")
      self:sayI18n("openCover_3")
    end
  end
end

return E3Tank
