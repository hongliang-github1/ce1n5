local E3Atm = class("E3Atm", function()
  return BasePlace.new()
end)

function E3Atm:initPhoto()
  self:addPhoto("2", 640, 768)
  self:addPhoto("3", 832, 768)
  self:addPhoto("4", 1088, 576)
  self:addPhoto("6", 832, 128)
  self:addPhoto("7", 1152, 192)
end

function E3Atm:initButton()
  self:addButton("getCamera", 534, 726, 914, 422)
  self:addButton("enter", 712, 428, 384, 298)
  self:addButton("card", 1096, 514, 252, 212)
end

function E3Atm:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "Drive")
end

function E3Atm:beforeLoad()
  self:imageOn("1")
  self:imageOn("7")

  if self:getInteger("card") < 0 then
    self:imageOn("4")
  end
  
  if self:getInteger("atm_unlock") > 0 then
    self:imageOn("2")
  
    if self:getInteger("nikon") == 0 then
      self:imageOn("3")
    end
  end
end

function E3Atm:afterLoad()
  if self:imageIsOn("3") then
    self:sayI18n("afterLoad_1")

  elseif self:imageIsOn("6") then
    self:sayI18n("afterLoad_2")

  elseif self:imageIsOn("2") then
    self:sayI18n("afterLoad_3")

  else
    self:sayI18n("afterLoad_4")
  end
end

function E3Atm:recordLastPlaceName()
  return false
end

function E3Atm:beforeUseItem(itemName)
  if itemName == "card" then
    return true
  end

  return false
end

function E3Atm:afterUseItem(itemName)
  if itemName == "card" then
    self:play("cup")
    self:imageOn("4")
    self:imageOn("6")
    self:sayI18n("afterUseItem_2")
    self:disableTouch()

    self.flickerCount  = 0
    self.flickerAction = self:schedule(0.2, function()
      self.flickerCount = self.flickerCount + 1

      if self.flickerCount == 1 then
        -- 预加载红灯亮图片
        self:imageTexture("6")
      end

      if self:imageIsOn("6") then
        self:imageOff("6")

      else
        self:imageOn("6")
      end

      if self.flickerCount > 2 then
        -- 停止闪烁
        self:unschedule(self.flickerAction)
        self:enableTouch()
        self:imageOff("6")

        self.flickerAction = nil

        return
      end
    end)

    return false
  end

  return true
end

function E3Atm:getCamera(rect)
  if self:imageIsOn("3") then
    -- 拿nikon
    self:switchPlace("Nikon")

    return
  end

  if self:imageIsOn("2") then
    self:sayI18n("getCamera_1")

  else
    self:sayI18n("getCamera_2")
  end
end

function E3Atm:enter(rect)
  if self:getInteger("atm_unlock") > 0 then
    self:sayI18n("enter_1")

    return
  end

  if not self:imageIsOn("4") then
    self:play("click")
    self:sayI18n("enter_2")

    return
  end

  self:switchPlaceZoomIn("AtmKeyboard", rect)
end

function E3Atm:card(rect)
  if self:imageIsOn("4") then
    self:sayI18n("card_1")

  else
    self:sayI18n("card_2")
  end
end

return E3Atm
