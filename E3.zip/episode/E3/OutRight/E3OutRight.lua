local E3OutRight = class("E3OutRight", function()
  return BasePlace.new()
end)

function E3OutRight:initPhoto()
  self:addPhoto("2", 1664, 576)
  self:addPhoto("3", 320, 576)
  self:addPhoto("4", 1088, 320)
  self:addPhoto("5", 320, 320)
end

function E3OutRight:initButton()
  self:addButton("openFront", 1132, 378, 252, 508)
  self:addButton("openRear", 852, 378, 278, 506)
  self:addButton("closeFront", 1386, 314, 236, 692, false)
  self:addButton("closeRear", 386, 360, 462, 520, false)
end

function E3OutRight:arrowLeft(rect)
  self:switchPlaceLeft("OutRear")
end

function E3OutRight:arrowRight(rect)
  self:switchPlaceRight("OutFront")
end

function E3OutRight:beforeLoad()
  self:imageOn("1")

  if self:getInteger("engine_start") < 1 then
    self:imageOn("2")
    self:imageOn("3")
  end

  if self.fromPlaceName == "SeeCodrive" then
    self:imageOn("4")

  elseif self.fromPlaceName == "SecondSeeRight" or self.fromPlaceName == "DoorOpenDialog" then
    self:imageOn("5")
  end
end

function E3OutRight:afterLoad()
  if self.fromPlaceName == "Park" then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3OutRight:afterLoad2()
  if self:getInteger("car_locked") == 0 then
    if self:getInteger("engine_start") > 0 then
      self:cacheImage("Codrive/1")

    else
      self:cacheImage("Codrive/2")
    end

    self:cacheImage("SecondSeeRight/1")
  end
end

function E3OutRight:beforeUseItem(itemName)
  return false
end

function E3OutRight:afterUseItem(itemName)
  return true
end

function E3OutRight:openFront(rect)
  if self:imageIsOn("4") then
    -- 前门已经打开了，坐进去
    if self:getInteger("car_locked") > 0 then
      self:switchPlaceZoomIn("Codrive", rect)

    else
      self:switchPlaceZoomIn("CodriveDialog", rect)
    end

  else
    -- 打开前门
    self:imageOn("4")
    self:play("frontdoor")

    -- 如果后门也开了则要重新显示一下图片，始终让5盖在4的上面才行
    if self:imageIsOn("5") then
      self:imageOn("5")
    end

    self:sayI18n("openFront_1")
  end
end

function E3OutRight:openRear(rect)
  if self:imageIsOn("5") then
    -- 后门已经打开了，坐进去
    self:switchPlaceZoomIn("SecondSeeRight", rect)

  else
    -- 打开后门
    self:imageOn("5")
    self:play("door")
    self:sayI18n("openRear_1")
  end
end

function E3OutRight:closeFront(rect)
  if self:imageIsOn("4") then
    self:imageOff("4")
    self:play("frontdoor")
    self:sayI18n("closeFront_1")
  end
end

function E3OutRight:closeRear(rect)
  if self:imageIsOn("5") then
    self:play("door")
    self:imageOff("5")
    self:sayI18n("closeRear_1")
  end
end

return E3OutRight
