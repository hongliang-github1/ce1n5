local E3SecondRightSeatBack = class("E3SecondRightSeatBack", function()
  return BasePlace.new()
end)

function E3SecondRightSeatBack:initPhoto()
  self:addPhoto("2", 832, 384)
  self:addPhoto("3", 512, 320)
end

function E3SecondRightSeatBack:initButton()
  self:addButton("getItem1", 490, 208, 1108, 516)
  self:addButton("under", 470, 726, 1176, 422)
end

function E3SecondRightSeatBack:arrowDown(rect)
  self:switchPlaceZoomOut("SecondRight")
end

function E3SecondRightSeatBack:beforeLoad()
  self.screwdriverHere = self:getString("second_right") == "screwdriver"

  self:imageOn("1")
end

function E3SecondRightSeatBack:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3SecondRightSeatBack:afterLoad2()
  self:cacheImage("RightSeatUnder/1")
end

function E3SecondRightSeatBack:beforeUseItem(itemName)
  return false
end

function E3SecondRightSeatBack:afterUseItem(itemName)
  return true
end

function E3SecondRightSeatBack:getItem1(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:getItem("screwdriver")
    self:sayI18n("getItem_1")

    return
  end

  if self:getInteger("screwdriver") == 0 and self.screwdriverHere then
    -- 还没拿过螺丝刀，掏出螺丝刀
    self:imageOn("2")
    self:play("click")
    self:sayI18n("getItem_3")

    return
  end

  -- 没东西
  self:play("click")
  self:sayI18n("getItem_5")
end

function E3SecondRightSeatBack:under(rect)
  self:switchPlaceDown("RightSeatUnder")
end

return E3SecondRightSeatBack
