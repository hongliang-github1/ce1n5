local E3OutRear = class("E3OutRear", function()
  return BasePlace.new()
end)

function E3OutRear:initPhoto()
  self:addPhoto("2", 512, 0)
  self:addPhoto("3", 640, 640)
  self:addPhoto("4", 1280, 640)
  self:addPhoto("5", 640, 640)
  self:addPhoto("6", 1280, 640)
end

function E3OutRear:initButton()
  self:addButton("open", 648, 474, 540, 526)
  self:addButton("close", 566, 0, 916, 470, false)
  self:addButton("corner", 1192, 490, 208, 506, false)
end

function E3OutRear:arrowLeft(rect)
  self:switchPlaceLeft("OutLeft")
end

function E3OutRear:arrowRight(rect)
  self:switchPlaceRight("OutRight")
end

function E3OutRear:beforeLoad()
  self:imageOn("1")

  if self.fromPlaceName == "TrunkSlot" then
    self:imageOn("2")

    if self:getInteger("engine_start") > 0 then
      self:imageOn("5")
      self:imageOn("6")
    end

  elseif self:getInteger("engine_start") > 0 then
    self:imageOn("3")
    self:imageOn("4")
  end
end

function E3OutRear:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3OutRear:afterLoad2()
  self:cacheImage("OutLeft/1")
end

function E3OutRear:beforeUseItem(itemName)
  return false
end

function E3OutRear:afterUseItem(itemName)
  return true
end

function E3OutRear:open(rect)
  if self:getInteger("atm") == 0 then
    -- 还没拿到ATM，不开后备厢
    self:sayI18n("open_1")

  else
    if self:imageIsOn("2") then
      -- 已经打开后备厢了
      self:sayI18n("open_2")

    else
      -- 还没打开后备厢，现在打开
      self:imageOn("2")
      self:play("trunk")
      self:imageOff("3")
      self:imageOff("4")

      if self:getInteger("engine_start") > 0 then
        self:imageOn("5")
        self:imageOn("6")
      end
      
      self:sayI18n("open_3")
    end
  end
end

function E3OutRear:close(rect)
  if not self:imageIsOn("2") then
    -- 后备厢还没打开，什么都不做

    return
  end

  -- 关后备厢
  self:imageOff("2")
  self:play("trunk")
  self:imageOff("5")
  self:imageOff("6")

  if self:getInteger("engine_start") > 0 then
    self:imageOn("3")
    self:imageOn("4")
  end
  
  self:sayI18n("close_1")
end

function E3OutRear:corner(rect)
  self:open(rect)
end

return E3OutRear
