local E3Credit = class("E3Credit", function()
  return BaseCredit.new()
end)

function E3Credit:afterCreate()
  -- 构造滚动字幕
  self:addLabelI18n(1.1, "beforeLoad_1")

  -- TODO 显示通关时间
  -- NSString *timingString  = [self timingString]
  -- NSString *labelStr    = UikitEnhancement:textByI18nDict("beforeLoad_2")

  -- self:addLabelI18n(1, [labelStr stringByAppendingFormat:"%@", timingString)]

  self:addLabelI18n(1, "beforeLoad_3")

  self:addBlank()

  self:addLabelI18n(1, "beforeLoad_4")

  self:addImage("gl8")

  self:addBlank()

  self:addLabelI18n(1, "beforeLoad_5")

  self:addLabelI18n(1, "beforeLoad_6")

  self:addLabelI18n(1, "beforeLoad_7")

  self:addLabelI18n(1, "beforeLoad_8")

  self:addLabelI18n(1, "beforeLoad_9")

  self:addLabelI18n(1, "beforeLoad_10")

  self:addLabelI18n(1, "beforeLoad_11")

  -- local hour = tonumber(os.date("%H"))

  -- if hour > 0 and hour < 7 then
  --   self:addLabelI18n(0.9, "beforeLoad_12")
  -- end

  self:addBlank()

  self:playMusic("credit")
end

return E3Credit
