local E3Panel = class("E3Panel", function()
  return BasePlace.new()
end)

function E3Panel:initPhoto()
end

function E3Panel:initButton()
  self:addButton("goPanelScreen", 620, 0, 964, 538)
  self:addButton("goPanelAir", 622, 872, 952, 276)
  self:addButton("goPanelMedia", 620, 542, 960, 326)
  self:addButton("goKey", 132, 458, 308, 356)
end

function E3Panel:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E3Panel:beforeLoad()
  if self:getInteger("engine_start") > 0 then
    self:imageOn("2")

  else
    self:imageOn("1")
  end
end

function E3Panel:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3Panel:afterLoad2()
  self:cacheImage("Key/1")
end

function E3Panel:beforeUseItem(itemName)
  return false
end

function E3Panel:afterUseItem(itemName)
  return true
end

function E3Panel:goPanelScreen(rect)
  self:switchPlaceZoomIn("PanelScreen", rect)
end

function E3Panel:goPanelAir(rect)
  self:switchPlaceZoomIn("PanelAir", rect)
end

function E3Panel:goPanelMedia(rect)
  self:sayI18n("goPanelMedia_1")
end

function E3Panel:goKey(rect)
  self:switchPlaceZoomIn("Key", rect)
end

return E3Panel
