local E3SecondRight = class("E3SecondRight", function()
  return BasePlace.new()
end)

function E3SecondRight:initPhoto()
end

function E3SecondRight:initButton()
  self:addButton("goRightSeatBack", 982, 518, 604, 638)
  self:addButton("goDrive", 200, 200, 776, 650)
  self:addButton("goFloorSlot", 688, 854, 290, 292)
  self:addButton("open", 1598, 560, 290, 440)
end

function E3SecondRight:arrowLeft(rect)
  self:switchPlaceLeft("SecondLeft")
end

function E3SecondRight:arrowRight(rect)
  self:switchPlaceRight("SecondSeeRight")
end

function E3SecondRight:beforeLoad()
  if self:getInteger("engine_start") > 0 then
    self:imageOn("2")

  else
    self:imageOn("1")
  end
end

function E3SecondRight:afterLoad()

end

function E3SecondRight:afterLoad2()
  self:cacheImage("SecondRightSeatBack/1")
end

function E3SecondRight:beforeUseItem(itemName)
  return false
end

function E3SecondRight:afterUseItem(itemName)
  return true
end

function E3SecondRight:goRightSeatBack(rect)
  self:switchPlaceZoomIn("SecondRightSeatBack", cc.rect(980, 622, 294 * 2, 180 * 2))
end

function E3SecondRight:goDrive(rect)
  self:switchPlaceZoomIn("Drive", cc.rect(350, 266, 255 * 2, 190 * 2))
end

function E3SecondRight:goFloorSlot(rect)
  self:switchPlaceZoomIn("FrontFloorSlot", rect)
end

function E3SecondRight:open(rect)
  if self:getInteger("engine_start") > 0 then
    -- 开门，到外面
    self:play("door")
    self:setInteger("second_right_door_open", 1)
    self:switchPlaceRight("SecondSeeRight")

    return
  end

  -- 门打不开
  self:play("frontdoor")
  self:sayI18n("open_1")
end

return E3SecondRight
