local E3Tip = class("E3Tip", function()
  return BaseTip.new()
end)

function E3Tip:getTipAtIndex(index)
  self:resetProgress()

  -- 去座椅下方，得到汤姆猫
  if self:nextProgress() == index or (self:getInteger("tom") == 0) then
    local place1 = nil
    local place2 = nil
    local place3 = nil

    if self:getString("left") == "tom" then
      place1 = self:addPlace("SecondLeft")
      place2 = self:addPlace("SecondLeftSeatBack")
      place3 = self:addPlace("LeftSeatUnder")

      place1:markButton("goLeftSeatBack")
      place2:markButton("under")
      place3:markButton("getCat")

    elseif self:getString("right") == "tom" then
      place1 = self:addPlace("SecondRight")
      place2 = self:addPlace("SecondRightSeatBack")
      place3 = self:addPlace("RightSeatUnder")

      place1:markButton("goRightSeatBack")
      place2:markButton("under")
      place3:markButton("getCat")
    end

    self:textI18n("progress_5")

    return self.progress
  end

  -- 拿螺丝刀
  if self:nextProgress() == index or (self:getInteger("screwdriver") == 0) then
    local place1 = nil
    local place2 = nil

    if "second_left" == self:getString("screwdriver") then
      place1 = self:addPlace("SecondLeft")
      place2 = self:addPlace("SecondLeftSeatBack")

      place1:markButton("goLeftSeatBack")
      place2:markButton("getItem")

    elseif "second_right" == self:getString("screwdriver") then
      place1 = self:addPlace("SecondRight")
      place2 = self:addPlace("SecondRightSeatBack")

      place1:markButton("goRightSeatBack")
      place2:markButton("getItem")
    end

    self:textI18n("progress_6")

    return self.progress
  end

  -- 去三排左杯架，得到电池一
  if self:nextProgress() == index or (self:getInteger("battery1") == 0) then
    local place0 = self:addPlace("SeeThirdFar")
    local place1 = self:addPlace("ThirdSeeFront")
    local place2 = self:addPlace("ThirdLeftSlot")

    place0:markButton("goThird")
    place1:markButton("goThirdLeftSlot")
    place2:markButton("getBattery")

    self:textI18n("progress_7")

    return self.progress
  end

  -- 去三排右杯架，得到电池二
  if self:nextProgress() == index or (self:getInteger("battery2") == 0) then
    local place1 = self:addPlace("ThirdSeeFront")
    local place2 = self:addPlace("ThirdRightSlot")

    place1:markButton("goThirdRightSlot")
    place2:markButton("getBattery")

    self:textI18n("progress_8")

    return self.progress
  end

  -- 组装汤姆猫，使汤姆猫为可说话状态
  if self:nextProgress() == index or (self:getInteger("tom_ok") == 0) then
    local place1 = self:addPlace("Tom")

    place1:imageOn("1")
    place1:imageOn("6")
    place1:markButton("assembly")

    self:textI18n("progress_9")

    return self.progress
  end

  -- 去三排看后备厢，得到ATM机
  if self:nextProgress() == index or (self:getInteger("atm") == 0) then
    local place1 = self:addPlace("SeeThirdFar")
    local place2 = self:addPlace("SeeThirdNear")
    local place3 = self:addPlace("ThirdSeeTrunk")

    place1:markButton("goTrunk")
    place2:markButton("goThirdTrunk")
    place3:markButton("getATM")

    self:textI18n("progress_10")

    return self.progress
  end

  -- 拿ATM卡
  if self:nextProgress() == index or (self:getInteger("card") == 0) then
    local place1 = self:addPlace("SecondLeft")
    local place2 = self:addPlace("FrontArm")
    local place3 = self:addPlace("FrontAux")

    place1:markButton("goFrontArm")
    place2:imageOn("2")
    place2:markButton("aux")
    place3:markButton("openAux")

    self:textI18n("progress_12")

    return self.progress
  end

  -- 拿NIKON U盘
  if self:nextProgress() == index or (self:getInteger("nikon") == 0) then
    local place1 = self:addPlace("Atm")

    place1:imageOff("6")
    place1:imageOff("7")
    place1:imageOn("2")
    place1:imageOn("3")
    place1:markButton("getCamera")

    self:textI18n("progress_15")

    return self.progress
  end

  -- 使用NIKON U盘
  if self:nextProgress() == index or (self:getInteger("nikon") > 0) then
    local place1 = self:addPlace("SecondLeft")
    local place2 = self:addPlace("FrontArm")
    local place3 = self:addPlace("FrontAux")

    place1:markButton("goFrontArm")
    place2:imageOn("2")
    place2:markButton("aux")
    place3:markButton("openAux")

    self:textI18n("progress_16")

    return self.progress
  end

  -- 发动车
  if self:nextProgress() == index or (self:getInteger("engine_start") < 1) then
    local place1 = self:addPlace("Drive")
    local place2 = self:addPlace("Panel")
    local place3 = self:addPlace("Key")

    place1:markButton("goKey")
    place1:markButton("goPanel")
    place2:markButton("goKey")
    place3:markButton("open")

    self:textI18n("progress_17")

    return self.progress
  end

  -- 拿iPhone充电电源
  if self:nextProgress() == index or (self:getInteger("charger") == 0) then
    local place1 = self:addPlace("Drive")
    local place2 = self:addPlace("FrontSlot")

    place1:markButton("goFrontSlot")
    place2:markButton("openTopLeft")

    self:textI18n("progress_18")

    return self.progress
  end

  -- 打开油箱开关
  if self:nextProgress() == index or (self:getInteger("tank_open") == 0 and self:getInteger("wire") == 0) then
    local place1 = self:addPlace("OutLeft")
    local place2 = self:addPlace("OutDrive")
    local place3 = self:addPlace("OutDriveUnder")

    place1:imageOn("4")
    place1:markButton("openFront")
    place2:markButton("goDriveUnder")
    place3:markButton("goOutTankSwitch")

    self:textI18n("progress_19")

    return self.progress
  end

  -- 拿iPhone充电线
  if self:nextProgress() == index or (self:getInteger("wire") == 0) then
    local place1 = self:addPlace("OutLeft")
    local place2 = self:addPlace("Tank")

    place1:markButton("closeRear")
    place2:markButton("openCover")

    self:textI18n("progress_20")

    return self.progress
  end

  -- 使用iPhone，给iPhone充电
  if self:nextProgress() == index or (self:getInteger("called") < 1) then
    local place1 = self:addPlace("SecondRight")
    local place2 = self:addPlace("FrontFloorSlot")

    place1:markButton("goFloorSlot")
    place2:imageOn("8")
    place2:markButton("openSlot1")

    self:textI18n("progress_23")

    return self.progress
  end

  return self:nextProgress()
end

return E3Tip
