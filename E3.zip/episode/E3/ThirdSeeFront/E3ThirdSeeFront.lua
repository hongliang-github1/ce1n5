local E3ThirdSeeFront = class("E3ThirdSeeFront", function()
  return BasePlace.new()
end)

function E3ThirdSeeFront:initPhoto()
  self:addPhoto("2", 960, 448)
end

function E3ThirdSeeFront:initButton()
  self:addButton("goThirdLeftSlot", 0, 740, 320, 408)
  self:addButton("goThirdRightSlot", 1690, 754, 352, 394)
  self:addButton("goThirdRightSeatBack", 1154, 538, 530, 528)
  self:addButton("goThirdLeftSeatBack", 326, 532, 536, 522)
end

function E3ThirdSeeFront:arrowUp(rect)
  self:switchPlaceZoomOut("SeeThirdFar")
end

function E3ThirdSeeFront:beforeLoad()
  self:imageOn("1")

  if self:getInteger("engine_start") > 0 then
    self:imageOn("2")
  end
end

function E3ThirdSeeFront:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3ThirdSeeFront:afterLoad2()
  self:cacheImage("ThirdLeftSlot/1")
  self:cacheImage("ThirdRightSlot/1")
end

function E3ThirdSeeFront:beforeUseItem(itemName)
  return false
end

function E3ThirdSeeFront:afterUseItem(itemName)
  return true
end

function E3ThirdSeeFront:goThirdLeftSlot(rect)
  self:switchPlaceLeft("ThirdLeftSlot")
end

function E3ThirdSeeFront:goThirdRightSlot(rect)
  self:switchPlaceRight("ThirdRightSlot")
end

function E3ThirdSeeFront:goThirdLeftSeatBack(rect)
  self:switchPlaceZoomIn("ThirdLeftSeatBack", rect)
end

function E3ThirdSeeFront:goThirdRightSeatBack(rect)
  self:switchPlaceZoomIn("ThirdRightSeatBack", rect)
end

return E3ThirdSeeFront
