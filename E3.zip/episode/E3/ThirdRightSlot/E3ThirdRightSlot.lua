local E3ThirdRightSlot = class("E3ThirdRightSlot", function()
  return BasePlace.new()
end)

function E3ThirdRightSlot:initPhoto()
  self:addPhoto("2", 960, 832)
end

function E3ThirdRightSlot:initButton()
  self:addButton("getBattery", 696, 518, 732, 560)
end

function E3ThirdRightSlot:arrowLeft(rect)
  self:switchPlaceLeft("ThirdSeeFront")
end

function E3ThirdRightSlot:beforeLoad()
  self:imageOn("1")

  if self:getInteger("battery2") == 0 then
    self:imageOn("2")
  end
end

function E3ThirdRightSlot:afterLoad()
  if self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E3ThirdRightSlot:beforeUseItem(itemName)
  return false
end

function E3ThirdRightSlot:afterUseItem(itemName)
  return true
end

function E3ThirdRightSlot:getBattery(rect)
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:getItem("battery2")
    self:sayI18n("getBattery_1")

  else
    self:sayI18n("getBattery_2")
  end
end

return E3ThirdRightSlot
