local E3PanelScreen = class("E3PanelScreen", function()
  return BasePlace.new()
end)

function E3PanelScreen:initPhoto()
  self:addPhoto("2", 384, 64)
end

function E3PanelScreen:initButton()
  self:addButton("goScreen", 368, 56, 1154, 652)
  self:addButton("num1", 388, 804, 228, 312, false)
  self:addButton("num2", 618, 806, 164, 310, false)
  self:addButton("num3", 784, 808, 168, 308, false)
  self:addButton("num4", 954, 808, 168, 308, false)
  self:addButton("num5", 1124, 808, 166, 308, false)
  self:addButton("num6", 1292, 808, 224, 308, false)
end

function E3PanelScreen:arrowDown(rect)
  self:switchPlaceZoomOut("Panel")
end

function E3PanelScreen:beforeLoad()
  self:imageOn("1")

  if self:getInteger("engine_start") > 0 then
    self:imageOn("2")
  end
end

function E3PanelScreen:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3PanelScreen:beforeUnload()
end

function E3PanelScreen:beforeUseItem(itemName)
  return false
end

function E3PanelScreen:afterUseItem(itemName)
  return true
end

function E3PanelScreen:goScreen(rect)
  if self:imageIsOn("2") then
    self:sayI18n("goScreen_1")

  else
    self:sayI18n("goScreen_2")
  end
end

return E3PanelScreen
