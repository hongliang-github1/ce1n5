local E3FrontSlot = class("E3FrontSlot", function()
  return BasePlace.new()
end)

function E3FrontSlot:initPhoto()
  self:addPhoto("2", 448, 448)
  self:addPhoto("3", 448, 448)
  self:addPhoto("4", 576, 448)
  self:addPhoto("5", 576, 704)
end

function E3FrontSlot:initButton()
  self:addButton("openTopLeft", 380, 356, 518, 362)
  self:addButton("openTopRight", 902, 358, 774, 358)
  self:addButton("openDown", 384, 720, 1288, 426)
end

function E3FrontSlot:arrowUp(rect)
  self:switchPlaceUp("Drive")
end

function E3FrontSlot:beforeLoad()
  self:imageOn("1")
end

function E3FrontSlot:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3FrontSlot:beforeUseItem(itemName)
  return false
end

function E3FrontSlot:afterUseItem(itemName)
  return true
end

function E3FrontSlot:openTopLeft(rect)
  if self:imageIsOn("2") then
    -- 拿iPhone充电器
    self:imageOn("3")
    self:imageOff("2")
    self:getItem("charger")
    self:sayI18n("openTopLeft_1")

    return
  end

  if self:imageIsOn("3") then
    -- 关上
    self:play("cup")
    self:imageOff("3")
    self:imageOff("4")
    self:imageOff("5")
    self:sayI18n("openTopLeft_2")

    return
  end

  -- 打开
  self:play("cup")
  self:imageOff("4")
  self:imageOff("5")

  if self:getInteger("charger") == 0 then
    self:imageOn("2")
    self:sayI18n("openTopLeft_3")

  else
    self:imageOn("3")
    self:sayI18n("openTopLeft_4")
  end
end

function E3FrontSlot:openTopRight(rect)
  if self:imageIsOn("4") then
    -- 关上
    self:play("cup")
    self:imageOff("2")
    self:imageOff("3")
    self:imageOff("4")
    self:imageOff("5")
    self:sayI18n("openTopRight_1")

    return
  end

  -- 打开
  self:play("cup")
  self:imageOff("2")
  self:imageOff("3")
  self:imageOn("4")
  self:imageOff("5")
  self:sayI18n("openTopRight_2")
end

function E3FrontSlot:openDown(rect)
  if self:imageIsOn("5") then
    -- 关上
    self:play("cup")
    self:imageOff("2")
    self:imageOff("3")
    self:imageOff("4")
    self:imageOff("5")
    self:sayI18n("openDown_1")

    return
  end

  -- 打开
  self:play("cup")
  self:imageOff("2")
  self:imageOff("3")
  self:imageOff("4")
  self:imageOn("5")
  self:sayI18n("openDown_2")
end

return E3FrontSlot
