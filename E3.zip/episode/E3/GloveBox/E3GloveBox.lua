local E3GloveBox = class("E3GloveBox", function()
  return BasePlace.new()
end)

function E3GloveBox:initPhoto()
  self:addPhoto("2", 0, 384)
  self:addPhoto("3", 512, 384)
end

function E3GloveBox:initButton()
  self:addButton("open", 516, 330, 836, 602)
end

function E3GloveBox:arrowDown(rect)
  self:switchPlaceZoomOut("Codrive")
end

function E3GloveBox:beforeLoad()
  self:imageOn("1")
end

function E3GloveBox:afterLoad()

end

function E3GloveBox:beforeUseItem(itemName)
  return false
end

function E3GloveBox:afterUseItem(itemName)
  return true
end

function E3GloveBox:open(rect)
  if self:imageIsOn("3") then
    -- 拿道具
    self:imageOff("3")

    return
  end

  if self:imageIsOn("2") then
    -- 关上手套箱
    self:play("glove_close")
    self:imageOff("2")
    self:sayI18n("open_2")

    return
  end

  -- 打开手套箱
  self:play("glove_open")
  self:imageOn("2")

  if self:getInteger("paper") then
    self:sayI18n("open_3")

  else
    self:imageOn("3")
    self:sayI18n("open_4")
  end
end

return E3GloveBox
