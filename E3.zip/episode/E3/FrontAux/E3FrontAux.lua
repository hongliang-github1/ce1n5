local E3FrontAux = class("E3FrontAux", function()
  return BasePlace.new()
end)

function E3FrontAux:initPhoto()
  self:addPhoto("2", 768, 384)
  self:addPhoto("3", 768, 384)
  self:addPhoto("4", 768, 256)
  self:addPhoto("5", 768, 256)
  self:addPhoto("6", 768, 256)
end

function E3FrontAux:initButton()
  self:addButton("openAux", 590, 208, 866, 800)
end

function E3FrontAux:arrowDown(rect)
  self:switchPlaceZoomOut("FrontArm")
end

function E3FrontAux:beforeLoad()
  self:imageOn("1")

  if self:getInteger("nikon") < 0 then
    self:imageOn("3")

  else
    self:imageOn("2")
  end
end

function E3FrontAux:afterLoad()
  if self:imageIsOn("3") then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")

  end
end

function E3FrontAux:beforeUseItem(itemName)
  if itemName == "nikon" then
    return self:imageIsOn("5")
  end

  return false
end

function E3FrontAux:afterUseItem(itemName)
  if itemName == "nikon" then
    -- 插入尼康u盘，atm机也不再需要了
    self:play("click")
    self:imageOn("4")
    self:imageOff("2")
    self:imageOff("5")
    self:voidItem("atm")
    self:sayI18n("afterUseItem_1")

    return false
  end

  return true
end

function E3FrontAux:openAux(rect)
  if self:imageIsOn("4") then
    if self:getInteger("engine_start") > 0 then
      self:sayI18n("openAux_1")

    else
      -- 还没着车，转到启动按钮地点
      self:switchPlace("Key")
    end

    return
  end

  if self:imageIsOn("3") then
    self:imageOn("4")
    self:imageOff("3")
    self:sayI18n("openAux_2")

    return
  end

  if self:imageIsOn("6") then
    -- 得到atm卡
    self:imageOff("6")
    self:imageOn("5")
    self:getItem("card")
    self:sayI18n("openAux_3")

    return
  end

  if self:imageIsOn("5") then
    self:sayI18n("openAux_4")

    return
  end

  -- 掀开黑色盖板
  self:play("click")
  if self:getInteger("card") == 0 then
    self:imageOn("6")
    self:sayI18n("openAux_5")

  else
    self:imageOn("5")
    self:sayI18n("openAux_6")
  end
end

return E3FrontAux
