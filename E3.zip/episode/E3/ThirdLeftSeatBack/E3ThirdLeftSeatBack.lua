local E3ThirdLeftSeatBack = class("E3ThirdLeftSeatBack", function()
  return BasePlace.new()
end)

function E3ThirdLeftSeatBack:initPhoto()
  self:addPhoto("2", 576, 384)
  self:addPhoto("3", 768, 384)
end

function E3ThirdLeftSeatBack:initButton()
  self:addButton("getItem1", 446, 180, 1092, 634)
end

function E3ThirdLeftSeatBack:arrowDown(rect)
  self:switchPlaceZoomOut("ThirdSeeFront")
end

function E3ThirdLeftSeatBack:beforeLoad()
  self:imageOn("1")
end

function E3ThirdLeftSeatBack:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3ThirdLeftSeatBack:beforeUseItem(itemName)
  return false
end

function E3ThirdLeftSeatBack:afterUseItem(itemName)
  return true
end

function E3ThirdLeftSeatBack:getItem1(rect)
  -- 没东西
  self:play("click")
  self:sayI18n("getItem_5")
end

return E3ThirdLeftSeatBack
