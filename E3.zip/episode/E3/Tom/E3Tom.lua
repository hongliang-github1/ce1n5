local E3Tom = class("E3Tom", function()
  return BasePlace.new()
end)

function E3Tom:initPhoto()
  self:addPhoto("10", 832, 192)
  self:addPhoto("2", 768, 0)
  self:addPhoto("3", 768, 0)
  self:addPhoto("4", 768, 0)
  self:addPhoto("5", 768, 192)
  self:addPhoto("6", 832, 192)
  self:addPhoto("7", 832, 192)
  self:addPhoto("8", 832, 192)
  self:addPhoto("9", 832, 192)
  self:addPhoto("m", 896, 448)
end

function E3Tom:initButton()
  self:addButton("assembly", 0, 0, 2044, 1148, false)
end

function E3Tom:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "Drive")
end

function E3Tom:beforeLoad()
  self.atmPassword = self:getString("atm_password")

  if self:getInteger("tom_ok") > 0 then
    -- 汤姆猫已经装好了
    self:imageOn("0")

  elseif self:getInteger("tom_apart") > 0 then
    -- 汤姆猫已经被拆开了，正等待装电池呢
    self:imageOn("1")
    self:imageOn("8")

  else
    self:imageOn("0")
  end
end

function E3Tom:beforeUnload()
end

function E3Tom:afterLoad()
  if self:imageIsOn("8") then
    self:sayI18n("afterLoad_1")

  else
    if self:getInteger("tom_ok") > 0 then
      self:assembly(nil)

    else
      self:sayI18n("afterLoad_2")
    end
  end
end

function E3Tom:recordLastPlaceName()
  return false
end

function E3Tom:beforeUseItem(itemName)
  if itemName == "screwdriver" then
    return self:imageIsOn("2")
  end

  if itemName == "battery1" then
    return not self.battery1Used and (self:imageIsOn("8") or self:imageIsOn("7"))
  end

  if itemName == "battery2" then
    return not self.battery2Used and (self:imageIsOn("8") or self:imageIsOn("7"))
  end

  return false
end

function E3Tom:afterUseItem(itemName)
  if itemName == "screwdriver" then
    self:imageOn("3")
    self:imageOff("2")
    self:sayI18n("afterUseItem_1")

    return true
  end

  if itemName == "battery1" or itemName == "battery2" then
    if itemName == "battery1" then
      self.battery1Used = true

    else
      self.battery2Used = true
    end

    -- 装电池
    if self:imageIsOn("8") then
      -- 先装第一节
      self:imageOn("7")
      self:imageOff("8")
      self:sayI18n("afterUseItem_2")

    else
      -- 两节都有了
      self:imageOn("6")
      self:imageOff("7")
      self:sayI18n("afterUseItem_3")
    end

    return true
  end

  return true
end

function E3Tom:assembly(rect)
  if self:getInteger("tom_ok") > 0 then
    -- 猫已经装好电池开始工作了，进入对话流程
    self:talk()

    return
  end

  if self:imageIsOn("0") then
    -- 正在看前面，转过去看猫的背面
    self:imageOff("0")
    self:imageOn("1")
    self:imageOn("2")
    self:sayI18n("assembly_1")

    return
  end

  if self:imageIsOn("2") then
    -- 正在看背面，等待使用螺丝刀，此时没有用螺丝刀而是又点击了一下，转回看正面
    self:imageOff("1")
    self:imageOff("2")
    self:imageOn("0")
    self:sayI18n("assembly_2")

    return
  end

  if self:imageIsOn("3") then
    -- 正在展示螺丝刀，把螺丝卸下
    self:imageOn("4")
    self:imageOff("3")
    self:sayI18n("assembly_3")

    return
  end

  if self:imageIsOn("4") then
    -- 正在展示螺丝刀卸下后的猫的背面，现在把猫放倒，底座露出缝隙表示已经打开
    self:imageOn("9")
    self:imageOff("4")
    self:sayI18n("assembly_4")

    return
  end

  if self:imageIsOn("9") then
    -- 彻底拆下底座，露出装电池的地方，等待装电池，标记汤姆猫已经被拆，正在等待装电池
    self:imageOn("8")
    self:imageOff("9")
    self:setInteger("tom_apart", 1)
    self:sayI18n("assembly_5")

    return
  end

  if self:imageIsOn("8") then
    -- 此时在等待装电池，玩家不使用电池而却点击屏幕，只给语言提示
    self:sayI18n("assembly_6")

    return
  end

  if self:imageIsOn("7") then
    -- 已经装入一节电池了，等待装另一节
    self:sayI18n("assembly_7")

    return
  end

  if self:imageIsOn("6") then
    -- 两节电池都放入了，此时点击屏幕需要把底座盖上
    self:imageOn("5")
    self:imageOff("6")
    self:sayI18n("assembly_8")

    return
  end

  if self:imageIsOn("5") then
    -- 猫组装完毕
    self:imageOff("5")
    self:imageOff("1")
    self:imageOn("0")
    self:setInteger("tom_ok", 1)
    self:voidItem("battery1")
    self:voidItem("battery2")
    self:voidItem("screwdriver")
    self:sayI18n("assembly_9")

    return
  end
end

function E3Tom:talk()
  local str1 = self.i18nTable["atm_password_str1"]
  local str2 = self.i18nTable["atm_password_str2"]

  self:say(str1 .. self.atmPassword .. "c" .. str2)

  self:schedule(0.15, function()
    if self:imageIsOn("m") then
      self:imageOff("m")

    else
      self:imageOn("m")
    end
  end)
end

return E3Tom
