local E3Drive = class("E3Drive", function()
  return BasePlace.new()
end)

function E3Drive:initPhoto()
end

function E3Drive:initButton()
  self:addButton("goDashboard", 638, 292, 658, 320)
  self:addButton("goKey", 1076, 616, 224, 224, false)
  self:addButton("goKnee", 644, 698, 294, 276)
  self:addButton("openDoor", 334, 494, 256, 270)
  self:addButton("goPanel", 1304, 358, 398, 538)
  self:addButton("goFrontSlot", 1308, 896, 464, 252)
end

function E3Drive:arrowLeft(rect)
  self:switchPlaceLeft("SeeDrive")
end

function E3Drive:arrowRight(rect)
  self:switchPlaceRight("Codrive")
end

function E3Drive:arrowDown(rect)
  self:switchPlaceZoomOut("SecondRight")
end

function E3Drive:beforeLoad()
  if self:getInteger("engine_start") > 0 then
    self:imageOn("2")

  else
    self:imageOn("1")
  end
end

function E3Drive:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3Drive:afterLoad2()
  self:cacheImage("SeeDrive/2")
  self:cacheImage("SecondRight/1")
end

function E3Drive:beforeUseItem(itemName)
  return false
end

function E3Drive:afterUseItem(itemName)
  return true
end

function E3Drive:goDashboard(rect)
  self:switchPlaceZoomIn("Dashboard", rect)
end

function E3Drive:goFrontSlot(rect)
  self:switchPlaceDown("FrontSlot")
end

function E3Drive:goKey(rect)
  -- 此处不直接去启动按钮视角，而是进中控视角，由中控视角统一进启动按钮视角
  self:switchPlaceZoomIn("Panel", self.buttonTable["goPanel"])
end

function E3Drive:goKnee(rect)
  self:switchPlaceZoomIn("Knee", rect)
end

function E3Drive:openDoor(rect)
  if self:getInteger("engine_start") > 0 then
    -- 开门出去
    self:play("frontdoor")
    self:setInteger("front_left_door_open", 1)
    self:switchPlaceLeft("SeeDrive")

  else
    self:play("frontdoor")
    self:sayI18n("openDoor_1")
  end
end

function E3Drive:goPanel(rect)
  self:switchPlaceZoomIn("Panel", rect)
end

return E3Drive
