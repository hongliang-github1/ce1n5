local E3SecondLeft = class("E3SecondLeft", function()
  return BasePlace.new()
end)

function E3SecondLeft:initPhoto()
end

function E3SecondLeft:initButton()
  self:addButton("goLeftSeatBack", 786, 506, 576, 568)
  self:addButton("open", 540, 554, 244, 374)
  self:addButton("goFrontArm", 1364, 770, 284, 378)
  self:addButton("goCodrive", 1368, 136, 676, 632)
end

function E3SecondLeft:arrowLeft(rect)
  self:switchPlaceLeft("SecondSeeLeft")
end

function E3SecondLeft:arrowRight(rect)
  self:switchPlaceRight("SecondRight")
end

function E3SecondLeft:beforeLoad()
  if self:getInteger("engine_start") > 0 then
    self:imageOn("2")

  else
    self:imageOn("1")
  end
end

function E3SecondLeft:afterLoad()

end

function E3SecondLeft:afterLoad2()
  self:cacheImage("SecondLeftSeatBack/1")
end

function E3SecondLeft:beforeUseItem(itemName)
  return false
end

function E3SecondLeft:afterUseItem(itemName)
  return true
end

function E3SecondLeft:goLeftSeatBack(rect)
  self:switchPlaceZoomIn("SecondLeftSeatBack", rect)
end

function E3SecondLeft:open(rect)
  if self:getInteger("engine_start") > 0 then
    -- 开门，到外面
    self:play("door")
    self:setInteger("second_left_door_open", 1)
    self:switchPlaceLeft("SecondSeeLeft")

    return
  end

  -- 门打不开
  self:play("frontdoor")
  self:sayI18n("open_1")
end

function E3SecondLeft:goFrontArm(rect)
  self:switchPlaceZoomIn("FrontArm", rect)
end

function E3SecondLeft:goCodrive(rect)
  self:switchPlaceZoomIn("Codrive", rect)
end

return E3SecondLeft
