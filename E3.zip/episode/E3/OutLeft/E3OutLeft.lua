local E3OutLeft = class("E3OutLeft", function()
  return BasePlace.new()
end)

function E3OutLeft:initPhoto()
  self:addPhoto("2", 128, 576)
  self:addPhoto("4", 384, 320)
  self:addPhoto("5", 832, 384)
end

function E3OutLeft:initButton()
  self:addButton("openFront", 642, 388, 218, 478)
  self:addButton("openRear", 864, 386, 228, 476)
  self:addButton("closeFront", 412, 340, 228, 622, false)
  self:addButton("closeRear", 1092, 386, 356, 474)
end

function E3OutLeft:arrowLeft(rect)
  self:switchPlaceLeft("OutFront")
end

function E3OutLeft:arrowRight(rect)
  self:switchPlaceRight("OutRear")
end

function E3OutLeft:beforeLoad()
  self:imageOn("1")

  if self:getInteger("engine_start") < 1 then
    self:imageOn("2")
  end

  if self.fromPlaceName == "OutDrive" then
    self:imageOn("4")

  elseif self.fromPlaceName == "SecondSeeLeft" then
    self:imageOn("5")
  end
end

function E3OutLeft:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3OutLeft:afterLoad2()
  if self:getInteger("car_locked") == 0 then
    self:cacheImage("OutDrive/1")
    self:cacheImage("SecondSeeLeft/1")
  end
end

function E3OutLeft:beforeUseItem(itemName)
  return false
end

function E3OutLeft:afterUseItem(itemName)
  return true
end

function E3OutLeft:openFront(rect)
  if self:imageIsOn("4") then
    -- 前门已经打开了，坐进去
    self:switchPlaceZoomIn("OutDrive", rect)

  else
    -- 打开前门
    self:imageOn("4")
    self:play("frontdoor")
    self:sayI18n("openFront_1")
  end
end

function E3OutLeft:openRear(rect)
  if self:imageIsOn("5") then
    -- 后门已经打开了，坐进去
    self:switchPlaceZoomIn("SecondSeeLeft", rect)

  else
    -- 打开后门
    self:imageOn("5")
    self:play("door")

    -- 如果前门也开了则要重新显示一下图片，始终让4盖在5的上面才行
    if self:imageIsOn("4") then
      self:imageOn("4")
    end

    self:sayI18n("openRear_1")
  end
end

function E3OutLeft:closeFront(rect)
  if self:imageIsOn("4") then
    self:imageOff("4")
    self:play("frontdoor")
    self:sayI18n("closeFront_1")
  end
end

function E3OutLeft:closeRear(rect)
  if self:imageIsOn("5") then
    self:imageOff("5")
    self:play("door")
    self:sayI18n("closeRear_1")

  else
    -- 去看油箱
    self:switchPlaceZoomIn("Tank", rect)
  end
end

return E3OutLeft
