local E3OutDrive = class("E3OutDrive", function()
  return BasePlace.new()
end)

function E3OutDrive:initPhoto()
end

function E3OutDrive:initButton()
  self:addButton("goDrive", 674, 0, 934, 724)
  self:addButton("goDriveUnder", 392, 726, 908, 422)
end

function E3OutDrive:arrowDown(rect)
  self:switchPlaceZoomOut("OutLeft")
end

function E3OutDrive:beforeLoad()
  self:imageOn("1")
end

function E3OutDrive:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3OutDrive:afterLoad2()
  self:cacheImage("OutDriveUnder/1")
end

function E3OutDrive:beforeUseItem(itemName)
  return false
end

function E3OutDrive:afterUseItem(itemName)
  return true
end

function E3OutDrive:goDrive(rect)
  if self:getInteger("car_locked") > 0 then
    self:switchPlaceZoomIn("Drive", rect)

  else
    -- 还没进入逃脱状态，去剧情的场景
    self:switchPlaceZoomIn("DriveDialog", rect)
  end
end

function E3OutDrive:goDriveUnder(rect)
  if self:getInteger("car_locked") > 0 then
    self:switchPlaceDown("OutDriveUnder")
  end
  
end

return E3OutDrive
