local E3SeeThirdFar = class("E3SeeThirdFar", function()
  return BasePlace.new()
end)

function E3SeeThirdFar:initPhoto()
end

function E3SeeThirdFar:initButton()
  self:addButton("goTrunk", 626, 344, 802, 250)
  self:addButton("goThird", 604, 598, 846, 474)
end

function E3SeeThirdFar:arrowLeft(rect)
  self:switchPlaceLeft("SecondSeeRight")
end

function E3SeeThirdFar:arrowRight(rect)
  self:switchPlaceRight("SecondSeeLeft")
end

function E3SeeThirdFar:beforeLoad()
  self:imageOn("1")
end

function E3SeeThirdFar:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3SeeThirdFar:afterLoad2()
  self:cacheImage("SeeThirdNear/1")
  self:cacheImage("ThirdSeeFront/1")
end

function E3SeeThirdFar:beforeUseItem(itemName)
  return false
end

function E3SeeThirdFar:afterUseItem(itemName)
  return true
end

function E3SeeThirdFar:goTrunk(rect)
  self:switchPlaceZoomIn("SeeThirdNear", rect)
end

function E3SeeThirdFar:goThird(rect)
  self:switchPlaceZoomIn("ThirdSeeFront", rect)
end

return E3SeeThirdFar
