local E3SeeThirdNear = class("E3SeeThirdNear", function()
  return BasePlace.new()
end)

function E3SeeThirdNear:initPhoto()
end

function E3SeeThirdNear:initButton()
  self:addButton("goThirdTrunk", 422, 594, 1180, 556)
end

function E3SeeThirdNear:arrowDown(rect)
  self:switchPlaceZoomOut("SeeThirdFar")
end

function E3SeeThirdNear:beforeLoad()
  self:imageOn("1")
end

function E3SeeThirdNear:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3SeeThirdNear:afterLoad2()
  self:cacheImage("ThirdSeeTrunk/1")
end

function E3SeeThirdNear:beforeUseItem(itemName)
  return false
end

function E3SeeThirdNear:afterUseItem(itemName)
  return true
end

function E3SeeThirdNear:goThirdTrunk(rect)
  self:switchPlaceDown("ThirdSeeTrunk")
end

return E3SeeThirdNear
