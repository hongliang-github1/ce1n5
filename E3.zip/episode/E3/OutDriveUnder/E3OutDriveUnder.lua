local E3OutDriveUnder = class("E3OutDriveUnder", function()
  return BasePlace.new()
end)

function E3OutDriveUnder:initPhoto()
end

function E3OutDriveUnder:initButton()
  self:addButton("goOutTankSwitch", 856, 704, 624, 444)
end

function E3OutDriveUnder:arrowUp(rect)
  self:switchPlaceUp("OutDrive")
end

function E3OutDriveUnder:beforeLoad()
  self:imageOn("1")
end

function E3OutDriveUnder:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E3OutDriveUnder:afterLoad2()
  self:cacheImage("OutTankSwitch/1")
end

function E3OutDriveUnder:beforeUseItem(itemName)
  return false
end

function E3OutDriveUnder:afterUseItem(itemName)
  return true
end

function E3OutDriveUnder:goOutTankSwitch(rect)
  self:switchPlaceZoomIn("OutTankSwitch", rect)
end

return E3OutDriveUnder
