local E6Run = class("E6Run", function()
  return BasePlace.new()
end)

function E6Run:initPhoto()
end

function E6Run:initButton()
end

function E6Run:beforeLoad()
  -- 创建Label
  local bgSize   = self:getContentSize()
  local fontSize = 75

  if self.gamingScene and self.gamingScene.labelSay then
    fontSize = math.ceil(self.gamingScene.labelSay:getFontSize() * 1.5)
  end

  label = cc.Label:createWithSystemFont(self.i18nTable["label"], "Helvetica", fontSize, cc.size(bgSize.width, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  label:setColor(cc.c4b(255, 255, 255, 255))
  label:setAnchorPoint(0.5, 0.5)
  label:setPositionX(bgSize.width / 2)
  label:setPositionY(bgSize.height - label:getContentSize().height / 2)
  self:addChild(label)

  -- 创建按钮
  local buttonRun = cc.ControlButton:create(self.i18nTable["button_run"], "Helvetica", fontSize)

  buttonRun:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  buttonRun:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  buttonRun:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  buttonRun:setAnchorPoint(0.5, 0.5)
  buttonRun:setPositionX(bgSize.width / 2)
  buttonRun:setPositionY(label:getPositionY() - label:getContentSize().height / 2 - buttonRun:getContentSize().height * 4)
  self:addChild(buttonRun)

  local buttonStay = cc.ControlButton:create(self.i18nTable["button_stay"], "Helvetica", fontSize)

  buttonStay:setTitleColorForState(cc.c3b(255, 255, 255), cc.CONTROL_STATE_NORMAL)
  buttonStay:getTitleLabel():enableGlow(cc.c4b(0, 255, 0, 255))
  buttonStay:getTitleLabel():setAlignment(cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  buttonStay:setAnchorPoint(0.5, 0.5)
  buttonStay:setPositionX(bgSize.width / 2)
  buttonStay:setPositionY(buttonRun:getPositionY() - buttonRun:getContentSize().height / 2 - buttonStay:getContentSize().height * 2)
  self:addChild(buttonStay)

  -- 控件创建完成，统一调整垂直居中
  local boxUp      = label:getPositionY() + label:getContentSize().height / 2
  local boxDown    = buttonStay:getPositionY() - buttonStay:getContentSize().height / 2
  local boxCenterY = (boxUp - boxDown) / 2
  local diff       = boxCenterY - bgSize.height / 2

  label:setPositionY(label:getPositionY() + diff)
  buttonRun:setPositionY(buttonRun:getPositionY() + diff)
  buttonStay:setPositionY(buttonStay:getPositionY() + diff)

  -- 绑定按钮事件
  buttonRun:registerControlEventHandler(function(button, eventType)
    self:goRun()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  buttonStay:registerControlEventHandler(function(button, eventType)
    self:goStay()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
end

function E6Run:recordLastPlaceName()
  return false
end

function E6Run:afterLoad()

end

function E6Run:afterLoad2()
  self:cacheImage("Gate/0")
end

function E6Run:goRun()
  -- 直接跑，根据状态来
  self:setInteger("current_bgm", 1)
  
  if self:getInteger("red_engine_start") ~= 0 then
    -- 进入开车跑剧情
    self:switchPlace("RunCar")

    return
  end

  -- 走路跑，进入失败剧情
  self:switchPlace("RunWalk")
end

function E6Run:goStay()
  self:setInteger("current_bgm", 0)
  self:playMusic("bgm")
  self:switchPlace("Gate")
end

return E6Run
