local E6MendRoomDoor = class("E6MendRoomDoor", function()
  return BasePlace.new()
end)

function E6MendRoomDoor:initPhoto()
end

function E6MendRoomDoor:initButton()
  self:addButton("goCabinet", 1120, 516, 500, 520)
  self:addButton("goDoor", 360, 82, 430, 948)
  self:addButton("microscope", 802, 300, 312, 404)
end

function E6MendRoomDoor:arrowDown(rect)
  self:switchPlaceZoomOut("SeeMendRoom")
end

function E6MendRoomDoor:beforeLoad()
  self:imageOn("0")
end

function E6MendRoomDoor:afterLoad()

end

function E6MendRoomDoor:afterLoad2()
  self:cacheImage("Toolbox/0")
  self:cacheImage("Toolbox/2")
  self:cacheImage("MendRoom/0")
  self:cacheImage("Microscope/0")
  self:cacheImage("SeeMendRoom/1")
end

function E6MendRoomDoor:beforeUseItem(itemName)
  return false
end

function E6MendRoomDoor:afterUseItem(itemName)
  return true
end

function E6MendRoomDoor:goCabinet(rect)
  self:switchPlaceZoomIn("Toolbox", rect)
end

function E6MendRoomDoor:goDoor(rect)
  self:switchPlaceZoomIn("MendRoom", cc.rect(180 * 2, 164 * 2, 214 * 2, 261 * 2))
end

function E6MendRoomDoor:microscope(rect)
  self:switchPlaceZoomIn("Microscope", rect)
end

return E6MendRoomDoor
