local E6RedFuse = class("E6RedFuse", function()
  return BasePlace.new()
end)

function E6RedFuse:initPhoto()
  self:addPhoto("1", 1280, 256)
end

function E6RedFuse:initButton()
  self:addButton("open", 0, 460, 2044, 576)
  self:addButton("goFuseNear", 1016, 94, 664, 378)
end

function E6RedFuse:arrowDown(rect)
  self:switchPlaceZoomOut("RedOutRear")
end

function E6RedFuse:beforeLoad()
  if self.lastPlaceName == "RedFuseNear" then
    self:imageOn("0")

    if self:getInteger("fuse") < 0 then
      self:imageOn("1")
    end

    return
  end

  self:imageOn("5")
end

function E6RedFuse:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E6RedFuse:afterLoad2()
  self:cacheImage("RedFuseNear/0")
  self:cacheImage("RedOutRear/0")
end

function E6RedFuse:beforeUseItem(itemName)
  return false
end

function E6RedFuse:afterUseItem(itemName)
  return true
end

function E6RedFuse:open(rect)
  if self:imageIsOn("0") then
    self:sayI18n("open_1")

    return
  end

  -- 打开
  self:imageOn("0")
  self:play("trunkcover")
  self:sayI18n("open_2")

  if self:getInteger("paper") == 0 then
    self:imageOn("2")
  end

  if self:getInteger("fuse") < 0 then
    self:imageOn("1")
  end
end

function E6RedFuse:goFuseNear(rect)
  if self:imageIsOn("0") then
    self:switchPlaceZoomIn("RedFuseNear", cc.rect(377 * 2, 35 * 2, 473 * 2, 254 * 2))
  end
end

return E6RedFuse
