local E6SeeGround = class("E6SeeGround", function()
  return BasePlace.new()
end)

function E6SeeGround:initPhoto()
end

function E6SeeGround:initButton()
end

function E6SeeGround:arrowDown(rect)
  self:switchPlaceZoomOut("SecondSofa")
end

function E6SeeGround:beforeLoad()
  self:imageOn("0")
end

function E6SeeGround:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E6SeeGround:afterLoad2()
  self:cacheImage("SecondSofa/0")
end

function E6SeeGround:beforeUseItem(itemName)
  return false
end

function E6SeeGround:afterUseItem(itemName)
  return true
end

return E6SeeGround
