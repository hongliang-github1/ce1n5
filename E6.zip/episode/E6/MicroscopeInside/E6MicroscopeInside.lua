local E6MicroscopeInside = class("E6MicroscopeInside", function()
  return BasePlace.new()
end)

function E6MicroscopeInside:initPhoto()
end

function E6MicroscopeInside:initButton()
end

function E6MicroscopeInside:arrowDown(rect)
  self:switchPlaceZoomOut("MicroscopeEye")
end

function E6MicroscopeInside:beforeLoad()
  self:imageOn("0")
end

function E6MicroscopeInside:afterLoad()
  -- 显示轮盘锁三组数字
  local fontSize = 50 * 2

  if self.gamingScene and self.gamingScene.labelSay then
    fontSize = math.ceil(self.gamingScene.labelSay:getFontSize() * 2.25)
  end

  local label1 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2 * 5, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label2 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2 * 5, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label3 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2 * 5, fontSize * 1.2), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  label1:setColor(cc.c4b(0, 0, 0, 255))
  label2:setColor(cc.c4b(0, 0, 0, 255))
  label3:setColor(cc.c4b(0, 0, 0, 255))
  label1:setAnchorPoint(0, 0)
  label2:setAnchorPoint(0, 0)
  label3:setAnchorPoint(0, 0)
  label1:setPosition(0, 0)
  label2:setPosition(0, 0)
  label3:setPosition(0, 0)

  self.label1 = label1
  self.label2 = label2
  self.label3 = label3

  self.label1:setString(self.i18nTable["table_1"] .. tostring(self:getInteger("round1")))
  self.label2:setString(self.i18nTable["table_2"] .. tostring(self:getInteger("round2")))
  self.label3:setString(self.i18nTable["table_1"] .. tostring(self:getInteger("round3")))

  self:addChild(label1)
  self:addChild(label2)
  self:addChild(label3)

  -- 计算四个label的位置，居中为准，分别向两边延伸
  local bgSize    = self:getContentSize()
  local labelSize = label1:getContentSize()
  local x         = bgSize.width / 2 - labelSize.width / 2
  local y         = bgSize.height / 2 - labelSize.height / 2

  label1:setPosition(x, y + 200)
  label2:setPosition(x, y)
  label3:setPosition(x, y - 200)

  self:sayI18n("afterLoad_1")
end

function E6MicroscopeInside:afterLoad2()
  self:cacheImage("MicroscopeEye/1")
end

function E6MicroscopeInside:beforeUnload()
  self.label1:setVisible(false)
  self.label2:setVisible(false)
  self.label3:setVisible(false)
end

function E6MicroscopeInside:beforeUseItem(itemName)
  return false
end

function E6MicroscopeInside:afterUseItem(itemName)
  return true
end

return E6MicroscopeInside
