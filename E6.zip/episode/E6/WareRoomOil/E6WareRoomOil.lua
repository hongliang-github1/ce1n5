local E6WareRoomOil = class("E6WareRoomOil", function()
  return BasePlace.new()
end)

function E6WareRoomOil:initPhoto()
  self:addPhoto("1", 640, 0)
end

function E6WareRoomOil:initButton()
  self:addButton("getOil", 492, 0, 866, 1148)
end

function E6WareRoomOil:arrowDown(rect)
  self:switchPlaceZoomOut("WareRoomRight")
end

function E6WareRoomOil:beforeLoad()
  self:imageOn("0")

  if self:getInteger("oil") == 0 then
    self:imageOn("1")
  end
end

function E6WareRoomOil:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E6WareRoomOil:afterLoad2()
  self:cacheImage("WareRoomRight/0")
end

function E6WareRoomOil:beforeUseItem(itemName)
  return false
end

function E6WareRoomOil:afterUseItem(itemName)
  return true
end

function E6WareRoomOil:getOil(rect)
  if self:getInteger("oil") == 0 then
    self:imageOff("1")
    self:getItem("oil")
    self:sayI18n("getOil_1")

  else
    self:sayI18n("getOil_2")
  end
end

return E6WareRoomOil
