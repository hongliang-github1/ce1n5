local E6Beginning = class("E6Beginning", function()
  return BasePlace.new()
end)

function E6Beginning:initPhoto()
end

function E6Beginning:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E6Beginning:beforeLoad()
  if userdata.getEpisodeLastPlace(userdata.currentEpisode) == "" then
    local p1 = math.random(39)
    local p2 = math.random(20) - 1
    local p3 = math.random(40) - 1

    if p1 <= 19 then
      p2 = p2 + 20

      if p3 > 19 then
        p3 = p3 - 20
      end

    elseif p3 <= 19 then
      p3 = p3 + 20
    end

    self:setInteger("round1", p1)
    self:setInteger("round2", p2)
    self:setInteger("round3", p3)
  end

  self:imageOn("SeeRedCar/0")
end

function E6Beginning:afterLoad()
  self:click(nil)
end

function E6Beginning:afterLoad2()
  self:cacheImage("SeeRedCar/0")
end

function E6Beginning:beforeUseItem(itemName)
  return false
end

function E6Beginning:afterUseItem(itemName)
  return true
end

function E6Beginning:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    progress = 0

    self:switchPlace("SeeRedCar")

    return
  end
end

return E6Beginning
  
