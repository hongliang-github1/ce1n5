local E6OilShelf = class("E6OilShelf", function()
  return BasePlace.new()
end)

function E6OilShelf:initPhoto()
end

function E6OilShelf:initButton()
  self:addButton("getEngineOil", 668, 228, 518, 534)
end

function E6OilShelf:arrowDown(rect)
  self:switchPlaceZoomOut("SeeMendRoom")
end

function E6OilShelf:beforeLoad()
  self:imageOn("1")
end

function E6OilShelf:afterLoad()

end

function E6OilShelf:afterLoad2()
  self:cacheImage("SeeMendRoom/1")
end

function E6OilShelf:beforeUseItem(itemName)
  return false
end

function E6OilShelf:afterUseItem(itemName)
  return true
end

function E6OilShelf:getEngineOil(rect)
  self:sayI18n("getEngineOil_1")
end

return E6OilShelf
