local E6RedFuseNear = class("E6RedFuseNear", function()
  return BasePlace.new()
end)

function E6RedFuseNear:initPhoto()
  self:addPhoto("1", 1216, 384)
end

function E6RedFuseNear:initButton()
  self:addButton("getFusepaper", 930, 0, 1114, 648)
end

function E6RedFuseNear:arrowDown(rect)
  self:switchPlaceZoomOut("RedFuse")
end

function E6RedFuseNear:beforeLoad()
  self:imageOn("0")

  if self:getInteger("fuse") < 0 then
    self:imageOn("1")
  end
end

function E6RedFuseNear:afterLoad()
  if self:getInteger("fuse") < 0 then
    self:sayI18n("afterLoad_1")

    return
  end

  self:sayI18n("afterLoad_2")
end

function E6RedFuseNear:afterLoad2()
  self:cacheImage("RedFuse/0")
end

function E6RedFuseNear:beforeUseItem(itemName)
  if itemName == "fuse" then
    return true
  end

  return false
end

function E6RedFuseNear:afterUseItem(itemName)
  if itemName == "fuse" then
    -- if self:getInteger("tip_fuse") == 0 then
    --   self:sayI18n("afterUseItem_2")

    --   return true
    -- end

    self:imageOn("1")
    self:play("item")
    self:sayI18n("afterUseItem_3")

    return false
  end

  return true
end

function E6RedFuseNear:getFusepaper(rect)
  -- 判断保险丝是否插上
  if self:getInteger("fuse") < 0 then
    self:sayI18n("getFusepaper_1")

    return
  end

  -- 还没去蓝车那边对照过
  -- if self:getInteger("fuse") == 0 then
  self:sayI18n("getFusepaper_4")

  --   return
  -- end
end

return E6RedFuseNear
