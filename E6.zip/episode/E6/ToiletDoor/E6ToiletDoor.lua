local E6ToiletDoor = class("E6ToiletDoor", function()
  return BasePlace.new()
end)

function E6ToiletDoor:initPhoto()
  self:addPhoto("1", 512, 0)
end

function E6ToiletDoor:initButton()
  self:addButton("openDoor", 626, 0, 800, 1148)
end

function E6ToiletDoor:arrowDown(rect)
  self:switchPlaceZoomOut("SeeMendRoom")
end

function E6ToiletDoor:beforeLoad()
  self:imageOn("0")

  self:imageOn("1")
end

function E6ToiletDoor:afterLoad()

end

function E6ToiletDoor:afterLoad2()
  self:cacheImage("ToiletInside/0")
  self:cacheImage("SeeMendRoom/1")
end

function E6ToiletDoor:beforeUseItem(itemName)
  return false
end

function E6ToiletDoor:afterUseItem(itemName)
  return true
end

function E6ToiletDoor:openDoor(rect)
  self:switchPlaceZoomIn("ToiletInside", cc.rect(620, 250, 800, 700))
end

return E6ToiletDoor
