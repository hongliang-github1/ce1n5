local E6RedShieldRight = class("E6RedShieldRight", function()
  return BasePlace.new()
end)

function E6RedShieldRight:initPhoto()
  self:addPhoto("2", 704, 0)
end

function E6RedShieldRight:initButton()
  self:addButton("getKey", 402, 0, 992, 562)
end

function E6RedShieldRight:arrowLeft(rect)
  self:switchPlaceZoomOut("RedDrive")
end

function E6RedShieldRight:beforeLoad()
  self:imageOn("0")
end

function E6RedShieldRight:afterLoad()

end

function E6RedShieldRight:afterLoad2()
  if self:getInteger("red_engine_on") > 0 then
    self:cacheImage("RedDrive/1")
  
  else  
    self:cacheImage("RedDrive/0")
  end
end

function E6RedShieldRight:beforeUseItem(itemName)
  return false
end

function E6RedShieldRight:afterUseItem(itemName)
  return true
end

function E6RedShieldRight:getKey(rect)
  if self:imageIsOn("1") then
    if self:getInteger("wareroomkey") ~= 0 then
      self:imageOff("1")
      self:sayI18n("getKey_1")

      return
    end

    self:imageOff("2")
    self:getItem("wareroomkey")
    self:sayI18n("getKey_2")

    return
  end

  -- 打开遮阳板
  self:imageOn("1")

  if self:getInteger("wareroomkey") == 0 then
    self:imageOn("2")
    self:sayI18n("getKey_3")

    return
  end

  self:sayI18n("getKey_4")
end

return E6RedShieldRight
