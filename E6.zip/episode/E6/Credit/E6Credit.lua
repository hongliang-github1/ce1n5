local E6Credit = class("E6Credit", function()
  return BaseCredit.new()
end)

function E6Credit:afterCreate()
  -- 构造滚动字幕
  self:addLabelI18n(1.1, "beforeLoad_2")

  -- 显示通关时间
  -- NSString *timingString  = [self timingString]
  -- NSString *labelStr    = UikitEnhancement:textByI18nDict("beforeLoad_3")

  -- self:addLabelI18n(1, [labelStr stringByAppendingFormat:"%@", timingString)]

  self:addLabelI18n(1, "beforeLoad_4")

  self:addBlank()

  self:addLabelI18n(1, "beforeLoad_5")

  -- self:imageViewWithImageName("ce4b_Ending_1")
  self:addImage("Ending/1")

  self:addBlank()

  self:addLabelI18n(1, "beforeLoad_6")
  self:addLabelI18n(1, "beforeLoad_7")

  self:addLabelI18n(1, "beforeLoad_8")

  self:addLabelI18n(1, "beforeLoad_9")

  self:addLabelI18n(1, "beforeLoad_10")

  self:addLabelI18n(1, "beforeLoad_11")

  self:addLabelI18n(1, "beforeLoad_12")

  self:addLabelI18n(1, "beforeLoad_13")

  self:addLabelI18n(1, "beforeLoad_14")

  self:addLabelI18n(1, "beforeLoad_15")

  self:addLabelI18n(1, "beforeLoad_16")

  self:addLabelI18n(1, "beforeLoad_17")

  self:addLabelI18n(1, "beforeLoad_18")

  self:addLabelI18n(1, "beforeLoad_19")


  self:addLabelI18n(1, "beforeLoad_20")

  -- if (allClearTwice
  --   && (
  --     ["chs" isEqualToString:[BaseAppDelegate baseAppDelegate].language]
  --     || ["cht" isEqualToString:[BaseAppDelegate baseAppDelegate].language]
  --     )
  -- ) {
  --   self:musicPlay("bgem_hzgg")

  -- else
  -- self:musicPlay("bgem_ce4b")
  self:addBlank()
  
  self:playMusic("credit")
  -- end
end

return E6Credit
