local E6RedHoodSwitch = class("E6RedHoodSwitch", function()
  return BasePlace.new()
end)

function E6RedHoodSwitch:initPhoto()
  self:addPhoto("1", 320, 256)
end

function E6RedHoodSwitch:initButton()
  self:addButton("pull", 98, 130, 660, 872)
end

function E6RedHoodSwitch:arrowDown(rect)
  self:switchPlaceZoomOut("RedOutLeft")
end

function E6RedHoodSwitch:beforeLoad()
  self:imageOn("0")
end

function E6RedHoodSwitch:afterLoad()
  self:sayI18n("afterLoad_1")
  self.progress = 0
end

function E6RedHoodSwitch:afterLoad2()
  self:cacheImage("RedOutLeft/1")
end

function E6RedHoodSwitch:beforeUseItem(itemName)
  return false
end

function E6RedHoodSwitch:afterUseItem(itemName)
  return true
end

function E6RedHoodSwitch:pull(rect)
  if self:getInteger("hood_switch_pull") > 1 then
    self:sayI18n("pull_1")

    return
  end

  if self:getInteger("hood_switch_pull") == 0 then
    self:imageOn("1")
    self:play("hoodswitch1")
    self:sayI18n("pull_2")

    self:setInteger("hood_switch_pull", self:getInteger("hood_switch_pull") + 1)
    self:disableTouch()
    self:scheduleOnce(0.3, function()
      self:switchImage()
    end)
    
    -- NSTimer:scheduledTimerWithTimeInterval(0.3 target:self selector:@selector(switchImage) userInfo:nil repeats:false)

  elseif self:getInteger("hood_switch_pull") == 1 then
    if self.progress == 0 then
      self.progress = self.progress + 1
      self:sayI18n("pull_3")

    elseif self.progress == 1 then
      self.progress = self.progress + 1
      self:sayI18n("pull_4")

    else
      self:imageOn("1")
      self:play("hoodswitch1")
      self:sayI18n("pull_5")

      self:setInteger("hood_switch_pull", self:getInteger("hood_switch_pull") + 1)
      self:disableTouch()
      self:scheduleOnce(0.3, function()
        self:switchImage()
      end)
    end
  end
end

function E6RedHoodSwitch:switchImage()
  self:imageOff("1")
  self:enableTouch()
end

return E6RedHoodSwitch
