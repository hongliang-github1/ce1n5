local E6SeeMendRoom = class("E6SeeMendRoom", function()
  return BasePlace.new()
end)

function E6SeeMendRoom:initPhoto()
end

function E6SeeMendRoom:initButton()
  self:addButton("goMendRoom", 492, 120, 612, 660)
  self:addButton("goToilet", 1300, 124, 302, 652)
  self:addButton("goShelf", 114, 228, 356, 674)
end

function E6SeeMendRoom:arrowLeft(rect)
  -- if ["ce4" isEqualToString:self.userData.currentChapter] then
  --   self:switchPlace("Ce4EnemyBack")

  --   return
  -- end

  self:switchPlaceLeft("SeeOffice")
end

function E6SeeMendRoom:arrowDown(rect)
  self:switchPlaceZoomOut("SeeRedCar")
end

function E6SeeMendRoom:beforeLoad()
  self:imageOn("1")
end

function E6SeeMendRoom:afterLoad()
end

function E6SeeMendRoom:afterLoad2()
  self:cacheImage("MendRoomDoor/0")
  self:cacheImage("ToiletDoor/0")
  self:cacheImage("SeeOffice/0")
  self:cacheImage("SeeRedCar/0")
end

function E6SeeMendRoom:beforeUseItem(itemName)
  return false
end

function E6SeeMendRoom:afterUseItem(itemName)
  return true
end

function E6SeeMendRoom:goMendRoom(rect)
  self:switchPlaceZoomIn("MendRoomDoor", rect)
end

function E6SeeMendRoom:goToilet(rect)
  self:switchPlaceZoomIn("ToiletDoor", rect)
end

function E6SeeMendRoom:goShelf(rect)
  self:switchPlaceZoomIn("OilShelf", rect)
end

return E6SeeMendRoom
