local E6RobotLock = class("E6RobotLock", function()
  return BasePlace.new()
end)

function E6RobotLock:initPhoto()
  self:addPhoto("1", 576, 256)
end

function E6RobotLock:initButton()
  self:addButton("getKey", 430, 180, 590, 502)
end

function E6RobotLock:arrowRight(rect)
  self:switchPlaceRight("Robot")
end

function E6RobotLock:beforeLoad()
  self:imageOn("0")

  if self:getInteger("officekey") == 0 then
    self:imageOn("1")
  end
end

function E6RobotLock:afterLoad()

end

function E6RobotLock:afterLoad2()
  self:cacheImage("Robot/0")
  self:cacheImage("RobotLockNear/0")
end

function E6RobotLock:beforeUseItem(itemName)
  return false
end

function E6RobotLock:afterUseItem(itemName)
  return true
end

function E6RobotLock:getKey(rect)
  if self:getInteger("officekey") == 0 then
    self:switchPlaceZoomIn("RobotLockNear", rect)

  else
    self:sayI18n("getKey_1")
  end
end

return E6RobotLock
