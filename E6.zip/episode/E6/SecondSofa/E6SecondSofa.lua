local E6SecondSofa = class("E6SecondSofa", function()
  return BasePlace.new()
end)

function E6SecondSofa:initPhoto()
end

function E6SecondSofa:initButton()
  self:addButton("lookRed", 346, 146, 800, 834)
end

function E6SecondSofa:arrowRight(rect)
  self:switchPlaceRight("SecondFloor")
end

function E6SecondSofa:beforeLoad()
  self:imageOn("0")
end

function E6SecondSofa:afterLoad()

end

function E6SecondSofa:afterLoad2()
  self:cacheImage("SeeGround/0")
  self:cacheImage("SecondFloor/0")
end

function E6SecondSofa:beforeUseItem(itemName)
  return false
end

function E6SecondSofa:afterUseItem(itemName)
  return true
end

function E6SecondSofa:lookRed(rect)
  self:switchPlaceZoomIn("SeeGround", cc.rect(244 * 2, 193 * 2, 258 * 2, 221 * 2))
end

return E6SecondSofa
