local E6BlackRoom = class("E6BlackRoom", function()
  return BasePlace.new()
end)

function E6BlackRoom:initPhoto()
end

function E6BlackRoom:initButton()
  self:addButton("goRoom", 1206, 672, 482, 396)
end

function E6BlackRoom:arrowRight(rect)
  self:switchPlaceZoomOut("SecondFloor")
end

function E6BlackRoom:beforeLoad()
  self:imageOn("0")
end

function E6BlackRoom:afterLoad()
  self:play("hulu")
  self:sayI18n("afterLoad_1")
end

function E6BlackRoom:afterLoad2()
  self:cacheImage("SecondFloor/0")
end

function E6BlackRoom:beforeUseItem(itemName)
  return false
end

function E6BlackRoom:afterUseItem(itemName)
  return true
end

function E6BlackRoom:goRoom(rect)
  self:stopAllEffects()
  self:play("hulu")
  self:sayI18n("goRoom_1")
end

return E6BlackRoom
