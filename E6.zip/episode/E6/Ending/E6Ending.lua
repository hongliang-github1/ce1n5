local E6Ending = class("E6Ending", function()
  return BasePlace.new()
end)

function E6Ending:initPhoto()
end

function E6Ending:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E6Ending:beforeLoad()
  self:imageOn("0")
end

function E6Ending:afterLoad()
  self:click(nil)
end

function E6Ending:afterLoad2()
end

function E6Ending:beforeUseItem(itemName)
  return false
end

function E6Ending:afterUseItem(itemName)
  return true
end

function E6Ending:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  -- if progress == self:nextProgressIndex() then
  --   self:imageOn("ce4_Beginning_enemy")
  --   self:sayI18n("click_3")

  --   return
  -- end

  -- if progress == self:nextProgressIndex() then
  --   self:sayI18n("click_4")

  --   return
  -- end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_5")

    return
  end

  if progress == self:nextProgressIndex() then
    -- self:imageOn("0")
    self:sayI18n("click_6")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 黑屏动画
    self:effectFadeBlack(nil, 1.5, 0, 0, function()
      userdata.setEpisodePassed(self.episodeName)

      -- 大门钥匙这里禁用
      self:voidItem("gatekey")

      -- TODO 设置通关时间

      -- TODO 进入通关字幕CreditScene
      cc.Director:getInstance():replaceScene(BaseScene.create("CreditScene"))

      -- 保留黑屏状态
      return true
    end)

    return
  end
end

return E6Ending
