local E6RedOutRight = class("E6RedOutRight", function()
  return BasePlace.new()
end)

function E6RedOutRight:initPhoto()
  self:addPhoto("1", 384, 128)
  self:addPhoto("2", 832, 128)
  self:addPhoto("3", 832, 128)
end

function E6RedOutRight:initButton()
  self:addButton("openFront", 876, 104, 466, 618)
  self:addButton("openRear", 398, 104, 472, 618)
end

function E6RedOutRight:arrowLeft(rect)
  self:switchPlaceLeft("RedOutRear")
end

function E6RedOutRight:arrowRight(rect)
  self:switchPlaceRight("RedOutFront")
end

function E6RedOutRight:beforeLoad()
  self:imageOn("0")
end

function E6RedOutRight:afterLoad()

end

function E6RedOutRight:afterLoad2()
  self:cacheImage("RedOutRear/0")
  self:cacheImage("RedOutFront/1")
end

function E6RedOutRight:beforeUseItem(itemName)
  return false
end

function E6RedOutRight:afterUseItem(itemName)
  return true
end

function E6RedOutRight:openFront(rect)
  if self:getInteger("redkey") >= 0 then
    self:sayI18n("openFront_1")

    return
  end

  -- 前门开着的情况，进行关前门
  if self:imageIsOn("2") or self:imageIsOn("3") then
    -- 如果后门是开着的
    if self:imageIsOn("1") then
      self:imageOff("2")

    else
      self:imageOff("3")
    end

    self:play("cardoorclose")
    self:sayI18n("openFront_2")

    return
  end

  -- 执行开前门的操作
  if self:imageIsOn("1") then
    self:imageOn("2")

  else
    self:imageOn("3")
  end

  self:play("cardooropen")
  self:sayI18n("openFront_3")
end

function E6RedOutRight:openRear(rect)
  if self:getInteger("redkey") >= 0 then
    self:sayI18n("openRear_1")

    return
  end

  -- 后门开着的，执行关后门的操作
  if self:imageIsOn("1") then
    if self:imageIsOn("2") then
      self:imageOn("3")
      self:imageOff("2")
    end

    self:imageOff("1")
    self:play("cardoorclose")
    self:sayI18n("openRear_2")

    return
  end

  -- 执行打开后门的操作
  self:imageOn("1")
  self:play("cardooropen")
  self:sayI18n("openRear_3")

  if self:imageIsOn("3") then
    self:imageOn("2")
    self:imageOff("3")
  end
end

return E6RedOutRight
