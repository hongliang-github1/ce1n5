local E6RobotLockNear = class("E6RobotLockNear", function()
  return BasePlace.new()
end)

function E6RobotLockNear:initPhoto()
  self:addPhoto("1", 704, 0)
  self:addPhoto("2", 512, 0)
end

function E6RobotLockNear:initButton()
  self:addButton("getKey", 442, 0, 1108, 1148)
end

function E6RobotLockNear:arrowDown(rect)
  self:switchPlaceZoomOut("RobotLock")
end

function E6RobotLockNear:beforeLoad()
  self:imageOn("0")

  local roundUnlock = self:getInteger("round_unlock")
  local officekey   = self:getInteger("officekey")

  if officekey == 0 then
    if roundUnlock ~= 0 then
      self:imageOn("1")

    else
      self:imageOn("2")
    end
  end
end

function E6RobotLockNear:afterLoad()
  local roundUnlock = self:getInteger("round_unlock")
  local officekey   = self:getInteger("officekey")

  if officekey == 0 then
    if roundUnlock ~= 0 then
      self:sayI18n("afterLoad_1")

    else
      self:sayI18n("afterLoad_2")
    end
  end
end

function E6RobotLockNear:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("2")
  self:cacheImage("RoundLock/0")
  self:cacheImage("RobotLock/0")
end

function E6RobotLockNear:beforeUseItem(itemName)
  return false
end

function E6RobotLockNear:afterUseItem(itemName)
  return true
end

function E6RobotLockNear:getKey(rect)
  local roundUnlock = self:getInteger("round_unlock")
  local officekey   = self:getInteger("officekey")

  if officekey == 0 then
    if roundUnlock ~= 0 then
      self:sayI18n("getKey_1")

      self:imageOff("1")
      self:getItem("officekey")

    else
      -- 进入轮盘锁视角
      self:switchPlaceZoomIn("RoundLock", cc.rect(256 * 2, 140 * 2, 310 * 2, 277 *2))
    end

  else
    self:sayI18n("getKey_2")
  end
end

return E6RobotLockNear
