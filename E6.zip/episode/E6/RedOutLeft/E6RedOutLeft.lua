local E6RedOutLeft = class("E6RedOutLeft", function()
  return BasePlace.new()
end)

function E6RedOutLeft:initPhoto()
  self:addPhoto("2", 448, 128)
  self:addPhoto("3", 448, 128)
  self:addPhoto("4", 896, 128)
  self:addPhoto("5", 896, 128)
  self:addPhoto("6", 704, 256)
end

function E6RedOutLeft:initButton()
  self:addButton("openFront", 676, 162, 358, 566)
  self:addButton("goHoodSwitch", 442, 160, 234, 568, false)
  self:addButton("openRear", 1034, 160, 466, 566)
end

function E6RedOutLeft:arrowLeft(rect)
  self:switchPlaceLeft("RedOutFront")
end

function E6RedOutLeft:arrowRight(rect)
  self:switchPlaceRight("RedOutRear")
end

function E6RedOutLeft:beforeLoad()
  self:imageOn("1")

  -- 如果是从里面出来的，把门打开
  if self.lastPlaceName == "RedDrive" or self.lastPlaceName == "RedHoodSwitch" then
    if self:getInteger("red_engine_on") > 0 then
      self:imageOn("2")

      return
    end

    self:imageOn("3")

    return
  end

  if self:getInteger("red_engine_on") > 0 then
    self:imageOn("6")
  end
end

function E6RedOutLeft:afterLoad()

end

function E6RedOutLeft:afterLoad2()
  if self:getInteger("red_engine_on") > 0 then
    self:cacheImage("RedDrive/1")
  
  else  
    self:cacheImage("RedDrive/0")
  end
  
  self:cacheImage("RedHoodSwitch/0")
  self:cacheImage("RedOutFront/1")
  self:cacheImage("RedOutRear/0")
end

function E6RedOutLeft:beforeUseItem(itemName)
  if itemName == "redkey" then
    return true
  end

  return false
end

function E6RedOutLeft:afterUseItem(itemName)
  if itemName == "redkey" then
    -- 使用了钥匙之后，打开车门
    self:imageOn("3")
    self:play("cardooropen")
    self:sayI18n("afterUseItem_1")

    return false
  end

  return true
end

function E6RedOutLeft:openFront(rect)
  if self:getInteger("redkey") >= 0 then
    self:sayI18n("openFront_1")

    return
  end

  -- 这里判断，当前门是打开的还是关着的，如果门是关的，就打开，如果打开了就进入驾驶室
  if self:imageIsOn("2") or self:imageIsOn("3") then
    self:switchPlaceZoomIn("RedDrive", cc.rect(358 * 2, 112 * 2, 164 * 2, 164 * 2))

    return
  end

  -- 开门
  if self:getInteger("red_engine_on") > 0 then
    self:imageOn("2")

  else
    self:imageOn("3")
  end

  self:play("cardooropen")
  self:sayI18n("openFront_2")

  -- 这里需要判断，如果后门也开这，切换的图是两个门都打开的，否则，切换前门打开的图
  if self:imageIsOn("4") then
    self:imageOn("5")
    self:imageOff("4")
  end
end

function E6RedOutLeft:goHoodSwitch(rect)
  -- 直接去开门的界面
  self:openFront(rect)
  -- if self:imageIsOn("2") or self:imageIsOn("3") then
  --   self:switchPlaceZoomIn("RedHoodSwitch", rect)
  -- end
end

function E6RedOutLeft:openRear(rect)
  if self:getInteger("redkey") >= 0 then
    self:sayI18n("openRear_1")

    return
  end

  -- 关车门操作
  if self:imageIsOn("4") or self:imageIsOn("5") then
    if self:imageIsOn("4") then
      self:imageOff("4")
    end

    if self:imageIsOn("5") then
      self:imageOff("5")
    end

    self:play("cardoorclose")
    self:sayI18n("openRear_2")

    return
  end

  -- 开车门操作
  self:play("cardooropen")
  self:sayI18n("openRear_3")

  -- 如果前门开着的情况
  if self:imageIsOn("2") or self:imageIsOn("3") then
    self:imageOn("5")

    return
  end

  self:imageOn("4")
end

return E6RedOutLeft
