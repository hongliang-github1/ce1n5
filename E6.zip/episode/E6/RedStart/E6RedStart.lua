local E6RedStart = class("E6RedStart", function()
  return BasePlace.new()
end)

function E6RedStart:initPhoto()
end

function E6RedStart:initButton()
  self:addButton("start", 592, 0, 890, 858)
end

function E6RedStart:arrowDown(rect)
  self:switchPlaceZoomOut("RedDrive")
end

function E6RedStart:beforeLoad()
  self:imageOn("0")
end

function E6RedStart:afterLoad()

end

function E6RedStart:afterLoad2()
  if self:getInteger("red_engine_on") > 0 then
    self:cacheImage("RedDrive/1")
  
  else  
    self:cacheImage("RedDrive/0")
  end
end

function E6RedStart:beforeUseItem(itemName)
  return false
end

function E6RedStart:afterUseItem(itemName)
  return true
end

function E6RedStart:start(rect)
  if self:getInteger("red_engine_start") > 0 then
    self:sayI18n("start_1")

    return
  end

  -- 车通电、机油已加是汽车发动的二大条件
  self:disableTouch()
  self:hideArrowButton()
  self:play("button1")

  if self:getInteger("red_engine_on") < 1 then
    -- 车没通电，转到仪表视角处理
    self.name = "RedDashboard"

    self:scheduleOnce(0.5, function()
      self:go()
    end)

    return
  end

  if self:getInteger("oil") >= 0 then
    -- 机油还没加，转到机油不足视角
    self.name = "IdriveOil"

    self:scheduleOnce(0.5, function()
      self:go()
    end)

    return
  end
  
  -- 全部调节满足，可以发动，转到仪表视角处理
  self.name = "RedDashboard"
  
  self:scheduleOnce(0.5, function()
    self:go()
  end)
end

function E6RedStart:go()
  self:enableTouch()
  self:switchPlace(self.name)
end

return E6RedStart
