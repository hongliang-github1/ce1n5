local E6WareRoomDoor = class("E6WareRoomDoor", function()
  return BasePlace.new()
end)

function E6WareRoomDoor:initPhoto()
  self:addPhoto("1", 704, 0)
end

function E6WareRoomDoor:initButton()
  self:addButton("open", 744, 0, 712, 1148)
end

function E6WareRoomDoor:arrowDown(rect)
  self:switchPlaceZoomOut("SecondFloor")
end

function E6WareRoomDoor:beforeLoad()
  self:imageOn("0")
end

function E6WareRoomDoor:afterLoad()
  if "SecondFloor" == self.lastPlaceName then
    self:sayI18n("afterLoad_1")
  end
end

function E6WareRoomDoor:afterLoad2()
  if self:getInteger("wareroomkey") ~= 1 then
    self:cacheImage("WareRoomLeft/0")
  end

  self:cacheImage("SecondFloor/0")
end

function E6WareRoomDoor:beforeUseItem(itemName)
  if "wareroomkey" == itemName then
    return not self:imageIsOn("1")
  end

  return false
end

function E6WareRoomDoor:afterUseItem(itemName)
  if "wareroomkey" == itemName then
    self:imageOn("1")
    self:play("doorkey")
    self:sayI18n("afterUseItem_1")

    return false
  end

  return true
end

function E6WareRoomDoor:open(rect)
  local itemWareroomkey = self:getInteger("wareroomkey")
  local opened          = self:imageIsOn("1")

  if opened and itemWareroomkey < 0 then
    self:switchPlaceZoomIn("WareRoomLeft", cc.rect(760, 300, 660, 660))

    return
  end

  if itemWareroomkey < 0 then
    self:imageOn("1")
    self:play("zhiniu")
    self:sayI18n("open_1")

    return
  end

  self:play("trydoor")
  self:sayI18n("open_2")
end

return E6WareRoomDoor
