local E6RedOutFront = class("E6RedOutFront", function()
  return BasePlace.new()
end)

function E6RedOutFront:initPhoto()
end

function E6RedOutFront:initButton()
  self:addButton("openCarFront", 510, 80, 980, 778)
end

function E6RedOutFront:arrowLeft(rect)
  self:switchPlaceLeft("RedOutRight")
end

function E6RedOutFront:arrowRight(rect)
  self:switchPlaceRight("RedOutLeft")
end

function E6RedOutFront:arrowDown(rect)
  self:switchPlaceZoomOut("SeeRedCar")
end

function E6RedOutFront:beforeLoad()
  self:imageOn("1")

  if self.lastPlaceName == "RedHood" then
    self:imageOn("2")
  end
end

function E6RedOutFront:afterLoad()

end

function E6RedOutFront:afterLoad2()
  self:cacheImage("RedOutRight/0")
  self:cacheImage("RedOutLeft/1")
  self:cacheImage("RedHood/0")
  self:cacheImage("SeeRedCar/0")
end

function E6RedOutFront:beforeUseItem(itemName)
  return false
end

function E6RedOutFront:afterUseItem(itemName)
  return true
end

function E6RedOutFront:openCarFront(rect)
  if self:imageIsOn("2") then
    self:switchPlaceZoomIn("RedHood", rect)

    return
  end

  self:imageOn("2")
  self:play("hoodup")
  self:sayI18n("openCarFront_3")
end

return E6RedOutFront
