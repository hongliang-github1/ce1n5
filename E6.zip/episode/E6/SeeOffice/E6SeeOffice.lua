local E6SeeOffice = class("E6SeeOffice", function()
  return BasePlace.new()
end)

function E6SeeOffice:initPhoto()
end

function E6SeeOffice:initButton()
  self:addButton("goTV", 376, 482, 556, 536)
  self:addButton("goLeft", 0, 0, 372, 1148)
  self:addButton("goStairs", 678, 0, 1364, 364)
  self:addButton("goStairs2", 1648, 368, 396, 420, false)

end

function E6SeeOffice:arrowRight(rect)
  self:switchPlaceRight("SeeMendRoom")
end

function E6SeeOffice:arrowDown(rect)
  self:switchPlaceZoomOut("SeeRedCar")
end

function E6SeeOffice:beforeLoad()
  self:imageOn("0")
end

function E6SeeOffice:afterLoad()

end

function E6SeeOffice:afterLoad2()
  self:cacheImage("Robot/0")
  self:cacheImage("OfficeDoor/0")
  self:cacheImage("SeeRedCar/0")
  self:cacheImage("SeeMendRoom/1")
end

function E6SeeOffice:beforeUseItem(itemName)
  return false
end

function E6SeeOffice:afterUseItem(itemName)
  return true
end

function E6SeeOffice:goTV(rect)
  self:switchPlaceZoomIn("Robot", rect)
end

function E6SeeOffice:goLeft(rect)  
  self:switchPlaceZoomIn("OfficeDoor", cc.rect(0, 340, 360, 600))
end

function E6SeeOffice:goStairs(rect)
  self:switchPlaceZoomIn("SeeStair", rect)
end

function E6SeeOffice:goStairs2(rect)
  self:goStairs(self.buttonTable["goStairs"])
end

return E6SeeOffice
