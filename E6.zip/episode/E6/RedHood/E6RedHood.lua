local E6RedHood = class("E6RedHood", function()
  return BasePlace.new()
end)

function E6RedHood:initPhoto()
  self:addPhoto("1", 1024, 192)
  self:addPhoto("2", 1024, 192)
  self:addPhoto("3", 704, 256)
end

function E6RedHood:initButton()
  self:addButton("addOil", 0, 0, 2044, 1148)
end

function E6RedHood:arrowDown(rect)
  self:switchPlaceZoomOut("RedOutFront")
end

function E6RedHood:beforeLoad()
  self:imageOn("0")
  self:imageOn("2")
end

function E6RedHood:afterLoad()
  self:sayI18n("afterLoad_1")
  self.status = 1
end

function E6RedHood:afterLoad2()
  self:cacheImage("RedOutFront/1")
end

function E6RedHood:beforeUseItem(itemName)
  if itemName == "oil" and not self:imageIsOn("3") and self:getInteger("tip_oil") > 0 then
    return true
  end

  return false
end

function E6RedHood:afterUseItem(itemName)
  if itemName == "oil" then
    status = 1

    self:hideArrowButton()
    self:imageOn("3")
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E6RedHood:addOil(rect)
  if self:getInteger("oil") < 0 then
    self:sayI18n("addOil_1")

    return
  end

  if not self:imageIsOn("3") then
    self:sayI18n("addOil_2")

    return
  end

  if self.status == 1 then
    self:imageOn("1")
    self:imageOff("2")
    self:sayI18n("addOil_3")

  elseif self.status == 2 then
    self:imageOff("1")
    self:sayI18n("addOil_4")

  elseif self.status == 3 then
    self:showArrowButton()
    self:imageOn("2")
    self:imageOff("3")
    self:voidItem("oil")
    self:play("item")
    self:sayI18n("addOil_5")
  end

  self.status = self.status + 1
end

return E6RedHood
