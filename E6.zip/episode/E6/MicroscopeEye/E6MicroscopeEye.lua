local E6MicroscopeEye = class("E6MicroscopeEye", function()
  return BasePlace.new()
end)

function E6MicroscopeEye:initPhoto()
end

function E6MicroscopeEye:initButton()
  self:addButton("seePwd", 620, 0, 918, 910)
end

function E6MicroscopeEye:arrowDown(rect)
  self:switchPlaceZoomOut("Microscope")
end

function E6MicroscopeEye:beforeLoad()
  if self:getInteger("flash") < 0 then
    -- 已经用过手电了
    self:imageOn("2")

    return
  end

  self:imageOn("1")
end

function E6MicroscopeEye:afterLoad()
  if self.lastPlaceName == "MicroscopeInside" then
    self:sayI18n("afterLoad_1")
  end
end

function E6MicroscopeEye:afterLoad2()
  self:cacheImage("Microscope/0")
  self:cacheImage("MicroscopeInside/0")
end

function E6MicroscopeEye:beforeUseItem(itemName)
  if itemName == "flash" then
    return true
  end

  return false
end

function E6MicroscopeEye:afterUseItem(itemName)
  if itemName == "flash" then
    self:imageOn("2")
    self:sayI18n("afterUseItem_1")

    return false
  end

  return true
end

function E6MicroscopeEye:seePwd(rect)
  if self:getInteger("flash") >= 0 then
    self:sayI18n("seePwd_1")

    return
  end

  self:switchPlaceZoomIn("MicroscopeInside", cc.rect(477 * 2, 53 * 2, 91 * 2, 91 * 2))
end

return E6MicroscopeEye
