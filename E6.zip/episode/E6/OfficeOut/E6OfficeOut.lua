local E6OfficeOut = class("E6OfficeOut", function()
  return BasePlace.new()
end)

function E6OfficeOut:initPhoto()
  self:addPhoto("1", 448, 448)
end

function E6OfficeOut:initButton()
  self:addButton("goBox", 304, 368, 442, 380)
end

function E6OfficeOut:arrowLeft(rect)
  self:switchPlaceLeft("Office")
end

function E6OfficeOut:beforeLoad()
  self:imageOn("0")

  if self:getInteger("keybox") == 0 then
    self:imageOn("1")
  end
end

function E6OfficeOut:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E6OfficeOut:afterLoad2()
  self:cacheImage("Office/0")
  self:cacheImage("OfficeKey/0")
end

function E6OfficeOut:beforeUseItem(itemName)
  return false
end

function E6OfficeOut:afterUseItem(itemName)
  return true
end

function E6OfficeOut:goBox(rect)
  self:switchPlaceZoomIn("OfficeKey", rect)
end

return E6OfficeOut
