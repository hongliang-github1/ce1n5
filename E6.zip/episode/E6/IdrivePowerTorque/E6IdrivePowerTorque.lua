local E6IdrivePowerTorque = class("E6IdrivePowerTorque", function()
  return BasePlace.new()
end)

function E6IdrivePowerTorque:initPhoto()
end

function E6IdrivePowerTorque:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E6IdrivePowerTorque:beforeLoad()
  self:disableAlwaysUseItem()
  self:imageOn("0")

  self.pprogress = 0
  self.tprogress = 0
end

function E6IdrivePowerTorque:afterLoad()
  -- 一定是从RunCarSTart场景转来，直接开始动画
  -- UIImage *image      = UIImage:imageWithContentsOfFile([[NSBundle mainBundle) pathForResource:"ce4b_IdrivePowerTorque_pin" ofType:"png"]]

  -- CGPoint pin1Point     = self:coordinateTranslateFrom1024(CGPointMake(434, 156))
  -- CGSize pin1Size     = self:coordinateTranslateFrom2048(CGSizeMake(image.size.width, image.size.height))

  -- CGPoint pin2Point     = self:coordinateTranslateFrom1024(CGPointMake(664, 158))
  -- CGSize pin2Size     = self:coordinateTranslateFrom2048(CGSizeMake(image.size.width, image.size.height))

  self:imageOn("pin", 868, 312)
  self:imageOn("pin", 1328, 316)

  self.pin1ImageView = self:imageIsOn("pin_868_312")
  self.pin2ImageView = self:imageIsOn("pin_1328_316")

  -- 设置为隐藏
  self.pin1ImageView:setVisible(false)
  self.pin2ImageView:setVisible(false)

  self:powerV(0)
  self:torqueV(0)
  self:animate()

  self:sayI18n("afterLoad_1")
end

function E6IdrivePowerTorque:afterLoad2()
end

function E6IdrivePowerTorque:beforeUnload()
  self:enableAlwaysUseItem()
end

function E6IdrivePowerTorque:click(rect)
  -- 跳回主线RunCar剧情
  self:switchPlace("RunCar")
end

function E6IdrivePowerTorque:powerV(power)
  if power < 1 then
    return
  end

  -- 显示新图，关掉原来的
  self:imageOn("v" .. power, 868, 312)
  self:imageOff("v" .. power - 1 .. "_868_312", true)
  
end

function E6IdrivePowerTorque:torqueV(power)
  if power < 1 then
    return
  end

  self:imageOn("v" .. power, 1328, 316)
  self:imageOff("v" .. power - 1 .. "_1328_316", true)
end

function E6IdrivePowerTorque:animate()
  -- 旋转动画开始，禁止用户交互
  self:disableTouch()

  -- 功率表指针动画时间分配：全程旋转125度，时间7秒
  self.duration = 7.0

  self.pin1ImageView:setVisible(true)
  self.pin2ImageView:setVisible(true)

  -- 重新设置一下初始位置
  self.pin1ImageView:setRotation(0)
  self.pin2ImageView:setRotation(0)

  local action1 = cc.RotateTo:create(self.duration, 125)
  local action2 = cc.RotateTo:create(self.duration, 190 + 360)

  self.pin1ImageView:runAction(action1)

  self.pin2ImageView:runAction(cc.Sequence:create(action2, cc.CallFunc:create(function()
    -- 动画结束
    self:enableTouch()
    self:sayI18n("animationDidStop_1")

    self:setInteger("sport_on", 1)

  end)))

  -- 播放引擎声音
  self:play("enginemax")
  self:ptimeout()
  self:ttimeout()
end

function E6IdrivePowerTorque:ptimeout()
  self:powerV(self.pprogress)
  
  self.pprogress = self.pprogress + 1

  if self.pprogress <= 4 then
    self:scheduleOnce(self.duration / 4.2, function()
      self:ptimeout()
    end)
  end
end

function E6IdrivePowerTorque:ttimeout()
  self:torqueV(self.tprogress)
  
  self.tprogress = self.tprogress + 1

  if self.tprogress <= 6 then
    self:scheduleOnce(self.duration / 6.5, function()
      self:ttimeout()
    end)
  end
end

return E6IdrivePowerTorque
