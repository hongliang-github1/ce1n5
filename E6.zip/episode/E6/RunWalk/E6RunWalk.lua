local E6RunWalk = class("E6RunWalk", function()
  return BasePlace.new()
end)

function E6RunWalk:initPhoto()
end

function E6RunWalk:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E6RunWalk:beforeLoad()
  self:imageOn("enemy")
end

function E6RunWalk:afterLoad()
  self:playMusic("gameover")
  self:sayI18n("afterLoad_1")
end

function E6RunWalk:afterLoad2()
end

function E6RunWalk:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:play("ak47")
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:setInteger("current_bgm", 0)
    self:playMusic("bgm")

    self:switchPlace(self.lastPlaceName or "Gate")

    return
  end
end

return E6RunWalk
