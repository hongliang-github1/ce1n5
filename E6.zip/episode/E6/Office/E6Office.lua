local E6Office = class("E6Office", function()
  return BasePlace.new()
end)

function E6Office:initPhoto()
  self:addPhoto("1", 768, 64)
end

function E6Office:initButton()
  self:addButton("helmetRack", 0, 0, 494, 696)
  self:addButton("takeBullet", 500, 440, 250, 254, false)
end

function E6Office:arrowRight(rect)
  self:switchPlaceRight("OfficeOut")
end

function E6Office:arrowDown(rect)
  self:switchPlaceZoomOut("OfficeDoor")
end

function E6Office:beforeLoad()
  self:imageOn("0")
end

function E6Office:afterLoad()

end

function E6Office:afterLoad2()
  self:cacheImage("OfficeOut/0")
  self:cacheImage("OfficeDoor/0")
end

function E6Office:beforeUseItem(itemName)
  return false
end

function E6Office:afterUseItem(itemName)
  return true
end

function E6Office:helmetRack(rect)
  if self.helmet then
    self:sayI18n("helmetRack_1")

  else
    self:sayI18n("helmetRack_2")
  end

  if self.helmet then
    self.helmet = false
  
  else
    self.helmet = true
  end
end

function E6Office:takeBullet(rect)
  self:helmetRack(rect)
end

return E6Office
