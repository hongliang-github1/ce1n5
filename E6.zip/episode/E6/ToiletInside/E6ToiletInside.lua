local E6ToiletInside = class("E6ToiletInside", function()
  return BasePlace.new()
end)

function E6ToiletInside:initPhoto()
  self:addPhoto("1", 1344, 320)
end

function E6ToiletInside:initButton()
  self:addButton("getFlashlight", 1166, 266, 378, 328)
end

function E6ToiletInside:arrowDown(rect)
  self:switchPlaceZoomOut("ToiletDoor")
end

function E6ToiletInside:beforeLoad()
  self:imageOn("0")

  if self:getInteger("flash") == 0 then
    self:imageOn("1")
  end
end

function E6ToiletInside:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E6ToiletInside:afterLoad2()
  self:cacheImage("ToiletDoor/0")
end

function E6ToiletInside:beforeUseItem(itemName)
  return false
end

function E6ToiletInside:afterUseItem(itemName)
  return true
end

function E6ToiletInside:getFlashlight(rect)
  if self:getInteger("flash") ~= 0 then
    self:sayI18n("getFlashlight_1")

    return
  end

  -- 如果没有拿到手电
  self:imageOff("1")
  self:getItem("flash")
  self:sayI18n("getFlashlight_2")
end

return E6ToiletInside
