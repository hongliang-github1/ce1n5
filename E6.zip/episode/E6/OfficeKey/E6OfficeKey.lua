local E6OfficeKey = class("E6OfficeKey", function()
  return BasePlace.new()
end)

function E6OfficeKey:initPhoto()
  self:addPhoto("1", 896, 448)
end

function E6OfficeKey:initButton()
  self:addButton("getBox", 602, 108, 854, 800)
end

function E6OfficeKey:arrowDown(rect)
  self:switchPlaceZoomOut("OfficeOut")
end

function E6OfficeKey:beforeLoad()
  self:imageOn("0")

  if self:getInteger("keybox") == 0 then
    self:imageOn("1")
  end
end

function E6OfficeKey:afterLoad()
  if self:getInteger("keybox") == 0 then
    self:sayI18n("afterLoad_1")
  end
end

function E6OfficeKey:afterLoad2()
  self:cacheImage("OfficeOut/0")
end

function E6OfficeKey:beforeUseItem(itemName)
  return false
end

function E6OfficeKey:afterUseItem(itemName)
  return true
end

function E6OfficeKey:getBox(rect)
  if self:getInteger("keybox") == 0 then
    self:imageOff("1")
    self:getItem("keybox")
    self:sayI18n("getBox_1")

  else
    self:sayI18n("getBox_2")
  end
end

return E6OfficeKey
