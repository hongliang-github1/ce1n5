local E6RunCarStart = class("E6RunCarStart", function()
  return BasePlace.new()
end)

function E6RunCarStart:initPhoto()
  self:addPhoto("RedDashboard/d", 1344, 794)
  self:addPhoto("RedDashboard/ds", 1344, 794)
  self:addPhoto("RedDashboard/p", 1344, 794)
  self:addPhoto("RedDashboard/11", 128, 768)
  self:addPhoto("RedDashboard/12", 384, 896)
  self:addPhoto("RedDashboard/13", 832, 640)
  self:addPhoto("RedDashboard/14", 960, 640)
  self:addPhoto("RedDashboard/23", 1216, 896)
end

function E6RunCarStart:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

-- function E6RedDashboard:arrowDown(rect)
--   if self.ending then
--     self:switchPlaceZoomOut("RedDriveDark")

--     return
--   end

--   self:switchPlaceZoomOut("RedDrive")
-- end

function E6RunCarStart:beforeLoad()
  self:disableAlwaysUseItem()
  self:imageOn("RedDashboard/10")
  self:showPin()
  self:imageOn("RedDashboard/11")
  self:imageOn("RedDashboard/d")
end

function E6RunCarStart:afterLoad()
  -- [self backButtonHide]
  self:hideArrowButton()

  -- 开走动画
  self:sayI18n("afterLoad_1")

  self:animate()
end

function E6RunCarStart:afterLoad2()
  self:cacheImage("RedDriveDark/0")

  if self:getInteger("red_engine_on") > 0 then
    self:cacheImage("RedDrive/1")
  
  else  
    self:cacheImage("RedDrive/0")
  end

  self:cacheImage("IdrivePowerTorque/0")
end

function E6RunCarStart:beforeUnload()
  self.pin1ImageView:setVisible(false)
  self.pin2ImageView:setVisible(false)

  -- [self itemAlwaysUseValid]
  self:enableAlwaysUseItem()
end

function E6RunCarStart:showPin()
  -- 如果还没设置，先把图片设置上，这里写图片的全名是因为在RunCarStart里调用到这个方法，直接写30读不到
  self:imageOn("RedDashboard/30", 200, 230)
  self:imageOn("RedDashboard/30", 1116, 256)

  self.pin1ImageView = self:imageIsOn("RedDashboard/30_200_230")
  self.pin2ImageView = self:imageIsOn("RedDashboard/30_1116_256")

  if self.pin1ImageView == nil then
    self.pin1ImageView = self:imageOn("RedDashboard/30", 200, 230)
  end

  if self.pin2ImageView == nil then
    self.pin2ImageView = self:imageOn("RedDashboard/30", 1116, 256)
  end

  -- 如果图片已经被隐藏，先设置为不隐藏，根据下面条件判断是否需要隐藏
  if self.pin1ImageView:isVisible() == false then
    self.pin1ImageView:setVisible(true)
  end

  if self.pin2ImageView:isVisible() == false then
    self.pin2ImageView:setVisible(true)
  end

  if self:getInteger("red_engine_start") ~= 0 then
    -- 速度表指向0，转速表指向700位置
    -- 转速表需要调整指针方向
    self.pin2ImageView:setRotation(39)

  elseif self:getInteger("red_engine_on") ~= 0 then
    -- 速度表指向0，转速表指向0，什么都不用做

  else
    -- 俩指针隐藏
    self.pin1ImageView:setVisible(false)
    self.pin2ImageView:setVisible(false)
  end
end

function E6RunCarStart:animate()
  -- 旋转动画开始，禁止用户交互
  self:disableTouch()

  -- 功率表指针动画
  local duration = 2.6

  self.pin1ImageView:setVisible(true)
  self.pin2ImageView:setVisible(true)

  -- 重新设置一下初始位置
  self.pin1ImageView:setRotation(0)
  self.pin2ImageView:setRotation(39)

  local action1 = cc.RotateTo:create(2.6, 55.4)
  local action2 = cc.RotateTo:create(2.6, 225.6 + 360)

  self.pin1ImageView:runAction(action1)

  self.pin2ImageView:runAction(cc.Sequence:create(action2, cc.CallFunc:create(function()
    -- 动画结束，设置发动参数为1
    self:enableTouch()
  end)))

  -- 播放引擎声音
  self:play("engine1")
end

function E6RunCarStart:click(rect)
  -- 仪表动画完成，开始播放SPORT+模式动画
  self:switchPlace("IdrivePowerTorque")
end

return E6RunCarStart
