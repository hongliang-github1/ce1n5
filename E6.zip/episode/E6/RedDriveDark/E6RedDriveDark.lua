local E6RedDriveDark = class("E6RedDriveDark", function()
  return BasePlace.new()
end)

function E6RedDriveDark:initPhoto()
end

function E6RedDriveDark:initButton()
  self:addButton("goShift", 1254, 774, 376, 374)
  self:addButton("goDashboard", 654, 272, 532, 258)
end

function E6RedDriveDark:beforeLoad()
  self:imageOn("0")
end

function E6RedDriveDark:afterLoad()
  -- if self:getInteger("need_grenade") > 0 then
  --   -- 坏人正面来袭，等待使用手雷
  --   self:sayI18n("afterLoad_1")

  -- elseif self:getInteger("need_gun") > 0 then
  --   -- 一个巡逻的坏人，等待使用枪
  --   self:sayI18n("afterLoad_2")

  -- end
  if self:getInteger("shift") < 1 then
    -- 刚要出大门，还没挂挡，等待用户去点挂挡位置
    self:sayI18n("afterLoad_3")
  end

  -- 根据不同情节切换背景音乐
  -- [[AppDelegate appDelegate].soundManager musicPlay:"bgm_runcar"]
  self:setInteger("current_bgm", 2)
  self:playMusic("runcar")
end

function E6RedDriveDark:afterLoad2()
  self:cacheImage("RedShift/0")
end

function E6RedDriveDark:beforeUseItem(itemName)
  -- if itemAlreadyUsed then

  --   return false
  -- end

  -- if ["gun" isEqualToString:itemName] then
  --   return self:getInteger("need_gun") > 0
  -- end

  -- if ["grenade" isEqualToString:itemName] then
  --   return self:getInteger("need_grenade") > 0
  -- end

  return false
end

function E6RedDriveDark:afterUseItem(itemName)
  -- if ["gun" isEqualToString:itemName] then
  --   -- 进入枪的视角
  --   self:switchPlace("RunGun")

  --   return true
  -- end

  -- if ["grenade" isEqualToString:itemName] then
  --   -- 进入手雷的视角
  --   self:switchPlace("RunGrenade")

  --   return false
  -- end

  return true
end

function E6RedDriveDark:goShift(rect)
  self:switchPlaceZoomIn("RedShift", rect)
end

function E6RedDriveDark:goDashboard(rect)
  self:switchPlaceZoomIn("RedDashboard", rect)
end

return E6RedDriveDark
