local E6MendRoomShelf = class("E6MendRoomShelf", function()
  return BasePlace.new()
end)

function E6MendRoomShelf:initPhoto()
  self:addPhoto("1", 1024, 384)
end

function E6MendRoomShelf:initButton()
  self:addButton("getSlides", 942, 292, 612, 570)
end

function E6MendRoomShelf:arrowDown(rect)
  self:switchPlaceZoomOut("MendRoom")
end

function E6MendRoomShelf:beforeLoad()
  self:imageOn("0")

  if self:getInteger("slide") == 0 then
    self:imageOn("1")
  end
end

function E6MendRoomShelf:afterLoad()
  if self:getInteger("slide") == 0 then
    self:sayI18n("afterLoad_1")
  end
end

function E6MendRoomShelf:afterLoad2()
  self:cacheImage("MendRoom/0")
end

function E6MendRoomShelf:beforeUseItem(itemName)
  return false
end

function E6MendRoomShelf:afterUseItem(itemName)
  return true
end

function E6MendRoomShelf:getSlides(rect)
  if self:getInteger("slide") ~= 0 then
    self:sayI18n("getSlides_1")

    return
  end

  self:imageOff("1")
  self:getItem("slide")
  self:sayI18n("getSlides_2")
end

return E6MendRoomShelf
