local E6WareRoomLeft = class("E6WareRoomLeft", function()
  return BasePlace.new()
end)

function E6WareRoomLeft:initPhoto()
end

function E6WareRoomLeft:initButton()
  self:addButton("clothes", 538, 0, 680, 648, false)
  self:addButton("chairs", 598, 650, 926, 498, false)
  self:addButton("goRight", 1528, 0, 516, 1148)
end

function E6WareRoomLeft:arrowDown(rect)
  self:switchPlaceZoomOut("WareRoomDoor")
end

function E6WareRoomLeft:beforeLoad()
  self:imageOn("0")
end

function E6WareRoomLeft:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E6WareRoomLeft:afterLoad2()
  self:cacheImage("WareRoomDoor/0")
  self:cacheImage("WareRoomRight/0")
end

function E6WareRoomLeft:beforeUseItem(itemName)
  return false
end

function E6WareRoomLeft:afterUseItem(itemName)
  return true
end

function E6WareRoomLeft:clothes(rect)
  self:sayI18n("clothes_1")
end

function E6WareRoomLeft:chairs(rect)
  self:sayI18n("chairs_1")
end

function E6WareRoomLeft:goRight(rect)
  self:switchPlaceRight("WareRoomRight")
end

return E6WareRoomLeft
