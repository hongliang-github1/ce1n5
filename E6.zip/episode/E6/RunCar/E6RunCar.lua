local E6RunCar = class("E6RunCar", function()
  return BasePlace.new()
end)

function E6RunCar:initPhoto()
end

function E6RunCar:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E6RunCar:beforeLoad()
  if "RedDashboard" == self.lastPlaceName or self:getInteger("sport_on") > 0 then
    self:imageOn("RedDriveDark/0")

    return
  end

  self:imageOn("Gate/9")
end

function E6RunCar:afterLoad()
  -- 本场景是所有逃跑剧情的主线串联，故会有许多其他场景不断地回到本场景来，因此剧情是不是刚开始要以run_progress变量来判断
  if self:getInteger("run_progress") == 0 then
    self:sayI18n("afterLoad_1")

    return
  end

  -- progress不是0，自动往下走剧情
  self:click(nil)
end

function E6RunCar:afterLoad2()
  self:cacheImage("RedDriveDark/0")
  self:cacheImage("Ending/0")
end

function E6RunCar:click(rect)
  if self:getInteger("run_progress") == 0 then
    self:imageOn("RedOutFront/1")
    self:sayI18n("click_1")

  elseif self:getInteger("run_progress") == 1 then
    self:setInteger("run_progress", 2)
    self:switchPlace("RedDriveDark")

    -- 注意这里是return
    return

  elseif self:getInteger("run_progress") == 2 and self:getInteger("sport_on") == 1 then
    -- 走到这里，表示已经档位已经调到了sport+模式，直接进入ending了
    self:sayI18n("click_6")
    self:setInteger("run_progress", 3)

    return

  elseif self:getInteger("run_progress") == 3 then
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()

    self:switchPlace("Ending")

    return
  end

  self:setInteger("run_progress", self:getInteger("run_progress") + 1)
end

return E6RunCar
