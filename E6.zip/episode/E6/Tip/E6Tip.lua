local E6Tip = class("E6Tip", function()
  return BaseTip.new()
end)

function E6Tip:getTipAtIndex(index)
  self:resetProgress()

  -- 拿载玻片
  if self:nextProgress() == index or (self:getInteger("slide") == 0) then
    local place1 = self:addPlace("MendRoomDoor")
    local place2 = self:addPlace("MendRoom")
    local place3 = self:addPlace("MendRoomShelf")

    place1:markButton("goDoor")
    place2:markButton("lookSlides")
    place3:markButton("getSlides")

    self:textI18n("progress_1")

    return self.progress
  end

  -- 拿手电
  if self:nextProgress() == index or (self:getInteger("flash") == 0) then
    local place1 = self:addPlace("SeeMendRoom")
    local place2 = self:addPlace("ToiletDoor")
    local place3 = self:addPlace("ToiletInside")

    place1:markButton("goToilet")
    place2:markButton("openDoor")
    place3:markButton("getFlashlight")

    self:textI18n("progress_2")

    return self.progress
  end

  -- 获取机器人锁的密码，手电还没使用，说明还没有看到解锁密码
  if self:nextProgress() == index or (self:getInteger("officekey") == 0 and self:getInteger("flash") > 0) then
    local place1 = self:addPlace("MendRoomDoor")
    local place2 = self:addPlace("Microscope")
    local place3 = self:addPlace("MicroscopeEye")

    place1:markButton("microscope")
    place2:markButton("putSlides")
    place3:markButton("seePwd")

    self:textI18n("progress_3")

    return self.progress
  end

  -- 获取机器人锁的密码
  if self:nextProgress() == index or (self:getInteger("officekey") == 0
      and self:getInteger("flash") < 0) then
    local place1 = self:addPlace("SeeOffice")
    local place2 = self:addPlace("Robot")
    local place3 = self:addPlace("RobotLock")

    place1:markButton("goTV")
    place2:markButton("_left")
    place3:markButton("getKey")

    self:textI18n("progress_4")

    return self.progress
  end

  -- 开办公室门
  if self:nextProgress() == index or (self:getInteger("officekey") > 0) then
    local place1 = self:addPlace("SeeOffice")
    self:addPlace("OfficeDoor")

    place1:markButton("goLeft")

    self:textI18n("progress_5")

    return self.progress
  end

  -- 办公室门后拿透明盒子
  if self:nextProgress() == index or (self:getInteger("keybox") == 0) then
    local place1 = self:addPlace("OfficeDoor")
    local place2 = self:addPlace("Office")
    local place3 = self:addPlace("OfficeOut")

    place1:markButton("goOffice")
    place2:markButton("_right")
    place3:markButton("goBox")

    self:textI18n("progress_6")

    return self.progress
  end

  -- 拿大扳手
  if self:nextProgress() == index or (self:getInteger("spanner") == 0) then
    local place1 = self:addPlace("SeeMendRoom")
    local place2 = self:addPlace("MendRoomDoor")
    local place3 = self:addPlace("Toolbox")

    place1:markButton("goMendRoom")
    place2:markButton("goCabinet")
    place3:markButton("boxOpen")

    self:textI18n("progress_7")

    return self.progress
  end

  -- 拿红车钥匙
  if self:nextProgress() == index or (self:getInteger("redkey") == 0) then
    self:addPlace("Keybox")
    local place1 = self:addPlace("Keybox")

    place1:imageOn("4")

    self:textI18n("progress_8")

    return self.progress
  end

  -- 使用红车钥匙
  if self:nextProgress() == index or (self:getInteger("redkey") > 0) then
    local place1 = self:addPlace("SeeRedCar")
    local place2 = self:addPlace("RedOutFront")
    self:addPlace("RedOutLeft")

    place1:markButton("goRedCar")
    place2:markButton("_right")

    self:textI18n("progress_9")

    return self.progress
  end

  -- 拿保险丝
  if self:nextProgress() == index or (self:getInteger("fuse") == 0) then
    local place1 = self:addPlace("RedOutLeft")
    local place2 = self:addPlace("RedDrive")
    local place3 = self:addPlace("RedSeatRight")

    place1:imageOn("3")
    place1:markButton("openFront")
    place2:markButton("goSeatRight")
    place3:markButton("getFuse")

    self:textI18n("progress_10")

    return self.progress
  end

  -- 拿保险丝说明书并使用
  if self:nextProgress() == index or (self:getInteger("fuse") > 0) then
    local place1 = self:addPlace("RedOutRear")
    local place2 = self:addPlace("RedFuse")
    local place3 = self:addPlace("RedFuseNear")

    place1:markButton("openTrunk")
    place2:imageOn("0")
    place2:markButton("goFuseNear")
    place3:markButton("getFusepaper")

    self:textI18n("progress_11")

    return self.progress
  end

  -- 红车是否通电，发动汽车，是否有需要油的提示
  if self:nextProgress() == index or (self:getInteger("tip_oil") < 1) then
    local place1 = self:addPlace("RedDrive")
    local place2 = self:addPlace("RedStart")

    place1:markButton("goStart")
    place2:markButton("start")

    self:textI18n("progress_12")

    return self.progress
  end

  -- 拿二楼仓库钥匙
  if self:nextProgress() == index or (self:getInteger("wareroomkey") == 0) then
    local place1 = self:addPlace("RedDrive")
    local place2 = self:addPlace("RedShieldRight")

    place1:markButton("goShield")
    place2:markButton("getKey")

    self:textI18n("progress_13")

    return self.progress
  end

  -- 使用仓库房门钥匙
  if self:nextProgress() == index or (self:getInteger("wareroomkey") > 0) then
    local place1 = self:addPlace("SecondFloor")
    local place2 = self:addPlace("WareRoomDoor")

    place1:markButton("warehouseDoor")
    place2:markButton("open")

    self:textI18n("progress_16")

    return self.progress
  end

  -- 进仓库拿机油
  if self:nextProgress() == index or (self:getInteger("oil") == 0) then
    local place1 = self:addPlace("WareRoomDoor")
    local place2 = self:addPlace("WareRoomLeft")
    local place3 = self:addPlace("WareRoomRight")

    place1:imageOn("1")
    place1:markButton("open")
    place2:markButton("goRight")
    place3:markButton("goOilNear")

    self:textI18n("progress_17")

    return self.progress
  end

  -- 开红车引擎盖
  if self:nextProgress() == index or (self:getInteger("hood_switch_pull") < 2) then
    local place1 = self:addPlace("RedOutLeft")
    local place2 = self:addPlace("RedHoodSwitch")

    place1:imageOn("2")
    place1:markButton("goHoodSwitch")
    place2:markButton("pull")

    self:textI18n("progress_18")

    return self.progress
  end

  -- 使用机油
  if self:nextProgress() == index or (self:getInteger("oil") > 0) then
    local place1 = self:addPlace("RedOutFront")
    local place2 = self:addPlace("RedHood")

    place1:imageOn("2")
    place1:markButton("openCarFront")
    place2:imageOn("3")
    place2:markButton("addOil")

    self:textI18n("progress_19")

    return self.progress
  end

  -- 发动汽车
  if self:nextProgress() == index or (self:getInteger("red_engine_start") < 1) then
    local place1 = self:addPlace("RedDrive")
    local place2 = self:addPlace("RedStart")

    place1:markButton("goStart")
    place2:markButton("start")

    self:textI18n("progress_20")

    return self.progress
  end

  -- 拿大门钥匙
  if self:nextProgress() == index or (self:getInteger("gatekey") == 0) then
    local place1 = self:addPlace("RedDrive")
    local place2 = self:addPlace("RedGlove")

    place1:markButton("goGlove")
    place2:markButton("open")

    self:textI18n("progress_24")

    return self.progress
  end

  -- 逃跑进度
  if self:nextProgress() == index or (self:getInteger("run_progress") < 1) then
    local place1 = self:addPlace("SeeRedCar")
    local place2 = self:addPlace("Gate")

    place1:markButton("_right")
    place2:imageOn("3")
    place2:markButton("goOut")

    self:textI18n("progress_25")

    return self.progress
  end

  if self:nextProgress() == index or true then
    local place1 = self:addPlace("RedDriveDark")
    local place2 = self:addPlace("RedShift")

    place1:markButton("goShift")
    place2:markButton("shift")

    self:textI18n("progress_26")

    return self.progress
  end

  return self:nextProgress()
end

return E6Tip
