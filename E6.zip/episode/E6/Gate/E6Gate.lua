local E6Gate = class("E6Gate", function()
  return BasePlace.new()
end)

function E6Gate:initPhoto()
  self:addPhoto("3", 1024, 384)
end

function E6Gate:initButton()
  self:addButton("goOut", 0, 0, 2044, 1148, false)
end

function E6Gate:arrowLeft(rect)
  self:switchPlaceLeft("SeeRedCar")
end

function E6Gate:beforeLoad()
  self:imageOn("0")
end

function E6Gate:afterLoad()
end

function E6Gate:afterLoad2()
  self:cacheImage("SeeRedCar/0")
end

function E6Gate:beforeUseItem(itemName)
  if itemName == "gatekey" and not self:imageIsOn("3") then
    return true
  end

  return false
end

function E6Gate:afterUseItem(itemName)
  if itemName == "gatekey" then
    self:imageOn("3")
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E6Gate:goOut(rect)
  if not self:imageIsOn("3") then
    self:sayI18n("goOut_1")

    return
  end

  self:imageOff("3")

  self:disableTouch()
  self:hideArrowButton()
  self:playMusic("beatenemy")

  self:scheduleTimes(0.5, 6, function(index)
    if index <= 5 then
      self:imageOn(tostring(index + 4))

      return
    end

    self:enableTouch()
    self:setInteger("run_progress", 0)
    self:setInteger("shift", 0)
    self:switchPlace("Run")

  end)
end

return E6Gate
