local E6SeeRedCar = class("E6SeeRedCar", function()
  return BasePlace.new()
end)

function E6SeeRedCar:initPhoto()
end

function E6SeeRedCar:initButton()
  self:addButton("goRedCar", 564, 470, 766, 434)
  self:addButton("goMoto", 0, 140, 560, 700)
  self:addButton("goDoor", 1332, 0, 494, 712)
end

function E6SeeRedCar:arrowRight(rect)
  self:switchPlaceRight("Gate")
end

function E6SeeRedCar:beforeLoad()
  self:imageOn("0")
end

function E6SeeRedCar:afterLoad()
end

function E6SeeRedCar:afterLoad2()
  self:cacheImage("RedOutFront/1")
  self:cacheImage("SeeOffice/0")
  self:cacheImage("SeeMendRoom/1")
end

function E6SeeRedCar:beforeUseItem(itemName)
  return false
end

function E6SeeRedCar:afterUseItem(itemName)
  return true
end

function E6SeeRedCar:goRedCar(rect)
  self:switchPlaceZoomIn("RedOutFront", rect)
end

function E6SeeRedCar:goMoto(rect)
  self:switchPlaceZoomIn("SeeOffice", rect)
end

function E6SeeRedCar:goDoor(rect)
  self:switchPlaceZoomIn("SeeMendRoom", cc.rect(666 * 2, 142 * 2, 160 * 2, 185 * 2))
end

return E6SeeRedCar
