local E6RedDashboard = class("E6RedDashboard", function()
  return BasePlace.new()
end)

function E6RedDashboard:initPhoto()
  self:addPhoto("d", 1344, 794)
  self:addPhoto("ds", 1344, 794)
  self:addPhoto("p", 1344, 794)
  self:addPhoto("11", 128, 768)
  self:addPhoto("12", 384, 896)
  self:addPhoto("13", 832, 640)
  self:addPhoto("14", 960, 640)
  self:addPhoto("23", 1216, 896)
end

function E6RedDashboard:initButton()
end

function E6RedDashboard:arrowDown(rect)
  if self.ending then
    self:switchPlaceZoomOut("RedDriveDark")

    return
  end

  self:switchPlaceZoomOut("RedDrive")
end

function E6RedDashboard:beforeLoad()
  if self:getInteger("red_engine_on") ~= 0 then
    self:imageOn("10")

  else
    self:imageOn("1")
  end

  self:showPin()

  if self:getInteger("red_engine_start") > 0 then
    self:engineStartStatus()

  elseif self:getInteger("red_engine_on") > 0 then
    self:engineOnStatus()
  end

  if "RedDriveDark" == self.lastPlaceName or "RunCar" == self.lastPlaceName then
    self.ending = true
  end

  if self.ending then
    -- local runProgress = self:getInteger("run_progress")
    -- local shift       = self:getInteger("shift")

    if self:getInteger("shift") ~= 0 then
      -- 车已开走，把安全带灯和手刹灯隐藏
      self:imageOff("12")
      self:imageOff("13")
      self:imageOn("23")
      self:imageOn("ds")
    end

    -- if runProgress > 2 then
    --   -- 车在行进中，速度指向80，转速指向1500
    --   pin1ImageView.transform = CGAffineTransformMakeRotation(degreesToRadians(54))
    --   pin2ImageView.transform = CGAffineTransformMakeRotation(degreesToRadians(62))
    -- end
  end
end

function E6RedDashboard:afterLoad()
  if self.ending then
    self:sayI18n("afterLoad_3")

    return
  end

  if "RedStart" ~= self.lastPlaceName then
    if self:getInteger("red_engine_on") < 1 then
      self:sayI18n("afterLoad_4")

    elseif self:getInteger("red_engine_start") ~= 0 then
      self:sayI18n("afterLoad_5")
    end

    return
  end

  -- 以下均为从启动开关视角转来，根据不同情况进入不同剧情
  if self:getInteger("red_engine_on") > 0 then
    -- 车已通电，从启动开关走到这里一定是符合发动条件，可以发动，开始指针动画，还原指针位置，禁用用户点击，开始播放启动声音
    -- pin2ImageView.transform = CGAffineTransformMakeRotation(degreesToRadians(0))
    self.pin2ImageView:setRotation(0)

    -- [self userInteractionDisable]
    self:disableTouch()
    
    self:play("enginestart")

    local action1 = cc.RotateTo:create(1, 54)
    local action2 = cc.RotateTo:create(2, 39)

    self.pin2ImageView:runAction(cc.Sequence:create(action1, action2, cc.CallFunc:create(function()
      -- 动画结束，设置发动参数为1
      self:enableTouch()
      self:setInteger("red_engine_start", 1)
      self:sayI18n("afterLoad_6")  
    end)))

    -- UIView:animateWithDuration(1 animations:^{
    --   pin2ImageView.transform = CGAffineTransformMakeRotation(degreesToRadians(54))

    -- end completion:^(BOOL finished){
    --   [UIView animateWithDuration:2 animations:^{
    --     pin2ImageView.transform = CGAffineTransformMakeRotation(degreesToRadians(39))

    --   end completion:^(BOOL finished){
    --     -- 动画结束，设置发动参数为1
    --     [self userInteractionEnable)
    --     self:setInteger("red_engine_start" value:1)
    --     self:sayI18n("afterLoad_6")
    --   end]
    -- end]

    return
  end

  -- 车还没通电，判断保险丝是否使用过
  if self:getInteger("fuse") < 0 then
    -- 保险丝已用，可以通电，开始仪表由暗变亮动画
    self:setInteger("red_engine_on", 1)
    self.cacheAction = self:schedule(0.3, function()
      self:engineOnDelay()
    end)

  else
    -- 保险丝还没用，没反应，给出提示，这里做仪表狂闪的动画
    self.cacheAction = self:schedule(0.2, function()
      self:flash()
    end)

    self:sayI18n("afterLoad_7")
  end
end

function E6RedDashboard:afterLoad2()
  self:cacheImage("10")

  if self.ending then
    self:cacheImage("RedDriveDark/0")
  end

  if self:getInteger("red_engine_on") > 0 then
    self:cacheImage("RedDrive/1")
  
  else  
    self:cacheImage("RedDrive/0")
  end
end

function E6RedDashboard:beforeUnload()
  if self.cacheAction ~= nil then
    self:unschedule(self.cacheAction)

    self.cacheAction = nil
  end
  
  self.pin1ImageView:setVisible(false)
  self.pin2ImageView:setVisible(false)
end

function E6RedDashboard:flash()
  if self:imageIsOn("1") then
    self:imageOn("10")

  else
    self:imageOn("1")
  end
end

function E6RedDashboard:engineOnDelay()
  self:engineOnStatus()

  self:sayI18n("engineOnDelay_1")
end

function E6RedDashboard:engineOnStatus()
  -- 车刚通电
  self:imageOn("10")
  self:showPin()
  self:imageOn("11")
  self:imageOn("12")
  self:imageOn("13")
  self:imageOn("14")
  self:imageOn("p")
end

function E6RedDashboard:engineStartStatus()
  -- 车刚发动起来
  self:imageOn("10")
  self:showPin()
  self:imageOn("11")
  self:imageOn("12")
  self:imageOn("13")
  self:imageOff("14")
  self:imageOn("p")

  -- 转速表指向700
  self.pin2ImageView:setRotation(39)
end

function E6RedDashboard:showPin()
  -- 如果还没设置，先把图片设置上，这里写图片的全名是因为在RunCarStart里调用到这个方法，直接写30读不到
  self:imageOn("30", 200, 230)
  self:imageOn("30", 1116, 256)

  self.pin1ImageView = self:imageIsOn("30_200_230")
  self.pin2ImageView = self:imageIsOn("30_1116_256")

  if self.pin1ImageView == nil then
    self.pin1ImageView = self:imageOn("30", 200, 230)
  end

  if self.pin2ImageView == nil then
    self.pin2ImageView = self:imageOn("30", 1116, 256)
  end

  -- 如果图片已经被隐藏，先设置为不隐藏，根据下面条件判断是否需要隐藏
  if self.pin1ImageView:isVisible() == false then
    self.pin1ImageView:setVisible(true)
  end

  if self.pin2ImageView:isVisible() == false then
    self.pin2ImageView:setVisible(true)
  end

  if self:getInteger("red_engine_start") ~= 0 then
    -- 速度表指向0，转速表指向700位置
    -- 转速表需要调整指针方向
    self.pin2ImageView:setRotation(39)

  elseif self:getInteger("red_engine_on") ~= 0 then
    -- 速度表指向0，转速表指向0，什么都不用做

  else
    -- 俩指针隐藏
    self.pin1ImageView:setVisible(false)
    self.pin2ImageView:setVisible(false)
  end
end

return E6RedDashboard
