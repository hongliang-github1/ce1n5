local E6Microscope = class("E6Microscope", function()
  return BasePlace.new()
end)

function E6Microscope:initPhoto()
  self:addPhoto("1", 896, 512)
end

function E6Microscope:initButton()
  self:addButton("putSlides", 552, 0, 876, 960)
end

function E6Microscope:arrowDown(rect)
  self:switchPlaceZoomOut("MendRoomDoor")
end

function E6Microscope:beforeLoad()
  self:imageOn("0")

  -- 如果载玻片已经使用了，就显示出来
  if self:getInteger("slide") < 0 then
    self:imageOn("1")
  end
end

function E6Microscope:afterLoad()
  if not self:imageIsOn("1") then
    self:sayI18n("afterLoad_1")

    return
  end
end

function E6Microscope:afterLoad2()
  self:cacheImage("MendRoomDoor/0")

  if self:getInteger("flash") < 0 then
    -- 已经用过手电了
    self:cacheImage("MicroscopeEye/2")

  else
    self:cacheImage("MicroscopeEye/1")
  end
end

function E6Microscope:beforeUseItem(itemName)
  if itemName == "slide" then
    return true
  end

  return false
end

function E6Microscope:afterUseItem(itemName)
  if itemName == "slide" then
    self:imageOn("1")
    self:sayI18n("afterUseItem_1")

    return false
  end

  return true
end

function E6Microscope:putSlides(rect)
  -- if ["ce4" isEqualToString:self.userData.currentChapter] then
  --   self:switchPlace("Ce4EnemyBack")

  --   return
  -- end

  if self:getInteger("slide") >= 0 then
    self:sayI18n("putSlides_1")

    return
  end

  -- 进入显微镜看镜头视角
  self:switchPlaceZoomIn("MicroscopeEye", cc.rect(400 * 2, 0, 219 * 2, 163 * 2))
end

return E6Microscope
