local E6RedGlove = class("E6RedGlove", function()
  return BasePlace.new()
end)

function E6RedGlove:initPhoto()
  self:addPhoto("1", 192, 0)
  self:addPhoto("2", 832, 384)
end

function E6RedGlove:initButton()
  self:addButton("open", 348, 0, 1696, 770)
end

function E6RedGlove:arrowLeft(rect)
  self:switchPlaceZoomOut("RedDrive")
end

function E6RedGlove:beforeLoad()
  self:imageOn("0")
  self:imageOn("1")
end

function E6RedGlove:afterLoad()

end

function E6RedGlove:afterLoad2()
  if self:getInteger("red_engine_on") > 0 then
    self:cacheImage("RedDrive/1")
  
  else  
    self:cacheImage("RedDrive/0")
  end
end

function E6RedGlove:beforeUseItem(itemName)
  return false
end

function E6RedGlove:afterUseItem(itemName)
  return true
end

function E6RedGlove:open(rect)
  -- 手套箱没打开的时候
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:play("armopen")

    if self:getInteger("gatekey") ~= 0 then
      self:sayI18n("open_1")

      return
    end

    self:imageOn("2")
    self:sayI18n("open_2")

    return
  end

  -- 手套箱打开之后
  if self:getInteger("gatekey") ~= 0 then
    self:imageOn("1")
    self:play("armclose")
    self:sayI18n("open_3")

    return
  end

  self:imageOff("2")
  self:getItem("gatekey")
  self:sayI18n("open_4")
end

return E6RedGlove
