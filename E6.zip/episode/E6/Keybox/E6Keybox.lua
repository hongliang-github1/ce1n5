local E6Keybox = class("E6Keybox", function()
  return BasePlace.new()
end)

function E6Keybox:initPhoto()
  self:addPhoto("1", 832, 256)
  self:addPhoto("2", 832, 256)
  self:addPhoto("4", 768, 64)
  self:addPhoto("5", 768, 64)
  self:addPhoto("8", 832, 256)
end

function E6Keybox:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E6Keybox:clickOpen()
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOff("8")
    self:imageOn("4")
    self:sayI18n("clickOpen_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("4")
    self:imageOn("5")
    self:voidItem("spanner")
    self:voidItem("keybox")
    self:getItem("redkey")

    self:sayI18n("clickOpen_3")

    self:showArrowButton()

    return
  end
end

function E6Keybox:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "SeeRedCar")
end

function E6Keybox:recordLastPlaceName()
  -- 场景不记录到lastSceneName中
  return false
end

function E6Keybox:beforeLoad()
  self:imageOn("0")
  self:imageOn("8")

  self:disableAlwaysUseItem()
end

function E6Keybox:afterLoad()
  self.status = 0
  self:click(nil)
end

function E6Keybox:afterLoad2()
end

function E6Keybox:beforeUseItem(itemName)
  -- 扳手可以使用
  if itemName == "spanner" then
    return not self.opened
  end

  return false
end

function E6Keybox:afterUseItem(itemName)
  if itemName == "spanner" then
    -- 使用扳手
    self:sayI18n("afterUseItem_1")

    self.opened = true

    self:hideArrowButton()

    return true
  end

  return true
end

function E6Keybox:click(rect)
  if self:getInteger("redkey") ~= 0 then
    self:imageOn("5")
    self:sayI18n("click_1")

    return
  end

  if self.opened then
    self:clickOpen()

    return
  end

  self.status = self.status + 1

  if 1 == self.status then
    self:sayI18n("click_2")

    return
  end

  if 2 == self.status then
    self:sayI18n("click_3")

    return
  end

  if 3 == self.status then
    self:sayI18n("click_4")

    self.status = 0

    return
  end
end

return E6Keybox
