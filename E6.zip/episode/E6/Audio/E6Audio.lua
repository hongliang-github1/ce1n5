local E6Audio = class("E6Audio", function()
  return BasePlace.new()
end)

function E6Audio:beforeLoad()
  if self:getInteger("current_bgm") == 0 then
    self:playMusic("bgm")

  elseif self:getInteger("current_bgm") == 1 then
    self:playMusic("beatenemy")
    
  elseif self:getInteger("current_bgm") == 2 then
    self:playMusic("runcar")
  end
end

return E6Audio
  
