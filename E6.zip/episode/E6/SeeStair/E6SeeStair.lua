local E6SeeStair = class("E6SeeStair", function()
  return BasePlace.new()
end)

function E6SeeStair:initPhoto()
end

function E6SeeStair:initButton()
  self:addButton("onStairs", 444, 0, 1132, 1148)
end

function E6SeeStair:arrowDown(rect)
  self:switchPlaceZoomOut("SeeOffice")
end

function E6SeeStair:beforeLoad()
  self:imageOn("0")
end

function E6SeeStair:afterLoad()
  if self.lastPlaceName == "StairBottom" then
    self:sayI18n("afterLoad_1")

  else
    self:sayI18n("afterLoad_2")
  end
end

function E6SeeStair:afterLoad2()
  if self.lastPlaceName == "StairBottom" then
    self:cacheImageRemove("StairBottom/0")
    self:cacheImageRemove("StairMiddle/0")
    self:cacheImageRemove("StairTop/0")
    self:cacheImageRemove("SecondFloor/0")
    self:cacheImageRemove("BlackRoom/0")
    self:cacheImageRemove("SecondSofa/0")
    self:cacheImageRemove("SeeGround/0")
    self:cacheImageRemove("WareRoomDoor/0")
    self:cacheImageRemove("WareRoomDoor/1")
    self:cacheImageRemove("WareRoomLeft/0")
    self:cacheImageRemove("WareRoomOil/0")
    self:cacheImageRemove("WareRoomOil/1")
    self:cacheImageRemove("WareRoomRight/0")
    self:cacheImageRemove("WareRoomRight/1")
  end

  self:cacheImage("StairBottom/0")
  self:cacheImage("SeeOffice/0")
end

function E6SeeStair:beforeUseItem(itemName)
  return false
end

function E6SeeStair:afterUseItem(itemName)
  return true
end

function E6SeeStair:onStairs(rect)
  self:switchPlaceZoomIn("StairBottom", cc.rect(800, 368, 400, 400))
end

return E6SeeStair
