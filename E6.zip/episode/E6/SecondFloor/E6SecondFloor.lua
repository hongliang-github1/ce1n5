local E6SecondFloor = class("E6SecondFloor", function()
  return BasePlace.new()
end)

function E6SecondFloor:initPhoto()
end

function E6SecondFloor:initButton()
  self:addButton("groceries", 558, 602, 864, 546)
  self:addButton("darkRoom", 176, 138, 370, 800)
  self:addButton("warehouseDoor", 1456, 0, 588, 1020)
end

function E6SecondFloor:arrowLeft(rect)
  self:switchPlaceLeft("SecondSofa")
end

function E6SecondFloor:arrowDown(rect)
  self:switchPlaceDown("StairTop")
end

function E6SecondFloor:beforeLoad()
  self:imageOn("0")
end

function E6SecondFloor:afterLoad()
  if StairTop == self.lastPlaceName then
    self:sayI18n("afterLoad_1")
  end
end

function E6SecondFloor:afterLoad2()
  self:cacheImage("WareRoomDoor/0")
  self:cacheImage("BlackRoom/0")
  self:cacheImage("SecondSofa/0")
  self:cacheImage("StairTop/0")
end

function E6SecondFloor:beforeUseItem(itemName)
  return false
end

function E6SecondFloor:afterUseItem(itemName)
  return true
end

function E6SecondFloor:groceries(rect)
  self:sayI18n("groceries_1")
end

function E6SecondFloor:darkRoom(rect)
  self:switchPlaceZoomIn("BlackRoom", cc.rect(140, 340, 370, 500))
end

function E6SecondFloor:warehouseDoor(rect)
  self:switchPlaceZoomIn("WareRoomDoor", cc.rect(734 * 2, 114 * 2, 229 * 2, 285 * 2))
end

return E6SecondFloor
