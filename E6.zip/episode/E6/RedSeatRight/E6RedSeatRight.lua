local E6RedSeatRight = class("E6RedSeatRight", function()
  return BasePlace.new()
end)

function E6RedSeatRight:initPhoto()
  self:addPhoto("1", 512, 384)
  self:addPhoto("2", 832, 704)
end

function E6RedSeatRight:initButton()
  self:addButton("getFuse", 662, 462, 522, 404)
end

function E6RedSeatRight:arrowLeft(rect)
  self:switchPlaceZoomOut("RedDrive")
end

function E6RedSeatRight:beforeLoad()
  self:imageOn("0")
  self:imageOn("1")
end

function E6RedSeatRight:afterLoad()

end

function E6RedSeatRight:afterLoad2()
  if self:getInteger("red_engine_on") > 0 then
    self:cacheImage("RedDrive/1")
  
  else  
    self:cacheImage("RedDrive/0")
  end
end

function E6RedSeatRight:beforeUseItem(itemName)
  return false
end

function E6RedSeatRight:afterUseItem(itemName)
  return true
end

function E6RedSeatRight:getFuse(rect)
  -- 座椅没翻开
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:play("leg")
    
    if self:getInteger("fuse") ~= 0 then
      self:sayI18n("getFuse_1")
      
      return
    end
    
    self:imageOn("2")
    self:sayI18n("getFuse_2")
    
    return
  end
  
  -- 座椅已经打开
  if self:getInteger("fuse") ~= 0 then
    self:imageOn("1")
    self:play("leg")
    self:sayI18n("getFuse_3")
    
    return
  end
  
  self:imageOff("2")
  self:getItem("fuse")
  self:sayI18n("getFuse_4")
end

return E6RedSeatRight
