local E6Toolbox = class("E6Toolbox", function()
  return BasePlace.new()
end)

function E6Toolbox:initPhoto()
  self:addPhoto("1", 640, 768)
  self:addPhoto("2", 448, 192)
  self:addPhoto("3", 448, 192)
  self:addPhoto("4", 448, 192)
end

function E6Toolbox:initButton()
  self:addButton("boxOpen", 524, 92, 1210, 954)
end

function E6Toolbox:arrowDown(rect)
  self:switchPlaceZoomOut("MendRoomDoor")
end

function E6Toolbox:beforeLoad()
  self:imageOn("0")
  self:imageOn("2")
  progress = 0
end

function E6Toolbox:afterLoad()

end

function E6Toolbox:afterLoad2()
  self:cacheImage("3")
  self:cacheImage("4")
  self:cacheImage("MendRoomDoor/0")
end

function E6Toolbox:beforeUseItem(itemName)
  return false
end

function E6Toolbox:afterUseItem(itemName)
  return true
end

function E6Toolbox:boxOpen(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOn("4")
    self:imageOff("2")
    self:sayI18n("boxOpen_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("3")
    self:imageOff("4")
    self:sayI18n("boxOpen_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("3")

    if self:getInteger("spanner") ~= 0 then
      self:sayI18n("boxOpen_3")

      return
    end

    self:imageOn("1")
    self:sayI18n("boxOpen_4")

    return
  end

  if progress == self:nextProgressIndex() then
    if self:getInteger("spanner") == 0 then
      self:imageOff("1")
      self:getItem("spanner")
      self:sayI18n("boxOpen_6")

      return
    end

    self:imageOn("2")
    self:sayI18n("boxOpen_7")
    
    self.progress = nil

    return
    
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:sayI18n("boxOpen_9")
    
    self.progress = nil

    return
  end
end

return E6Toolbox
