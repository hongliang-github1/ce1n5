local E6StairMiddle = class("E6StairMiddle", function()
  return BasePlace.new()
end)

function E6StairMiddle:initPhoto()
end

function E6StairMiddle:initButton()

end

function E6StairMiddle:arrowUp(rect)
  self:switchPlaceUp("StairTop")
end

function E6StairMiddle:arrowDown(rect)
  self:switchPlaceDown("StairBottom")
end

function E6StairMiddle:beforeLoad()
  self:imageOn("0")
end

function E6StairMiddle:afterLoad()
  if "StairBottom" == self.lastPlaceName then
    self:sayI18n("afterLoad_1")
  end
end

function E6StairMiddle:afterLoad2()
  self:cacheImage("StairTop/0")
  self:cacheImage("StairBottom/0")
end

function E6StairMiddle:beforeUseItem(itemName)
  return false
end

function E6StairMiddle:afterUseItem(itemName)
  return true
end

return E6StairMiddle
