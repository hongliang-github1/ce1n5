local E6RoundLock = class("E6RoundLock", function()
  return BasePlace.new()
end)

function E6RoundLock:initPhoto()
  self:addPhoto("2", 674, 226)
end

function E6RoundLock:initButton()
end

function E6RoundLock:arrowDown(rect)
  self:switchPlaceZoomOut("RobotLockNear")
end

function E6RoundLock:beforeLoad()
  self:imageOn("0")
  self:imageOn("2")

  self.roundCenter = cc.p(674 + 400, 226 + 400)
end

function E6RoundLock:afterLoad()
  if self:getInteger("round_unlock") > 0 then
    -- 防止锁已经开了但是用户退出程序后又进来
    self:switchPlace("RobotLockNear")

    return
  end

  local fontSize = 50 * 2

  if self.gamingScene and self.gamingScene.labelSay then
    fontSize = math.ceil(self.gamingScene.labelSay:getFontSize() * 2.85)
  end

  local label1 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label2 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label3 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2, fontSize * 1.2), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  label1:setColor(cc.c4b(255, 255, 255, 255))
  label2:setColor(cc.c4b(255, 255, 255, 255))
  label3:setColor(cc.c4b(255, 255, 255, 255))
  
  label1:setAnchorPoint(0, 0)
  label2:setAnchorPoint(0, 0)
  label3:setAnchorPoint(0, 0)
  
  label1:setPosition(0, 0)
  label2:setPosition(0, 0)
  label3:setPosition(0, 0)

  self.label1 = label1
  self.label2 = label2
  self.label3 = label3

  self:addChild(label1)
  self:addChild(label2)
  self:addChild(label3)

  -- 计算四个label的位置，居中为准，分别向两边延伸
  local bgSize    = self:getContentSize()
  local labelSize = label1:getContentSize()
  local x         = 854 * 2

  label1:setPosition(x, bgSize.height - 100 * 2)
  label2:setPosition(x, bgSize.height - 232 * 2)
  label3:setPosition(x, bgSize.height - 364 * 2)

  -- 添加两个带图片的按钮
  local sprite1     = ccui.Scale9Sprite:create(self:imagePath("down"), cc.rect(0, 0, 160, 120), cc.rect(0, 0, 160, 120))  
  local downButton = cc.ControlButton:create(sprite1)
  self.downButton  = downButton

  downButton:setAnchorPoint(0.5, 0.5)
  downButton:setPreferredSize(cc.size(320, 240))
  downButton:setPositionX(300)
  downButton:setPositionY(400)
  downButton:setLocalZOrder(101)
  self:addChild(downButton)

  -- 绑定按钮事件
  self.downButton:registerControlEventHandler(function(button, eventType)
    self:goDown()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  local sprite2     = ccui.Scale9Sprite:create(self:imagePath("up"), cc.rect(0, 0, 160, 120), cc.rect(0, 0, 160, 120))  
  local upButton = cc.ControlButton:create(sprite2)
  self.upButton  = upButton

  upButton:setAnchorPoint(0.5, 0.5)
  upButton:setPreferredSize(cc.size(320, 240))
  upButton:setPositionX(300)
  upButton:setPositionY(800)
  upButton:setLocalZOrder(101)
  self:addChild(upButton)

  -- 绑定按钮事件
  self.upButton:registerControlEventHandler(function(button, eventType)
    self:goUp()
  end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

  self.lastNumber = 0
  self.pos        = 0

  -- self:sayI18n("afterLoad_1")
end

function E6RoundLock:afterLoad2()
  self:cacheImage("RobotLockNear/0")
end

function E6RoundLock:beforeUseItem(itemName)
  return false
end

function E6RoundLock:afterUseItem(itemName)
  return true
end

function E6RoundLock:goUp()
  if self.unlocked then
    return
  end

  if self.rotateImage == nil then
    self.rotateImage = self:imageIsOn("2")
  end

  local nowAngleDegree = self.rotateImage:getRotation()

  -- 防止角度累计超过360度，始终保持角度范围在0-360之间
  if nowAngleDegree >= 360 then
    nowAngleDegree = nowAngleDegree - 360
  end

  self.rotateImage:setRotation(nowAngleDegree + 9)

  local number = math.ceil(40 - self.rotateImage:getRotation() / 9)

  if number == 40 then
    number = 0
  end

  self.clockwise = false;

  self:labelShowNum(number)
end

function E6RoundLock:goDown()
  if self.unlocked then
    return
  end

  if self.rotateImage == nil then
    self.rotateImage = self:imageIsOn("2")
  end

  local nowAngleDegree = self.rotateImage:getRotation()

  -- 防止角度累计小于0度，始终保持角度范围在0-360之间
  if nowAngleDegree <= 0 then
    nowAngleDegree = 360
  end

  self.rotateImage:setRotation(nowAngleDegree - 9)

  local number = math.ceil(40 - self.rotateImage:getRotation() / 9)

  if number == 40 then
    number = 0
  end

  self.clockwise = true;

  self:labelShowNum(number)
end

function E6RoundLock:labelShowNum(number)
  -- 最终刻度已计算好，与上一个刻度比较是否反向
  if self.pos == 0 then
    -- 刚进入场景，一次密码还没有选过，将当前角度作为第一位密码，不做反向判断
    -- 第一次旋转时按照newAngle是否大于0来设置初始方向，不以刻度为准
    self.label3:setVisible(false)
    self.label2:setVisible(false)
    self.label1:setVisible(true)
    self.label1:setString(tostring(number))

    self.pos = 1;
  
  else
    -- 判断是否反向，如果反向，则记录当前角度作为密码，newAngle为正数表示顺时针旋转，负数表示逆时针旋转
    local sameDirection = self.clockwise == self.lastClockwise;

    if sameDirection then
      -- 没反向，更新当前密码选择的label数字
      if self.pos == 1 then
        -- 更新第一位密码
        self.label1:setString(tostring(number))

      elseif self.pos == 2 then
        -- 更新第二位密码
        self.label2:setString(tostring(number))

      elseif self.pos == 3 then
        -- 更新第三位密码
        self.label3:setString(tostring(number))

        self:check()
      end
    
    else
      -- 反向了，将上一个刻度作为密码
      if self.pos == 1 then
        -- 之前是在选第一位密码，现在反向了，将当前角度作为第二位密码
        self.label2:setVisible(true)
        self.label2:setString(tostring(number))
      
        self.pos = 2;

      elseif self.pos == 2 then
        -- 之前是在选第二位密码，现在反向了，将当前角度作为第三位密码了，时刻检查密码是否正确
        self.label3:setVisible(true)
        self.label3:setString(tostring(number))
      
        self.pos = 3;

        self:check()

      elseif self.pos == 3 then
        -- 之前是在选第三位密码，现在反向了，说明要重新从第一位密码重新开始选
        self.label3:setVisible(false)
        self.label2:setVisible(false)
        self.label1:setVisible(true)
        self.label1:setString(tostring(number))
      
        self.pos = 1;
      end
    end
  end

  -- 标记一下最近一次的转向
  self.lastClockwise = self.clockwise
end

function E6RoundLock:onTouchEnded(touch, event)
end

function E6RoundLock:beforeUnload()
  if self.label1 ~= nil then
    self.label1:setVisible(false)
  end

  if self.label2 ~= nil then
    self.label2:setVisible(false)
  end

  if self.label3 ~= nil then
    self.label3:setVisible(false)
  end
end

function E6RoundLock:check()
  local password  = tostring(self:getInteger("round1")) .. "_" .. tostring(self:getInteger("round2")) .. "_" .. tostring(self:getInteger("round3"))
  local try       = self.label1:getString() .. "_" .. self.label2:getString() .. "_" .. self.label3:getString()

  if password == try then
    self:sayI18n("check_1")
    self:play("armopen")
    self:setInteger("round_unlock", 1)

    local color = cc.c4b(255, 0, 0, 255)

    self.label1:setColor(color)
    self.label2:setColor(color)
    self.label3:setColor(color)

    self.unlocked = true
  end
end

return E6RoundLock
