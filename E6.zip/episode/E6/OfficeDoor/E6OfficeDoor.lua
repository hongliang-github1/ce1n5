local E6OfficeDoor = class("E6OfficeDoor", function()
  return BasePlace.new()
end)

function E6OfficeDoor:initPhoto()
  self:addPhoto("3", 960, 0)
end

function E6OfficeDoor:initButton()
  self:addButton("goOffice", 928, 96, 528, 1030)
end

function E6OfficeDoor:arrowDown(rect)
  self:switchPlaceZoomOut("SeeOffice")
end

function E6OfficeDoor:beforeLoad()
  self:imageOn("0")

  if self:getInteger("officekey") < 0 then
    self:imageOn("3")
  end
end

function E6OfficeDoor:afterLoad()

end

function E6OfficeDoor:afterLoad2()
  if self.lastPlaceName == "Office" then
    self:cacheImageRemove("Office/0")
    self:cacheImageRemove("OfficeKey/0")
    self:cacheImageRemove("OfficeKey/1")
    self:cacheImageRemove("OfficeOut/0")
    self:cacheImageRemove("OfficeOut/1")
  end

  self:cacheImage("Office/0")
  self:cacheImage("SeeOffice/0")
end

function E6OfficeDoor:beforeUseItem(itemName)
  if itemName == "officekey" then
    return  true
  end

  return false
end

function E6OfficeDoor:afterUseItem(itemName)
  if itemName == "officekey" then
    self:imageOn("3")
    self:play("zhiniu")
    self:sayI18n("afterUseItem_1")

    return  false
  end

  return true
end

function E6OfficeDoor:goOffice(rect)
  if self:getInteger("officekey") < 0 then
    -- 使用过钥匙了，门已经打开了直接进去
    self:switchPlaceZoomIn("Office", cc.rect(463 * 2, 152 * 2, 263 * 2, 312 * 2))

    return
  end

  self:play("trydoor")
  self:sayI18n("goOffice_1")
end

return E6OfficeDoor
