local E6IdriveOil = class("E6IdriveOil", function()
  return BasePlace.new()
end)

function E6IdriveOil:initPhoto()
end

function E6IdriveOil:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E6IdriveOil:arrowDown(rect)
  -- 得到所有的label 把label的hidden设置成yes
  -- for (NSString *key in labelDict) {
  --   ((UILabel *)labelDict:objectForKey(key)).hidden = true
  -- end

  self:switchPlaceZoomOut("RedDrive")
end

function E6IdriveOil:beforeLoad()
  self:imageOn("0")

  local fontSize = 50

  -- if self.gamingScene and self.gamingScene.labelSay then
  --   fontSize = math.ceil(self.gamingScene.labelSay:getFontSize() * 1.1)
  -- end

  local label1 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2 * 10, fontSize * 1.2), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local label2 = cc.Label:createWithSystemFont(" ", "Helvetica", fontSize, cc.size(fontSize * 1.2 * 10, fontSize * 1.2), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER)

  label1:setColor(cc.c4b(255, 0, 0, 255))
  label2:setColor(cc.c4b(255, 0, 0, 255))
  
  
  label1:setAnchorPoint(0, 0)
  label2:setAnchorPoint(0, 0)
  
  label1:setPosition(0, 0)
  label2:setPosition(0, 0)

  self.label1 = label1
  self.label2 = label2

  label1:setString("警告")
  label2:setString("机油严重不足")

  self:addChild(label1)
  self:addChild(label2)

  -- 计算四个label的位置，居中为准，分别向两边延伸
  local bgSize    = self:getContentSize()
  local labelSize = label1:getContentSize()
  local x         = 854 * 2

  label1:setPosition(412, bgSize.height - 120 - labelSize.height)
  label2:setPosition(600, bgSize.height - 255 - labelSize.height)

  -- BOOL isPad = [BaseAppDelegate baseAppDelegate].isiPad

  -- self:putLabelWithText(@{
  --    "chs" : "警告",
  --    "cht" : "警告",
  --    "en"  : "Warning",
  --    "jp"  : "警告",
  --    "kr"  : "경고",
  --  end x:206 y:64 w:600 h:50 fontSize:isPad ? 22 : 12 isBold:false isColor:true)

  -- self:putLabelWithText(@{
  --    "chs" : "机油严重不足",
  --    "cht" : "機油嚴重不足",
  --    "en"  : "Engine oil is empty.",
  --    "jp"  : "エンジンオイル不足",
  --    "kr"  : "기계유가 심하게 부족합니다",
  --  end x:300 y:124 w:600 h:68 fontSize:isPad ? 24 : 14 isBold:false isColor:true)

  self:play("enginefail")
  self:sayI18n("beforeLoad_1")

  if self:getInteger("tip_oil") < 1 then
    self:setInteger("tip_oil", 1)
  end
end

function E6IdriveOil:afterLoad()
  self.progress = 0
end

function E6IdriveOil:afterLoad2()
  if self:getInteger("red_engine_on") > 0 then
    self:cacheImage("RedDrive/1")
  
  else  
    self:cacheImage("RedDrive/0")
  end
end

function E6IdriveOil:click(rect)
  if self.progress == 0 then
    self:sayI18n("click_1")

  else
    self:sayI18n("click_2")

    -- 注意此处是return
    return
  end

  self.progress = self.progress + 1
end

return E6IdriveOil
