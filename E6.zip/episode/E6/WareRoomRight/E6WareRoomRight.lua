local E6WareRoomRight = class("E6WareRoomRight", function()
  return BasePlace.new()
end)

function E6WareRoomRight:initPhoto()
  self:addPhoto("1", 768, 512)
end

function E6WareRoomRight:initButton()
  self:addButton("goOilNear", 624, 322, 500, 590)
end

function E6WareRoomRight:arrowLeft(rect)
  self:switchPlaceLeft("WareRoomLeft")
end

function E6WareRoomRight:beforeLoad()
  self:imageOn("0")
  if self:getInteger("oil") == 0 then
    self:imageOn("1")
  end
end

function E6WareRoomRight:afterLoad()
  if self:getInteger("oil") == 0 then
    self:sayI18n("afterLoad_1")
  end
end

function E6WareRoomRight:afterLoad2()
  self:cacheImage("WareRoomLeft/0")
  self:cacheImage("WareRoomOil/0")
end

function E6WareRoomRight:beforeUseItem(itemName)
  return false
end

function E6WareRoomRight:afterUseItem(itemName)
  return true
end

function E6WareRoomRight:goOilNear(rect)
  if self:getInteger("oil") == 0 then
    self:switchPlaceZoomIn("WareRoomOil", rect)

  else
    self:sayI18n("goOilNear_1")
  end
end

return E6WareRoomRight
