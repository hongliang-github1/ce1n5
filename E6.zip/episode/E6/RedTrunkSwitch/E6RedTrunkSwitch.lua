local E6RedTrunkSwitch = class("E6RedTrunkSwitch", function()
  return BasePlace.new()
end)

function E6RedTrunkSwitch:initPhoto()
  self:addPhoto("1", 832, 192)
end

function E6RedTrunkSwitch:initButton()
  self:addButton("trunkSwitch", 634, 0, 800, 800)
end

function E6RedTrunkSwitch:arrowDown(rect)
  self:switchPlaceZoomOut("RedOutRear")
end

function E6RedTrunkSwitch:beforeLoad()
  self:imageOn("0")
  self:imageOn("1")
end

function E6RedTrunkSwitch:afterLoad()
  if self:getInteger("tip_trunk") == 0 then
    self:sayI18n("afterLoad_1")
  end
end

function E6RedTrunkSwitch:afterLoad2()
  self:cacheImage("RedOutRear/0")
end

function E6RedTrunkSwitch:beforeUseItem(itemName)
  return false
end

function E6RedTrunkSwitch:afterUseItem(itemName)
  return true
end

function E6RedTrunkSwitch:trunkSwitch(rect)
  if self:getInteger("tip_trunk") > 0 then
    -- 去车尾视角，直接开后备厢
    self:switchPlace("RedOutRear")

    return
  end

  self:imageOff("1")
  self:play("ce4_isofix")
  self:setInteger("tip_trunk", 1)
  self:sayI18n("trunkSwitch_1")
end

return E6RedTrunkSwitch
