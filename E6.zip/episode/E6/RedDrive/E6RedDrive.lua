local E6RedDrive = class("E6RedDrive", function()
  return BasePlace.new()
end)

function E6RedDrive:initPhoto()
end

function E6RedDrive:initButton()
  self:addButton("goSeatRight", 1638, 768, 406, 380)
  self:addButton("goGlove", 1636, 368, 408, 390)
  self:addButton("goDashboard", 654, 134, 532, 258)
  self:addButton("goStart", 972, 400, 274, 308)
  self:addButton("goShield", 1606, 0, 438, 200)
  self:addButton("openDoor", 154, 352, 390, 390)
end

function E6RedDrive:beforeLoad()
  if self:getInteger("red_engine_on") > 0 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E6RedDrive:afterLoad()

end

function E6RedDrive:afterLoad2()
  self:cacheImage("RedSeatRight/0")
  self:cacheImage("RedGlove/0")
  self:cacheImage("RedShieldRight/0")
  self:cacheImage("RedDashboard/1")
  self:cacheImage("RedStart/0")
  self:cacheImage("RedOutLeft/1")
end

function E6RedDrive:beforeUseItem(itemName)
  return false
end

function E6RedDrive:afterUseItem(itemName)
  return true
end

function E6RedDrive:goSeatRight(rect)
  self:switchPlaceZoomIn("RedSeatRight", rect)
end

function E6RedDrive:goGlove(rect)
  self:switchPlaceZoomIn("RedGlove", rect)
end

function E6RedDrive:goDashboard(rect)
  self:switchPlaceZoomIn("RedDashboard", rect)
end

function E6RedDrive:goStart(rect)
  self:switchPlaceZoomIn("RedStart", rect)
end

function E6RedDrive:openDoor(rect)
  self:play("open")

  self:switchPlaceZoomOut("RedOutLeft")
end

function E6RedDrive:goShield(rect)
  self:switchPlaceZoomIn("RedShieldRight", rect)
end

return E6RedDrive
