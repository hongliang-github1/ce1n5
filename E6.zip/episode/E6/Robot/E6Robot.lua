local E6Robot = class("E6Robot", function()
  return BasePlace.new()
end)

function E6Robot:initPhoto()
end

function E6Robot:initButton()
end

function E6Robot:arrowLeft(rect)
  self:switchPlaceLeft("RobotLock")
end

function E6Robot:arrowDown(rect)
  self:switchPlaceZoomOut("SeeOffice")
end

function E6Robot:beforeLoad()
  self:imageOn("0")
end

function E6Robot:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E6Robot:afterLoad2()
  self:cacheImage("RobotLock/0")
  self:cacheImage("SeeOffice/0")
end

function E6Robot:beforeUseItem(itemName)
  return false
end

function E6Robot:afterUseItem(itemName)
  return true
end

return E6Robot
