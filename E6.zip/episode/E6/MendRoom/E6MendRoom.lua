local E6MendRoom = class("E6MendRoom", function()
  return BasePlace.new()
end)

function E6MendRoom:initPhoto()
  self:addPhoto("1", 1280, 448)
end

function E6MendRoom:initButton()
  self:addButton("partsOne", 376, 96, 712, 896, false)
  self:addButton("partsTwo", 1238, 44, 678, 224, false)
  self:addButton("partsThree", 1454, 302, 304, 372, false)
  self:addButton("lookSlides", 1134, 310, 308, 300)
end

function E6MendRoom:arrowDown(rect)
  self:switchPlaceZoomOut("MendRoomDoor")
end

function E6MendRoom:beforeLoad()
  self:imageOn("0")

  if self:getInteger("slide") == 0 then
    self:imageOn("1")
  end
end

function E6MendRoom:afterLoad()

end

function E6MendRoom:afterLoad2()
  self:cacheImage("MendRoomDoor/0")
  self:cacheImage("MendRoomShelf/0")
end

function E6MendRoom:beforeUseItem(itemName)
  return false
end

function E6MendRoom:afterUseItem(itemName)
  return true
end

function E6MendRoom:partsOne(rect)
  -- if ["ce4" isEqualToString:self.userData.currentChapter] then
  --   self:switchPlace("Ce4EnemyBack")

  --   return
  -- end

  self:sayI18n("partsOne_1")
end

function E6MendRoom:partsTwo(rect)
  -- if ["ce4" isEqualToString:self.userData.currentChapter] then
  --   self:switchPlace("Ce4EnemyBack")

  --   return
  -- end

  self:sayI18n("partsTwo_1")
end

function E6MendRoom:partsThree(rect)
  -- if ["ce4" isEqualToString:self.userData.currentChapter] then
  --   self:switchPlace("Ce4EnemyBack")

  --   return
  -- end

  self:sayI18n("partsThree_1")
end

function E6MendRoom:lookSlides(rect)
  -- if ["ce4" isEqualToString:self.userData.currentChapter] then
  --   self:switchPlace("Ce4EnemyBack")

  --   return
  -- end

  self:switchPlaceZoomIn("MendRoomShelf", rect)
end

return E6MendRoom
