local E6RedShift = class("E6RedShift", function()
  return BasePlace.new()
end)

function E6RedShift:initPhoto()
  self:addPhoto("1", 1088, 0)
  self:addPhoto("31", 0, 600)
  self:addPhoto("32", 0, 600)
  self:addPhoto("33", 0, 600)
end

function E6RedShift:initButton()
  self:addButton("shift", 1092, 0, 692, 922)
end

function E6RedShift:shiftDone()
  self:enableTouch()
  self:imageOff("1")

  self.shifted = true
end

function E6RedShift:arrowDown(rect)
  if self.shifted or self.modeSwitched then
    self:shift(rect)

    return
  end

  self:switchPlaceZoomOut("RedDriveDark")
end

function E6RedShift:afterShowArrowButton()
  if self.shifted or self.modeSwitched then
    self:hideArrowButton()
  end
end

function E6RedShift:beforeLoad()
  self:imageOn("0")
end

function E6RedShift:afterLoad()
  if self:getInteger("shift") < 1 then
    -- 刚要出大门，还没挂挡，等待用户去点挂挡位置
    self:sayI18n("afterLoad_3")
  end
end

function E6RedShift:afterLoad2()
  self:cacheImage("RedDriveDark/0")
end

function E6RedShift:beforeUnload()
  -- [self itemAlwaysUseValid]
end

function E6RedShift:shift(rect)
  if self.modeSwitched then
    -- 驾驶模式调节完成，进入仪表动画
    self:switchPlace("RunCarStart")

    return
  end

  if self.shifted then
    -- 排挡完成，自动进入调节驾驶模式动画
    -- [self modeGoSport]
    self:modeGoSport()

    return
  end

  local shift = self:getInteger("shift")

  if shift > 0 then
    -- 挡位早已挂好
    self:sayI18n("shift_1")
    -- [self sceneDidLoad]

    return
  end

  -- 等待剧情换挡呢，此处一触即发，开始走剧情，设置挡位已挂
  self:sayI18n("shift_2")

  self:disableTouch()
  self:hideArrowButton()

  self:imageOn("1")
  self:play("shift")
  self:setInteger("shift", 1)
  
  self:scheduleOnce(0.3, function()
    self:shiftDone()
  end)
end

function E6RedShift:modeGoSport()
  -- 进入调整到SPORT+模式动画
  self:sayI18n("modeGoSport_1")

  -- self:play("ce4_tik")
  self:play("tik")
  self:imageOn("33")
  -- [self userInteractionDisable]
  self:disableTouch()

  self:scheduleOnce(0.7, function()
    self:sportDelay1()
  end)
end

function E6RedShift:sportDelay1()
  self:play("tik")
  self:imageOn("32")

  self:scheduleOnce(0.7, function()
    self:sportDelay2()
  end)
end

function E6RedShift:sportDelay2()
  self:play("tik")
  self:imageOn("31")

  self:scheduleOnce(0.7, function()
    self:sportDelay3()
  end)
end

function E6RedShift:sportDelay3()
  -- 动画结束，等待用户再次点击
  self.modeSwitched = true
  
  self:enableTouch()
end

function E6RedShift:onTouchBegan(touch, event)
  if self.modeSwitched then
    self:shift(rect)

    return
  end
end

return E6RedShift
