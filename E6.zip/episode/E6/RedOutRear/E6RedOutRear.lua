local E6RedOutRear = class("E6RedOutRear", function()
  return BasePlace.new()
end)

function E6RedOutRear:initPhoto()
  self:addPhoto("1", 512, 0)
end

function E6RedOutRear:initButton()
  self:addButton("openTrunk", 534, 220, 960, 460)
  self:addButton("closeTrunk", 522, 0, 998, 220, false)
end

function E6RedOutRear:arrowLeft(rect)
  self:switchPlaceLeft("RedOutLeft")
end

function E6RedOutRear:arrowRight(rect)
  self:switchPlaceRight("RedOutRight")
end

function E6RedOutRear:beforeLoad()
  self:imageOn("0")

  if self.lastPlaceName == "RedTrunkSwitch" then
    if self:getInteger("tip_trunk") > 0 then
      -- 从后备厢开关视角转来，直接把后备厢打开
      self:imageOn("1")
      self:play("trunkopen")
      self:sayI18n("beforeLoad_1")
    end
  
  elseif self.lastPlaceName == "RedFuse" then
    self:imageOn("1")
  end
end

function E6RedOutRear:afterLoad()

end

function E6RedOutRear:afterLoad2()
  self:cacheImage("RedTrunkSwitch/0")
  self:cacheImage("RedFuse/0")
  self:cacheImage("RedOutLeft/1")
  self:cacheImage("RedOutRight/0")
end

function E6RedOutRear:beforeUseItem(itemName)
  return false
end

function E6RedOutRear:afterUseItem(itemName)
  return true
end

function E6RedOutRear:openTrunk(rect)
  if self:getInteger("redkey") >= 0 then
    self:sayI18n("openTrunk_1")

    return
  end

  if self:imageIsOn("1") then
    -- 如果后备厢已经打开了，那么进入保险丝视角
    self:switchPlaceZoomIn("RedFuse", rect)

    return
  end

  -- 还不知道怎么开后备厢呢，去后备厢开关视角
  if self:getInteger("tip_trunk") == 0 then
    self:switchPlaceZoomIn("RedTrunkSwitch", rect)

    return
  end

  -- 如果没开，就打开后备厢
  self:imageOn("1")
  self:play("trunkopen")
  self:sayI18n("openTrunk_2")
end

function E6RedOutRear:closeTrunk(rect)
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:play("trunkclose")
    self:sayI18n("closeTrunk_1")
  end
end

return E6RedOutRear
