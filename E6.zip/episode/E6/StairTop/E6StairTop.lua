local E6StairTop = class("E6StairTop", function()
  return BasePlace.new()
end)

function E6StairTop:initPhoto()
end

function E6StairTop:initButton()
end

function E6StairTop:arrowDown(rect)
  self:switchPlaceDown("StairMiddle")
end

function E6StairTop:arrowUp(rect)
  self:switchPlaceUp("SecondFloor")
end

function E6StairTop:beforeLoad()
  self:imageOn("0")
end

function E6StairTop:afterLoad()
  if "SecondFloor" ~= self.lastPlaceName then
    self:sayI18n("afterLoad_1")
  end
end

function E6StairTop:afterLoad2()
  self:cacheImage("SecondFloor/0")
  self:cacheImage("StairMiddle/0")
end

function E6StairTop:beforeUseItem(itemName)
  return false
end

function E6StairTop:afterUseItem(itemName)
  return true
end

return E6StairTop
