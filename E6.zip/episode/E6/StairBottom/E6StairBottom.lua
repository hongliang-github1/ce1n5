local E6StairBottom = class("E6StairBottom", function()
  return BasePlace.new()
end)

function E6StairBottom:initPhoto()
end

function E6StairBottom:initButton()
end

function E6StairBottom:arrowLeft(rect)
  self:switchPlaceZoomOut("SeeStair")
end

function E6StairBottom:arrowUp(rect)
  self:switchPlaceUp("StairMiddle")
end

function E6StairBottom:beforeLoad()
  self:imageOn("0")
end

function E6StairBottom:afterLoad()
  if "StairMiddle" == self.lastPlaceName then
    self:sayI18n("afterLoad_1")

  elseif "SeeStair" == self.lastPlaceName then
    self:sayI18n("afterLoad_2")
  end
end

function E6StairBottom:afterLoad2()
  self:cacheImage("StairMiddle/0")
  self:cacheImage("SeeStair/0")
end

function E6StairBottom:beforeUseItem(itemName)
  return false
end

function E6StairBottom:afterUseItem(itemName)
  return true
end

return E6StairBottom
