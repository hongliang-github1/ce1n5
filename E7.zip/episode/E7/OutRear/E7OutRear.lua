local E7OutRear = class("E7OutRear", function()
  return BasePlace.new()
end)

function E7OutRear:initPhoto()
  self:addPhoto("1", 896, 448)
  self:addPhoto("2", 448, 0)
  self:addPhoto("3", 320, 384)
  self:addPhoto("t", 704, 128)
end

function E7OutRear:initButton()
  self:addButton("open", 898, 410, 248, 262)
end

function E7OutRear:arrowLeft(rect)
  self:switchPlaceLeft("OutLeftRear")
end

function E7OutRear:arrowRight(rect)
  self:switchPlaceRight("OutRightRear")
end

function E7OutRear:beforeLoad()
  self:imageOn("0")

  if self:getInteger("car_door_open") == 1 then
    -- 车门已经打开
    self:imageOn("2")
  end

  if self:getInteger("car_engine_ready") == 1 then
    -- 车已经发动
    self:imageOn("3")
  end
end

function E7OutRear:afterLoad()
  if "Beginning" == self.lastPlaceName then
    -- 先走一段剧情
    self:hideArrowButton()
    self:sayI18n("afterLoad_1")

    self.isPlot = true

    return
  end

function E7OutRear:afterLoad2()
  self:cacheImage("OutLeftRear/0")
  self:cacheImage("OutRightRear/0")
end

  self:sayTip()
  self:sayI18n("afterLoad_2")
end

function E7OutRear:afterLoad2()
  if self:getInteger("car_engine_ready") == 1 then
    self:cacheImage("OutLeftRear/20")
    self:cacheImage("OutRightRear/20")
  
  else
    self:cacheImage("OutRightRear/0")
    self:cacheImage("OutLeftRear/0")
  end
end

function E7OutRear:beforeUnload()
end

function E7OutRear:beforeUseItem(itemName)
  return false
end

function E7OutRear:afterUseItem(itemName)
  return true
end

function E7OutRear:open(rect)
  if self.isPlot then
    self:onTouchBegan()

    return
  end

  if self:imageIsOn("1") then
    self:imageOff("1")
    self:play("steeringbutton")
    self:sayI18n("open_1")

    return
  end

  -- 尝试打开
  self:imageOn("1")
  self:play("steeringbutton")
  self:sayI18n("open_2")
end

function E7OutRear:onTouchBegan(touch, event)
  if self.isPlot then
    local progress = self:nextProgress()

    self:resetProgressIndex()

    if progress == self:nextProgressIndex() then
      self:stopTip()
      self:sayTip()
      self:sayI18n("click_1")

      return
    end

    if progress == self:nextProgressIndex() then
      self:stopTip()
      self:sayI18n("click_2")

      return
    end

    if progress == self:nextProgressIndex() then
      self:stopTip()
      self:sayTip()
      self:sayI18n("click_3")

      return
    end

    if progress == self:nextProgressIndex() then
      self:stopTip()
      self:sayI18n("click_4")

      self:showArrowButton()

      self.isPlot = false

      return
    end

  end
end

function E7OutRear:sayTip()  
  self.flikerAction = self:scheduleTimes(0.12, 12, function(index)
    if index == 1 then
      -- 预加载说话图片
      self:imageTexture("t")
    end

    if self:imageIsOn("t") then
      self:imageOff("t")

    else
      self:imageOn("t")
    end
  end)
end

function E7OutRear:stopTip()
  self:unschedule(self.flikerAction)
end

return E7OutRear
