local E7OutRightRear = class("E7OutRightRear", function()
  return BasePlace.new()
end)

function E7OutRightRear:initPhoto()
  self:addPhoto("10", 0, 0)
  self:addPhoto("12", 0, 0)
  self:addPhoto("1", 1792, 64)
  self:addPhoto("22", 0, 0)
  self:addPhoto("2", 256, 384)
end

function E7OutRightRear:initButton()
  self:addButton("slot", 926, 340, 312, 508)
  self:addButton("tank", 230, 334, 220, 232)
  self:addButton("seeLeft", 458, 148, 464, 544)
  self:addButton("closeDoor", 1242, 334, 216, 526, false)
end

function E7OutRightRear:arrowLeft(rect)
  self:switchPlaceLeft("OutRear")
end

function E7OutRightRear:arrowRight(rect)
  self:switchPlaceRight("OutRightFront")
end

function E7OutRightRear:beforeLoad()
  -- 如果是车里出来的，门开着
  if "AshRear" == self.lastPlaceName or "SeeLeft" == self.lastPlaceName then
    self.opened = true

    if self:getInteger("car_engine_ready") == 1 then
      self:imageOn("20")
      self:imageOn("22")
      
    else
      self:imageOn("0")
      self:imageOn("10")
      self:imageOn("12")
    end
    
    if self:getInteger("sucker") < 0 then
      -- 已经使用过吸盘，说明油箱盖子被吸开了
      self:imageOn("2")
    end
    
    return
  end

  if self:getInteger("car_engine_ready") == 1 then
    -- 车已经发动了
    self:imageOn("20")

    if self:getInteger("sucker") < 0 then
      -- 已经使用过吸盘，说明油箱盖子被吸开了
      self:imageOn("2")
    end

    return
  end

  self:imageOn("0")

  if self:getInteger("car_door_open") == 1 then
    -- 车门已经打开过
    self:imageOn("10")
  end

  if self:getInteger("car_tank_open") == 1 then
    -- 油箱盖子已经被打开
    self:imageOn("2")
  end

  if self:getInteger("sucker") == 0 then
    -- 吸盘还没有得到
    self:imageOn("1")
  end
end

function E7OutRightRear:afterLoad()

end

function E7OutRightRear:afterLoad2()
  self:cacheImage("OutRear/0")

  if self:getInteger("car_engine_ready") == 1 then
    self:cacheImage("OutRightFront/20")

  else
    self:cacheImage("OutRightFront/0")
  end
end

function E7OutRightRear:beforeUseItem(itemName)
  return false
end

function E7OutRightRear:afterUseItem(itemName)
  return true
end

function E7OutRightRear:slot(rect)
  -- 去后车门烟灰盒
  if self.opened then
    self:switchPlaceZoomIn("AshRear", rect)

    return
  end

  self:switchPlaceRight("OutRightFront")
end

function E7OutRightRear:tank(rect)
  self:switchPlaceZoomIn("Tank", rect)
end

function E7OutRightRear:seeLeft(rect)
  -- 车门还没解锁
  if self:getInteger("car_door_open") <= 0 then
    self:sayI18n("seeLeft_2")
    
    return
  end

  -- 车门已经打开
  if self.opened then
    self:switchPlaceZoomIn("SeeLeft", rect)

    return
  end

  -- 打开车门
  if self:getInteger("car_engine_ready") == 1 then
    self:imageOn("22")

  else
    self:imageOn("12")
  end

  -- 每次动画换图的时候，都需要重新设置一下油箱盖的图片
  if self:getInteger("sucker") < 0 then
    self:imageOn("2")
  end

  self:play("cardooropen")
  self:sayI18n("seeLeft_3")

  self.opened = true
end

function E7OutRightRear:closeDoor(rect)
  if self.opened then
    self.opened = false

    if self:getInteger("car_engine_ready") == 1 then
      self:imageOff("22")

    else
      self:imageOff("12")
    end

    self:play("cardoorclose")
    self:sayI18n("closeDoor_1")

    return
  end

  self:switchPlaceRight("OutRightFront")
end

return E7OutRightRear
