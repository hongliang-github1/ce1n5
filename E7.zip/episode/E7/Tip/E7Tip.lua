local E7Tip = class("E7Tip", function()
  return BaseTip.new()
end)

function E7Tip:getTipAtIndex(index)
  self:resetProgress()

  -- 刚进来，还没拿到吸盘，去拿吸盘
  if self:nextProgress() == index or self:getInteger("sucker") == 0 then
    self:addPlace("OutLeftFront"):markButton("door")
    self:addPlace("Door"):markButton("suck")
    
    self:textI18n("progress_1")
    
    return self.progress
  end

  -- 使用吸盘，去开油箱盖
  if self:nextProgress() == index or self:getInteger("sucker") > 0 then
    self:addPlace("OutRightRear"):markButton("tank")
    self:addPlace("Tank"):markButton("open")
    
    self:textI18n("progress_2")
    
    return self.progress
  end

  -- 得到车钥匙
  if self:nextProgress() == index or self:getInteger("key1") == 0 then
    self:addPlace("OutRightRear"):markButton("tank")
    self:addPlace("Tank"):markButton("open")
    
    self:textI18n("progress_3")
    
    return self.progress
  end

  -- 得知驾驶位车门把手的钥匙孔
  if self:nextProgress() == index or self:getInteger("car_door_near_seen") == 0 then
    self:addPlace("OutLeftFront"):markButton("handle")
    self:addPlace("CarDoor"):markButton("open")
    self:addPlace("CarDoorNear"):markButton("click")
    
    self:textI18n("progress_4")
    
    return self.progress
  end

  -- 得到车钥匙里的备用钥匙
  if self:nextProgress() == index or self:getInteger("key2") == 0 then
    self:addPlace("Key")
    
    self:textI18n("progress_5")
    
    return self.progress
  end

  -- 使用备用钥匙，打开车门
  if self:nextProgress() == index or self:getInteger("car_door_open") == 0 then
    self:addPlace("OutLeftFront"):markButton("handle")
    self:addPlace("CarDoor"):markButton("open")
    self:addPlace("CarDoorNear"):markButton("click")
    
    self:textI18n("progress_6")
    
    return self.progress
  end

  -- 去拿小螺丝刀
  if self:nextProgress() == index or self:getInteger("screwdriver") == 0 then
    self:addPlace("Drive"):markButton("cup")
    self:addPlace("CupFront"):markButton("cup")
    
    self:textI18n("progress_16")
    
    return self.progress
  end

  -- 去拿纽扣电池，之前还没得到过
  if self:nextProgress() == index or self:getInteger("battery") == 0 then
    local place = self:addPlace("OutRightRear")

    place:imageOn("OutRightRear/12")
    place:markButton("slot")
    
    self:addPlace("AshRear"):markButton("ash")
    
    self:textI18n("progress_10")
    
    return self.progress
  end

  -- 将纽扣电池装入车钥匙中
  if self:nextProgress() == index or self:getInteger("battery") >= 0 then
    self:addPlace("Key")
    
    self:textI18n("progress_11")
    
    return self.progress
  end

  -- 插入车钥匙，车启动
  if self:nextProgress() == index or self:getInteger("car_engine_ready") == 0 then
    self:addPlace("Drive"):markButton("key")
    self:addPlace("Ignition"):markButton("key")
    
    self:textI18n("progress_12")
    
    return self.progress
  end

  -- 放下后排扶手，与小平对话
  if self:nextProgress() == index or self:getInteger("first_seeRear") == 0 then
    local place = self:addPlace("OutRightRear")

    place:imageOn("OutRightRear/12")
    place:markButton("seeLeft")

    self:addPlace("SeeLeft"):markButton("seeRear")
    self:addPlace("SeeRear"):markButton("open")

    self:textI18n("progress_8")

    return self.progress
  end

  -- 用备用钥匙解锁手套箱
  if self:nextProgress() == index or self:getInteger("glovebox_open") == 0 then
    local place = self:addPlace("OutLeftFront")
    
    place:imageOn("OutLeftFront/13", 320, 64)
    place:markButton("drive")
    
    self:addPlace("Drive"):markButton("glovebox")
    self:addPlace("Glovebox"):markButton("hole")
    
    self:textI18n("progress_9")
    
    return self.progress
  end

  -- 打开手套箱，找到粘灯
  if self:nextProgress() == index or self:getInteger("lamp") == 0 then
    self:addPlace("Drive"):markButton("glovebox")
    self:addPlace("Glovebox"):markButton("hole")
    
    self:textI18n("progress_13")
    
    return self.progress
  end

  -- 将粘灯从后备厢通道递给小平，得到小平在后备厢发现的温度计
  if self:nextProgress() == index or self:getInteger("temp") == 0 then
    self:addPlace("SeeRear"):markButton("open")
    
    self:textI18n("progress_14")
    
    return self.progress
  end

  -- 去调仪表时间
  if self:nextProgress() == index or true then
    self:addPlace("Temp")
    self:addPlace("Dashboard")
    
    self:textI18n("progress_15")
    
    return self.progress
  end

  return self:nextProgress()
end

return E7Tip
