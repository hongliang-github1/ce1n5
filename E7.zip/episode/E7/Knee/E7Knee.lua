local E7Knee = class("E7Knee", function()
  return BasePlace.new()
end)

function E7Knee:initPhoto()
  self:addPhoto("1", 512, 256)
  self:addPhoto("2", 960, 576)
  self:addPhoto("3", 832, 512)
end

function E7Knee:initButton()
  self:addButton("open", 544, 312, 1162, 708)
end

function E7Knee:arrowDown(rect)
  self:switchPlaceZoomOut(self.fromPlaceName)
end

function E7Knee:beforeLoad()
  self:imageOn("0")
end

function E7Knee:afterLoad()

end

function E7Knee:afterLoad2()
  self:cacheImage("Drive/0")
end

function E7Knee:beforeUseItem(itemName)
  return false
end

function E7Knee:afterUseItem(itemName)
  return true
end

function E7Knee:open(rect)
  if self:imageIsOn("1") then
    self:play("leftkneeclose")
    self:imageOff("1")
    self:sayI18n("open_1")

    return
  end

  -- 打开左膝盖板
  self:imageOn("1")
  self:play("leftkneeopen")
  self:sayI18n("open_2")
end

return E7Knee
