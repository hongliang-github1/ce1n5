local E7Drive = class("E7Drive", function()
  return BasePlace.new()
end)

function E7Drive:initPhoto()
  self:addPhoto("01", 0, 0)
  self:addPhoto("21", 0, 0)
  self:addPhoto("22", 1408, 256)
  self:addPhoto("23", 1216, 480)
  self:addPhoto("key", 1088, 576)
end

function E7Drive:initButton()
  self:addButton("door", 484, 556, 212, 256)
  self:addButton("dashboard", 874, 354, 302, 180)
  self:addButton("key", 1076, 538, 128, 168)
  self:addButton("cup", 1274, 984, 294, 164)
  self:addButton("glovebox", 1454, 514, 438, 230)
  self:addButton("knee", 698, 510, 174, 166)
end

function E7Drive:arrowLeft(rect)
  -- 从车内出来
  if not self.opened then
    self:play("cardooropeninside")
  end
  
  self:switchPlaceZoomOut("OutLeftFront")
end

function E7Drive:beforeLoad()
  -- 车已经发动了
  if self:getInteger("car_engine_ready") == 1 then
    self:imageOn("20")
    self:imageOn("23")
    self:imageOn("key")
    
    if self:getInteger("car_mirror_lamp") == 1 then
      self:imageOn("22")
    end
    
    return
  end
  
  self:imageOn("0")
end

function E7Drive:afterLoad()
  if "OutLeftFront" == self.lastPlaceName then
    self:sayI18n("afterLoad_1")
  end
end

function E7Drive:afterLoad2()
  self:cacheImage("OutLeftFront/0")
  self:cacheImage("CupFront/0")
  self:cacheImage("Glovebox/0")
end

function E7Drive:beforeUseItem(itemName)
  return false
end

function E7Drive:afterUseItem(itemName)
  return true
end

function E7Drive:door(rect)
  if self.opened then
    self:switchPlaceZoomIn("DoorLeftFront", rect)
    
    return
  end
  
  -- 打开车门
  if self:getInteger("car_engine_ready") == 1 then
    self:imageOn("21")
    
  else
    self:imageOn("01")
  end
  
  self:play("cardooropeninside")
  self:sayI18n("door_1")
  
  self.opened = true
end

function E7Drive:dashboard(rect)
  if self:getInteger("car_engine_ready") > 0 then
    self:switchPlaceZoomIn("Dashboard", rect)
    
  else
    self:sayI18n("dashboard_1")
  end
end

function E7Drive:key(rect)
  self:switchPlaceZoomIn("Ignition", rect)
end

function E7Drive:cup(rect)
  self:switchPlaceZoomIn("CupFront", rect)
end

function E7Drive:glovebox(rect)
  self:switchPlaceZoomIn("Glovebox", rect)
end

function E7Drive:knee(rect)
  self:switchPlaceZoomIn("Knee", rect)
end

return E7Drive
