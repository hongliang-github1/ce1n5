local E7Shock = class("E7Shock", function()
  return BasePlace.new()
end)

function E7Shock:initPhoto()
  self:addPhoto("1", 896, 192)
end

function E7Shock:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E7Shock:beforeLoad()
  self:imageOn("0")
  self:disableAlwaysUseItem()
end

function E7Shock:afterLoad()
  self:click(nil)
end

function E7Shock:beforeUseItem(itemName)
  return false
end

function E7Shock:afterUseItem(itemName)
  return true
end

function E7Shock:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:getItem("shock")
    self:sayI18n("click_3")

    return
  end

  if progress == self:nextProgressIndex() then
      -- 到这里就算通关了，设置通关标记
      userdata.setEpisodePassed(self.episodeName)

      cc.Director:getInstance():replaceScene(BaseScene.create("CreditScene"))

    return
  end
end

return E7Shock
