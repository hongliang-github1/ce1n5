local E7CarDoorNear = class("E7CarDoorNear", function()
  return BasePlace.new()
end)

function E7CarDoorNear:initPhoto()
end

function E7CarDoorNear:initButton()
  self:addButton("click", 642, 368, 446, 390)
end

function E7CarDoorNear:arrowDown(rect)
  self:switchPlaceZoomOut("CarDoor")
end

function E7CarDoorNear:beforeLoad()
  self:imageOn("0")

  self:sayI18n("beforeLoad_1")
end

function E7CarDoorNear:afterLoad()
   -- 标记来过这里，给tip用
  if self:getInteger("car_door_near_seen") < 1 then
    self:setInteger("car_door_near_seen", 1)
  end
end

function E7CarDoorNear:afterLoad2()
  self:cacheImage("CarDoor/0")
end

function E7CarDoorNear:beforeUseItem(itemName)
  if "key2" == itemName then

    return true
  end

  return false
end

function E7CarDoorNear:afterUseItem(itemName)
  if "key2" == itemName then
    -- 跳转到CarDoor走剧情
    self:setInteger("door_opening", 1)
    self:switchPlace("CarDoor")

    return true
  end

  return true
end

function E7CarDoorNear:click(rect)
  self:sayI18n("click_1")
end

return E7CarDoorNear
