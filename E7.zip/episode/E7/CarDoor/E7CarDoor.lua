local E7CarDoor = class("E7CarDoor", function()
  return BasePlace.new()
end)

function E7CarDoor:initPhoto()
  self:addPhoto("11", 1024, 512)
  self:addPhoto("13", 1024, 448)
  self:addPhoto("1", 1024, 512)
  self:addPhoto("20", 0, 0)
  self:addPhoto("21", 0, 0)
  self:addPhoto("2", 1024, 512)
  self:addPhoto("3", 1024, 512)
end

function E7CarDoor:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
  self:addButton("open", 470, 442, 866, 474)
end

function E7CarDoor:arrowDown(rect)
  self:switchPlaceZoomOut("OutLeftFront")
end

function E7CarDoor:beforeLoad()
  self:imageOn("0")

  -- 使用了钥匙，正在开门中，开始走剧情
  if self:getInteger("door_opening") == 1 then
    self:setInteger("door_opening", 0)
    self:imageOn("1")
    self:hideArrowButton()
    self:sayI18n("beforeLoad_1")

    self.isUseKey = true
  end
end

function E7CarDoor:afterLoad()

end

function E7CarDoor:afterLoad2()
  self:cacheImage("OutLeftFront/0")
  self:cacheImage("CarDoorNear/0")
end

function E7CarDoor:beforeUseItem(itemName)
  return false
end

function E7CarDoor:afterUseItem(itemName)
  return true
end

function E7CarDoor:open(rect)
  -- 如果已经打开了，直接返回到外面
  if self:getInteger("car_door_open") == 1 then
    self:onTouchBegan(nil)

    return
  end

  -- 如果没有插入钥匙，点击就直接跳转到CarDoorNear
  if not self.isUseKey then
    self:switchPlaceZoomIn("CarDoorNear", rect)

    return
  end

  -- 如果插入了钥匙
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOff("1")
    self:imageOn("2")
    self:sayI18n("open_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("2")
    self:imageOn("3")
    self:sayI18n("open_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("3")
    self:imageOn("11")
    self:play("carkeyin")
    self:sayI18n("open_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("11")
    self:imageOn("13")
    self:sayI18n("open_4")

    -- 开门动画
    self:disableTouch()
    
    self:scheduleOnce(0.6, function()
      self:imageOff("13")
      self:imageOn("20")

      self:scheduleOnce(0.2, function()
        self:play("cardooropen")
        self:sayI18n("openDelay_1")
        self:setInteger("car_door_open", 1)

        -- 车门打开后把动画过程中用到的图干掉
        self:imageOff("20")
        self:imageOn("21")
        self:enableTouch()
      end)
    end)

    return
  end
end

function E7CarDoor:onTouchBegan(rect)
  if self:getInteger("car_door_open") == 1 then
    self:switchPlaceZoomOut("OutLeftFront")

    return
  end

  if self.isUseKey then
    self:open(self.buttonTable["open"])
  end
end

return E7CarDoor
