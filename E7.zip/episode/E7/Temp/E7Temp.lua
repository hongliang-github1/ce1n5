local E7Temp = class("E7Temp", function()
  return BasePlace.new()
end)

function E7Temp:initPhoto()
  self:addPhoto("1", 908, 270)
  self:addPhoto("2", 834, 560)
end

function E7Temp:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E7Temp:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "OutRear")
end

function E7Temp:beforeLoad()
  self:imageOn("0")
  self:imageOn("1")
  self:imageOn("2")
  
  -- 10-30 : 湿度每格旋转2.2
  -- 30-40 : 湿度每格旋转1.8
  -- 40-50 : 湿度每格旋转1.68
  -- 50-60 : 湿度每格旋转1.6
  
  -- 0-24 : 摄氏度每格旋转2.65度
  
  if not self:imageIsOn("1") then
    self:imageOn("1")
  end
  
  if not self:imageIsOn("2") then
    self:imageOn("2")
  end
  
  local hour    = self:getInteger("temp_hour")
  local minute  = self:getInteger("temp_minute")
  
  -- 摄氏度与湿度旋转的角度
  local h = hour * 2.65
  local m = 0
  
  -- 以下分别为10-30之间的总度数、10-40之间的总度数、10-50之间的总度数
  local m30 = (30 - 10) * 2.2
  local m40 = m30 + ((40 - 30) * 1.8)
  local m50 = m40 + ((50 - 40) * 1.68)
  
  if minute <= 30 then
    m = (minute - 10) * 2.2
    
  elseif minute <= 40 then
    m = m30 + ((minute - 30) * 1.8)
    
  elseif minute <= 50 then
    m = m40 + ((minute - 40) * 1.68)
    
  elseif minute <= 60 then
    m = m50 + ((minute - 50) * 1.6)
  end

  -- 设置图片旋转度数  
  self:imageIsOn("1"):setRotation(h)
  self:imageIsOn("2"):setRotation(m)
end

function E7Temp:afterLoad()
end

function E7Temp:afterLoad2()
end

function E7Temp:beforeUseItem(itemName)
  return false
end

function E7Temp:afterUseItem(itemName)
  return true
end

function E7Temp:click(rect)
  self:say(self.i18nTable["click_1"] .. " (" .. tostring(self:getInteger("temp_hour")) .. ", " .. tostring(self:getInteger("temp_minute")) .. ")")
end

return E7Temp
