local E7AshRear = class("E7AshRear", function()
  return BasePlace.new()
end)

function E7AshRear:initPhoto()
  self:addPhoto("1", 768, 384)
  self:addPhoto("2", 960, 512)
end

function E7AshRear:initButton()
  self:addButton("ash", 808, 394, 552, 514)
end

function E7AshRear:arrowDown(rect)
  self:switchPlaceZoomOut("OutRightRear")
end

function E7AshRear:beforeLoad()
  self:imageOn("0")
end

function E7AshRear:afterLoad()

end

function E7AshRear:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("OutRightRear/0")
end

function E7AshRear:beforeUseItem(itemName)
  return false
end

function E7AshRear:afterUseItem(itemName)
  return true
end

function E7AshRear:ash(rect)
  -- 有道具则拿道具，没有则关上盒子
  if self:imageIsOn("1") then
    if self:getInteger("battery") == 0 then
      self:imageOff("2")
      self:getItem("battery")
      self:sayI18n("ash_1")

      return
    end

    -- 关上盒子
    self:imageOff("1")
    self:play("backrightashclose")
    self:sayI18n("ash_2")

    return
  end

  -- 拉开烟灰盒
  self:imageOn("1")
  self:play("backrightashopen")

  if self:getInteger("battery") == 0 then
    self:imageOn("2")
    self:sayI18n("ash_3")

    return
  end

  self:sayI18n("ash_4")
end

return E7AshRear
