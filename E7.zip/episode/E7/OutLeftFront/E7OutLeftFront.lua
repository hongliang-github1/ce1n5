local E7OutLeftFront = class("E7OutLeftFront", function()
  return BasePlace.new()
end)

function E7OutLeftFront:initPhoto()
  self:addPhoto("10", 832, 0)
  self:addPhoto("13", 320, 64)
  self:addPhoto("1", 448, 128)
  self:addPhoto("23", 320, 64)
end

function E7OutLeftFront:initButton()
  self:addButton("door", 394, 76, 316, 276)
  self:addButton("handle", 1320, 500, 238, 242)
  self:addButton("doorLeftFront", 964, 420, 354, 368, false)
  self:addButton("drive", 1320, 224, 314, 272, false)
  self:addButton("slot", 574, 422, 388, 460, false)
  self:addButton("closeDoor", 292, 420, 268, 638, false)
end

function E7OutLeftFront:arrowRight(rect)
  self:switchPlaceRight("OutLeftRear")
end

function E7OutLeftFront:arrowLeft(rect)
  self:switchPlaceLeft("OutFront")
end

function E7OutLeftFront:beforeLoad()
  -- 如果是车里出来的，门开着
  if "Drive" == self.lastPlaceName or "DoorLeftFront" == self.lastPlaceName or "SlotLeft" == self.lastPlaceName or ("CarDoor" == self.lastPlaceName and self:getInteger("car_door_open") == 1) then
    
    self.opened = true

    if "CarDoor" == self.lastPlaceName and self:getInteger("car_door_open") == 1 then
      -- 刚刚解完车门锁，很兴奋
      self:sayI18n("beforeLoad_1")

    else
      self:sayI18n("beforeLoad_2")
    end

    if self:getInteger("car_engine_ready") == 1 then
      self:imageOn("20")
      self:imageOn("23")

      return
    end

    self:imageOn("0")
    self:imageOn("10")
    self:imageOn("13")

    return
  end

  if self:getInteger("car_engine_ready") == 1 then
    -- 车已经发动了
    self:imageOn("20")

    return
  end

  self:imageOn("0")

  if self:getInteger("car_door_open") == 1 then
    -- 车门已经打开过
    self:imageOn("10")
  end

  if self:getInteger("sucker") == 0 then
    -- 吸盘还没有得到
    self:imageOn("1")
  end
end

function E7OutLeftFront:afterLoad()

end

function E7OutLeftFront:afterLoad2()
  self:cacheImage("OutLeftRear/0")
  self:cacheImage("OutFront/0")
end

function E7OutLeftFront:beforeUseItem(itemName)
  return false
end

function E7OutLeftFront:afterUseItem(itemName)
  return true
end

function E7OutLeftFront:door(rect)
  if self.opened then
    return
  end

  self:switchPlaceZoomIn("Door", rect)
end

function E7OutLeftFront:handle(rect)
  -- 车门已经打开，进入驾驶位
  if self.opened then
    self:drive(self.buttonTable["drive"])

    return
  end

  -- 尝试开车门，判断是否使用过钥匙，如果使用过了，就打开门，否则打不开
  if self:getInteger("car_door_open") == 1 then
    if self:getInteger("car_engine_ready") == 1 then
      self:imageOn("23")

    else
      self:imageOn("13")
    end

    self:play("cardooropen")
    self:sayI18n("handle_1")

    self.opened = true

    return
  end

  -- 如果什么都没有使用，点击跳转到CarDoor界面
  self:switchPlaceZoomIn("CarDoor", rect)
end

function E7OutLeftFront:doorLeftFront(rect)
  if self.opened then
    self:switchPlaceZoomIn("DoorLeftFront", rect)
  end
end

function E7OutLeftFront:drive(rect)
  if self.opened then
    self:switchPlaceZoomIn("Drive", rect)
  end
end

function E7OutLeftFront:slot(rect)
  if self.opened then
    self:switchPlaceZoomIn("SlotLeft", rect)
  end
end

function E7OutLeftFront:closeDoor(rect)
  if self.opened then
    self.opened = false

    if self:getInteger("car_engine_ready") == 1 then
      self:imageOff("23")

    else
      self:imageOff("13")
    end

    self:play("cardoorclose")
    self:sayI18n("closeDoor_1")
  end
end

return E7OutLeftFront
