local E7SeeLeft = class("E7SeeLeft", function()
  return BasePlace.new()
end)

function E7SeeLeft:initPhoto()
  self:addPhoto("1", 512, 256)
end

function E7SeeLeft:initButton()
  self:addButton("seeRear", 596, 324, 314, 602)
  self:addButton("cup", 912, 678, 454, 282)
  self:addButton("goSwitchRight", 220, 286, 280, 270)
end

function E7SeeLeft:arrowDown(rect)
  self:switchPlaceZoomOut("OutRightRear")
end

function E7SeeLeft:beforeLoad()
  self:imageOn("0")

  -- 后座椅打开了
  if self:getInteger("seeRear_open") == 1 then
    self:imageOn("1")
  end
end

function E7SeeLeft:afterLoad()

end

function E7SeeLeft:afterLoad2()
  self:cacheImage("OutRightRear/0")
  self:cacheImage("SeeRear/0")
end

function E7SeeLeft:beforeUseItem(itemName)
  return false
end

function E7SeeLeft:afterUseItem(itemName)
  return true
end

function E7SeeLeft:seeRear(rect)
  self:switchPlaceZoomIn("SeeRear", rect)
end

function E7SeeLeft:cup(rect)
  if self:getInteger("seeRear_open") == 1 then
    self:sayI18n("cup_1")

    return
  end

  self:seeRear(self.buttonTable["seeRear"])
end

function E7SeeLeft:goSwitchRight(rect)
  self:switchPlaceZoomIn("SwitchRight", rect)
end

return E7SeeLeft
