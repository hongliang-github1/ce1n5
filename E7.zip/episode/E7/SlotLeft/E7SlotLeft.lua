local E7SlotLeft = class("E7SlotLeft", function()
  return BasePlace.new()
end)

function E7SlotLeft:initPhoto()
end

function E7SlotLeft:initButton()
end

function E7SlotLeft:arrowDown(rect)
  self:switchPlaceZoomOut("OutLeftFront")
end

function E7SlotLeft:beforeLoad()
  self:imageOn("0")
end

function E7SlotLeft:afterLoad()

end

function E7SlotLeft:afterLoad2()
  self:cacheImage("OutLeftFront/0")
end

function E7SlotLeft:beforeUseItem(itemName)
  return false
end

function E7SlotLeft:afterUseItem(itemName)
  return true
end

return E7SlotLeft
