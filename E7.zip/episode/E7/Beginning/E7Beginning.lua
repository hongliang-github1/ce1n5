local E7Beginning = class("E7Beginning", function()
  return BasePlace.new()
end)

function E7Beginning:initPhoto()
  self:addPhoto("t", 1024, 256)
end

function E7Beginning:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E7Beginning:beforeLoad()
  -- 生成温度计数值
  if userdata.getEpisodeLastPlace(userdata.currentEpisode) == "" then
    local temp_hours = {}
    
    for i = 1, 11 do
      table.insert(temp_hours, i * 2)
    end

    local temp_minutes = {}

    for i = 2, 10 do
      table.insert(temp_minutes, i * 5)
    end
    
    local temp_hour    = temp_hours[math.random(#temp_hours)]
    local temp_minute  = temp_minutes[math.random(#temp_minutes)]

    self:setInteger("temp_hour", temp_hour)
    self:setInteger("temp_minute", temp_minute)
  end

  self:imageOn("x")
end

function E7Beginning:afterLoad()
  self:click(nil)
end

function E7Beginning:afterLoad2()
  self:cacheImage("p")
  self:cacheImage("0")
  self:cacheImage("1")
  self:cacheImage("2")
  self:cacheImage("3")
  self:cacheImage("4")
  self:cacheImage("OutRear/0")
end

function E7Beginning:afterUnload()
  self:cacheImageRemove("x")
  self:cacheImageRemove("p")
  self:cacheImageRemove("0")
  self:cacheImageRemove("1")
  self:cacheImageRemove("2")
  self:cacheImageRemove("3")
  self:cacheImageRemove("4")
end

function E7Beginning:beforeUseItem(itemName)
  return false
end

function E7Beginning:afterUseItem(itemName)
  return true
end

function E7Beginning:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then    
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("p")
    self:sayI18n("click_2")
    
    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("0")
    self:sayI18n("click_3")
        
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_4")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_5")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_6")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_7")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:sayI18n("click_8")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("3")
    self:sayI18n("click_9")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_10")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("4")
    self:sayI18n("click_11")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self.flickerCount  = 0
    self.flickerAction = self:schedule(0.12, function()
      self.flickerCount = self.flickerCount + 1

      if self.flickerCount == 1 then
        -- 预加载说话图片
        self:imageTexture("t")
      end

      if self:imageIsOn("t") then
        self:imageOff("t")

      else
        self:imageOn("t")
      end

      if self.flickerCount > 12 then
        -- 停止闪烁
        self:unschedule(self.flickerAction)
        self:imageOff("t")

        self.flickerAction = nil

        return
      end
    end)
    
    self:sayI18n("click_12")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    -- 轮到自己说话的时候
    if self.flickerAction then
      self:unschedule(self.flickerAction)
      self:imageOff("t")

      self.flickerAction = nil
    end
    
    self:sayI18n("click_13")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_14")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:switchPlaceZoomIn("OutRear", cc.rect(1010, 498, 638, 426))
    
    return
  end
end

return E7Beginning
