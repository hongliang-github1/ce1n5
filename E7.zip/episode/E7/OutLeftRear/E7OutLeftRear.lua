local E7OutLeftRear = class("E7OutLeftRear", function()
  return BasePlace.new()
end)

function E7OutLeftRear:initPhoto()
  self:addPhoto("10", 384, 0)
  self:addPhoto("12", 384, 0)
  self:addPhoto("1", 320, 0)
  self:addPhoto("22", 384, 0)
end

function E7OutLeftRear:initButton()
  self:addButton("slot", 712, 306, 410, 506)
  self:addButton("seeRight", 1136, 138, 408, 496)
  self:addButton("glass", 420, 12, 682, 290, false)
  self:addButton("closeDoor", 422, 306, 282, 546, false)
end

function E7OutLeftRear:arrowLeft(rect)
  self:switchPlaceLeft("OutLeftFront")
end

function E7OutLeftRear:arrowRight(rect)
  self:switchPlaceRight("OutRear")
end

function E7OutLeftRear:beforeLoad()
  -- 如果是车里出来的，门开着
  if "SlotLeftRear" == self.lastPlaceName or "SeeRight" == self.lastPlaceName then
    self.opened = true

    if self:getInteger("car_engine_ready") == 1 then
      self:imageOn("20")
      self:imageOn("22")

      return
    end

    self:imageOn("0")
    self:imageOn("10")
    self:imageOn("12")

    return
  end

  if self:getInteger("car_engine_ready") == 1 then
    -- 车已经发动了
    self:imageOn("20")

    return
  end

  self:imageOn("0")

  if self:getInteger("car_door_open") == 1 then
    -- 车门已经打开过
    self:imageOn("10")
  end

  if self:getInteger("sucker") == 0 then
    -- 吸盘还没有得到
    self:imageOn("1")
  end
end

function E7OutLeftRear:afterLoad()

end

function E7OutLeftRear:afterLoad2()
  self:cacheImage("OutRear/0")

  if self:getInteger("car_engine_ready") == 1 then
    self:cacheImage("OutLeftFront/20")

  else
    self:cacheImage("OutLeftFront/0")
  end
end

function E7OutLeftRear:beforeUseItem(itemName)
  return false
end

function E7OutLeftRear:afterUseItem(itemName)
  return true
end

function E7OutLeftRear:slot(rect)
  if self.opened then
    self:switchPlaceZoomIn("SlotLeftRear", rect)

    return
  end

  self:switchPlaceLeft("OutLeftFront")
end

function E7OutLeftRear:glass(rect)
  if self.opened then
    return
  end

  self:switchPlaceLeft("OutLeftFront")
end

function E7OutLeftRear:seeRight(rect)
  -- 车门还没解锁
  if self:getInteger("car_door_open") <= 0 then
    self:sayI18n("seeRight_2")

    return
  end

  -- 车门已经打开之后，直接进入
  if self.opened then
    self:switchPlaceZoomIn("SeeRight", rect)

    return
  end

  -- 开车门
  if self:getInteger("car_engine_ready") == 1 then
    self:imageOn("22")

  else
    self:imageOn("12")
  end

  self:play("cardooropen")
  self:sayI18n("seeRight_3")

  self.opened = true
end

function E7OutLeftRear:closeDoor(rect)
  if self.opened then
    self.opened = false

    if self:getInteger("car_engine_ready") == 1 then
      self:imageOff("22")

    else
      self:imageOff("12")
    end

    self:play("cardoorclose")
    self:sayI18n("closeDoor_1")

    return
  end

  self:switchPlaceLeft("OutLeftFront")
end

return E7OutLeftRear
