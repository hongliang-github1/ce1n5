local E7SwitchTrunk = class("E7SwitchTrunk", function()
  return BasePlace.new()
end)

function E7SwitchTrunk:initPhoto()
  self:addPhoto("1", 896, 576)
end

function E7SwitchTrunk:initButton()
  self:addButton("click", 844, 374, 400, 416)
end

function E7SwitchTrunk:arrowDown(rect)
  self:switchPlaceZoomOut("DoorLeftFront")
end

function E7SwitchTrunk:beforeLoad()
  self:imageOn("0")
end

function E7SwitchTrunk:afterLoad()

end

function E7SwitchTrunk:afterLoad2()
  self:cacheImage("DoorLeftFront/0")
end

function E7SwitchTrunk:beforeUseItem(itemName)
  return false
end

function E7SwitchTrunk:afterUseItem(itemName)
  return true
end

function E7SwitchTrunk:click(rect)
  self:disableTouch()
  self:imageOn("1")
  self:sayI18n("click_1")

  self:scheduleOnce(0.7, function()
    self:imageOff("1")
    self:sayI18n("switchImage_1")

    self:enableTouch()
  end)
end

return E7SwitchTrunk
