local E7Glovebox = class("E7Glovebox", function()
  return BasePlace.new()
end)

function E7Glovebox:initPhoto()
  self:addPhoto("11", 640, 704)
  self:addPhoto("12", 832, 640)
  self:addPhoto("13", 512, 704)
  self:addPhoto("14", 512, 640)
  self:addPhoto("15", 960, 448)
  self:addPhoto("1", 512, 448)
  self:addPhoto("20", 256, 320)
  self:addPhoto("21", 896, 320)
  self:addPhoto("22", 896, 320)
  self:addPhoto("2", 512, 448)
  self:addPhoto("16", 768, 448)
end

function E7Glovebox:initButton()
  self:addButton("hole", 402, 372, 460, 538)
  self:addButton("close", 310, 914, 1678, 222, false)
  self:addButton("getItem", 864, 660, 600, 218, false)
end

function E7Glovebox:openGlovebox()
  self:imageOn("10")
  self:play("gloveopen")

  if self:getInteger("lamp") == 0 then
    -- 粘灯
    self:imageOn("12")
  end

  self:sayI18n("openGlovebox_1")
end

function E7Glovebox:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E7Glovebox:beforeLoad()
  self:imageOn("0")
end

function E7Glovebox:afterLoad()
end

function E7Glovebox:afterLoad2()
  self:cacheImage("Lamp/0")
  self:cacheImage("Lamp/1")
  self:cacheImage("Drive/0")
end

function E7Glovebox:beforeUseItem(itemName)
  if "key2" == itemName and self:getInteger("glovebox_open") == 0 then
    return true
  end

  return false
end

function E7Glovebox:afterUseItem(itemName)
  if "key2" == itemName then
    self:imageOn("1")
    self:play("glovekeyin")
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E7Glovebox:hole(rect)
  -- 已经插入钥匙之后
  if self:imageIsOn("1") then
    self:imageOn("2")
    self:imageOff("1")
    self:play("glovekeyturn")
    self:sayI18n("hole_1")

    return
  end

  -- 拿掉钥匙，直接打开手套箱
  if self:imageIsOn("2") then
    self:imageOff("2")
    self:voidItem("key2")
    self:setInteger("glovebox_open", 1)
    self:openGlovebox()

    return
  end

  -- 手套箱还没有被钥匙打开过
  if self:getInteger("glovebox_open") == 0 then
    self:sayI18n("hole_2")

    return
  end

  -- 已经用钥匙解锁过后，直接打开手套箱
  if not self:imageIsOn("10") then
    self:openGlovebox()

    return
  end

  -- 手套箱打开后的时候，点击此按钮区域，执行getItem区域相同的作用
  self:getItem(self.buttonTable["getItem"])
end

function E7Glovebox:getItem(rect)
  if self:imageIsOn("0") then
    -- 手套箱还没有打开，什么都不做
    return
  end

  if self:getInteger("lamp") == 0 then
    -- 粘灯
    self:imageOff("12")
    self:switchPlace("Lamp")

    return
  end

  self:sayI18n("getItem_2")
end

function E7Glovebox:close(rect)
  if self:imageIsOn("0") then
    -- 手套箱还没有打开，什么都不做
    return
  end

  -- 关上手套箱，为了防止图片没有移除，这里全部imageOff一下
  self:imageOff("11")
  self:imageOff("12")
  self:imageOff("13")
  self:imageOff("14")
  self:imageOff("15")
  self:imageOff("16")
  self:imageOff("20")
  self:imageOff("21")
  self:imageOff("22")
  self:imageOn("0")
  self:play("gloveclose")
  self:sayI18n("close_1")
end

return E7Glovebox
