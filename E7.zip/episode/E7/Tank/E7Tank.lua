local E7Tank = class("E7Tank", function()
  return BasePlace.new()
end)

function E7Tank:initPhoto()
  self:addPhoto("1", 1088, 0)
  self:addPhoto("2", 704, 384)
  self:addPhoto("3", 704, 256)
  self:addPhoto("4", 704, 320)
  self:addPhoto("5", 704, 320)
  self:addPhoto("6", 704, 320)
  self:addPhoto("7", 704, 320)
  self:addPhoto("8", 704, 256)
  self:addPhoto("9", 768, 448)
end

function E7Tank:initButton()
  self:addButton("close", 1268, 312, 440, 674, false)
  self:addButton("open", 724, 312, 540, 674)
end

function E7Tank:arrowDown(rect)
  self:switchPlaceZoomOut("OutRightRear")
end

function E7Tank:beforeLoad()
  self:imageOn("0")

  if self:getInteger("car_door_open") == 1 then
    self:imageOn("1")
  end

  if self:getInteger("car_tank_open") == 1 then
    self:imageOn("2")
  end
end

function E7Tank:afterLoad()
end

function E7Tank:afterLoad2()
  self:cacheImage("3")
  self:cacheImage("4")
  self:cacheImage("5")
  self:cacheImage("8")
  self:cacheImage("OutRightRear/0")
end

function E7Tank:beforeUseItem(itemName)
  if "sucker" == itemName then
    return true
  end

  return false
end

function E7Tank:afterUseItem(itemName)
  if "sucker" == itemName then
    self:imageOn("4")
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E7Tank:open(rect)
  if self:imageIsOn("9") then
    self:imageOff("9")
    self:getItem("key1")
    self:sayI18n("open_4")
  end

  if self:getInteger("car_tank_open") == 1 then
    -- 打开盖子
    self:imageOn("3")
    self:imageOff("2")

    if self:getInteger("key1") == 0 then
      self:imageOn("9")
    end

    self:play("oiltanklidopen")
    self:sayI18n("tankOpen_1")

    return
  end

  if self.openWaiting == true then
    self:imageOn("3")
    self:imageOn("9")
    self:play("oiltanklidopen")
    self:sayI18n("openDelay_1")
    self:voidItem("sucker")
    self:setInteger("car_tank_open", 1)

    self.openWaiting = false

    return
  end

  if self:imageIsOn("4") then
    self:imageOn("5")
    self:imageOff("4")
    self:play("sucker")
    self:sayI18n("open_2")

    self.openWaiting = true

    return
  end

  if self:imageIsOn("3") or self:imageIsOn("8") then
    -- 有道具则拿，没道具就关
    if self:getInteger("key1") == 0 then
      self:imageOff("9")
      self:getItem("key1")
      self:sayI18n("open_4")

      return
    end

    self:sayI18n("open_5")

    return
  end

  self:sayI18n("open_3")
end

function E7Tank:close(rect)
  if self:imageIsOn("3") or self:imageIsOn("8") then
    self:imageOff("3")
    self:imageOff("8")
    self:imageOff("4")
    self:imageOff("5")
    self:imageOn("2")
    self:play("oiltanklidclose")
    self:sayI18n("tankOpen_2")
  end
end

return E7Tank
