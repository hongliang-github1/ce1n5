local E7Lamp = class("E7Lamp", function()
  return BasePlace.new()
end)

function E7Lamp:initPhoto()
end

function E7Lamp:initButton()
  self:addButton("click", 766, 278, 516, 584, false)
end

function E7Lamp:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "OutRear")
end

function E7Lamp:beforeLoad()
  self:imageOn("0")
  self:hideArrowButton()
  self:disableAlwaysUseItem()
end

function E7Lamp:afterLoad()
  self:click(nil)
end

function E7Lamp:afterLoad2()
end

function E7Lamp:beforeUseItem(itemName)
  return false
end

function E7Lamp:afterUseItem(itemName)
  return true
end

function E7Lamp:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:showArrowButton()
    self:imageOn("0")
    self:getItem("lamp")
    self:sayI18n("click_3")

    return
  end
end

return E7Lamp
