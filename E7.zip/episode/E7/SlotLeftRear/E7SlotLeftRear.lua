local E7SlotLeftRear = class("E7SlotLeftRear", function()
  return BasePlace.new()
end)

function E7SlotLeftRear:initPhoto()
end

function E7SlotLeftRear:initButton()
  self:addButton("nothing", 1058, 454, 436, 450)
  self:addButton("slot", 320, 712, 736, 414)
end

function E7SlotLeftRear:arrowDown(rect)
  self:switchPlaceZoomOut("OutLeftRear")
end

function E7SlotLeftRear:beforeLoad()
  self:imageOn("0")
end

function E7SlotLeftRear:afterLoad()

end

function E7SlotLeftRear:afterLoad2()
  self:cacheImage("OutLeftRear/0")
end

function E7SlotLeftRear:beforeUseItem(itemName)
  return false
end

function E7SlotLeftRear:afterUseItem(itemName)
  return true
end

function E7SlotLeftRear:nothing(rect)
  self:sayI18n("nothing_1")
end

function E7SlotLeftRear:slot(rect)
  self:sayI18n("slot_1")
end

return E7SlotLeftRear
