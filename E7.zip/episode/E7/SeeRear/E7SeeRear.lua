local E7SeeRear = class("E7SeeRear", function()
  return BasePlace.new()
end)

function E7SeeRear:initPhoto()
  self:addPhoto("1", 640, 128)
  self:addPhoto("2", 640, 128)
  self:addPhoto("3", 640, 128)
  self:addPhoto("4", 640, 128)
  self:addPhoto("5", 640, 128)
  self:addPhoto("6", 640, 128)
  self:addPhoto("7", 640, 128)
  self:addPhoto("t", 704, 192)
end

function E7SeeRear:initButton()
  self:addButton("open", 794, 62, 578, 816)
end

function E7SeeRear:arrowLeft(rect)
  self:switchPlaceZoomOut("SeeLeft")
end

function E7SeeRear:arrowRight(rect)
  self:switchPlaceZoomOut("SeeRight")
end

function E7SeeRear:beforeLoad()
  self.firstProgress  = 0
  self.normalProgress = 0
  self.lampProgress   = 0

  self:imageOn("0")

  if self:getInteger("seeRear_open") == 1 then
    self:imageOn("2")

    self.open1 = true
    self.open2 = true

    -- 第二层已经打开，开始走剧情
    if self:getInteger("xp_props") == 1 then
      -- 已经从小平这里得到了道具
      self.lampProgress = 2

      return
    end
  end
end

function E7SeeRear:afterLoad()
  -- 根据不同的状态给不同的对话
  if self:getInteger("first_seeRear") == 0 then
    -- 第一次来到这里
    self:sayTip()
    self:sayI18n("afterLoad_1")

    return
  end

function E7SeeRear:afterLoad2()
  self:cacheImage("SeeLeft/0")
  self:cacheImage("SeeRight/0")
end

  -- 不管扶手是不是打开的，都先给出小平催促的声音
  self:sayTip()

  if self:imageIsOn("2") then
    self:sayI18n("afterLoad_2")

  else
    self:sayI18n("afterLoad_3")
  end
end

function E7SeeRear:afterLoad2()
  self:cacheImage("SeeLeft/0")
  self:cacheImage("SeeRight/0")
end

function E7SeeRear:beforeUnload()
end

function E7SeeRear:beforeUseItem(itemName)
  if "lamp" == itemName and self:imageIsOn("3") then
    -- 当小平伸出手的时候，才可以使用粘灯
    return not self.lampUsed
  end

  return false
end

function E7SeeRear:afterUseItem(itemName)
  if "lamp" == itemName then
    self:imageOn("4")
    self:imageOff("3")
    self:sayI18n("afterUseItem_1")

    self.lampUsed = true

    self:hideArrowButton()

    return true
  end

  return true
end

function E7SeeRear:open(rect)
  -- 第一次来到这里
  if self:getInteger("first_seeRear") == 0 then
    self:firstPlot()

    return
  end

  if not self.open1 then
    self.open1 = true

    self:imageOn("1")
    self:play("backarmclose")
    self:sayI18n("handleOpen_1")

    return
  end

  if not self.open2 then
    self.open2 = true

    self:imageOn("2")
    self:imageOff("1")
    self:play("backarmtwicedown")
    self:sayI18n("handleOpen_2")

    -- 记录后座椅挡板打开了
    self:setInteger("seeRear_open", 1)

    -- 只要挡板打开，小平就是不生气的
    self.angry = false

    if self:getInteger("xp_props") == 1 then
      -- 已经从小平这里得到了道具
      self.lampProgress = 2
    end

    return
  end

  -- 以下为根据状态走不同的剧情
  if self.lampUsed then
    -- 已经使用了粘灯
    self:lampAfter()

    return
  end

  if self.open2 then
    -- 第二层已经打开，开始走剧情
    if self:getInteger("xp_props") == 1 then
      -- 已经从小平这里得到了道具
      self:lampAfter()

      return
    end

    if self:getInteger("xp_tip") == 1 then
      -- 得到小平要灯的提示了
      self:lampTip()

      return
    end

    -- 第一次过来，正常情况下走情节
    self:normalPlot()

    return
  end

  if self.open1 then
    -- 已经打开了第一层了
    self:sayI18n("open_1")

    return
  end

  if self.angry then
    -- 已经触发了小平生气情节
    self:angryPlot()

    return
  end

  self:sayI18n("open_2")
end

function E7SeeRear:firstPlot()
  self.firstProgress = self.firstProgress + 1

  if self.firstProgress == 1 then
    self:stopTip()
    self:sayI18n("firstPlot_1")

    return
  end

  if self.firstProgress == 2 then
    self:sayTip()
    self:sayI18n("firstPlot_2")

    return
  end

  if self.firstProgress == 3 then
    self:stopTip()
    self:sayI18n("firstPlot_3")

    -- 这里记录与小平结束了第一次对话
    self:setInteger("first_seeRear", 1)

    return
  end
end

function E7SeeRear:normalPlot()
  self.normalProgress = self.normalProgress + 1

  if self.normalProgress == 1 then
    self:sayI18n("normalPlot_1")

    return
  end

  if self.normalProgress == 2 then
    self:sayTip()
    self:sayI18n("normalPlot_2")

    return
  end

  if self.normalProgress == 3 then
    self:stopTip()
    self:sayI18n("normalPlot_3")

    return
  end

  if self.normalProgress == 4 then
    self:sayTip()
    self:sayI18n("normalPlot_4")

    return
  end

  if self.normalProgress == 5 then
    self:stopTip()
    self:sayI18n("normalPlot_5")

    return
  end

  if self.normalProgress == 6 then
    -- 小平伸出手，要粘灯
    self:imageOn("3")
    self:sayTip()
    self:sayI18n("normalPlot_6")

    return
  end

  if self.normalProgress == 7 then
    self:stopTip()

    -- 还没有灯的时候
    if self:getInteger("lamp") == 0 then
      self:sayI18n("normalPlot_7")

      return
    end

    -- 等待使用粘灯
    self.normalProgress = self.normalProgress - 1

    self:sayTip()
    self:sayI18n("normalPlot_8")

    return
  end

  if self.normalProgress == 8 then
    self:stopTip()

    self:imageOff("3")
    self:sayTip()
    self:sayI18n("normalPlot_9")

    -- 记录得到小平需要粘灯的提示
    self:setInteger("xp_tip", 1)

    return
  end
end

function E7SeeRear:lampTip()
  self.normalProgress = self.normalProgress + 1

  if self.normalProgress == 1 then
    if self:getInteger("lamp") == 0 then
      -- 还没找到灯，得到小平的催促
      self.normalProgress = self.normalProgress - 1

      self:sayTip()
      self:sayI18n("lampTip_1")

      return
    end

    self:sayI18n("lampTip_2")

    return
  end

  if self.normalProgress == 2 then
    -- 伸出手，等待使用粘灯
    self:imageOn("3")
    self:sayTip()
    self:sayI18n("lampTip_3")

    return
  end
end

function E7SeeRear:lampAfter()
  self.lampProgress = self.lampProgress + 1

  if self.lampProgress == 1 then
    self:imageOff("4")
    self:sayTip()
    self:sayI18n("lampAfter_1")

    self:stopTip()
    self:disableTouch()

    -- 黑屏，显示过一会儿
    self:effectFadeBlack("afterWhile", 2, 3, 2, function()
      if self:getInteger("temp") == 0 then
        self:imageOn("6")
      end

      self:sayTip()
      self:sayI18n("lampAfter_2")
      
      self:enableTouch()
    end)


    return
  end

  if self.lampProgress == 2 then
    -- 记录已经从小平这里得到了道具
    self:setInteger("xp_props", 1)
    self:voidItem("lamp")
    self:showArrowButton()

    -- 拿小平给的道具
    if self:getInteger("temp") == 0 then
      self:imageOff("6")
      self:getItem("temp")

      return
    end

    return
  end

  -- 得到道具之后
  if self.lampProgress == 3 then
    self:stopTip()

    self:sayTip()
    self:sayI18n("lampAfter_4")

    return
  end

  if self.lampProgress == 4 then
    self:stopTip()
    self:sayI18n("lampAfter_5")

    self.lampProgress = 2

    return
  end
end

function E7SeeRear:angryPlot()
  self:sayTip()
  self:sayI18n("angryPlot_1")
end

function E7SeeRear:sayTip()
  -- 小平说话的时候
  self.flikerAction = self:scheduleTimes(0.12, 12, function(index)
    if index == 1 then
      -- 预加载说话图片
      self:imageTexture("t")
    end

    if self:imageIsOn("t") then
      self:imageOff("t")

    else
      self:imageOn("t")
    end
  end)
end

function E7SeeRear:stopTip()
  -- 轮到自己说话的时候
  self:unschedule(self.flikerAction)
  self:imageOff("t")
end

return E7SeeRear
