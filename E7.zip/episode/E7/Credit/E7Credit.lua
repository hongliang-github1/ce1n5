local E7Credit = class("E7Credit", function()
  return BaseCredit.new()
end)

function E7Credit:afterCreate()
  -- 构造滚动字幕
  self:addLabelI18n(1.1, "beforeLoad_1")
  
  -- 显示通关时间
  -- NSString *timingString  = [self timingString]
  -- NSString *labelStr    = UikitEnhancement:textByI18nDict("beforeLoad_2")
  
  -- self:addLabelI18n(1, [labelStr stringByAppendingFormat:"%@", timingString)]
  
  self:addLabelI18n(1, "beforeLoad_3")
  
  self:addBlank()
  
  self:addLabelI18n(1, "beforeLoad_4")
  
  self:addImage("cc")
  
  self:addBlank()
  
  self:addLabelI18n(1, "beforeLoad_5")
  
  self:addImage("ping")
  
  if "chs" == i18n.getLang() then
    self:addLabel(1, "感谢 @韩路- 和 @胡永平- 等好朋友的大力帮助！")
  end
  
  self:addBlank()
  
  self:addLabelI18n(1, "beforeLoad_6")
  
  self:addLabelI18n(1, "beforeLoad_7")
    
  self:addBlank()
  
  self:playMusic("credit")
end

return E7Credit
