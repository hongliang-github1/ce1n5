local E7CupFront = class("E7CupFront", function()
  return BasePlace.new()
end)

function E7CupFront:initPhoto()
  self:addPhoto("10", 192, 384)
  self:addPhoto("11", 640, 576)
  self:addPhoto("12", 576, 512)
  self:addPhoto("20", 832, 0)
  self:addPhoto("21", 1344, 384)
  self:addPhoto("22", 1344, 384)
  self:addPhoto("23", 1344, 384)
  self:addPhoto("24", 1408, 512)
  self:addPhoto("25", 1280, 448)
  self:addPhoto("26", 1024, 320)
  self:addPhoto("30", 0, 0)
  self:addPhoto("32", 576, 512)
end

function E7CupFront:initButton()
  self:addButton("cup", 166, 286, 728, 800)
  self:addButton("arm", 898, 40, 1146, 894)
end

function E7CupFront:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E7CupFront:beforeLoad()
  self:imageOn("0")
end

function E7CupFront:afterLoad()
end

function E7CupFront:afterLoad2()
  self:cacheImage("Drive/0")
end

function E7CupFront:beforeUseItem(itemName)
  return false
end

function E7CupFront:afterUseItem(itemName)
  return true
end

function E7CupFront:cup(rect)
  if self:imageIsOn("10") then
    if self:getInteger("screwdriver") == 0 then
      self:imageOff("11")
      self:getItem("screwdriver")
      self:sayI18n("cup_1")

      return
    end

    -- 关上杯架
    self:imageOff("10")
    self:play("frontcupholderclose")
    self:sayI18n("cup_2")

    return
  end

  -- 打开杯架
  self:imageOn("10")
  self:play("frontcupholderclose")

  if self:getInteger("screwdriver") == 0 then
    self:imageOn("11")
    self:sayI18n("cup_3")

    return
  end

  self:sayI18n("cup_4")
end

function E7CupFront:arm(rect)
  self:sayI18n("arm_1")
  
  return
end

return E7CupFront
