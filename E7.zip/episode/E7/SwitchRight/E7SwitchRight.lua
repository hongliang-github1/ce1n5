local E7SwitchRight = class("E7SwitchRight", function()
  return BasePlace.new()
end)

function E7SwitchRight:initPhoto()
end

function E7SwitchRight:initButton()
  self:addButton("click", 356, 170, 736, 580)
end

function E7SwitchRight:arrowDown(rect)
  self:switchPlaceZoomOut("SeeLeft")
end

function E7SwitchRight:beforeLoad()
  self:imageOn("0")
end

function E7SwitchRight:afterLoad()

end

function E7SwitchRight:afterLoad2()
  self:cacheImage("SeeLeft/0")
end

function E7SwitchRight:beforeUseItem(itemName)
  return false
end

function E7SwitchRight:afterUseItem(itemName)
  return true
end

function E7SwitchRight:click(rect)
  self:sayI18n("click_1")
end

return E7SwitchRight
