local E7Ending = class("E7Ending", function()
  return BasePlace.new()
end)

function E7Ending:initPhoto()
end

function E7Ending:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E7Ending:oneDelay()
  self:imageOn("3")
  self:sayI18n("oneDelay_1")
  self.plot = 1
end

function E7Ending:beforeLoad()
  self.onePlotProgress   = 0
  self.twoPlotProgress   = 0
  self.threePlotProgress = 0

  self:imageOn("0")
end

function E7Ending:afterLoad()
  -- 开始动画
  self:hideArrowButton()
  self:play("trunkopen")
  self:oneDelay()
end

function E7Ending:afterLoad2()
  self:cacheImage("3")
  self:cacheImage("18")
  self:cacheImage("21")
  self:cacheImage("shock")
  self:cacheImage("Shock/0")
end

function E7Ending:beforeUseItem(itemName)
  return false
end

function E7Ending:afterUseItem(itemName)
  return true
end

function E7Ending:click(rect)
  -- 根据进度走不同的情节
  if self.plot == 1 then
    self:onePlot()

  elseif self.plot == 2 then
    self:twoPlot()

  else
    self:threePlot()
  end
end

function E7Ending:onePlot()
  self.onePlotProgress = self.onePlotProgress + 1

  if self.onePlotProgress == 1 then
    self:sayI18n("onePlot_1")

    return
  end

  if self.onePlotProgress == 2 then
    self:sayI18n("onePlot_2")

    return
  end

  if self.onePlotProgress == 3 then
    self:sayI18n("onePlot_3")

    return
  end

  if self.onePlotProgress == 4 then
    self:say("")

    -- 接着走动画
    self:twoDelay()

    return
  end
end

function E7Ending:twoDelay()
  self:imageOn("18")
  self:imageOff("3")
  self:sayI18n("twoDelay_1")
  self.plot = 2
end

function E7Ending:twoPlot()
  self.twoPlotProgress = self.twoPlotProgress + 1

  if self.twoPlotProgress == 1 then
    self:sayI18n("twoPlot_1")

    return
  end

  if self.twoPlotProgress == 2 then
    self:sayI18n("twoPlot_2")

    -- 接着走动画
    self:threeDelay()

    return
  end
end

function E7Ending:threeDelay()
  self:imageOn("21")
  self:imageOff("18")
  self:sayI18n("threeDelay_1")
  self.plot = 3
end

function E7Ending:threePlot()
  self.threePlotProgress = self.threePlotProgress + 1

  if self.threePlotProgress == 1 then
    self:sayI18n("threePlot_1")

    return
  end

  if self.threePlotProgress == 2 then
    self:sayI18n("threePlot_2")

    return
  end

  if self.threePlotProgress == 3 then
    self:sayI18n("threePlot_3")

    return
  end

  if self.threePlotProgress == 4 then
    self:imageOff("21")
    self:imageOn("shock")
    self:sayI18n("threePlot_4")

    return
  end

  if self.threePlotProgress == 5 then
    self:switchPlace("Shock")

    return
  end
end

return E7Ending
