local E7OutFront = class("E7OutFront", function()
  return BasePlace.new()
end)

function E7OutFront:initPhoto()
  self:addPhoto("21", 384, 256)
  self:addPhoto("22", 384, 0)
  self:addPhoto("31", 384, 256)
  self:addPhoto("32", 384, 0)
end

function E7OutFront:initButton()
end

function E7OutFront:arrowLeft(rect)
  self:switchPlaceLeft("OutRightFront")
end

function E7OutFront:arrowRight(rect)
  self:switchPlaceRight("OutLeftFront")
end

function E7OutFront:beforeLoad()
  self:sayI18n("beforeLoad_1")

  self:imageOn("0")
end

function E7OutFront:afterLoad()
end

function E7OutFront:afterLoad2()
  self:cacheImage("OutRightFront/0")
  self:cacheImage("OutLeftFront/0")
end

function E7OutFront:beforeUseItem(itemName)
  return false
end

function E7OutFront:afterUseItem(itemName)
  return true
end

return E7OutFront
