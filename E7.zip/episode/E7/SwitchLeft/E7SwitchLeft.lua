local E7SwitchLeft = class("E7SwitchLeft", function()
  return BasePlace.new()
end)

function E7SwitchLeft:initPhoto()
end

function E7SwitchLeft:initButton()
  self:addButton("click", 996, 404, 588, 460)
end

function E7SwitchLeft:arrowDown(rect)
  self:switchPlaceZoomOut("SeeRight")
end

function E7SwitchLeft:beforeLoad()
  self:imageOn("0")
end

function E7SwitchLeft:afterLoad()

end

function E7SwitchLeft:afterLoad2()
  self:cacheImage("SeeRight/0")
end

function E7SwitchLeft:beforeUseItem(itemName)
  return false
end

function E7SwitchLeft:afterUseItem(itemName)
  return true
end

function E7SwitchLeft:click(rect)
  self:sayI18n("click_1")
end

return E7SwitchLeft
