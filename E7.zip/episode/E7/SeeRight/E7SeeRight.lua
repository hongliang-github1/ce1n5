local E7SeeRight = class("E7SeeRight", function()
  return BasePlace.new()
end)

function E7SeeRight:initPhoto()
  self:addPhoto("10", 512, 128)
end

function E7SeeRight:initButton()
  self:addButton("cup", 676, 644, 470, 216, false)
  self:addButton("seeRear", 1112, 262, 250, 380)
  self:addButton("goSwitchLeft", 1374, 260, 250, 202)
end

function E7SeeRight:arrowDown(rect)
  self:switchPlaceZoomOut("OutLeftRear")
end

function E7SeeRight:beforeLoad()
  self:imageOn("0")

  -- 后座椅打开了
  if self:getInteger("seeRear_open") == 1 then
    self:imageOn("10")
  end
end

function E7SeeRight:afterLoad()

end

function E7SeeRight:afterLoad2()
  self:cacheImage("OutLeftRear/0")
  self:cacheImage("SeeRear/0")
end

function E7SeeRight:beforeUseItem(itemName)
  return false
end

function E7SeeRight:afterUseItem(itemName)
  return true
end

function E7SeeRight:cup(rect)
  if self:getInteger("seeRear_open") == 1 then
    self:sayI18n("cup_1")

    return
  end

  self:seeRear(self.buttonTable["seeRear"])
end

function E7SeeRight:seeRear(rect)
  self:switchPlaceZoomIn("SeeRear", rect)
end

function E7SeeRight:goSwitchLeft(rect)
  self:switchPlaceZoomIn("SwitchLeft", rect)
end

return E7SeeRight
