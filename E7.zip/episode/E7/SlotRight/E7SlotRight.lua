local E7SlotRight = class("E7SlotRight", function()
  return BasePlace.new()
end)

function E7SlotRight:initPhoto()
end

function E7SlotRight:initButton()
  self:addButton("slot", 448, 426, 1008, 522)
end

function E7SlotRight:arrowDown(rect)
  self:switchPlaceZoomOut("OutRightFront")
end

function E7SlotRight:beforeLoad()
  self:imageOn("0")
end

function E7SlotRight:afterLoad()

end

function E7SlotRight:afterLoad2()
  self:cacheImage("OutRightFront/0")
end

function E7SlotRight:beforeUseItem(itemName)
  return false
end

function E7SlotRight:afterUseItem(itemName)
  return true
end

function E7SlotRight:slot(rect)
  self:sayI18n("slot_1")
end

return E7SlotRight
