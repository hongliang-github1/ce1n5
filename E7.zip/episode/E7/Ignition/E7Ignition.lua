local E7Ignition = class("E7Ignition", function()
  return BasePlace.new()
end)

function E7Ignition:initPhoto()
  self:addPhoto("1", 576, 0)
  self:addPhoto("3", 1280, 576)
  self:addPhoto("4", 1280, 576)
  self:addPhoto("5", 1280, 576)
  self:addPhoto("6", 1280, 576)
end

function E7Ignition:initButton()
  self:addButton("key", 1196, 444, 570, 672)
end

function E7Ignition:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E7Ignition:beforeLoad()
  self:imageOn("0")

  if self:getInteger("car_engine_ready") > 0 then
    self:imageOn("1")

    -- 如果钥匙还在点火装置中插着
    if self:getInteger("key1") < 0 then
      self:imageOn("6")
    end
  end
end

function E7Ignition:afterLoad()
end

function E7Ignition:afterLoad2()
  self:cacheImage("Drive/0")
end

function E7Ignition:beforeUseItem(itemName)
  if "key1" == itemName then
    return not self.isPullOut and not self.keyUsed
  end

  return false
end

function E7Ignition:afterUseItem(itemName)
  if "key1" == itemName then
    -- 插入钥匙动画
    self:play("carkeyplate")
    self:disableTouch()

    self:scheduleTimes(0.2, 3, function(index)
      if index == 1 then
        self:imageOn("4")

        return
      end

      if index == 2 then
        if self:imageIsOn("4") then
          self:imageOn("5")
          self:imageOff("4")
        end

        return
      end

      if index == 3 then
        if self:imageIsOn("5") then
          self:imageOn("6")
          self:imageOff("5")
        end

        if self:getInteger("battery") >= 0 then
          self.isPullOut = true

          self:noPower()

        else
          self:setInteger("car_engine_ready", 1)
          self:imageOn("1")
          self:voidItem("key1")
          self:sayI18n("key_1")
        end

        self:enableTouch()

        return
      end
    end)

    return true
  end

  return true
end

function E7Ignition:key(rect)
  -- 车已经启动
  if self:getInteger("car_engine_ready") > 0 then
    self:sayI18n("key_1")

    return
  end

  if self.isPullOut then
    self:noPower()

    return
  end

  self:sayI18n("key_2")
end

function E7Ignition:onTouchBegan(touch, event)
  -- 专供钥匙没电的时候走失败的剧情使用
  if self.isPullOut then
    self:noPower()

    return
  end
end

function E7Ignition:noPower()
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:hideArrowButton()
    self:sayI18n("noPower_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("noPower_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("noPower_3")

    return
  end

  if progress == self:nextProgressIndex() then
    -- 结束对话
    -- 拔出钥匙动画
    self:showArrowButton()
    self:play("carkeyplate")
    self:disableTouch()

    self:scheduleTimes(0.2, 3, function(index)
      if index == 1 then
        if self:imageIsOn("6") then
          self:imageOn("5")
          self:imageOff("6")
        end

        return
      end

      if index == 2 then
        if self:imageIsOn("5") then
          self:imageOn("4")
          self:imageOff("5")
        end

        return
      end

      if index == 3 then
        if self:imageIsOn("4") then
          self:imageOn("3")
          self:imageOff("4")
        end

        self:sayI18n("pullOut_1")
        self.isPullOut = false
        self.keyUsed   = true
        self:enableTouch()

        return
      end
    end)

    return
  end

  return true
end

return E7Ignition
