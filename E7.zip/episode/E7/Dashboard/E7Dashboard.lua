local E7Dashboard = class("E7Dashboard", function()
  return BasePlace.new()
end)

function E7Dashboard:initPhoto()
  self:addPhoto("1", 704, 320)
  self:addPhoto("button", 1472, 0)
  self:addPhoto("SettingCN10", 704, 320)
  self:addPhoto("SettingCN11s1", 704, 320)
  self:addPhoto("SettingCN12", 704, 320)
  self:addPhoto("SettingCN1", 704, 320)
  self:addPhoto("SettingCN2s0", 704, 320)
  self:addPhoto("SettingCN2s9", 704, 320)
  self:addPhoto("SettingCN3s0", 704, 320)
  self:addPhoto("SettingCN4s0", 704, 320)
  self:addPhoto("SettingCN5s0", 704, 320)
  self:addPhoto("SettingCN6", 704, 320)
  self:addPhoto("SettingCN6s1", 704, 320)
  self:addPhoto("SettingCN7", 704, 320)
  self:addPhoto("SettingCN7s1", 704, 320)
  self:addPhoto("SettingCN8", 704, 320)
  self:addPhoto("SettingCN9", 704, 320)
  self:addPhoto("SettingCN9s0", 704, 320)
  self:addPhoto("SettingEN10", 704, 320)
  self:addPhoto("SettingEN11s1", 704, 320)
  self:addPhoto("SettingEN12", 704, 320)
  self:addPhoto("SettingEN1", 704, 320)
  self:addPhoto("SettingEN1s1", 704, 320)
  self:addPhoto("SettingEN1s2", 704, 320)
  self:addPhoto("SettingEN2s0", 704, 320)
  self:addPhoto("SettingEN2s9", 704, 320)
  self:addPhoto("SettingEN3s0", 704, 320)
  self:addPhoto("SettingEN4s0", 704, 320)
  self:addPhoto("SettingEN5s0", 704, 320)
  self:addPhoto("SettingEN6", 704, 320)
  self:addPhoto("SettingEN6s1", 704, 320)
  self:addPhoto("SettingEN7", 704, 320)
  self:addPhoto("SettingEN7s1", 704, 320)
  self:addPhoto("SettingEN8", 704, 320)
  self:addPhoto("SettingEN9", 704, 320)
  self:addPhoto("SettingEN9s0", 704, 320)
  self:addPhoto("hour10", 832, 448)
  self:addPhoto("hour11", 832, 448)
  self:addPhoto("hour12", 832, 448)
  self:addPhoto("hour13", 832, 448)
  self:addPhoto("hour14", 832, 448)
  self:addPhoto("hour15", 832, 448)
  self:addPhoto("hour16", 832, 448)
  self:addPhoto("hour17", 832, 448)
  self:addPhoto("hour18", 832, 448)
  self:addPhoto("hour19", 832, 448)
  self:addPhoto("hour1", 832, 448)
  self:addPhoto("hour20", 832, 448)
  self:addPhoto("hour21", 832, 448)
  self:addPhoto("hour22", 832, 448)
  self:addPhoto("hour23", 832, 448)
  self:addPhoto("hour2", 832, 448)
  self:addPhoto("hour3", 832, 448)
  self:addPhoto("hour4", 832, 448)
  self:addPhoto("hour5", 832, 448)
  self:addPhoto("hour6", 832, 448)
  self:addPhoto("hour7", 832, 448)
  self:addPhoto("hour8", 832, 448)
  self:addPhoto("hour9", 832, 448)
  self:addPhoto("Hset0", 832, 448)
  self:addPhoto("Hset10", 832, 448)
  self:addPhoto("Hset11", 832, 448)
  self:addPhoto("Hset12", 832, 448)
  self:addPhoto("Hset13", 832, 448)
  self:addPhoto("Hset14", 832, 448)
  self:addPhoto("Hset15", 832, 448)
  self:addPhoto("Hset16", 832, 448)
  self:addPhoto("Hset17", 832, 448)
  self:addPhoto("Hset18", 832, 448)
  self:addPhoto("Hset19", 832, 448)
  self:addPhoto("Hset1", 832, 448)
  self:addPhoto("Hset20", 832, 448)
  self:addPhoto("Hset21", 832, 448)
  self:addPhoto("Hset22", 832, 448)
  self:addPhoto("Hset23", 832, 448)
  self:addPhoto("Hset2", 832, 448)
  self:addPhoto("Hset3", 832, 448)
  self:addPhoto("Hset4", 832, 448)
  self:addPhoto("Hset5", 832, 448)
  self:addPhoto("Hset6", 832, 448)
  self:addPhoto("Hset7", 832, 448)
  self:addPhoto("Hset8", 832, 448)
  self:addPhoto("Hset9", 832, 448)
  self:addPhoto("minute00", 832, 448)
  self:addPhoto("minute01", 832, 448)
  self:addPhoto("minute02", 832, 448)
  self:addPhoto("minute03", 832, 448)
  self:addPhoto("minute04", 832, 448)
  self:addPhoto("minute05", 832, 448)
  self:addPhoto("minute06", 832, 448)
  self:addPhoto("minute07", 832, 448)
  self:addPhoto("minute08", 832, 448)
  self:addPhoto("minute09", 832, 448)
  self:addPhoto("minute10", 832, 448)
  self:addPhoto("minute20", 832, 448)
  self:addPhoto("minute30", 832, 448)
  self:addPhoto("minute40", 832, 448)
  self:addPhoto("minute50", 832, 448)
  self:addPhoto("Mset00", 832, 448)
  self:addPhoto("Mset01", 832, 448)
  self:addPhoto("Mset02", 832, 448)
  self:addPhoto("Mset03", 832, 448)
  self:addPhoto("Mset04", 832, 448)
  self:addPhoto("Mset05", 832, 448)
  self:addPhoto("Mset06", 832, 448)
  self:addPhoto("Mset07", 832, 448)
  self:addPhoto("Mset08", 832, 448)
  self:addPhoto("Mset09", 832, 448)
  self:addPhoto("Mset10", 832, 448)
  self:addPhoto("Mset20", 832, 448)
  self:addPhoto("Mset30", 832, 448)
  self:addPhoto("Mset40", 832, 448)
  self:addPhoto("Mset50", 832, 448)
  self:addPhoto("rev", 192, 372)
  self:addPhoto("s1", 704, 320)
  self:addPhoto("s2", 704, 320)
  self:addPhoto("s3", 704, 320)
  self:addPhoto("s4", 704, 320)
  self:addPhoto("s5", 704, 320)
  self:addPhoto("s6", 704, 320)
  self:addPhoto("speed", 1176, 352)
end

function E7Dashboard:initButton()
  self:addButton("show", 704, 276, 468, 540)
  self:addButton("left", 1416, 106, 200, 212, false)
  self:addButton("right", 1844, 106, 200, 200, false)
  self:addButton("up", 1620, 0, 222, 136, false)
  self:addButton("down", 1620, 292, 220, 154, false)
  self:addButton("ok", 1622, 136, 218, 150, false)
end

function E7Dashboard:showScreen()
  self:imageOn("1")
  self:showArrowButton()
  self:enableTouch()
end

function E7Dashboard:arrowDown(rect)
  self:switchPlaceZoomOut("Drive")
end

function E7Dashboard:beforeLoad()
  -- 默认当前菜单层级为0，所选行数为1
  self.level = 0
  self.pos   = 1

  self:imageOn("0")
  self:imageOn("speed")
  self:imageOn("rev")
  
  if self:getInteger("car_engine_ready") > 0 then
    -- 车钥匙已插入，该显示行车电脑了
    if "Ignition" == self.lastPlaceName then
      -- 从打火装置过来的，先不显示图，等一下再显示
      self:hideArrowButton()
      
    else
      self:showScreen()
    end
  end
end

function E7Dashboard:afterLoad()
  if "Ignition" == self.lastPlaceName then
    -- 从点火装置过来，行车电脑显示屏亮
    self:hideArrowButton()
    self:disableTouch()

    self:scheduleOnce(0.5, function()
      self:showScreen()
    end)
  end
end

function E7Dashboard:afterLoad2()
  self:cacheImage("Drive/0")
end

function E7Dashboard:beforeUnload()
  self:imageOff("rev")
  self:imageOff("speed")
end

function E7Dashboard:beforeUseItem(itemName)
  return false
end

function E7Dashboard:afterUseItem(itemName)
  return true
end

function E7Dashboard:selfCheckAnimate()
  -- 自检动画时间1秒，自检完成之后跳到通关场景
  local revPointer   = self:imageIsOn("rev")
  local speedPointer = self:imageIsOn("speed")

  revPointer:setAnchorPoint(0.5, 0.5)
  speedPointer:setAnchorPoint(0.5, 0.5)

  local actionTable  = {}
  local actionTable2 = {}
  local rotateTable  = {
    {0, 5},  
    {0.347, 185},  
    {0.5, 264},  
    {0.653, 185},  
    {1, 5},  
  }

  for _, t in ipairs(rotateTable) do
    table.insert(actionTable, cc.RotateTo:create(t[1], t[2]))
  end

  for _, t in ipairs(rotateTable) do
    table.insert(actionTable2, cc.RotateTo:create(t[1], t[2]))
  end

  table.insert(actionTable2, cc.DelayTime:create(0.2))

  table.insert(actionTable2, cc.CallFunc:create(function(sender)
    self:hideArrowButton()
    self:revAnimateDone()
  end))

  speedPointer:runAction(cc.Sequence:create(actionTable))
  revPointer:runAction(cc.Sequence:create(actionTable2))
end

function E7Dashboard:revAnimateDone()
  -- 跳到通关场景
  self:enableTouch()
  self:switchPlace("Ending")
end

function E7Dashboard:show(rect)
  if self:getInteger("car_engine_ready") == 0 then
    self:sayI18n("show_1")

    return
  end

  if self.useButton then
    self:sayI18n("show_2")

    return
  end

  -- 按钮显示出来供操作
  self.useButton = true

  self:imageOn("button")
  self:sayI18n("show_3")
end

function E7Dashboard:hideTipSprite(rect)
  -- 隐藏Dashboard中间的提示精灵
  local tipSprite = self:getChildByName("button_style_" .. "show")

  if tipSprite then
    tipSprite:setVisible(false)
  end
end

function E7Dashboard:left(rect)
  self:hideTipSprite(nil)

  if not self.useButton then
    -- 按钮没显示出来的时候，什么都不做
    return
  end

  if self.settingUsed and self.level == 0 then
    -- 退回原始状态
    self.settingUsed = false
    self.pos         = 1

    self:imageOn("1")

    -- 干掉所有在第0级可能出现的图，防止贴图错误
    self:imageOff("s1")
    self:imageOff("s2")
    self:imageOff("s3")
    self:imageOff("s4")
    self:imageOff("s5")
    self:imageOff("s6")
    self:imageOff("CN1")
    self:imageOff("CN6")
    self:imageOff("CN7")
    self:imageOff("CN8")
    self:imageOff("CN9")
    self:imageOff("CN10")
    self:imageOff("CN12")
    self:imageOff("EN1")
    self:imageOff("EN6")
    self:imageOff("EN7")
    self:imageOff("EN8")
    self:imageOff("EN9")
    self:imageOff("EN10")
    self:imageOff("EN12")

    return
  end

  if not self.settingUsed then
    -- 进入编辑设置状态
    self:imageOnCNEN("1")
    self:imageOn("s1")
    self:imageOff("1")

    self.settingUsed = true

    return
  end

  if self.level == 0 then
    -- 在第1级，向左什么都不做
    return
  end

  -- 根据last_pos值决定是从哪一层级回到主菜单
  local lastPos = self:getInteger("last_pos")

  if lastPos == 1 then
    self:left1()

  elseif lastPos == 2 then
    self:left2()

  elseif lastPos == 3 then
    self:left3()

  elseif lastPos == 4 then
    self:left4()

  elseif lastPos == 5 then
    self:left5()

  elseif lastPos == 6 then
    self:left6()

  elseif lastPos == 7 then
    self:left7()

  elseif lastPos == 8 then
    -- 无操作

  elseif lastPos == 9 then
    self:left9()

  elseif lastPos == 10 then
    -- 无操作

  elseif lastPos == 11 then
    self:left11()

  elseif lastPos == 12 then
    -- 无操作

  else
    -- 无操作
  end
end

function E7Dashboard:right(rect)
  self:hideTipSprite(nil)

  if not self.useButton then
    -- 按钮没显示出来的时候，什么都不做
    return
  end

  if not self.settingUsed then
    -- 进入编辑设置状态
    self:imageOnCNEN("1")
    self:imageOn("s1")
    self:imageOff("1")

    self.settingUsed = true

    return
  end

  -- 在主菜单的时候
  if self.level == 0 then
    if self.pos == 1 then
      -- 语言
      self:show1()

    elseif self.pos == 2 then
      -- 多功能显示
      self:show2()

    elseif self.pos == 3 then
      -- 舒适系统
      self:show3()

    elseif self.pos == 4 then
      -- 灯光
      self:show4()

    elseif self.pos == 5 then
      -- 时钟
      self:show5()

    elseif self.pos == 6 then
      -- 冬季轮胎
      self:show6()

    elseif self.pos == 7 then
      -- 单位
      self:show7()

    elseif self.pos == 8 then
      -- 次车速单位，无操作
      self:say("...")

    elseif self.pos == 9 then
      -- 自动驻车系统
      self:show9()

    elseif self.pos == 10 then
      -- 旅行模式，无操作
      self:say("...")

    elseif self.pos == 11 then
      -- 保养
      self:show11()

    elseif self.pos == 12 then
      -- 默认设置
      self:say("...")

    else
      -- 无操作
    end

    return
  end

  -- 通过last_pos值决定，当前执行哪一个方法
  local lastPos = self:getInteger("last_pos")

  if lastPos == 1 then
    self:right1()

  elseif lastPos == 2 then
    self:right2()

  elseif lastPos == 3 then
    self:right3()

  elseif lastPos == 4 then
    self:right4()

  elseif lastPos == 5 then
    self:right5()

  elseif lastPos == 6 then
    self:right6()

  elseif lastPos == 7 then
    self:right7()

  elseif lastPos == 8 then
    -- 无操作

  elseif lastPos == 9 then
    self:right9()

  elseif lastPos == 10 then
    -- 无操作

  elseif lastPos == 11 then
    self:right11()

  elseif lastPos == 12 then
    -- 无操作

  else
    -- 无操作
  end
end

function E7Dashboard:up(rect)
  self:hideTipSprite(nil)

  if not self.useButton or not self.settingUsed then
    -- 按钮没显示出来的时候，或者还没有进入设置的编辑状态，什么都不做
    return
  end

  -- 主菜单
  if self.level == 0 then
    if self.pos == 1 then
      -- 到第一行，什么都不做
      return
    end

    self.pos = self.pos - 1

    self:mainMenuK(self.pos)

    return
  end

  -- 通过last_pos值决定，当前执行哪一个方法
  local lastPos = self:getInteger("last_pos")

  if lastPos == 1 then
    self:up1()

  elseif lastPos == 2 then
    self:up2()

  elseif lastPos == 3 then
    self:up3()

  elseif lastPos == 4 then
    self:up4()

  elseif lastPos == 5 then
    self:up5()

  elseif lastPos == 6 then
    self:up6()

  elseif lastPos == 7 then
    self:up7()

  elseif lastPos == 8 then
    -- 无操作

  elseif lastPos == 9 then
    self:up9()

  elseif lastPos == 10 then
    -- 无操作

  elseif lastPos == 11 then
    self:up11()

  elseif lastPos == 12 then
    -- 无操作

  else
    -- 无操作
  end
end

function E7Dashboard:down(rect)
  self:hideTipSprite(nil)

  if not self.useButton or not self.settingUsed then
    -- 按钮没显示出来的时候，或者还没有进入设置的编辑状态，什么都不做
    return
  end

  -- 主菜单
  if self.level == 0 then
    if self.pos == 12 then
      -- 到最后一行，什么都不做
      return
    end

    self.pos = self.pos + 1

    self:mainMenuK(self.pos)

    return
  end

  -- 通过last_pos值决定，当前执行哪一个方法
  local lastPos = self:getInteger("last_pos")

  if lastPos == 1 then
    self:down1()

  elseif lastPos == 2 then
    self:down2()

  elseif lastPos == 3 then
    self:down3()

  elseif lastPos == 4 then
    self:down4()

  elseif lastPos == 5 then
    self:down5()

  elseif lastPos == 6 then
    self:down6()

  elseif lastPos == 7 then
    self:down7()

  elseif lastPos == 8 then
    -- 无操作

  elseif lastPos == 9 then
    self:down9()

  elseif lastPos == 10 then
    -- 无操作

  elseif lastPos == 11 then
    self:down11()

  elseif lastPos == 12 then
    -- 无操作

  else
    -- 无操作
  end
end

function E7Dashboard:ok(rect)
  self:hideTipSprite(nil)

  if not self.useButton then
    -- 按钮没显示出来的时候，什么都不做
    return
  end

  -- ok键和右方向键功能一样
  self:right(self.buttonTable["right"])
end

function E7Dashboard:mainMenuK(index)
  self:say("")

  if index == 1 then
    self:imageOn("s1")
    self:imageOff("s2")

  elseif index == 2 then
    self:imageOn("s2")
    self:imageOff("s1")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")
    self:imageOff("s4")

  elseif index == 4 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 5 then
    self:imageOnCNEN("1")
    self:imageOff("SettingCN6")
    self:imageOff("SettingEN6")
    self:imageOn("s5")
    self:imageOff("s4")

  elseif index == 6 then
    self:imageOnCNEN("6")
    self:imageOff("SettingCN1")
    self:imageOff("SettingCN7")
    self:imageOff("SettingEN1")
    self:imageOff("SettingEN7")
    self:imageOff("s5")

  elseif index == 7 then
    self:imageOnCNEN("7")
    self:imageOff("SettingCN6")
    self:imageOff("SettingCN8")
    self:imageOff("SettingEN6")
    self:imageOff("SettingEN8")

  elseif index == 8 then
    self:imageOnCNEN("8")
    self:imageOff("SettingCN7")
    self:imageOff("SettingCN9")
    self:imageOff("SettingEN7")
    self:imageOff("SettingEN9")

  elseif index == 9 then
    self:imageOnCNEN("9")
    self:imageOff("SettingCN8")
    self:imageOff("SettingCN10")
    self:imageOff("SettingEN8")
    self:imageOff("SettingEN10")

  elseif index == 10 then
    self:imageOnCNEN("10")
    self:imageOff("SettingCN9")
    self:imageOff("SettingCN12")
    self:imageOff("SettingEN9")
    self:imageOff("SettingEN12")

  elseif index == 11 then
    self:imageOnCNEN("12")
    self:imageOff("SettingCN10")
    self:imageOff("SettingEN10")

    self:imageOn("s5")
    self:imageOff("s6")

  elseif index == 12 then
    self:imageOn("s6")
    self:imageOff("s5")

  else
    -- 无操作
  end
end

function E7Dashboard:show1()
  -- 记住上一级的pos值，再重置当前的pos为1
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 1

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOn("SettingEN1s1")

  self:menuK1(self.pos)
end

function E7Dashboard:up1()
  if self.pos == 1 then
    -- 在第一行，什么也不做
    return
  end

  self.pos = self.pos - 1

  self:menuK1(self.pos)
end

function E7Dashboard:down1()
  if self.pos == 10 then
    -- 到最后一行，什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK1(self.pos)
end

function E7Dashboard:left1()
  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingEN1s1")
  self:imageOff("SettingEN1s2")
  self:imageOff("s1")
  self:imageOff("s2")
  self:imageOff("s3")
  self:imageOff("s4")
  self:imageOff("s5")
  self:imageOff("s6")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right1()
  -- 由于最后一行是返回，所以最后一行的右和左是一样的
  if self.pos == 10 then
    self:left1()

    return
  end

  -- 什么都不做
  self:say("...")
end

function E7Dashboard:menuK1(index)
  self:say("")

  if index == 1 then
    self:imageOn("s1")
    self:imageOff("s2")

  elseif index == 2 then
    self:imageOn("s2")
    self:imageOff("s1")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")
    self:imageOff("s4")

  elseif index == 4 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 5 then
    self:imageOn("SettingEN1s1")
    self:imageOn("s5")
    self:imageOff("s4")
    self:imageOff("s2")

  elseif index == 6 then
    self:imageOn("SettingEN1s2")
    self:imageOn("s2")
    self:imageOff("s5")
    self:imageOff("s3")

  elseif index == 7 then
    self:imageOn("s3")
    self:imageOff("s2")
    self:imageOff("s4")

  elseif index == 8 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 9 then
    self:imageOn("s5")
    self:imageOff("s4")
    self:imageOff("s6")

  elseif index == 10 then
    self:imageOn("s6")
    self:imageOff("s5")

  else
    -- 无操作
  end
end

function E7Dashboard:show2()
  -- 记住上一级的pos值，再重置当前的pos为1
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 1

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOnCNEN("2s0")
  self:menuK2(self.pos)
end

function E7Dashboard:up2()
  if self.pos == 1 then
    -- 在第一行，什么也不做
    return
  end

  self.pos = self.pos - 1

  self:menuK2(self.pos)
end

function E7Dashboard:down2()
  if self.pos == 9 then
    -- 到最后一行，什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK2(self.pos)
end

function E7Dashboard:left2()
  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingCN2s0")
  self:imageOff("SettingCN2s9")
  self:imageOff("SettingEN2s0")
  self:imageOff("SettingEN2s9")
  self:imageOff("s1")
  self:imageOff("s2")
  self:imageOff("s3")
  self:imageOff("s4")
  self:imageOff("s5")
  self:imageOff("s6")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right2()
  -- 由于最后一行是返回，所以最后一行的右和左是一样的
  if self.pos == 9 then
    self:left2()

    return
  end

  -- 什么都不做的时候
  self:say("...")
end

function E7Dashboard:menuK2(index)
  self:say("")

  if index == 1 then
    self:imageOn("s1")
    self:imageOff("s2")

  elseif index == 2 then
    self:imageOn("s2")
    self:imageOff("s1")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")
    self:imageOff("s4")

  elseif index == 4 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 5 then
    self:imageOn("SettingCN2s0")
    self:imageOn("s5")
    self:imageOff("s4")
    self:imageOff("s3")

  elseif index == 6 then
    self:imageOn("SettingCN2s9")
    self:imageOn("s3")
    self:imageOff("s5")
    self:imageOff("s4")

  elseif index == 7 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 8 then
    self:imageOn("s5")
    self:imageOff("s4")
    self:imageOff("s6")

  elseif index == 9 then
    self:imageOn("s6")
    self:imageOff("s5")

  else
    -- 无操作
  end
end

function E7Dashboard:show3()
  -- 记住上一级的pos值，再重置当前的pos为1
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 1

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOnCNEN("3s0")
  self:menuK3(self.pos)
end

function E7Dashboard:up3()
  if self.pos == 1 then
    -- 什么都不做
    return
  end

  self.pos = self.pos - 1

  self:menuK3(self.pos)
end

function E7Dashboard:down3()
  if self.pos == 5 then
    -- 什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK3(self.pos)
end

function E7Dashboard:left3()
  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingCN3s0")
  self:imageOff("SettingEN3s0")
  self:imageOff("s1")
  self:imageOff("s2")
  self:imageOff("s3")
  self:imageOff("s4")
  self:imageOff("s5")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right3()
  -- 由于最后一行是返回，所以最后一行的右和左是一样的
  if self.pos == 5 then
    self:left3()

    return
  end

  -- 什么都不做
  self:say("...")
end

function E7Dashboard:menuK3(index)
  self:say("")

  if index == 1 then
    self:imageOn("s1")
    self:imageOff("s2")

  elseif index == 2 then
    self:imageOn("s2")
    self:imageOff("s1")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")
    self:imageOff("s4")

  elseif index == 4 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 5 then
    self:imageOn("s5")
    self:imageOff("s4")

  else
    -- 无操作
  end
end

function E7Dashboard:show4()
  -- 记住上一级的pos值，再重置当前的pos为1
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 1

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOnCNEN("4s0")
  self:menuK4(self.pos)
end

function E7Dashboard:up4()
  if self.pos == 1 then
    -- 什么都不做
    return
  end

  self.pos = self.pos - 1

  self:menuK4(self.pos)
end

function E7Dashboard:down4()
  if self.pos == 6 then
    -- 什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK4(self.pos)
end

function E7Dashboard:left4()
  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingCN4s0")
  self:imageOff("SettingEN4s0")
  self:imageOff("s1")
  self:imageOff("s2")
  self:imageOff("s3")
  self:imageOff("s4")
  self:imageOff("s5")
  self:imageOff("s6")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right4()
  -- 在最后一行返回的时候
  if self.pos == 6 then
    self:left4()

    return
  end

  -- 什么都不做
  self:say("...")
end

function E7Dashboard:menuK4(index)
  self:say("")

  if index == 1 then
    self:imageOn("s1")
    self:imageOff("s2")

  elseif index == 2 then
    self:imageOn("s2")
    self:imageOff("s1")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")
    self:imageOff("s4")

  elseif index == 4 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 5 then
    self:imageOn("s5")
    self:imageOff("s4")
    self:imageOff("s6")

  elseif index == 6 then
    self:imageOn("s6")
    self:imageOff("s5")

  else
    -- 无操作
  end
end

function E7Dashboard:show5()
  -- 记住上一级的pos值，再重置当前的pos为2
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 2

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOnCNEN("5s0")
  self:menuK5(self.pos)

  -- 显示设置的时间
  if self:getInteger("dashboard_hour") > 0 then
    self:imageOn("hour" .. self:getInteger("dashboard_hour"))
  end

  if self:getInteger("dashboard_minute") > 0 then
    if self:getInteger("dashboard_minute") > 9 then
      -- 分钟有两位数的情况下
      local minute = self:getInteger("dashboard_minute")

      -- 十位数字
      local first = math.floor(minute / 10)

      -- 个位数字
      local last  = minute % 10

      -- 由于图片原因，先加后面一位数，再加前面的
      self:imageOn("minute0" .. last)
      self:imageOn("minute" .. first .. 0)

      return
    end

    self:imageOn("minute0" .. self:getInteger("dashboard_minute"))
  end
end

function E7Dashboard:up5()
  -- 在编辑状态中
  if self.clocking then
    -- 当前正在编辑小时
    if self.pos == 2 then
      local hour = self:getInteger("dashboard_hour")

      hour = hour + 1

      if hour > 23 then
        hour = 0
      end

      self:imageOn("Hset" .. hour)
      self:setInteger("dashboard_hour", hour)

      return
    end

    -- 当前正在编辑分钟
    local minute = self:getInteger("dashboard_minute")

    minute = minute + 1

    if minute > 59 then
      minute = 0
    end

    -- 记录当前设置的分钟
    self:setInteger("dashboard_minute", minute)

    -- 分钟有两位数的情况下
    if self:getInteger("dashboard_minute") > 9 then
      local minute = self:getInteger("dashboard_minute")

      -- 十位数字
      local first = math.floor(minute / 10)

      -- 个位数字
      local last  = minute % 10

      -- 由于图片原因，先加后面一位数，再加前面的
      self:imageOn("Mset0" .. last)
      self:imageOn("Mset" .. first .. 0)

      return
    end

    self:imageOn("Mset0" .. self:getInteger("dashboard_minute"))

    return
  end

  if self.pos == 2 then
    -- 什么都不做
    return
  end

  self.pos = self.pos - 1

  self:menuK5(self.pos)
end

function E7Dashboard:down5()
  -- 在编辑状态中
  if self.clocking then
    -- 当前正在编辑小时
    if self.pos == 2 then
      local hour = self:getInteger("dashboard_hour")

      hour = hour - 1

      if hour < 0 then
        hour = 23
      end

      self:imageOn("Hset" .. hour)
      self:setInteger("dashboard_hour", hour)

      return
    end

    -- 当前正在编辑分钟
    local minute = self:getInteger("dashboard_minute")

    minute = minute - 1

    if minute < 0 then
      minute = 59
    end

    -- 记录当前设置的分钟
    self:setInteger("dashboard_minute", minute)

    -- 分钟有两位数的情况下
    if self:getInteger("dashboard_minute") > 9 then
      local minute = self:getInteger("dashboard_minute")

      -- 从开始取到第1位，不包括第1位
      local first = math.floor(minute / 10)

      -- 从第1位开始取到最后位
      local last  = minute % 10

      -- 由于图片原因，先加后面一位数，再加前面的
      self:imageOn("Mset0" .. last)
      self:imageOn("Mset" .. first .. 0)

      return
    end

    self:imageOn("Mset0" .. self:getInteger("dashboard_minute"))

    return
  end

  if self.pos == 6 then
    -- 什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK5(self.pos)
end

function E7Dashboard:left5()
  -- 退出编辑状态
  if self.clocking then
    self.clocking = false

    self:exitEdit()

    return
  end

  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingCN5s0")
  self:imageOff("SettingEN5s0")
  self:imageOff("s2")
  self:imageOff("s3")
  self:imageOff("s4")
  self:imageOff("s5")
  self:imageOff("s6")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right5()
  -- 退出编辑状态
  if self.clocking then
    self.clocking = false

    self:exitEdit()

    return
  end

  if self.pos == 2 then
    if self:getInteger("trunk_unlock") == 1 then
      self:sayI18n("right5_1")

      return
    end

    -- 进入时钟调节状态，调节小时
    self.clocking = true
    self:imageOn("Hset" .. self:getInteger("dashboard_hour"))

  elseif self.pos == 3 then
    if self:getInteger("trunk_unlock") == 1 then
      self:sayI18n("right5_2")

      return
    end

    -- 进入时钟调节状态，调节分钟
    self.clocking = true

    if self:getInteger("dashboard_minute") > 9 then
      -- 分钟有两位数的情况下
      local minute = self:getInteger("dashboard_minute")

      -- 从开始取到第1位，不包括第1位
      local first = math.floor(minute / 10)

      -- 从第1位开始取到最后位
      local last  = minute % 10

      -- 由于图片原因，先加后面一位数，再加前面的
      self:imageOn("Mset0" .. last)
      self:imageOn("Mset" .. first .. 0)

      return
    end

    self:imageOn("Mset0" .. self:getInteger("dashboard_minute"))

  elseif self.pos == 6 then
    -- 返回，直接退回到主菜单
    self:left5()

  else
    -- 什么都不做
    self:say("...")
  end
end

function E7Dashboard:menuK5(index)
  self:say("")

  if index == 2 then
    self:imageOn("s2")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")
    self:imageOff("s4")

  elseif index == 4 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 5 then
    self:imageOn("s5")
    self:imageOff("s4")
    self:imageOff("s6")

  elseif index == 6 then
    self:imageOn("s6")
    self:imageOff("s5")

  else
    -- 无操作
  end
end

function E7Dashboard:exitEdit()
  -- 退出小时编辑状态
  if self.pos == 2 then
    -- 干掉编辑状态中的图片
    for i = 0, 24 do
      self:imageOff("Hset" .. i)
    end

    -- 设置时间
    if self:getInteger("dashboard_hour") > 0 then
      self:imageOn("hour" .. self:getInteger("dashboard_hour"))

    else
      -- 如果时间又设置为0，由于没有0这张图片，所有干掉所有时间的图片，防止图片叠加出错
      for j = 1, 24 do
        self:imageOff("hour" .. j)
      end
    end

    -- 只要退出编辑状态的时候，就判断密码是否正确，如果正确就解锁后备厢
    self:unlockTrunk()

    return
  end

  -- 退出分钟编辑状态
  -- 干掉编辑状态中的图片
  self:imageOff("Mset10")
  self:imageOff("Mset20")
  self:imageOff("Mset30")
  self:imageOff("Mset40")
  self:imageOff("Mset50")

  for i = 0, 10 do
    self:imageOff("Mset0" .. i)
  end

  -- 设置时间
  if self:getInteger("dashboard_minute") > 9 then
    -- 分钟有两位数的情况下
    local minute = self:getInteger("dashboard_minute")

    -- 从开始取到第1位，不包括第1位
    local first = math.floor(minute / 10)

    -- 从第1位开始取到最后位
    local last  = minute % 10

    -- 由于图片原因，先加后面一位数，再加前面的
    self:imageOn("minute0" .. last)
    self:imageOn("minute" .. first .. 0)

  else
    self:imageOn("minute0" .. self:getInteger("dashboard_minute"))
  end

  -- 只要退出编辑状态的时候，就判断密码是否正确，如果正确就解锁后备厢
  self:unlockTrunk()
end

function E7Dashboard:unlockTrunk()
  local hour       = self:getInteger("dashboard_hour")
  local minute     = self:getInteger("dashboard_minute")
  local tempHour   = self:getInteger("temp_hour")
  local tempMinute = self:getInteger("temp_minute")

  -- 满足trunk解锁条件
  if hour == tempHour and minute == tempMinute then
    self:disableTouch()
    self:play("centerdraweropen")
    self:sayI18n("unlockTrunk_1")
    
    -- 仪表自检动画开始
    self:setInteger("trunk_unlock", 1)
    self:voidItem("temp")
    self:selfCheckAnimate()
  end
end

function E7Dashboard:show6()
  -- 记住上一级的pos值，再重置当前的pos为2
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 2

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOnCNEN("6s1")
  self:menuK6(self.pos)
end

function E7Dashboard:up6()
  if self.pos == 2 then
    -- 什么都不做
    return
  end

  self.pos = self.pos - 1

  self:menuK6(self.pos)
end

function E7Dashboard:down6()
  if self.pos == 5 then
    -- 什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK6(self.pos)
end

function E7Dashboard:left6()
  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingCN6s1")
  self:imageOff("SettingEN6s1")
  self:imageOff("s2")
  self:imageOff("s3")
  self:imageOff("s4")
  self:imageOff("s5")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right6()
  if self.pos == 5 then
    self:left6()

    return
  end

  -- 什么都不做
  self:say("...")
end

function E7Dashboard:menuK6(index)
  self:say("")

  if index == 2 then
    self:imageOn("s2")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")
    self:imageOff("s4")

  elseif index == 4 then
    self:imageOn("s4")
    self:imageOff("s3")
    self:imageOff("s5")

  elseif index == 5 then
    self:imageOn("s5")
    self:imageOff("s4")
    self:imageOff("s6")

  else
    -- 无操作
  end
end

function E7Dashboard:show7()
  -- 记住上一级的pos值，再重置当前的pos为2
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 1

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOnCNEN("7s1")
  self:menuK7(self.pos)
end

function E7Dashboard:up7()
  if self.pos == 1 then
    -- 什么都不做
    return
  end

  self.pos = self.pos - 1

  self:menuK7(self.pos)
end

function E7Dashboard:down7()
  if self.pos == 3 then
    -- 什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK7(self.pos)
end

function E7Dashboard:left7()
  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingCN7s1")
  self:imageOff("SettingEN7s1")
  self:imageOff("s1")
  self:imageOff("s2")
  self:imageOff("s3")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right7()
  if self.pos == 3 then
    self:left7()

    return
  end

  -- 什么都不做
  self:say("...")
end

function E7Dashboard:menuK7(index)
  self:say("")

  if index == 1 then
    self:imageOn("s1")
    self:imageOff("s2")

  elseif index == 2 then
    self:imageOn("s2")
    self:imageOff("s1")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")

  else
    -- 无操作
  end
end

function E7Dashboard:show9()
  -- 记住上一级的pos值，再重置当前的pos为2
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 1

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOnCNEN("9s0")
  self:menuK9(self.pos)
end

function E7Dashboard:up9()
  if self.pos == 1 then
    -- 什么都不做
    return
  end

  self.pos = self.pos - 1

  self:menuK9(self.pos)
end

function E7Dashboard:down9()
  if self.pos == 3 then
    -- 什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK9(self.pos)
end

function E7Dashboard:left9()
  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingCN9s0")
  self:imageOff("SettingEN9s0")
  self:imageOff("SettingCN9ss1")
  self:imageOff("SettingCN9ss2")
  self:imageOff("s1")
  self:imageOff("s2")
  self:imageOff("s3")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right9()
  if self.pos == 3 then
    -- 返回
    self:left9()

    return
  end

  -- 什么都不做
  self:say("...")
end

function E7Dashboard:menuK9(index)
  self:say("")

  if index == 1 then
    self:imageOn("s1")
    self:imageOff("s2")

  elseif index == 2 then
    self:imageOn("s2")
    self:imageOff("s1")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")

  else
    -- 无操作
  end
end

function E7Dashboard:show11()
  -- 记住上一级的pos值，再重置当前的pos为2
  self:setInteger("last_pos", self.pos)
  self.level = 1
  self.pos   = 1

  -- 进入下一级，图片全部直接叠加，上一级的不移除，以便返回上一级时，直接干掉，不容易出错
  self:imageOnCNEN("11s1")
  self:menuK11(self.pos)
end

function E7Dashboard:up11()
  if self.pos == 1 then
    -- 什么都不做
    return
  end

  self.pos = self.pos - 1

  self:menuK11(self.pos)
end

function E7Dashboard:down11()
  if self.pos == 3 then
    -- 什么都不做
    return
  end

  self.pos = self.pos + 1

  self:menuK11(self.pos)
end

function E7Dashboard:left11()
  self.level = 0
  self.pos   = self:getInteger("last_pos")

  -- 干掉在这一级菜单中所有出现的图，防止图片叠加出错
  self:imageOff("SettingCN11s1")
  self:imageOff("SettingEN11s1")
  self:imageOff("s1")
  self:imageOff("s2")
  self:imageOff("s3")

  -- 从下一级回去之后，再重新显示主菜单
  self:mainMenuK(self.pos)
end

function E7Dashboard:right11()
  if self.pos == 3 then
    self:left11()

    return
  end

  -- 什么都不做
  self:say("...")
end

function E7Dashboard:menuK11(index)
  self:say("")

  if index == 1 then
    self:imageOn("s1")
    self:imageOff("s2")

  elseif index == 2 then
    self:imageOn("s2")
    self:imageOff("s1")
    self:imageOff("s3")

  elseif index == 3 then
    self:imageOn("s3")
    self:imageOff("s2")

  else
    -- 无操作
  end
end

function E7Dashboard:imageOnCNEN(filename)
  if "chs" == i18n.getLang() then
    self:imageOn("SettingCN" .. filename)

    return
  end

  self:imageOn("SettingEN" .. filename)
end

return E7Dashboard
