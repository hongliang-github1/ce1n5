local E7Door = class("E7Door", function()
  return BasePlace.new()
end)

function E7Door:initPhoto()
  self:addPhoto("1", 960, 512)
  self:addPhoto("2", 960, 512)
end

function E7Door:initButton()
  self:addButton("suck", 982, 496, 198, 154)
  self:addButton("handle", 982, 658, 252, 220)
end

function E7Door:arrowDown(rect)
  self:switchPlaceZoomOut(self.fromPlaceName)
end

function E7Door:beforeLoad()
  self:imageOn("0")

  if self:getInteger("sucker") == 0 then
    self:imageOn("2")
    self:sayI18n("beforeLoad_1")
  end
end

function E7Door:afterLoad()

end

function E7Door:beforeUseItem(itemName)
  return false
end

function E7Door:afterUseItem(itemName)
  return true
end

function E7Door:suck(rect)
  if self:getInteger("sucker") == 0 then
    if self:imageIsOn("1") then
      self:imageOff("1")
      self:getItem("sucker")
      self:sayI18n("suck_1")

      return
    end

    self:imageOn("1")
    self:imageOff("2")
    self:play("sucker")
    self:sayI18n("suck_2")

    return
  end

  self:sayI18n("suck_3")
end

function E7Door:handle(rect)
  self:sayI18n("handle_1")
end

return E7Door
