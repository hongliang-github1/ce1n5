local E7OutRightFront = class("E7OutRightFront", function()
  return BasePlace.new()
end)

function E7OutRightFront:initPhoto()
  self:addPhoto("10", 0, 64)
  self:addPhoto("13", 0, 0)
  self:addPhoto("1", 1344, 64)
  self:addPhoto("20", 0, 0)
  self:addPhoto("23", 0, 0)
end

function E7OutRightFront:initButton()
  self:addButton("glovebox", 414, 480, 384, 360)
  self:addButton("slot", 1096, 676, 352, 302, false)
  self:addButton("glass", 1356, 36, 434, 278)
  self:addButton("closeDoor", 1486, 416, 382, 718, false)
end

function E7OutRightFront:arrowLeft(rect)
  self:switchPlaceLeft("OutRightRear")
end

function E7OutRightFront:arrowRight(rect)
  self:switchPlaceRight("OutFront")
end

function E7OutRightFront:beforeLoad()
  -- 如果是车里出来的，门开着
  if "SlotRight" == self.lastPlaceName then
    self.opened = true

    if self:getInteger("car_engine_ready") == 1 then
      self:imageOn("23")

      return
    end

    self:imageOn("0")
    self:imageOn("10")
    self:imageOn("13")

    return
  end

  if self:getInteger("car_engine_ready") == 1 then
    -- 车已经发动了
    self:imageOn("20")

    return
  end

  self:imageOn("0")

  if self:getInteger("car_door_open") == 1 then
    -- 车门已经打开过
    self:imageOn("10")
  end

  if self:getInteger("sucker") == 0 then
    -- 吸盘还没有得到
    self:imageOn("1")
  end
end

function E7OutRightFront:afterLoad()

end

function E7OutRightFront:afterLoad2()
  self:cacheImage("OutRightRear/0")
  self:cacheImage("OutFront/0")
  self:cacheImage("Door/0")
end

function E7OutRightFront:beforeUseItem(itemName)
  return false
end

function E7OutRightFront:afterUseItem(itemName)
  return true
end

function E7OutRightFront:glovebox(rect)
  -- 车门还没解锁
    if self:getInteger("car_door_open") <= 0 then
      self:sayI18n("glovebox_2")

      return
    end

  -- 车门已经打开了，什么都不做
  if self.opened == true then
    return
  end

  -- 打开车门
  if self:getInteger("car_engine_ready") == 1 then
    -- 由于2对应的都是底图，直接替换即可
    self:imageOn("23")

  else
    self:imageOn("13")
    self:imageOff("10")
  end

  self:play("cardooropen")
  self:sayI18n("glovebox_3")

  self.opened = true
end

function E7OutRightFront:slot(rect)
  if self.opened == true then
    self:switchPlaceZoomIn("SlotRight", rect)
  end
end

function E7OutRightFront:glass(rect)
  if self.opened == true then
    return
  end

  self:switchPlaceZoomIn("Door", rect)
end

function E7OutRightFront:closeDoor(rect)
  if self.opened == true then
    self.opened = false

    if self:getInteger("car_engine_ready") == 1 then
      self:imageOn("20")

    else
      self:imageOff("13")
    end

    self:play("cardoorclose")
    self:sayI18n("closeDoor_1")
  end
end

return E7OutRightFront
