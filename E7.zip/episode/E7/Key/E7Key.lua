local E7Key = class("E7Key", function()
  return BasePlace.new()
end)

function E7Key:initPhoto()
  self:addPhoto("01", 832, 320)
  self:addPhoto("10", 896, 192)
  self:addPhoto("11", 896, 320)
  self:addPhoto("12", 896, 320)
  self:addPhoto("13", 896, 192)
  self:addPhoto("14", 896, 256)
  self:addPhoto("15", 768, 256)
  self:addPhoto("16", 576, 256)
  self:addPhoto("17", 768, 256)
  self:addPhoto("1", 960, 320)
  self:addPhoto("2", 960, 256)
  self:addPhoto("3", 896, 128)
  self:addPhoto("5", 896, 0)
  self:addPhoto("6", 832, 320)
  self:addPhoto("7", 832, 320)
  self:addPhoto("8", 896, 64)
end

function E7Key:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E7Key:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "OutRear")
end

function E7Key:recordLastPlaceName()
  return false
end

function E7Key:beforeLoad()
  self:imageOn("0")

  if self:getInteger("key2") == 0 then
    self:imageOn("01")
  
  else
    self:imageOn("11")
  end
end


function E7Key:afterLoad()
  -- 如果电池已经有电了，则只要显示台词就可以了
  if self:getInteger("battery") < 0 then
    self:sayI18n("batteryAfter_3")

    return
  end
end

function E7Key:afterLoad2()
end

function E7Key:beforeUseItem(itemName)
  if "screwdriver" == itemName then
    return self:getInteger("battery") >= 0 and not self.screwdriverUsed
  end

  if "battery" == itemName then
    return self:imageIsOn("15")
  end

  return false
end

function E7Key:afterUseItem(itemName)
  if "screwdriver" == itemName then
    self:imageOn("15")
    self:sayI18n("disassemble_4")

    self.screwdriverUsed = true

    return true
  end

  if "battery" == itemName then
    self:imageOff("15")
    self:imageOn("16")
    self:sayI18n("afterUseItem_1")

    self.batteryUsed = true

    return true
  end

  return true
end

function E7Key:click(rect)
  -- 还没有得到钥匙展出状态
  if self:getInteger("key2") == 0 then
    self:getKey2()

    return
  end

  -- 电池已使用，有电的状态
  if self:getInteger("battery") < 0 then
    self:sayI18n("batteryAfter_3")

    return
  end

  -- 剩下的情况就是电池还没有使用过、车钥匙现在还没有电，等待用户去使用螺丝刀或者电池
  if not self.screwdriverUsed then
    self:sayI18n("afterLoad_3")

    return
  end

  -- 这里开始就是使用过螺丝刀的情况了，看电池是否已使用
  if not self.batteryUsed then
    self:sayI18n("disassemble_4")

    return
  end

  -- 这里开始就是使用过电池了，开始走装配剧情
  if self:imageIsOn("16") then
    self:sayI18n("batteryAfter_1")
    self:imageOff("16")
    self:imageOn("17")

  elseif self:imageIsOn("17") then
    self:sayI18n("disassemble_11")
    self:imageOn("11")
    self:imageOff("17")
    self:play("item")
    self:voidItem("screwdriver")
    self:voidItem("battery")
  end
end

function E7Key:getKey2()
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:sayI18n("getKey2_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("getKey2_2")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("1")
    self:imageOff("01")
    self:imageOn("2")
    self:sayI18n("getKey2_3")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("2")
    self:imageOn("3")
    self:sayI18n("getKey2_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("3")
    self:imageOn("5")
    self:sayI18n("getKey2_5")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("5")
    self:imageOn("6")
    self:sayI18n("getKey2_6")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("6")
    self:imageOn("7")
    self:sayI18n("getKey2_7")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("7")
    self:imageOn("8")
    self:sayI18n("getKey2_8")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("8")
    self:imageOn("10")
    self:sayI18n("getKey2_9")

    return
  end

  if progress == self:nextProgressIndex() then
    self:getItem("key2")
    self:imageOff("10")
    self:imageOn("11")
    self:sayI18n("getKey2_10")

    return
  end
end

return E7Key
