local E7DoorLeftFront = class("E7DoorLeftFront", function()
  return BasePlace.new()
end)

function E7DoorLeftFront:initPhoto()
end

function E7DoorLeftFront:initButton()
  self:addButton("trunk", 270, 668, 336, 324)
  self:addButton("knee", 1158, 0, 638, 514)
end

function E7DoorLeftFront:arrowDown(rect)
  self:switchPlaceZoomOut("OutLeftFront")
end

function E7DoorLeftFront:beforeLoad()
  self:imageOn("0")
end

function E7DoorLeftFront:afterLoad()
  
end

function E7DoorLeftFront:afterLoad2()
  self:cacheImage("OutLeftFront/0")
  self:cacheImage("SwitchTrunk/0")
  self:cacheImage("Knee/0")
end

function E7DoorLeftFront:beforeUseItem(itemName)
  return false
end

function E7DoorLeftFront:afterUseItem(itemName)
  return true
end

function E7DoorLeftFront:trunk(rect)
  self:switchPlaceZoomIn("SwitchTrunk", rect)
end

function E7DoorLeftFront:knee(rect)
  self:switchPlaceZoomIn("Knee", rect)
end

return E7DoorLeftFront
