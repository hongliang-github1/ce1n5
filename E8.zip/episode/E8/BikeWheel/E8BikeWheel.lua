local E8BikeWheel = class("E8BikeWheel", function()
  return BasePlace.new()
end)

function E8BikeWheel:initPhoto()
  self:addPhoto("11", 1216, 960)
  self:addPhoto("12", 1216, 960)
  self:addPhoto("1", 1216, 320)
  self:addPhoto("3", 1216, 256)
  self:addPhoto("41", 1088, 192)
  self:addPhoto("42", 1088, 192)
  self:addPhoto("4", 1088, 192)
  self:addPhoto("51", 1088, 192)
  self:addPhoto("52", 1088, 192)
  self:addPhoto("5", 1088, 192)
end

function E8BikeWheel:initButton()
end

function E8BikeWheel:arrowDown(rect)
  self:switchPlaceZoomOut("BikeSide")
end

function E8BikeWheel:beforeLoad()
  self:imageOn("0")
end

function E8BikeWheel:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8BikeWheel:afterLoad2()
  self:cacheImage("BikeSide/0")
end

function E8BikeWheel:beforeUseItem(itemName)
  return false
end

function E8BikeWheel:afterUseItem(itemName)
  return true
end

return E8BikeWheel
