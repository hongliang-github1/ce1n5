local E8Gswitch = class("E8Gswitch", function()
  return BasePlace.new()
end)

function E8Gswitch:initPhoto()
end

function E8Gswitch:initButton()
  self:addButton("open", 998, 376, 362, 316)
end

function E8Gswitch:arrowLeft(rect)
  self:switchPlaceLeft("Gdoor")
end

function E8Gswitch:beforeLoad()
  if self:getInteger("room_g_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8Gswitch:afterLoad()
  
end

function E8Gswitch:afterLoad2()
  self:cacheImage("Gdoor/0")
end

function E8Gswitch:beforeUseItem(itemName)
  return false
end

function E8Gswitch:afterUseItem(itemName)
  return true
end

function E8Gswitch:open(rect)
  if self:imageIsOn("0") then
    -- 开灯
    self:imageOn("1")
    self:setInteger("room_g_switch", 1)
    self:play("switch")
    self:sayI18n("open_1")
    
    return
  end
  
  -- 关灯
  self:imageOn("0")
  self:setInteger("room_g_switch", 0)
  self:play("switch")
  self:sayI18n("open_2")
end

return E8Gswitch
