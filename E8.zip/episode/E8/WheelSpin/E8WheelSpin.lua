local E8WheelSpin = class("E8WheelSpin", function()
  return BasePlace.new()
end)

function E8WheelSpin:initPhoto()
  self:addPhoto("1", 1536, 448)
  self:addPhoto("s", 1472, 576)
end

function E8WheelSpin:initButton()
  self:addButton("click", 376, 0, 1148, 1148, false)
  self:addButton("knife", 1526, 468, 518, 344, false)
end

function E8WheelSpin:arrowDown(rect)
  self:switchPlaceZoomOut("BikeSide")
end

function E8WheelSpin:beforeLoad()
  self:imageOn("0")

  -- 轮子空转，循环播放音效
  self.wheelrollPlayId = self:play("wheelroll", true)
end

function E8WheelSpin:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8WheelSpin:afterLoad2()
  self:cacheImage("BikeSide/0")
end

function E8WheelSpin:beforeUnload()
  self:stopAllEffects()
end

function E8WheelSpin:beforeUseItem(itemName)
  if "knife" == itemName then
    return not self:imageIsOn("1")
  end
  
  return false
end

function E8WheelSpin:afterUseItem(itemName)
  if "knife" == itemName then
    -- 把刀拿出来，开始磨刀，或者已经磨过了
    self:imageOn("1")
    self:imageOn("s")

    self.knifePlayId = self:play("knife", true)
    
    self.sharpening  = true

    self:hideArrowButton()
    
    if self:getInteger("knife") == 2 then
      -- 已经磨过了，再磨磨
      self:sayI18n("afterUseItem_1")

    else
      -- 还没磨过，第一次想起来可以磨刀
      self:sayI18n("afterUseItem_2")
    end

    return true
  end
  
  return true
end

function E8WheelSpin:onTouchBegan(touch, event)
  if self.sharpening or (self.sharpened and self:imageIsOn("1")) then
    self:knife(nil)
  end
end

function E8WheelSpin:click(rect)
  if self.sharpening or (self.sharpened and self:imageIsOn("1")) then
    self:onTouchBegan(nil)

    return
  end

  if self:imageIsOn("1") or self:getInteger("knife") == 2 then
    self:sayI18n("click_1")

    return
  end
  
  self:sayI18n("click_2")
end

function E8WheelSpin:knife(rect)
  if self.sharpening and self:imageIsOn("1") and self:imageIsOn("s") then
    self:disableTouch()
    self:black()

    return
  end

  if self:imageIsOn("1") and self:imageIsOn("s") then
    -- 磨刀完成
    self:imageOff("s")
    self:stopEffect(self.knifePlayId)
    
    self.sharpened = true
    self:showArrowButton()
    
    if self:getInteger("knife") == 2 then
      self:sayI18n("knife_1")

    else
      self:setInteger("knife", 2)
      self:sayI18n("knife_2")
    end
    
    return
  end
  
  if self.sharpened and self:imageIsOn("1") then
    -- 已经磨过刀了，刀还显示在上面，把刀拿下
    self:imageOff("1")
    self:sayI18n("knife_3")
    
    return
  end
end

function E8WheelSpin:black()
  -- 黑屏，显示一会儿后
  self:say("")
  
  self:effectFadeBlack("afterAWhile", 2, 3, 2, function()
    self:enableTouch()
    self.sharpening = false
    self:knife(nil)
  end)
end

return E8WheelSpin
