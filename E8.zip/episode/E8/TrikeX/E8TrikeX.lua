local E8TrikeX = class("E8TrikeX", function()
  return BasePlace.new()
end)

function E8TrikeX:initPhoto()
  self:addPhoto("1", 1344, 704)
end

function E8TrikeX:initButton()
  self:addButton("goXdoor", 0, 0, 720, 1144)
  self:addButton("door", 1768, 20, 222, 330, false)
  self:addButton("door2", 1720, 590, 246, 276, false)
  self:addButton("nothing", 1606, 912, 438, 236, false)
end

function E8TrikeX:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsX")
end

function E8TrikeX:beforeLoad()
  self:imageOn("0")
end

function E8TrikeX:afterLoad()
end

function E8TrikeX:afterLoad2()
  self:cacheImage("DoorsX/0")
  self:cacheImage("Xdoor/0")
end

function E8TrikeX:beforeUseItem(itemName)
  return false
end

function E8TrikeX:afterUseItem(itemName)
  return true
end

function E8TrikeX:goXdoor(rect)
  self:switchPlaceZoomIn("Xdoor", cc.rect(0, 260, 720, 600))
end

function E8TrikeX:door(rect)
  self:sayI18n("door_1")
end

function E8TrikeX:door2(rect)
  self:sayI18n("door2_1")
end

function E8TrikeX:nothing(rect)
  self:sayI18n("nothing_1")
end

return E8TrikeX
