local E8Exit = class("E8Exit", function()
  return BasePlace.new()
end)

function E8Exit:initPhoto()
end

function E8Exit:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E8Exit:arrowDown(rect)
  self:switchPlaceZoomOut("WayGH")
end

function E8Exit:beforeLoad()
  self:imageOn("1")

  if "Envelope" == self.fromPlaceName and self:getInteger("envelop_tipped") > 0 then
    -- 已经拿到了房卡并且知道了是什么酒店，准备通关剧情
    self:sayI18n("beforeLoad_1")

    return
  end

  self:sayI18n("beforeLoad_2")
end

function E8Exit:afterLoad()
  if "Envelope" == self.fromPlaceName and self:getInteger("envelop_tipped") > 0 then
    self:hideArrowButton()
  end  
end

function E8Exit:afterLoad2()
  self:cacheImage("WayGH/0")
end

function E8Exit:beforeUseItem(itemName)
  return false
end

function E8Exit:afterUseItem(itemName)
  return true
end

function E8Exit:click(rect)
  if "Envelope" == self.fromPlaceName and self:getInteger("envelop_tipped") > 0 then
    -- 到这里就算通关了，设置通关标记
    userdata.setEpisodePassed(self.episodeName)
    
    -- -- 发送通关成绩至Game Center
    -- NSInteger timingSecond = [self.userData timingSecond:self.userData.currentChapter]
    
    -- [self.userData setTimingSecondLastValue:timingSecond chapter:self.userData.currentChapter]
    -- [[BaseAppDelegate baseAppDelegate].gameCenterManager submitTimingSecond:timingSecond leaderboardID:"ce5ce2"]
    -- [[BaseAppDelegate baseAppDelegate].gameCenterManager submitAchievement:"ce5.clear.ce2"]
    
    -- 进入通关字幕
    cc.Director:getInstance():replaceScene(BaseScene.create("CreditScene"))

    return
  end
  
  if self.shouldBack then
    self:switchPlaceZoomOut("WayGH")
    
    return
  end
  
  self:sayI18n("click_1")
  
  self.shouldBack = true
end

return E8Exit
