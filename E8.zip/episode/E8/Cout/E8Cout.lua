local E8Cout = class("E8Cout", function()
  return BasePlace.new()
end)

function E8Cout:initPhoto()
  self:addPhoto("1", 768, 832)
  self:addPhoto("2", 832, 0)
end

function E8Cout:initButton()
  self:addButton("goCluggage", 714, 776, 472, 372)
  self:addButton("goCbulb", 702, 0, 368, 172)
  self:addButton("goCswitch", 0, 368, 180, 190)
  self:addButton("goCdoor", 198, 110, 452, 1010)
  self:addButton("nothing", 702, 180, 1342, 588, false)
end

function E8Cout:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("luggage") == 0 then
    self:imageOn("1")
  end
  
  if self:getInteger("bulb") == 0 then
    self:imageOn("2")
  end
end

function E8Cout:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Cout:afterLoad2()
  if self:getInteger("luggage") == 0 then
    self:cacheImage("Cluggage/0")
  end
  
  if self:getInteger("bulb") == 0 then
    self:cacheImage("Cbulb/0")
  end

  if self:getInteger("room_c_switch") == 1 then
    self:cacheImage("Cswitch/1")
    self:cacheImage("Cdoor/1")

  else  
    self:cacheImage("Cswitch/0")
    self:cacheImage("Cdoor/0")
  end
end

function E8Cout:beforeUseItem(itemName)
  return false
end

function E8Cout:afterUseItem(itemName)
  return true
end

function E8Cout:goCluggage(rect)
  self:switchPlaceZoomIn("Cluggage", rect)
end

function E8Cout:goCbulb(rect)
  self:switchPlaceZoomIn("Cbulb", rect)
end

function E8Cout:goCswitch(rect)
  self:switchPlaceZoomIn("Cswitch", rect)
end

function E8Cout:goCdoor(rect)
  self:switchPlaceZoomOut("Cdoor")
end

function E8Cout:nothing(rect)
  self:sayI18n("nothing_1")
end

return E8Cout
