local E8Dbattery = class("E8Dbattery", function()
  return BasePlace.new()
end)

function E8Dbattery:initPhoto()
  self:addPhoto("1", 768, 576)
end

function E8Dbattery:initButton()
  self:addButton("goDbatteryNear", 778, 532, 512, 568)
end

function E8Dbattery:arrowLeft(rect)
  self:switchPlaceLeft("DbikeNear")
end

function E8Dbattery:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("battery") == 0 then
    self:imageOn("1")
  end
end

function E8Dbattery:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Dbattery:afterLoad2()
  self:cacheImage("DbikeNear/0")
  self:cacheImage("DbatteryNear/0")
end

function E8Dbattery:beforeUseItem(itemName)
  return false
end

function E8Dbattery:afterUseItem(itemName)
  return true
end

function E8Dbattery:goDbatteryNear(rect)
  if self:getInteger("battery") > 0 then
    self:sayI18n("goDbatteryNear_1")
    
    return
  end
  
  self:switchPlaceZoomIn("DbatteryNear", rect)
end

return E8Dbattery
