local E8DoorsCD = class("E8DoorsCD", function()
  return BasePlace.new()
end)

function E8DoorsCD:initPhoto()
end

function E8DoorsCD:initButton()
  self:addButton("goCdoor", 1116, 0, 744, 1148)
  self:addButton("goDdoor", 226, 0, 800, 1148)
end

function E8DoorsCD:arrowDown(rect)
  self:switchPlaceZoomOut("WayCD")
end

function E8DoorsCD:beforeLoad()
  if self:getInteger("room_c_switch") == 1 and self:getInteger("room_d_switch") == 1 then
    self:imageOn("3")
    
    return
  end
  
  if self:getInteger("room_c_switch") == 1 then
    self:imageOn("2")
    
    return
  end
  
  if self:getInteger("room_d_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8DoorsCD:afterLoad()
  
end

function E8DoorsCD:afterLoad2()
  e8.removeCacheGroomToFroom(self)
  e8.removeCacheAroomToXroom(self)
  e8.removeCacheBroom(self)
  
  if self:getInteger("room_c_switch") == 1 then
    self:cacheImage("Cdoor/1")
    
  else
    self:cacheImage("Cdoor/0")
  end

  if self:getInteger("room_d_switch") == 1 then
    self:cacheImage("Ddoor/2")
    
  else    
    self:cacheImage("Ddoor/0")
  end

  if self:getInteger("baby_car_switch") == 1 and self:getInteger("room_d_switch") == 1 then
    self:cacheImage("WayCD/3")
    
  elseif self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayCD/2")
    
  elseif self:getInteger("room_d_switch") == 1 then
    self:cacheImage("WayCD/1")
    
  else
    self:cacheImage("WayCD/0")
  end
end

function E8DoorsCD:beforeUseItem(itemName)
  return false
end

function E8DoorsCD:afterUseItem(itemName)
  return true
end

function E8DoorsCD:goCdoor(rect)
  self:switchPlaceZoomIn("Cdoor", cc.rect(1112, 256, 752, 660))
end

function E8DoorsCD:goDdoor(rect)
  self:switchPlaceZoomIn("Ddoor", cc.rect(228, 256, 800, 660))
end

return E8DoorsCD
