local E8DoorsAB = class("E8DoorsAB", function()
  return BasePlace.new()
end)

function E8DoorsAB:initPhoto()
end

function E8DoorsAB:initButton()
  self:addButton("goAdoor", 1348, 0, 696, 1148)
  self:addButton("goBdoor", 0, 0, 1046, 1148)
end

function E8DoorsAB:arrowDown(rect)
  self:switchPlaceZoomOut("WayAB")
end

function E8DoorsAB:beforeLoad()
  if self:getInteger("room_a_switch") == 1 and self:getInteger("room_b_switch") == 1 then
    self:imageOn("3")
    
    return
  end
  
  if self:getInteger("room_a_switch") == 1 then
    self:imageOn("2")
    
    return
  end
  
  if self:getInteger("room_b_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8DoorsAB:afterLoad()

end

function E8DoorsAB:afterLoad2()
  if self:getInteger("room_a_switch") == 1 then
    self:cacheImage("Adoor/1")
      
  else
    self:cacheImage("Adoor/0")
  end

  if self:getInteger("room_b_switch") == 1 then
    self:cacheImage("Bdoor/2")

  else
    self:cacheImage("Bdoor/1")
  end

  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayAB/4")
    
  elseif self:getInteger("room_a_switch") == 1 and self:getInteger("room_b_switch") == 1 then
    self:cacheImage("WayAB/3")
    
  elseif self:getInteger("room_a_switch") == 1 then
    self:cacheImage("WayAB/2")
    
  elseif self:getInteger("room_b_switch") == 1 then
    self:cacheImage("WayAB/1")
    
  else
    self:cacheImage("WayAB/0")
  end
end

function E8DoorsAB:beforeUseItem(itemName)
  return false
end

function E8DoorsAB:afterUseItem(itemName)
  return true
end

function E8DoorsAB:goAdoor(rect)
  self:switchPlaceZoomIn("Adoor", cc.rect(1348, 300, 700, 600))
end

function E8DoorsAB:goBdoor(rect)
  self:switchPlaceZoomIn("Bdoor", cc.rect(0, 336, 1040, 550))
end

return E8DoorsAB
