local E8Xswitch = class("E8Xswitch", function()
  return BasePlace.new()
end)

function E8Xswitch:initPhoto()
end

function E8Xswitch:initButton()
  self:addButton("click", 1280, 304, 382, 366)
end

function E8Xswitch:arrowLeft(rect)
  self:switchPlaceLeft("Xpole")
end

function E8Xswitch:beforeLoad()
  self:imageOn("0")
end

function E8Xswitch:afterLoad()

end

function E8Xswitch:afterLoad2()
  self:cacheImage("Xpole/0")
end

function E8Xswitch:beforeUseItem(itemName)
  return false
end

function E8Xswitch:afterUseItem(itemName)
  return true
end

function E8Xswitch:click(rect)
  self:sayI18n("click_1")
end

return E8Xswitch
