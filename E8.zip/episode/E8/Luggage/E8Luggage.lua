local E8Luggage = class("E8Luggage", function()
  return BasePlace.new()
end)

function E8Luggage:initPhoto()
  self:addPhoto("1", 640, 704)
end

function E8Luggage:initButton()
  self:addButton("unzip", 584, 690, 898, 260)
  self:addButton("goLuggageLock", 598, 282, 836, 404)
  self:addButton("nothing", 584, 954, 882, 194, false)
end

function E8Luggage:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "WayGH")
end

function E8Luggage:beforeLoad()
  -- 已经得知如何去看箱子了
  if self.gamingScene and self:getInteger("ask_open") == 1 then
    self:switchPlace("LuggageOpen")

    return false
  end

  self:imageOn("0")
end

function E8Luggage:afterLoad()
  if self:getInteger("envelope") == 0 and self:getInteger("card") == 0 then
    self:sayI18n("afterLoad_1")
  end
end

function E8Luggage:afterLoad2()
  self:cacheImage("LuggageOpen/0")
  self:cacheImage("LuggageLock/0")
end

function E8Luggage:recordLastPlaceName()
  return false
end

function E8Luggage:beforeUseItem(itemName)
  return false
end

function E8Luggage:afterUseItem(itemName)
  return true
end

function E8Luggage:unzip(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    if self:imageIsOn("1") then
      self:imageOff("1")
      self:sayI18n("handleSwipeFrom_1")

      self.progress = 0
      
    else
      self:imageOn("1")
      self:sayI18n("handleSwipeFrom_4")
    end

    return
  end

  if progress == self:nextProgressIndex() then
    if self:imageIsOn("1") then
      self:sayI18n("unzip_1")
    end

    self.progress = 0

    return
  end
end

function E8Luggage:goLuggageLock(rect)
  self:switchPlace("LuggageLock")
end

function E8Luggage:nothing(rect)
  self:sayI18n("nothing_1")
end

return E8Luggage
