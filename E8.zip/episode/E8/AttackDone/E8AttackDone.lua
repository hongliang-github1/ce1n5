local E8AttackDone = class("E8AttackDone", function()
  return BasePlace.new()
end)

function E8AttackDone:initPhoto()
end

function E8AttackDone:initButton()
  self:addButton("find", 448, 112, 1024, 1020)
end

function E8AttackDone:beforeLoad()
  self:imageOn("0")
end

function E8AttackDone:afterLoad()
  self:find(nil)
end

function E8AttackDone:afterLoad2()
  self:cacheImage("Entry/0")
end

function E8AttackDone:beforeUseItem(itemName)
  return false
end

function E8AttackDone:afterUseItem(itemName)
  return true
end

function E8AttackDone:find(rect)
  -- 在这里禁用掉防狼手电，防止用户在使用了防狼手电后程序退出了，再进来就用不了，但是剧情没走完
  self:voidItem("shock")
  
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:play("manscream")
    self:sayI18n("shockSuccess_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("shockSuccess_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("shockSuccess_3")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:switchPlace("Entry")
    
    return
  end
end

return E8AttackDone
