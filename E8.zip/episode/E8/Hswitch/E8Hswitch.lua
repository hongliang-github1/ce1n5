local E8Hswitch = class("E8Hswitch", function()
  return BasePlace.new()
end)

function E8Hswitch:initPhoto()
end

function E8Hswitch:initButton()
  self:addButton("open", 772, 346, 464, 478)
end

function E8Hswitch:arrowRight(rect)
  self:switchPlaceRight("Hdoor")
end

function E8Hswitch:beforeLoad()
  self:imageOn("0")
end

function E8Hswitch:afterLoad()

end

function E8Hswitch:afterLoad2()
  self:cacheImage("Hdoor/0")
end

function E8Hswitch:beforeUseItem(itemName)
  return false
end

function E8Hswitch:afterUseItem(itemName)
  return true
end

function E8Hswitch:open(rect)
  self:sayI18n("open_1")
end

return E8Hswitch
