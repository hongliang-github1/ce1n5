local E8BatteryHole = class("E8BatteryHole", function()
  return BasePlace.new()
end)

function E8BatteryHole:initPhoto()
  self:addPhoto("1", 960, 640)
end

function E8BatteryHole:initButton()
  self:addButton("goBatteryHoleNear", 670, 368, 702, 570)
end

function E8BatteryHole:arrowLeft(rect)
  self:switchPlaceZoomOut("BikeSide")
end

function E8BatteryHole:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("keyb") == 0 then
    self:imageOn("1")
  end
end

function E8BatteryHole:afterLoad()
  if self:imageIsOn("1") then
    self:sayI18n("afterLoad_1")
  end
end

function E8BatteryHole:afterLoad2()
  self:cacheImage("BikeSide/0")
  self:cacheImage("BatteryHoleNear/0")
end

function E8BatteryHole:beforeUseItem(itemName)
  return false
end

function E8BatteryHole:afterUseItem(itemName)
  return true
end

function E8BatteryHole:goBatteryHoleNear(rect)
  if self:getInteger("keyb") == 0 then
    self:switchPlaceZoomIn("BatteryHoleNear", rect)
    
    return
  end
  
  self:sayI18n("goBatteryHoleNear_1")
end

return E8BatteryHole
