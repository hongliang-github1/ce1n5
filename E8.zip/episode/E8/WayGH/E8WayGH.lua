local E8WayGH = class("E8WayGH", function()
  return BasePlace.new()
end)

function E8WayGH:initPhoto()
end

function E8WayGH:initButton()
  self:addButton("goWayEF", 1088, 248, 448, 540)
end

function E8WayGH:arrowDown(rect)
  self:switchPlaceZoomOut("Exit")
end

function E8WayGH:beforeLoad()
  if self:getInteger("baby_car_switch") == 1 then
    self:imageOn("2")

    return
  end

  self:imageOn("0")
end

function E8WayGH:afterLoad()
  if "Entry" == self.lastPlaceName then
    -- 设置开始剧情已经走完了，开始探索地下车库了
    self:setInteger("way_gh_visited", 1)
    self:sayI18n("afterLoad_1")
  end
end

function E8WayGH:afterLoad2()
  e8.removeCacheBroom(self)
  e8.removeCacheAroomToXroom(self)

  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayEF/1")

  else
    self:cacheImage("WayEF/0")
  end
end

function E8WayGH:beforeUseItem(itemName)
  return false
end

function E8WayGH:afterUseItem(itemName)
  return true
end

function E8WayGH:goWayEF(rect)
  self:switchPlaceZoomIn("WayEF", rect)
end

return E8WayGH
