local E8DoorsGH = class("E8DoorsGH", function()
  return BasePlace.new()
end)

function E8DoorsGH:initPhoto()
end

function E8DoorsGH:initButton()
  self:addButton("goGdoor", 1172, 0, 800, 1148)
  self:addButton("goHdoor", 24, 0, 906, 1148)
end

function E8DoorsGH:arrowDown(rect)
  self:switchPlaceZoomOut("WayGH")
end

function E8DoorsGH:beforeLoad()
  if self:getInteger("room_g_switch") == 1 then
    self:imageOn("0")
    
    return
  end
  
  self:imageOn("1")
end

function E8DoorsGH:afterLoad()

end

function E8DoorsGH:afterLoad2()
  if self:getInteger("room_g_switch") == 1 then
    self:cacheImage("Gdoor/2")
    
  elseif "Gswitch" == self.lastPlaceName then
    self:cacheImage("Gdoor/1")
    
  else
    self:cacheImage("Gdoor/0")
  end

  if "Hswitch" == self.lastPlaceName then
    self:cacheImage("Hdoor/1")
    
  else
    self:cacheImage("Hdoor/0")
  end

  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayGH/2")

  else
    self:cacheImage("WayGH/0")
  end
end

function E8DoorsGH:beforeUseItem(itemName)
  return false
end

function E8DoorsGH:afterUseItem(itemName)
  return true
end

function E8DoorsGH:goGdoor(rect)
  self:switchPlaceZoomIn("Gdoor", cc.rect(1174, 280, 800, 660))
end

function E8DoorsGH:goHdoor(rect)
  self:switchPlaceZoomIn("Hdoor", cc.rect(30, 270, 896, 670))
end

return E8DoorsGH
