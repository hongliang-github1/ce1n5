local E8Entry = class("E8Entry", function()
  return BasePlace.new()
end)

function E8Entry:initPhoto()
end

function E8Entry:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E8Entry:beforeLoad()
  self:imageOn("0")
end

function E8Entry:afterLoad()
  self:click(nil)
end

function E8Entry:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("2")
  self:cacheImage("WayGH/0")
end

function E8Entry:beforeUseItem(itemName)
  return false
end

function E8Entry:afterUseItem(itemName)
  return true
end

function E8Entry:click(rect)
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:sayI18n("click_3")
  end
  
  if progress == self:nextProgressIndex() then
    self:switchPlaceZoomIn("WayGH", cc.rect(580, 230, 870, 700))
    
    return
  end
end

return E8Entry
