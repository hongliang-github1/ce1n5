local E8AwoodOut = class("E8AwoodOut", function()
  return BasePlace.new()
end)

function E8AwoodOut:initPhoto()
  self:addPhoto("1", 1728, 448)
  self:addPhoto("2", 1664, 256)
end

function E8AwoodOut:initButton()
  self:addButton("goSwitch", 6, 130, 284, 296)
  self:addButton("goAdoor", 544, 2, 932, 1146)
end

function E8AwoodOut:beforeLoad()
  self:imageOn("0")
end

function E8AwoodOut:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8AwoodOut:afterLoad2()
  self:cacheImage("Adoor/0")
end

function E8AwoodOut:beforeUseItem(itemName)
  return false
end

function E8AwoodOut:afterUseItem(itemName)
  return true
end

function E8AwoodOut:goSwitch(rect)
  self:sayI18n("goSwitch_1")
end

function E8AwoodOut:goAdoor(rect)
  self:switchPlaceZoomOut("Adoor")
end

return E8AwoodOut
