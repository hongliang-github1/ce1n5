local E8Pencil = class("E8Pencil", function()
  return BasePlace.new()
end)

function E8Pencil:initPhoto()
  self:addPhoto("1", 1088, 0)
  self:addPhoto("2", 1088, 0)
end

function E8Pencil:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E8Pencil:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "WayGH")
end

function E8Pencil:beforeLoad()
  if self:getInteger("pencil") == 2 then
    self:imageOn("9")
    
    return
  end
  
  self:imageOn("0")
end

function E8Pencil:afterLoad()
  if self:imageIsOn("9") then
    self:sayI18n("afterLoad_1")
    
  else
    self:sayI18n("afterLoad_2")
  end
end

function E8Pencil:afterLoad2()
end

function E8Pencil:recordLastPlaceName()
  return false
end

function E8Pencil:beforeUseItem(itemName)
  if "knife" == itemName then
    return not self.knifing
  end
  
  return false
end

function E8Pencil:afterUseItem(itemName)
  if "knife" == itemName then
    -- 使用了小刀，如果小刀还没打磨，显示钝的小刀图片，否则显示锋利小刀图片
    if self:getInteger("knife") ~= 2 then
      self:imageOn("1")
      
    else
      self:imageOn("2")
    end
    
    self:sayI18n("afterUseItem_1")
    
    -- 记录尝试削过铅笔，给tip用
    if self:getInteger("tried_sharp_knife") < 1 then
      self:setInteger("tried_sharp_knife", 1)
    end

    self.knifing = true
    
    return true
  end
  
  return true
end

function E8Pencil:click(rect)
  if not self.knifing then
    if self:imageIsOn("0") then
      self:sayI18n("click_1")
      
      return
    end
    
    self:sayI18n("click_2")
    
    return
  end
  
  if self:getInteger("knife") ~= 2 then
    -- 小刀还没有打磨锋利
    self:sayI18n("handleSwipeFrom_1")
          
    return
  end
  
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:imageOff("2")
    self:imageOn("3")
    self:play("pencil")
    self:sayI18n("handleSwipeFrom_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("4")
    self:play("pencil")
    self:sayI18n("handleSwipeFrom_3")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("5")
    self:play("pencil")
    self:sayI18n("handleSwipeFrom_4")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("6")
    self:play("pencil")
    self:sayI18n("handleSwipeFrom_5")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("7")
    self:play("pencil")
    self:sayI18n("handleSwipeFrom_6")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("8")
    self:play("pencil")
    self:sayI18n("handleSwipeFrom_7")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("9")
    self:play("item")
    self:voidItem("knife")
    self:setInteger("pencil", 2)
    self:sayI18n("handleSwipeFrom_8")
    
    self.knifing = false
    
    return
  end
end

return E8Pencil
