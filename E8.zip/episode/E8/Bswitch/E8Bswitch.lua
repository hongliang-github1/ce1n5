local E8Bswitch = class("E8Bswitch", function()
  return BasePlace.new()
end)

function E8Bswitch:initPhoto()
  self:addPhoto("1", 1152, 512)
end

function E8Bswitch:initButton()
  self:addButton("open", 970, 388, 402, 406)
end

function E8Bswitch:arrowRight(rect)
  self:switchPlaceRight("Bdoor")
end

function E8Bswitch:beforeLoad()
  if self:getInteger("room_b_switch") == 1 then
    self:imageOn("2")
    
    return
  end
  
  self:imageOn("0")
  
  if "Bbulb" == self.lastPlaceName then
    self:imageOn("1")
  end
end

function E8Bswitch:afterLoad()
end

function E8Bswitch:afterLoad2()
  self:cacheImage("Bdoor/1")
  self:cacheImage("Bbulb/0")
end

function E8Bswitch:beforeUseItem(itemName)
  return false
end

function E8Bswitch:afterUseItem(itemName)
  return true
end

function E8Bswitch:open(rect)
  if self:getInteger("bulb") < 0 then
    if self:imageIsOn("2") then
      self:imageOn("0")
      self:play("switch")
      self:sayI18n("open_1")
      
      self:setInteger("room_b_switch", 0)
      
      return
    end
    
    self:imageOn("2")
    self:play("switch")
    self:sayI18n("open_2")
    
    self:setInteger("room_b_switch", 1)
    
    return
  end
  
  -- 还没有安装灯泡的情况下
  if self:imageIsOn("1") then
    self:switchPlace("Bbulb")
    
    return
  end
  
  self:imageOn("1")
  self:play("switch")
  self:sayI18n("open_3")
end

return E8Bswitch
