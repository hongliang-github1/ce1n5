local E8Cluggage = class("E8Cluggage", function()
  return BasePlace.new()
end)

function E8Cluggage:initPhoto()
  self:addPhoto("1", 512, 192)
end

function E8Cluggage:initButton()
  self:addButton("getLuggage", 566, 92, 824, 1018)
end

function E8Cluggage:arrowDown(rect)
  self:switchPlaceZoomOut("Cout")
end

function E8Cluggage:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("luggage") == 0 then
    self:imageOn("1")
  end
end

function E8Cluggage:afterLoad()
  if self:imageIsOn("1") then
    self:sayI18n("afterLoad_1")
  end
end

function E8Cluggage:afterLoad2()
  self:cacheImage("Cout/0")
end

function E8Cluggage:beforeUseItem(itemName)
  return false
end

function E8Cluggage:afterUseItem(itemName)
  return true
end

function E8Cluggage:getLuggage(rect)
  if self:imageIsOn("1") then
    self:imageOff("1")
    self:getItem("luggage")
    self:sayI18n("getLuggage_1")
    
    return
  end
  
  self:sayI18n("getLuggage_2")
end

return E8Cluggage
