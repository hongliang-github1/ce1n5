local E8BatteryHoleNear = class("E8BatteryHoleNear", function()
  return BasePlace.new()
end)

function E8BatteryHoleNear:initPhoto()
  self:addPhoto("1", 960, 704)
end

function E8BatteryHoleNear:initButton()
  self:addButton("getKeyb", 830, 666, 468, 414)
end

function E8BatteryHoleNear:arrowDown(rect)
  self:switchPlaceZoomOut("BatteryHole")
end

function E8BatteryHoleNear:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("keyb") == 0 then
    self:imageOn("1")
  end
end

function E8BatteryHoleNear:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8BatteryHoleNear:afterLoad2()
  self:cacheImage("BatteryHole/0")
end

function E8BatteryHoleNear:beforeUseItem(itemName)
  return false
end

function E8BatteryHoleNear:afterUseItem(itemName)
  return true
end

function E8BatteryHoleNear:getKeyb(rect)
  if self:getInteger("keyb") == 0 then
    self:imageOff("1")
    self:getItem("keyb")
    
    self:sayI18n("getKeyb_1")
    
    return
  end
  
  self:sayI18n("getKeyb_2")
end

return E8BatteryHoleNear
