local E8BabyCar = class("E8BabyCar", function()
  return BasePlace.new()
end)

function E8BabyCar:initPhoto()
  self:addPhoto("1", 640, 384)
end

function E8BabyCar:initButton()
  self:addButton("goBabyCarNear", 548, 312, 380, 314)
end

function E8BabyCar:arrowUp(rect)
  self:switchPlaceUp("BabyCarSwitch")
end

function E8BabyCar:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("ultralight") == 0 then
    self:imageOn("1")
  end
end

function E8BabyCar:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8BabyCar:afterLoad2()
  self:cacheImage("BabyCarSwitch/0")
  self:cacheImage("BabyCarNear/0")
end

function E8BabyCar:beforeUseItem(itemName)
  return false
end

function E8BabyCar:afterUseItem(itemName)
  return true
end

function E8BabyCar:goBabyCarNear(rect)
  self:switchPlaceZoomIn("BabyCarNear", rect)
end

return E8BabyCar
