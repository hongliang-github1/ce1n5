local E8BabyCarSwitch = class("E8BabyCarSwitch", function()
  return BasePlace.new()
end)

function E8BabyCarSwitch:initPhoto()
end

function E8BabyCarSwitch:initButton()
  self:addButton("open", 1620, 360, 284, 286)
  self:addButton("goBabyCar", 826, 798, 796, 350)
end

function E8BabyCarSwitch:arrowLeft(rect)
  self:switchPlaceLeft("WayAB")
end

function E8BabyCarSwitch:beforeLoad()
  if self:getInteger("baby_car_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8BabyCarSwitch:afterLoad()

end

function E8BabyCarSwitch:afterLoad2()
  self:cacheImage("WayAB/0")
  self:cacheImage("BabyCar/0")
end

function E8BabyCarSwitch:beforeUseItem(itemName)
  return false
end

function E8BabyCarSwitch:afterUseItem(itemName)
  return true
end

function E8BabyCarSwitch:open(rect)
  if self:imageIsOn("0") then
    self:imageOn("1")
    self:setInteger("baby_car_switch", 1)
    self:play("switch")
    self:sayI18n("open_1")
    
    return
  end
  
  self:imageOn("0")
  self:setInteger("baby_car_switch", 0)
  self:play("switch")
  self:sayI18n("open_2")
  
  return
end

function E8BabyCarSwitch:goBabyCar(rect)
  if self:getInteger("baby_car_switch") == 1 then
    self:switchPlaceDown("BabyCar")
    
    return
  end
end

return E8BabyCarSwitch
