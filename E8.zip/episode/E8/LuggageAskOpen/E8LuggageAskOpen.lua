local E8LuggageAskOpen = class("E8LuggageAskOpen", function()
  return BasePlace.new()
end)

function E8LuggageAskOpen:initPhoto()
end

function E8LuggageAskOpen:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E8LuggageAskOpen:beforeLoad()
  self:imageOn("0" .. i18n.getLang())
end

function E8LuggageAskOpen:afterLoad()
  self:sayI18n("afterLoad_2")
end

function E8LuggageAskOpen:afterLoad2()
  self:cacheImage("LuggageOpen/0")
end

function E8LuggageAskOpen:recordLastPlaceName()
  return false
end

function E8LuggageAskOpen:beforeUseItem(itemName)
  return false
end

function E8LuggageAskOpen:afterUseItem(itemName)
  return true
end

function E8LuggageAskOpen:click(rect)  
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("askTwice_5")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("askTwice_6")
    
    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("askTwice_7")
    
    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("askTwice_8")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:setInteger("ask_open", 1)
    self:switchPlace("LuggageOpen")
    
    return
  end
end

return E8LuggageAskOpen
