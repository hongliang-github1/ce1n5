local E8WayAB = class("E8WayAB", function()
  return BasePlace.new()
end)

function E8WayAB:initPhoto()
end

function E8WayAB:initButton()
  self:addButton("goDoorsAB", 604, 40, 300, 1110)
  self:addButton("goDoorsX", 928, 138, 590, 914)
end

function E8WayAB:arrowDown(rect)
  self:switchPlaceZoomOut("WayCD")
end

function E8WayAB:arrowRight(rect)
  self:switchPlaceRight("BabyCarSwitch")
end

function E8WayAB:beforeLoad()
  if self:getInteger("baby_car_switch") == 1 then
    self:imageOn("4")
    
    return
  end
  
  if self:getInteger("room_a_switch") == 1 and self:getInteger("room_b_switch") == 1 then
    self:imageOn("3")
    
    return
  end
  
  if self:getInteger("room_a_switch") == 1 then
    self:imageOn("2")
    
    return
  end
  
  if self:getInteger("room_b_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
  self:sayI18n("beforeLoad_1")
  
  -- 记录来过这里，给tip用
  if self:getInteger("way_ab_visited") < 1 then
    self:setInteger("way_ab_visited", 1)
  end
end

function E8WayAB:afterLoad()

end

function E8WayAB:afterLoad2()
  if self:getInteger("room_a_switch") == 1 and self:getInteger("room_b_switch") == 1 then
    self:cacheImage("DoorsAB/3")
    
  elseif self:getInteger("room_a_switch") == 1 then
    self:cacheImage("DoorsAB/2")
    
  elseif self:getInteger("room_b_switch") == 1 then
    self:cacheImage("DoorsAB/1")

  else  
    self:cacheImage("DoorsAB/0")
  end

  self:cacheImage("DoorsX/0")

  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("BabyCarSwitch/1")
    
  else  
    self:cacheImage("BabyCarSwitch/0")
  end

  if self:getInteger("baby_car_switch") == 1 and self:getInteger("room_d_switch") == 1 then
    self:cacheImage("WayCD/3")
    
  elseif self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayCD/2")
    
  elseif self:getInteger("room_d_switch") == 1 then
    self:cacheImage("WayCD/1")
    
  else  
    self:cacheImage("WayCD/0")
  end
end

function E8WayAB:beforeUseItem(itemName)
  return false
end

function E8WayAB:afterUseItem(itemName)
  return true
end

function E8WayAB:goDoorsAB(rect)
  self:switchPlaceZoomIn("DoorsAB", cc.rect(608, 370, 296, 426))
end

function E8WayAB:goDoorsX(rect)
  if self:getInteger("baby_car_switch") == 0 then
    self:sayI18n("goDoorsX_1")
    
    return
  end
  
  self:switchPlaceZoomIn("DoorsX", cc.rect(926, 366, 586, 446))
end

return E8WayAB
