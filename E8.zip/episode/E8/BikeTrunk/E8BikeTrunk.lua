local E8BikeTrunk = class("E8BikeTrunk", function()
  return BasePlace.new()
end)

function E8BikeTrunk:initPhoto()
  self:addPhoto("01", 768, 576)
  self:addPhoto("02", 704, 192)
  self:addPhoto("12", 384, 0)
  self:addPhoto("13", 768, 576)
end

function E8BikeTrunk:initButton()
end

function E8BikeTrunk:arrowDown(rect)
  self:switchPlaceZoomOut("Bdoor")
end

function E8BikeTrunk:beforeLoad()
  self:imageOn("0")
end

function E8BikeTrunk:afterLoad()
end

function E8BikeTrunk:afterLoad2()
  self:cacheImage("Bdoor/1")
end

function E8BikeTrunk:beforeUseItem(itemName)
  return false
end

function E8BikeTrunk:afterUseItem(itemName)
  return true
end

function E8BikeTrunk:onTouchBegan(touch, event)
  local progress = self:nextProgress()

  self:resetProgressIndex()

  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:imageOff("0")
    self:sayI18n("unlock_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:sayI18n("getBox_4")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOff("1")
    self:imageOn("0")
    self:sayI18n("unlock_2")

    self.progress = 0

    return
  end
end

return E8BikeTrunk
