local E8Ddoor = class("E8Ddoor", function()
  return BasePlace.new()
end)

function E8Ddoor:initPhoto()
end

function E8Ddoor:initButton()
  self:addButton("goDbike", 784, 232, 848, 916)
  self:addButton("goDwall", 0, 0, 784, 342, false)
end

function E8Ddoor:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsCD")
end

function E8Ddoor:arrowLeft(rect)
  self:switchPlaceLeft("Dswitch")
end

function E8Ddoor:beforeLoad()
  if self:getInteger("room_d_switch") == 1 then
    self:imageOn("2")
    
    return
  end
  
  self:imageOn("1")
end

function E8Ddoor:afterLoad()
end

function E8Ddoor:afterLoad2()
  if self:getInteger("room_d_switch") == 1 then
    self:cacheImage("Dswitch/1")

  else  
    self:cacheImage("Dswitch/0")
  end

  self:cacheImage("Dbike/0")

  if self:getInteger("room_c_switch") == 1 and self:getInteger("room_d_switch") == 1 then
    self:cacheImage("DoorsCD/3")
  
  elseif self:getInteger("room_c_switch") == 1 then
    self:cacheImage("DoorsCD/2")
  
  elseif self:getInteger("room_d_switch") == 1 then
    self:cacheImage("DoorsCD/1")
    
  else  
    self:cacheImage("DoorsCD/0")
  end
end

function E8Ddoor:beforeUseItem(itemName)
  return false
end

function E8Ddoor:afterUseItem(itemName)
  return true
end

function E8Ddoor:goDbike(rect)  
  if self:imageIsOn("1") then
    self:sayI18n("goDbike_1")
    
    return
  end
  
  self:switchPlaceZoomIn("Dbike", cc.rect(391 * 2, 273 * 2, 361 * 2, 237 * 2))
end

function E8Ddoor:goDwall(rect)
  self:sayI18n("afterLoad_1")
end

return E8Ddoor
