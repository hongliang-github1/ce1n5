local E8Fdoor = class("E8Fdoor", function()
  return BasePlace.new()
end)

function E8Fdoor:initPhoto()
end

function E8Fdoor:initButton()
  self:addButton("goFwall", 550, 230, 848, 492, false)
  self:addButton("goFstuff", 660, 824, 748, 324)
end

function E8Fdoor:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsEF")
end

function E8Fdoor:beforeLoad()
  self:imageOn("0")
end

function E8Fdoor:afterLoad()

end

function E8Fdoor:afterLoad2()
  self:cacheImage("Fstuff/0")
  self:cacheImage("DoorsEF/0")
end

function E8Fdoor:beforeUseItem(itemName)
  return false
end

function E8Fdoor:afterUseItem(itemName)
  return true
end

function E8Fdoor:goFwall(rect)
  self:sayI18n("afterLoad_1")
end

function E8Fdoor:goFstuff(rect)
  self:switchPlaceZoomIn("Fstuff", rect)
end

return E8Fdoor
