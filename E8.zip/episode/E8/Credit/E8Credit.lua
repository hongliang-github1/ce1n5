local E8Credit = class("E8Credit", function()
  return BaseCredit.new()
end)

function E8Credit:afterCreate()
  -- 构造滚动字幕
  self:addLabelI18n(1.1, "beforeLoad_1")
  
  -- -- 显示通关时间
  -- -- NSString *timingString  = [self timingString]
  -- -- NSString *labelStr    = UikitEnhancement:textByI18nDict("beforeLoad_2")
  
  -- -- self:addLabelI18n(1, [labelStr stringByAppendingFormat:"%@", timingString)]
  
  self:addLabelI18n(1, "beforeLoad_3")
  
  self:addBlank()
  
  self:addLabelI18n(1, "beforeLoad_4")
  
  self:addImage("am")
  
  self:addBlank()
   
  self:addLabelI18n(1, "beforeLoad_6")

  self:addLabelI18n(1, "followUpStory_1")

  self:addLabelI18n(1, "followUpStory_2")

  self:addLabelI18n(1, "followUpStory_3")

  self:addLabelI18n(1, "beforeLoad_7")
    
  self:addBlank()
  
  self:playMusic("credit")
end

return E8Credit
