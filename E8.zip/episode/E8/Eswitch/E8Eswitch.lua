local E8Eswitch = class("E8Eswitch", function()
  return BasePlace.new()
end)

function E8Eswitch:initPhoto()
end

function E8Eswitch:initButton()
  self:addButton("open", 814, 368, 410, 468)
end

function E8Eswitch:arrowLeft(rect)
  self:switchPlaceLeft("Edoor")
end

function E8Eswitch:beforeLoad()
  self:imageOn("0")
end

function E8Eswitch:afterLoad()

end

function E8Eswitch:afterLoad2()
  self:cacheImage("Edoor/0")
end

function E8Eswitch:beforeUseItem(itemName)
  return false
end

function E8Eswitch:afterUseItem(itemName)
  return true
end

function E8Eswitch:open(rect)
  self:sayI18n("open_1")
end

return E8Eswitch
