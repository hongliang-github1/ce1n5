local E8Dbike = class("E8Dbike", function()
  return BasePlace.new()
end)

function E8Dbike:initPhoto()
end

function E8Dbike:initButton()
  self:addButton("seeDashboard", 730, 0, 636, 396)
  self:addButton("seeAutobike", 730, 400, 636, 748, false)
  self:addButton("seeAutobike2", 1368, 0, 300, 1004, false)
end

function E8Dbike:arrowDown(rect)
  self:switchPlaceZoomOut("Ddoor")
end

function E8Dbike:beforeLoad()
  self:imageOn("0")
end

function E8Dbike:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Dbike:afterLoad2()
  self:cacheImage("Ddoor/0")
  self:cacheImage("DbikeNear/0")
end

function E8Dbike:beforeUseItem(itemName)
  return false
end

function E8Dbike:afterUseItem(itemName)
  return true
end

function E8Dbike:seeDashboard(rect)
  self:switchPlaceZoomIn("DbikeNear", rect)
end

function E8Dbike:seeAutobike(rect)
  self:sayI18n("seeAutobike_1")
end

function E8Dbike:seeAutobike2(rect)
  self:seeAutobike(button)
end

return E8Dbike
