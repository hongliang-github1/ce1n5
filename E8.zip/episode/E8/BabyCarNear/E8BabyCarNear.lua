local E8BabyCarNear = class("E8BabyCarNear", function()
  return BasePlace.new()
end)

function E8BabyCarNear:initPhoto()
  self:addPhoto("1", 768, 384)
end

function E8BabyCarNear:initButton()
  self:addButton("getUltralight", 768, 226, 588, 592)
end

function E8BabyCarNear:arrowDown(rect)
  self:switchPlaceZoomOut("BabyCar");
end

function E8BabyCarNear:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("ultralight") == 0 then
    self:imageOn("1")
  end
end

function E8BabyCarNear:afterLoad()
  if self:imageIsOn("1") then
    self:sayI18n("afterLoad_1")
  end
end

function E8BabyCarNear:afterLoad2()
  self:cacheImage("BabyCar/0")

  if self:getInteger("ultralight") == 0 then
    self:cacheImage("Ultralight/0")
  end
end

function E8BabyCarNear:beforeUseItem(itemName)
  return false
end

function E8BabyCarNear:afterUseItem(itemName)
  return true
end

function E8BabyCarNear:getUltralight(rect)
  if self:getInteger("ultralight") == 0 then
    self:imageOff("1")
    self:switchPlace("Ultralight")
    
    return
  end
  
  self:sayI18n("getUltralight_1")
end

return E8BabyCarNear
