local E8Ultralight = class("E8Ultralight", function()
  return BasePlace.new()
end)

function E8Ultralight:initPhoto()
  self:addPhoto("1", 0, 0)
end

function E8Ultralight:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E8Ultralight:beforeLoad()
  self:imageOn("0")
end

function E8Ultralight:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Ultralight:afterLoad2()
  self:cacheImage("BabyCarNear/0")
end

function E8Ultralight:recordLastPlaceName()
  return false
end

function E8Ultralight:beforeUseItem(itemName)
  return false
end

function E8Ultralight:afterUseItem(itemName)
  return true
end

function E8Ultralight:click(rect)
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:play("uvlight")
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:getItem("ultralight")
    self:sayI18n("click_3")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:switchPlace("BabyCarNear")
    
    return
  end
end

return E8Ultralight
