local E8Tip = class("E8Tip", function()
  return BaseTip.new()
end)

function E8Tip:getTipAtIndex(index)
  self:resetProgress()

  -- 刚进游戏，还没点击屏幕得到防狼手电
  if self:nextProgress() == index or (self:getInteger("shock") == 0) then
    self:addPlace("Beginning")
    
    self:textI18n("progress_1")

    return self.progress
  end

  -- 还没用防狼手电击晕坏人
  if self:nextProgress() == index or (self:getInteger("enemy_dead") == 0) then
    local place = self:addPlace("Attack")

    place:markButton("electricShockAss")
    place:markButton("electricShockWaist")
    place:markButton("electricShockBack")
    place:markButton("electricShockNeck")

    self:textI18n("progress_2")

    return self.progress
  end
  
  -- 坏人电晕了，接下来下车库里
  if self:nextProgress() == index or (self:getInteger("way_gh_visited") == 0) then
    self:addPlace("Entry")
    self:addPlace("WayGH")

    self:textI18n("progress_3")
    
    return self.progress
  end
  
  -- 先去探索最深处
  if self:nextProgress() == index or (self:getInteger("way_ab_visited") == 0) then
    self:addPlace("WayGH"):markButton("goWayEF")
    self:addPlace("WayEF"):markButton("goWayCD")
    self:addPlace("WayCD"):markButton("goWayAB")
    
    self:textI18n("progress_4")
    
    return self.progress
  end
  
  -- 去开C房间的灯
  if self:nextProgress() == index or (self:getInteger("room_c_switched") == 0) then
    self:addPlace("WayCD"):markButton("goDoorsCD")
    self:addPlace("DoorsCD"):markButton("goCdoor")
    self:addPlace("Cdoor"):markButton("_right")
    
    self:textI18n("progress_5")
    
    return self.progress
  end
  
  -- 去拿行李箱
  if self:nextProgress() == index or (self:getInteger("luggage") == 0) then
    self:addPlace("DoorsCD"):markButton("goCdoor")
    self:addPlace("Cdoor"):markButton("goCout")
    self:addPlace("Cout"):markButton("goCluggage")
    
    self:textI18n("progress_6")
    
    return self.progress
  end
  
  -- 查看行李箱，给小华打电话，得知用笔捅开拉链
  if self:nextProgress() == index or (self:getInteger("ask_open") == 0) then
    self:addPlace("Luggage"):markButton("goLuggageLock")
    self:addPlace("LuggageLock"):markButton("click")
    
    self:textI18n("progress_8")
    
    return self.progress
  end
  
  -- 去找笔，笔可能在X房间，需要先打开两个灯开关，打开儿童车上方的开关
  if self:nextProgress() == index or (self:getInteger("baby_car_switch") == 0) then
    self:addPlace("WayAB"):markButton("_right")
    self:addPlace("BabyCarSwitch"):markButton("open")
    
    self:textI18n("progress_9")
    
    return self.progress
  end
  
  -- 去X房间拿笔
  if self:nextProgress() == index or (self:getInteger("pencil") == 0) then
    self:addPlace("TrikeX"):markButton("goXdoor")
    self:addPlace("Xdoor"):markButton("_right")
    self:addPlace("Xpole"):markButton("click")
    
    self:textI18n("progress_13")
    
    return self.progress
  end
  
  -- 去拿小刀
  if self:nextProgress() == index or (self:getInteger("knife") == 0) then
    self:addPlace("WayEF"):markButton("goWayCD")
    self:addPlace("WayCD"):markButton("goPlug")
    self:addPlace("Plug"):markButton("click")
    
    self:textI18n("progress_14")
    
    return self.progress
  end

  -- 去尝试磨刀
  if self:nextProgress() == index or (self:getInteger("tried_sharp_knife") == 0 and self:getInteger("knife") ~= 2) then
    self:addPlace("Pencil"):imageOn("2")
    
    self:textI18n("progress_15")
    
    return self.progress
  end

  -- 去拿灯泡
  if self:nextProgress() == index or (self:getInteger("bulb") == 0) then
    self:addPlace("DoorsCD"):markButton("goCdoor")
    self:addPlace("Cdoor"):markButton("goCout")
    self:addPlace("Cout"):markButton("goCbulb")
    
    self:textI18n("progress_16")
    
    return self.progress
  end
  
  -- 去打开B房间（自行车）的灯，使用灯泡
  if self:nextProgress() == index or (self:getInteger("room_b_switch") == 0 or self:getInteger("bulb") > 0) then
    self:addPlace("Bdoor"):markButton("goBswitch")
    self:addPlace("Bswitch"):markButton("open")
    self:addPlace("Bbulb"):markButton("click")

    self:textI18n("progress_17")
    
    return self.progress
  end
  
  -- 去捡车钥匙
  if self:nextProgress() == index or (self:getInteger("keyb") == 0) then
    self:addPlace("Bdoor"):markButton("goBikeSide")
    self:addPlace("BikeSide"):markButton("battery")
    self:addPlace("BatteryHole"):markButton("goBatteryHoleNear")
    
    self:textI18n("progress_18")
    
    return self.progress
  end
  
  -- 使用车钥匙，尝试通电，不成
  if self:nextProgress() == index or (self:getInteger("keyb") > 0) then
    self:addPlace("BikeSide"):markButton("goDashboard")
    self:addPlace("Dashboard"):markButton("goKeyhole")
    self:addPlace("Keyhole"):markButton("open")
    
    self:textI18n("progress_19")
    
    return self.progress
  end
  
  -- 去拿电瓶，先开D房间的灯
  if self:nextProgress() == index or (self:getInteger("room_d_switched") == 0) then
    self:addPlace("DoorsCD"):markButton("goDdoor")
    self:addPlace("Ddoor"):markButton("_left")
    self:addPlace("Dswitch"):markButton("open")
    
    self:textI18n("progress_20")
    
    return self.progress
  end
  
  -- 去拿电瓶
  if self:nextProgress() == index or (self:getInteger("battery") == 0) then
    self:addPlace("Ddoor"):markButton("goDbike")
    self:addPlace("Dbike"):markButton("seeDashboard")
    self:addPlace("DbikeNear"):markButton("goDbattery")
    
    self:textI18n("progress_21")
    
    return self.progress
  end

  -- 使用电瓶
  if self:nextProgress() == index or (self:getInteger("battery") > 0) then
    self:addPlace("BikeSide"):markButton("battery")
    self:addPlace("BikeBattery"):markButton("click")
    
    self:textI18n("progress_22")
    
    return self.progress
  end
  
  -- 电动自行车已经可以转了，去将钥匙拧到ON挡
  if self:nextProgress() == index or (self:getInteger("keyb_on") < 1) then
    self:addPlace("BikeSide"):markButton("goDashboard")
    self:addPlace("Dashboard"):markButton("goKeyhole")
    self:addPlace("Keyhole"):markButton("open")
    
    self:textI18n("progress_44")
    
    return self.progress
  end

  -- 拧油门，定速巡航
  if self:nextProgress() == index or (self:getInteger("throttle_hold") == 0) then
    self:addPlace("BikeSide"):markButton("goDashboard")
    self:addPlace("Dashboard"):markButton("goAccelerator")
    self:addPlace("Throttle")

    self:textI18n("progress_45")
    
    return self.progress
  end
    
  -- 磨刀
  if self:nextProgress() == index or (self:getInteger("knife") == 1) then
    self:addPlace("BikeSide"):markButton("lock")
    self:addPlace("WheelSpin"):markButton("knife")
    
    self:textI18n("progress_46")
    
    return self.progress
  end
  
  -- 削铅笔
  if self:nextProgress() == index or (self:getInteger("knife") > 0 or self:getInteger("pencil") == 1) then
    if self:getInteger("pencil") == 2 then
      self:addPlace("Pencil")
    else
      self:addPlace("Pencil"):imageOn("2")
    end
    
    self:textI18n("progress_47")
    
    return self.progress
  end
  
  -- 用铅笔捅开行李箱
  if self:nextProgress() == index or (self:getInteger("pencil") == 2 or self:getInteger("luggage_open") == 0) then
    self:addPlace("LuggageOpen")
    
    self:textI18n("progress_48")
    
    return self.progress
  end
  
  -- 得到信封
  if self:nextProgress() == index or (self:getInteger("envelope") == 0) then
    self:addPlace("LuggageOpen"):markButton("click")
    
    self:textI18n("progress_49")
    
    return self.progress
  end
  
  -- 得到房卡
  if self:nextProgress() == index or (self:getInteger("card") == 0) then
    self:addPlace("Envelope")
    
    self:textI18n("progress_50")
    
    return self.progress
  end

  -- 接下来需要用紫外线手电照信封，先去拿手电
  if self:nextProgress() == index or (self:getInteger("ultralight") == 0) then
    self:addPlace("WayAB"):markButton("_right")
    self:addPlace("BabyCarSwitch"):markButton("goBabyCar")
    self:addPlace("BabyCar"):markButton("goBabyCarNear")
    
    self:textI18n("progress_23")
    
    return self.progress
  end
  
  -- 对着信封使用紫外线手电，通关
  if self:nextProgress() == index or true then
    self:addPlace("Envelope")
    
    self:textI18n("progress_51")
    
    return self.progress
  end
  
  return self:nextProgress()
end

return E8Tip
