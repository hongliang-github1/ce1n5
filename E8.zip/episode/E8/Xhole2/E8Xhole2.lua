local E8Xhole2 = class("E8Xhole2", function()
  return BasePlace.new()
end)

function E8Xhole2:initPhoto()
end

function E8Xhole2:initButton()
end

function E8Xhole2:arrowDown(rect)
  self:switchPlaceZoomOut("Xpole")
end

function E8Xhole2:beforeLoad()
  self:imageOn("0")
end

function E8Xhole2:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Xhole2:afterLoad2()
  self:cacheImage("Xpole/0")
end

function E8Xhole2:beforeUseItem(itemName)
  return false
end

function E8Xhole2:afterUseItem(itemName)
  return true
end

return E8Xhole2
