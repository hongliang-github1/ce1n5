local E8Ebulb = class("E8Ebulb", function()
  return BasePlace.new()
end)

function E8Ebulb:initPhoto()
end

function E8Ebulb:initButton()
  self:addButton("see", 658, 212, 720, 716, false)
end

function E8Ebulb:arrowDown(rect)
  self:switchPlaceZoomOut("Edoor")
end

function E8Ebulb:beforeLoad()
  self:imageOn("0")
end

function E8Ebulb:afterLoad()
  
end

function E8Ebulb:afterLoad2()
  self:cacheImage("Edoor/0")
end

function E8Ebulb:beforeUseItem(itemName)
  if "bulb" == itemName then
    return true
  end
  
  return false
end

function E8Ebulb:afterUseItem(itemName)
  if "bulb" == itemName then
    self:sayI18n("afterUseItem_1")
    
    return true
  end
  
  return true
end

function E8Ebulb:see(rect)
  self:sayI18n("see_1")
end

return E8Ebulb
