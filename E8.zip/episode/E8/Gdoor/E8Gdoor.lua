local E8Gdoor = class("E8Gdoor", function()
  return BasePlace.new()
end)

function E8Gdoor:initPhoto()
end

function E8Gdoor:initButton()
  self:addButton("goGwall", 798, 0, 1246, 486, false)
end

function E8Gdoor:arrowRight(rect)
  self:switchPlaceRight("Gswitch")
end

function E8Gdoor:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsGH")
end

function E8Gdoor:beforeLoad()
  if self:getInteger("room_g_switch") == 1 then
    self:imageOn("2")
    
    return
  end
  
  self:imageOn("1")
end

function E8Gdoor:afterLoad()
end

function E8Gdoor:afterLoad2()
  if self:getInteger("room_g_switch") == 1 then
    self:cacheImage("Gswitch/1")

  else  
    self:cacheImage("Gswitch/0")
  end

  if self:getInteger("room_g_switch") == 1 then
    self:cacheImage("DoorsGH/0")
    
  else  
    self:cacheImage("DoorsGH/1")
  end
end

function E8Gdoor:beforeUseItem(itemName)
  return false
end

function E8Gdoor:afterUseItem(itemName)
  return true
end

function E8Gdoor:goGwall(rect)
  self:sayI18n("afterLoad_1")
end

function E8Gdoor:onTouchBegan(touch, event)
  -- 已经开灯了，或者用过手电筒了，什么都不干
  if not self:imageIsOn("0") then
    self:sayI18n("click_1")
    
    return
  end
end

return E8Gdoor
