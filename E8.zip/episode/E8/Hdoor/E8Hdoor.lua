local E8Hdoor = class("E8Hdoor", function()
  return BasePlace.new()
end)

function E8Hdoor:initPhoto()
end

function E8Hdoor:initButton()
  self:addButton("goHwall", 68, 0, 916, 462, false)
end

function E8Hdoor:arrowLeft(rect)
  self:switchPlaceLeft("Hswitch")
end

function E8Hdoor:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsGH")
end

function E8Hdoor:beforeLoad()
  self:imageOn("1")
end

function E8Hdoor:afterLoad()
end

function E8Hdoor:afterLoad2()
  self:cacheImage("Hswitch/0")

  if self:getInteger("room_g_switch") == 1 then
    self:cacheImage("DoorsGH/0")

  else  
    self:cacheImage("DoorsGH/1")
  end
end

function E8Hdoor:beforeUseItem(itemName)
  return false
end

function E8Hdoor:afterUseItem(itemName)
  return true
end

function E8Hdoor:goHwall(rect)
  if self:imageIsOn("1") then
    self:sayI18n("afterLoad_1")
    
    return
  end
end

return E8Hdoor
