local E8AchairNear = class("E8AchairNear", function()
  return BasePlace.new()
end)

function E8AchairNear:initPhoto()
  self:addPhoto("1", 896, 512)
end

function E8AchairNear:initButton()
  self:addButton("turn", 810, 362, 828, 604)
end

function E8AchairNear:arrowDown(rect)
  self:switchPlaceZoomOut("Achair")
end

function E8AchairNear:beforeLoad()
  self:imageOn("0")
end

function E8AchairNear:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8AchairNear:afterLoad2()
  self:cacheImage("Achair/0")
end

function E8AchairNear:beforeUseItem(itemName)
  return false
end

function E8AchairNear:afterUseItem(itemName)
  return true
end

function E8AchairNear:turn(rect)
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("turn_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("turn_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("turn_3")
    
    return
  end
end

return E8AchairNear
