local E8Cbulb = class("E8Cbulb", function()
  return BasePlace.new()
end)

function E8Cbulb:initPhoto()
  self:addPhoto("1", 832, 704)
  self:addPhoto("2", 768, 192)
  self:addPhoto("3", 832, 704)
end

function E8Cbulb:initButton()
  self:addButton("getBulb", 714, 564, 418, 396)
end

function E8Cbulb:arrowDown(rect)
  self:switchPlaceZoomOut("Cout")
end

function E8Cbulb:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("room_d_switch") == 1 then
    self:imageOn("2")
    
    if self:getInteger("bulb") == 0 then
      self:imageOn("3")
    end
    
    return
  end
  
  if self:getInteger("bulb") == 0 then
    self:imageOn("1")
  end
end

function E8Cbulb:afterLoad()
  if self:imageIsOn("1") or self:imageIsOn("3") then
    self:sayI18n("afterLoad_1")
  end
end

function E8Cbulb:afterLoad2()
  self:cacheImage("Cout/0")
end

function E8Cbulb:beforeUseItem(itemName)
  return false
end

function E8Cbulb:afterUseItem(itemName)
  return true
end

function E8Cbulb:getBulb(rect)
  if self:getInteger("bulb") == 0 then
    if self:getInteger("room_d_switch") == 1 then
      self:imageOff("3")
      
    else
      self:imageOff("1")
    end
    
    self:getItem("bulb")
    self:sayI18n("getBulb_1")
    
    return
  end
  
  self:sayI18n("getBulb_2")
end

return E8Cbulb
