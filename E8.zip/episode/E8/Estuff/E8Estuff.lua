local E8Estuff = class("E8Estuff", function()
  return BasePlace.new()
end)

function E8Estuff:initPhoto()
end

function E8Estuff:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E8Estuff:arrowDown(rect)
  self:switchPlaceZoomOut("Edoor")
end

function E8Estuff:beforeLoad()
  self:imageOn("0")
end

function E8Estuff:afterLoad()

end

function E8Estuff:afterLoad2()
  self:cacheImage("Edoor/0")
end

function E8Estuff:beforeUseItem(itemName)
  return false
end

function E8Estuff:afterUseItem(itemName)
  return true
end

function E8Estuff:click(rect)
  self:sayI18n("click_1")
end

return E8Estuff
