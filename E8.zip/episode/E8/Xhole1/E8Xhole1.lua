local E8Xhole1 = class("E8Xhole1", function()
  return BasePlace.new()
end)

function E8Xhole1:initPhoto()
end

function E8Xhole1:initButton()
end

function E8Xhole1:arrowDown(rect)
  self:switchPlaceZoomOut("Xpole")
end

function E8Xhole1:beforeLoad()
  self:imageOn("0")
end

function E8Xhole1:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Xhole1:afterLoad2()
  self:cacheImage("Xpole/0")
end

function E8Xhole1:beforeUseItem(itemName)
  return false
end

function E8Xhole1:afterUseItem(itemName)
  return true
end

return E8Xhole1
