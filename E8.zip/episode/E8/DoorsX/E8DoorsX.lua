local E8DoorsX = class("E8DoorsX", function()
  return BasePlace.new()
end)

function E8DoorsX:initPhoto()
end

function E8DoorsX:initButton()
  self:addButton("goTrikeX", 240, 0, 1650, 1148)
end

function E8DoorsX:arrowDown(rect)
  self:switchPlaceZoomOut("WayAB")
end

function E8DoorsX:beforeLoad()
  self:imageOn("0")
end

function E8DoorsX:afterLoad()

end

function E8DoorsX:afterLoad2()
  self:cacheImage("TrikeX/0")

  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayAB/4")
    
  elseif self:getInteger("room_a_switch") == 1 and self:getInteger("room_b_switch") == 1 then
    self:cacheImage("WayAB/3")
    
  elseif self:getInteger("room_a_switch") == 1 then
    self:cacheImage("WayAB/2")
    
  elseif self:getInteger("room_b_switch") == 1 then
    self:cacheImage("WayAB/1")
    
  else
    self:cacheImage("WayAB/0")
  end
end

function E8DoorsX:beforeUseItem(itemName)
  return false
end

function E8DoorsX:afterUseItem(itemName)
  return true
end

function E8DoorsX:goTrikeX(rect)
  self:switchPlaceZoomIn("TrikeX", cc.rect(940, 100, 934, 800))
end

return E8DoorsX
