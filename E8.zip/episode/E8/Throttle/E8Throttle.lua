local E8Throttle = class("E8Throttle", function()
  return BasePlace.new()
end)

function E8Throttle:initPhoto()
  self:addPhoto("1", 320, 192)
  self:addPhoto("2", 320, 192)
  self:addPhoto("3", 320, 192)
  self:addPhoto("4", 0, 0)
end

function E8Throttle:initButton()
end

function E8Throttle:arrowDown(rect)
  if self.wheelrollPlayId then
    self:stopEffect(self.wheelrollPlayId)
  end
  
  self:switchPlaceZoomOut("Dashboard")
end

function E8Throttle:beforeLoad()
  self:imageOn("0")
    
  if self:getInteger("throttle_hold") == 1 then
    -- 已经是定速巡航状态了，显示后轮转动小图
    self:imageOn("3")
    self:imageOn("4")
    self.wheelrollPlayId = self:play("wheelroll", true)
  end
end

function E8Throttle:afterLoad()
  if self:imageIsOn("4") then
    self:sayI18n("afterLoad_1")
    
  else
    self:sayI18n("afterLoad_2")
  end
end

function E8Throttle:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("2")
  self:cacheImage("3")
  self:cacheImage("Dashboard/0")
end

function E8Throttle:beforeUseItem(itemName)
  return false
end

function E8Throttle:afterUseItem(itemName)
  return true
end

function E8Throttle:onTouchBegan(touch, event)
  if self:getInteger("throttle_hold") == 1 then
    -- 已经在巡航了，不做任何事情
    
    return
  end

  if self:getInteger("battery") >= 0 or self:getInteger("keyb_on") < 1 then
    -- 电瓶没使用，或者钥匙没拧开，没反应
    self:sayI18n("buttonTouchesEnd_1")

    return
  end

  self:disableTouch()
  self:scheduleTimes(0.2, 4, function(index)
    if index > 3 then
      self:imageOn("4")
      self:setInteger("throttle_hold", 1)
      self.wheelrollPlayId = self:play("wheelroll", true)
      self:sayI18n("afterLoad_1")
      self:enableTouch()

      return
    end

    self:imageOn(tostring(index))

    if index > 1 then
      self:imageOff(tostring(index - 1))
    end
  end)
end

return E8Throttle
