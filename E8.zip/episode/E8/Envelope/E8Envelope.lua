local E8Envelope = class("E8Envelope", function()
  return BasePlace.new()
end)

function E8Envelope:initPhoto()
end

function E8Envelope:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E8Envelope:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "WayGH")
end

function E8Envelope:beforeLoad()
  self.cardProgress       = 0
  self.ultralightProgress = 0

  if self:getInteger("card") == 0 then
      self:imageOn("0")
      self:sayI18n("beforeLoad_1")
      
  else
      self:imageOn("4")
      self:sayI18n("beforeLoad_2")
  end
end

function E8Envelope:afterLoad2()
  self:cacheImage("Exit/1")
end

function E8Envelope:recordLastPlaceName()
  return false
end

function E8Envelope:beforeUseItem(itemName)
  if "ultralight" == itemName and self:imageIsOn("4") and self:getInteger("card") > 0 then
    return true
  end
  
  return false
end

function E8Envelope:afterUseItem(itemName)
  if "ultralight" == itemName then
    -- 这里得知线索
    self:imageOn("5")
    self:play("item")
    self:hideArrowButton()
    self:sayI18n("afterUseItem_1")
    
    self.ultralighted = true
    
    return true
  end
  
  return true
end

function E8Envelope:click(rect)
  if self.ultralighted then
    self:clickUltralight()
    
    return
  end
  
  if self:getInteger("card") > 0 then
    self:sayI18n("click_1")
    
    return
  end
  
  self.cardProgress = self.cardProgress + 1
  
  self:resetProgressIndex()
  
  if self.cardProgress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_2")
    
    return
  end
  
  if self.cardProgress == self:nextProgressIndex() then
    self:imageOn("2")
    self:sayI18n("click_3")
    
    return
  end
  
  if self.cardProgress == self:nextProgressIndex() then
    self:imageOn("3")
    self:sayI18n("click_4")
    
    return
  end
  
  if self.cardProgress == self:nextProgressIndex() then
    self:imageOn("4")
    self:sayI18n("click_5")
    
    return
  end
  
  if self.cardProgress == self:nextProgressIndex() then
    self:getItem("card")
    self:sayI18n("click_6")
    
    return
  end
end

function E8Envelope:clickUltralight()
  self.ultralightProgress = self.ultralightProgress + 1

  self:resetProgressIndex()
  
  if self.ultralightProgress == self:nextProgressIndex() then
    self:sayI18n("clickUltralight_1")
    
    return
  end
  
  if self.ultralightProgress == self:nextProgressIndex() then
    self:sayI18n("clickUltralight_2")
    
    return
  end
  
  if self.ultralightProgress == self:nextProgressIndex() then
    self:sayI18n("clickUltralight_3")
    
    return
  end
  
  if self.ultralightProgress == self:nextProgressIndex() then
    self:sayI18n("clickUltralight_4")
    
    return
  end
  
  if self.ultralightProgress == self:nextProgressIndex() then
    self:setInteger("envelop_tipped", 1)
    self:switchPlace("Exit")
    
    return
  end
end

return E8Envelope
