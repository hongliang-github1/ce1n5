local E8Edoor = class("E8Edoor", function()
  return BasePlace.new()
end)

function E8Edoor:initPhoto()
end

function E8Edoor:initButton()
  self:addButton("goEwall", 912, 250, 814, 380, false)
  self:addButton("goEstuff", 112, 708, 1636, 438)
  self:addButton("goEbulb", 540, 0, 734, 246)
end

function E8Edoor:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsEF")
end

function E8Edoor:arrowRight(rect)
  self:switchPlaceRight("Eswitch")
end

function E8Edoor:beforeLoad()
  self:imageOn("1")
end

function E8Edoor:afterLoad()
end

function E8Edoor:afterLoad2()
  self:cacheImage("Eswitch/0")
  self:cacheImage("DoorsEF/0")
end

function E8Edoor:beforeUseItem(itemName)
  return false
end

function E8Edoor:afterUseItem(itemName)
  return true
end

function E8Edoor:goEwall(rect)
  self:sayI18n("afterLoad_1")
end

function E8Edoor:goEstuff(rect)
  self:switchPlaceZoomIn("Estuff", cc.rect(360, 704, 1070, 440))
end

function E8Edoor:goEbulb(rect)
  self:switchPlaceZoomIn("Ebulb", rect)
end

return E8Edoor
