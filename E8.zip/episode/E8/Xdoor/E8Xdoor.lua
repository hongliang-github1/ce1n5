local E8Xdoor = class("E8Xdoor", function()
  return BasePlace.new()
end)

function E8Xdoor:initPhoto()
end

function E8Xdoor:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E8Xdoor:arrowDown(rect)
  self:switchPlaceZoomOut("TrikeX")
end

function E8Xdoor:arrowRight(rect)
  self:switchPlaceRight("Xpole")
end

function E8Xdoor:beforeLoad()
  self:imageOn("0")
end

function E8Xdoor:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Xdoor:afterLoad2()
  e8.removeCacheGroomToFroom(self)
  e8.removeCacheDroomToCroom(self)
  e8.removeCacheBroom(self)
  
  self:cacheImage("TrikeX/0")
  self:cacheImage("Xpole/0")
end

function E8Xdoor:beforeUseItem(itemName)
  return false
end

function E8Xdoor:afterUseItem(itemName)
  return true
end

function E8Xdoor:click(rect)
  self:sayI18n("click_1")
end

return E8Xdoor
