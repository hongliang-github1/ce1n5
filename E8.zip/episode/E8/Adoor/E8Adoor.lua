local E8Adoor = class("E8Adoor", function()
  return BasePlace.new()
end)

function E8Adoor:initPhoto()
end

function E8Adoor:initButton()
  self:addButton("click", 474, 0, 1292, 606)
  self:addButton("goAchair", 716, 608, 578, 540)
end

function E8Adoor:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsAB")
end

function E8Adoor:arrowRight(rect)
  self:switchPlaceRight("Aswitch")
end

function E8Adoor:beforeLoad()
  if self:getInteger("room_a_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8Adoor:afterLoad()
end

function E8Adoor:afterLoad2()
  if self:getInteger("room_a_switch") == 1 then
    self:cacheImage("Aswitch/1")
    self:cacheImage("Achair/0")
    self:cacheImage("AwoodOut/0")
    
  else
    self:cacheImage("Aswitch/0")
  end

  if self:getInteger("room_a_switch") == 1 and self:getInteger("room_b_switch") == 1 then
    self:cacheImage("DoorsAB/3")
    
  elseif self:getInteger("room_a_switch") == 1 then
    self:cacheImage("DoorsAB/2")
    
  elseif self:getInteger("room_b_switch") == 1 then
    self:cacheImage("DoorsAB/1")
    
  else
    self:cacheImage("DoorsAB/0")
  end
end

function E8Adoor:beforeUseItem(itemName)
  return false
end

function E8Adoor:afterUseItem(itemName)
  return true
end

function E8Adoor:goAchair(rect)
  if self:imageIsOn("1") then
    self:switchPlaceZoomIn("Achair", rect)
    
    return
  end
  
  self:sayI18n("goAchair_1")
end

function E8Adoor:click(rect)
  if self:imageIsOn("1") then
    self:switchPlaceZoomIn("AwoodOut", cc.rect(868, 356, 512, 476))
    
    return
  end
  
  self:sayI18n("click_1")
end

return E8Adoor
