local E8Aswitch = class("E8Aswitch", function()
  return BasePlace.new()
end)

function E8Aswitch:initPhoto()
end

function E8Aswitch:initButton()
  self:addButton("open", 852, 342, 432, 432)
end

function E8Aswitch:arrowLeft(rect)
  self:switchPlaceLeft("Adoor")
end

function E8Aswitch:beforeLoad()
  if self:getInteger("room_a_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8Aswitch:afterLoad()
  
end

function E8Aswitch:afterLoad2()
  self:cacheImage("Adoor/0")
end

function E8Aswitch:beforeUseItem(itemName)
  return false
end

function E8Aswitch:afterUseItem(itemName)
  return true
end

function E8Aswitch:open(rect)
  if self:imageIsOn("0") then
    -- 开灯
    self:imageOn("1")
    self:setInteger("room_a_switch", 1)
    self:play("switch")
    self:sayI18n("open_1")
    
    -- 记录开过灯，给tip用
    if self:getInteger("room_a_switched") < 1 then
      self:setInteger("room_a_switched", 1)
    end

    return
  end
  
  -- 关灯
  self:imageOn("0")
  self:setInteger("room_a_switch", 0)
  self:play("switch")
  self:sayI18n("open_2")
end

return E8Aswitch
