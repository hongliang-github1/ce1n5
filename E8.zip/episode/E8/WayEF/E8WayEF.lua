local E8WayEF = class("E8WayEF", function()
  return BasePlace.new()
end)

function E8WayEF:initPhoto()
end

function E8WayEF:initButton()
  self:addButton("goDoorsEF", 466, 190, 380, 898)
  self:addButton("goWayCD", 854, 296, 298, 550)
end

function E8WayEF:arrowDown(rect)
  self:switchPlaceZoomOut("WayGH")
end

function E8WayEF:beforeLoad()
  if self:getInteger("baby_car_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8WayEF:afterLoad()

end

function E8WayEF:afterLoad2()
  if self:getInteger("baby_car_switch") == 1 and self:getInteger("room_d_switch") == 1 then
    self:cacheImage("WayCD/3")
    
  elseif self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayCD/2")
    
  elseif self:getInteger("room_d_switch") == 1 then
    self:cacheImage("WayCD/1")
    
  else
    self:cacheImage("WayCD/0")
  end

  self:cacheImage("DoorsEF/0")

  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayGH/2")

  else
    self:cacheImage("WayGH/0")
  end
end

function E8WayEF:beforeUseItem(itemName)
  return false
end

function E8WayEF:afterUseItem(itemName)
  return true
end

function E8WayEF:goDoorsEF(rect)
  self:switchPlaceZoomIn("DoorsEF", cc.rect(466, 346, 386, 544))
end

function E8WayEF:goWayCD(rect)
  self:switchPlaceZoomIn("WayCD", rect)
end

return E8WayEF
