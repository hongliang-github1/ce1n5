local E8WayCD = class("E8WayCD", function()
  return BasePlace.new()
end)

function E8WayCD:initPhoto()
end

function E8WayCD:initButton()
  self:addButton("goDoorsCD", 134, 0, 740, 1146)
  self:addButton("goWayAB", 970, 156, 528, 730)
  self:addButton("goPlug", 1502, 488, 252, 282)
end

function E8WayCD:arrowDown(rect)
  self:switchPlaceZoomOut("WayEF")
end

function E8WayCD:beforeLoad()
  if self:getInteger("baby_car_switch") == 1 and self:getInteger("room_d_switch") == 1 then
    self:imageOn("3")
    
    return
  end
  
  if self:getInteger("baby_car_switch") == 1 then
    self:imageOn("2")
    
    return
  end
  
  if self:getInteger("room_d_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8WayCD:afterLoad()

end

function E8WayCD:afterLoad2()
  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayAB/4")
    
  elseif self:getInteger("room_a_switch") == 1 and self:getInteger("room_b_switch") == 1 then
    self:cacheImage("WayAB/3")
    
  elseif self:getInteger("room_a_switch") == 1 then
    self:cacheImage("WayAB/2")
    
  elseif self:getInteger("room_b_switch") == 1 then
    self:cacheImage("WayAB/1")
    
  else
    self:cacheImage("WayAB/0")
  end

  if self:getInteger("room_c_switch") == 1 and self:getInteger("room_d_switch") == 1 then
    self:cacheImage("DoorsCD/3")
    
  elseif self:getInteger("room_c_switch") == 1 then
    self:cacheImage("DoorsCD/2")
    
  elseif self:getInteger("room_d_switch") == 1 then
    self:cacheImage("DoorsCD/1")
    
  else
    self:cacheImage("DoorsCD/0")
  end

  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayEF/1")
    
  else
    self:cacheImage("WayEF/0")
  end
end

function E8WayCD:beforeUseItem(itemName)
  return false
end

function E8WayCD:afterUseItem(itemName)
  return true
end

function E8WayCD:goDoorsCD(rect)
  self:switchPlaceZoomIn("DoorsCD",cc.rect(130, 180, 744, 780))
end

function E8WayCD:goWayAB(rect)
  self:switchPlaceZoomIn("WayAB", rect)
end

function E8WayCD:goPlug(rect)
  self:switchPlaceZoomIn("Plug", rect)
end

return E8WayCD
