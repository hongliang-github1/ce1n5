local E8Bbulb = class("E8Bbulb", function()
  return BasePlace.new()
end)

function E8Bbulb:initPhoto()
end

function E8Bbulb:initButton()
  self:addButton("click", 388, 0, 1188, 922)
end

function E8Bbulb:beforeLoad()
  -- 判断灯泡是否使用了，如果使用了，就需要显示上了灯泡的图，加这个判断是为了保证当用户使用了灯泡之后设置成no了，这时候程序崩溃，下次进来的时候能正确的显示
  if self:getInteger("bulb") < 0 then
    self:imageOn("1")
    self:sayI18n("beforeLoad_1")
    
  else
    self:imageOn("0")
    self:sayI18n("beforeLoad_2")
  end
end

function E8Bbulb:afterLoad()
end

function E8Bbulb:afterLoad2()
  self:cacheImage("Bswitch/0")
end

function E8Bbulb:beforeUseItem(itemName)
  if "bulb" == itemName then
    return true
  end
  
  return false
end

function E8Bbulb:afterUseItem(itemName)
  if "bulb" == itemName then
    -- 把灯泡装上去
    self:imageOn("1")
    self:sayI18n("afterUseItem_1")
    
    return false
  end
  
  return true
end

function E8Bbulb:click(rect)
  if self:imageIsOn("1") then
    self:imageOn("2")
    self:setInteger("room_b_switch", 1)
    self:play("item")
    self:sayI18n("click_1")
    
    return
  end
  
  self:switchPlace("Bswitch")
end

return E8Bbulb
