local E8Horn = class("E8Horn", function()
  return BasePlace.new()
end)

function E8Horn:initPhoto()
end

function E8Horn:initButton()
  self:addButton("honk", 958, 650, 486, 428)
end

function E8Horn:arrowDown(rect)
  self:switchPlaceZoomOut("Dashboard")
end

function E8Horn:beforeLoad()
  self:imageOn("0")
end

function E8Horn:afterLoad()
  self:sayI18n("afterLoad_1")
  
end

function E8Horn:afterLoad2()
  self:cacheImage("Dashboard/0")
end

function E8Horn:beforeUseItem(itemName)
  return false
end

function E8Horn:afterUseItem(itemName)
  return true
end

function E8Horn:honk(rect)
  -- 判断是否已经通电，如果没通电，没反应
  if self:getInteger("keyb") < 0 and self:getInteger("battery") < 0 and self:getInteger("keyb_on") > 0 then
    self:play("speaker")
    self:sayI18n("honk_1")
    
    return
  end
  
  self:sayI18n("honk_2")
end

return E8Horn
