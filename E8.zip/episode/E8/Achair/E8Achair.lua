local E8Achair = class("E8Achair", function()
  return BasePlace.new()
end)

function E8Achair:initPhoto()
  self:addPhoto("0", 0, 0)
end

function E8Achair:initButton()
  self:addButton("goAchairNear", 790, 594, 650, 474)
end

function E8Achair:arrowDown(rect)
  self:switchPlaceZoomOut("Adoor")
end

function E8Achair:beforeLoad()
  self:imageOn("0")
end

function E8Achair:afterLoad()
  if "Adoor" == self.lastPlaceName then
    self:sayI18n("afterLoad_1")
  end
end

function E8Achair:afterLoad2()
  self:cacheImage("Adoor/0")
  self:cacheImage("AchairNear/0")
end

function E8Achair:beforeUseItem(itemName)
  return false
end

function E8Achair:afterUseItem(itemName)
  return true
end

function E8Achair:goAchairNear(rect)
  self:switchPlaceZoomIn("AchairNear", rect)
end

return E8Achair
