local E8Keyhole = class("E8Keyhole", function()
  return BasePlace.new()
end)

function E8Keyhole:initPhoto()
  self:addPhoto("1", 896, 576)
  self:addPhoto("2", 576, 0)
  self:addPhoto("3", 896, 512)
end

function E8Keyhole:initButton()
  self:addButton("open", 738, 316, 696, 660)
end

function E8Keyhole:arrowDown(rect)
  self:switchPlaceZoomOut("Dashboard")
end

function E8Keyhole:beforeLoad()
  self:imageOn("0")
  
  -- 判断是否插入了钥匙，如果插入了钥匙，判断是否使用过电池，如果用了，表示车通电了
  if self:getInteger("keyb") < 0 then
    if self:getInteger("keyb_on") == 0 then
      self:imageOn("1")
      
      return
    end
    
    -- 钥匙已经拧到开的状态了，如果这个时候，电池使用过了，表示车通电了，这个时候显示3，否则显示4
    if self:getInteger("battery") < 0 then
      self:imageOn("2")
      
    else
      self:imageOn("3")
    end
  end
end

function E8Keyhole:afterLoad()
  if self:imageIsOn("2") then
    self:sayI18n("afterLoad_1")
    
  elseif self:imageIsOn("1") or self:imageIsOn("3") then
    self:sayI18n("afterLoad_2")
    
  else
    self:sayI18n("afterLoad_3")
  end
end

function E8Keyhole:afterLoad2()
  self:cacheImage("Dashboard/0")
end

function E8Keyhole:beforeUseItem(itemName)
  if "keyb" == itemName then
    return true
  end
  
  return false
end

function E8Keyhole:afterUseItem(itemName)
  if "keyb" == itemName then
    self:imageOn("1")
    self:play("key")
    self:sayI18n("afterUseItem_1")
    
    return false
  end
  
  return true
end

function E8Keyhole:open(rect)
  -- 如果钥匙没有插进去，点击没反应
  if self:getInteger("keyb") >= 0 then
    return
  end
  
  -- 如果已经是定速巡航状态了，就不能断电了
  if self:getInteger("throttle_hold") == 1 then
    self:sayI18n("open_1")
    
    return
  end
  
  -- 要是插进去之后，判断当前是开还是关，如果是开的话，就关上，如果是关的就打开
  if self:getInteger("keyb_on") == 0 then
    self:imageOff("1")
    self:play("ebikeonoff")
    
    if self:getInteger("battery") < 0 then
      self:imageOn("2")
      self:sayI18n("open_2")
      
    else
      self:imageOn("3")
      self:sayI18n("open_3")
    end
    
    self:setInteger("keyb_on", 1)
    
    return
  end
  
  -- 已经是打开的了，关掉2,3，然后开启1
  self:imageOff("2")
  self:imageOff("3")
  self:imageOn("1")
  self:setInteger("keyb_on", 0)
  self:play("ebikeonoff")
  self:sayI18n("open_4")
end

return E8Keyhole
