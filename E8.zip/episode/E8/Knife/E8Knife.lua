local E8Knife = class("E8Knife", function()
  return BasePlace.new()
end)

function E8Knife:initPhoto()
  self:addPhoto("2", 384, 384)
  self:addPhoto("3", 704, 320)
  self:addPhoto("4", 704, 384)
end

function E8Knife:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E8Knife:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "WayGH")
end

function E8Knife:beforeLoad()
  self:imageOn("0")
  self:imageOn("4")
end

function E8Knife:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Knife:afterLoad2()
  self:cacheImage("Plug/0")
end

function E8Knife:recordLastPlaceName()
  return false
end

function E8Knife:beforeUseItem(itemName)
  return false
end

function E8Knife:afterUseItem(itemName)
  return true
end

function E8Knife:click(rect)
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:imageOn("3")
    self:imageOff("4")
    self:sayI18n("click_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:imageOff("3")
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:getItem("knife")
    self:sayI18n("click_3")
    
    self:switchPlace("Plug")

    return
  end
end

return E8Knife
