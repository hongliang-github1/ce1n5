local E8Xpole = class("E8Xpole", function()
  return BasePlace.new()
end)

function E8Xpole:initPhoto()
  self:addPhoto("p1", 960, 256)
  self:addPhoto("p2", 960, 256)
  self:addPhoto("p3", 960, 256)
  self:addPhoto("p4", 960, 256)
  self:addPhoto("s1", 960, 256)
  self:addPhoto("s2", 960, 256)
  self:addPhoto("s3", 960, 256)
  self:addPhoto("s4", 960, 256)
end

function E8Xpole:initButton()
  self:addButton("click", 950, 254, 366, 508)
  self:addButton("goXhole1", 0, 240, 504, 566, false)
  self:addButton("goXhole2", 1514, 290, 530, 552, false)
  self:addButton("nothing", 462, 1022, 162, 126, false)
  self:addButton("wire", 942, 766, 324, 382, false)
end

function E8Xpole:arrowLeft(rect)
  self:switchPlaceLeft("Xdoor")
end

function E8Xpole:arrowRight(rect)
  self:switchPlaceRight("Xswitch")
end

function E8Xpole:beforeLoad()
  self:imageOn("0")

  if self:getInteger("pencil") == 0 then
    self:imageOn("p1")
  end
end

function E8Xpole:afterLoad()
  if self:imageIsOn("p1") then
    self:sayI18n("afterLoad_1")
  end
end

function E8Xpole:afterLoad2()
  self:cacheImage("Xdoor/0")
  self:cacheImage("Xswitch/0")
end

function E8Xpole:beforeUseItem(itemName)
  return false
end

function E8Xpole:afterUseItem(itemName)
  return true
end

function E8Xpole:click(rect)
  if self:getInteger("pencil") ~= 0 then
    self:sayI18n("click_3")
    
    return
  end

  -- 拿铅笔
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
      
  if progress == self:nextProgressIndex() then
    self:imageOn("p2")
    self:imageOff("p1")
    self:sayI18n("handleSwipeFrom_5")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("p3")
    self:imageOff("p2")
    self:sayI18n("handleSwipeFrom_6")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("p4")
    self:imageOff("p3")
    self:sayI18n("handleSwipeFrom_7")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOff("p4")
    self:getItem("pencil")
    self:sayI18n("handleSwipeFrom_8")
    
    return
  end
  
  self:sayI18n("handleSwipeFrom_9")
end

function E8Xpole:goXhole1(rect)
  self:switchPlaceZoomIn("Xhole1", rect)
end

function E8Xpole:goXhole2(rect)
  self:switchPlaceZoomIn("Xhole2", rect)
end

function E8Xpole:nothing(rect)
  self:sayI18n("nothing_1")
end

function E8Xpole:wire(rect)
  self:sayI18n("nothing_1")
end

return E8Xpole
