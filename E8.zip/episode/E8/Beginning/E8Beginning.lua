local E8Beginning = class("E8Beginning", function()
  return BasePlace.new()
end)

function E8Beginning:initPhoto()
end

function E8Beginning:initButton()
  self:addButton("click", 0, 0, 2048, 1152, false)
end

function E8Beginning:beforeLoad()
  self:imageOn("0")
end

function E8Beginning:afterLoad()
  self:click(nil)
end

function E8Beginning:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("2")
  self:cacheImage("3")
  self:cacheImage("4")
  self:cacheImage("5")
  self:cacheImage("6")
  self:cacheImage("7")
  self:cacheImage("8")
  self:cacheImage("Attack/0")
end

function E8Beginning:afterUnload()
  -- 清除当前场景加载的图，因为这些图其他场景用不到了，而且会占用大量内存
  self:cacheImageRemove("0")
  self:cacheImageRemove("1")
  self:cacheImageRemove("2")
  self:cacheImageRemove("3")
  self:cacheImageRemove("4")
  self:cacheImageRemove("5")
  self:cacheImageRemove("6")
  self:cacheImageRemove("7")
  self:cacheImageRemove("8")  
end

function E8Beginning:beforeUseItem(itemName)
  return false
end

function E8Beginning:afterUseItem(itemName)
  return true
end

function E8Beginning:click(rect)
  local progress = self:nextProgress()

  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")
    
    return
  end
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:getItem("shock")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("1")
    self:sayI18n("click_3")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:sayI18n("click_4")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("3")
    self:sayI18n("click_5")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_6")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:say("")
    
    -- 门上锁了，蹲点的动画
    self:effectFadeBlack("afterDaybreak", 2, 3, 2, function()
      self:disableTouch()
      self:imageOn("4")

      -- 开门动作5次，开门动作图片是从4.jpg开始
      self:play("doorunlock")
      self:scheduleTimes(0.5, 6, function(index)
        if index >= 6 then
          self:enableTouch()
          self:sayI18n("animation_1")

          return
        end

        self:imageOn(tostring(index + 3))
      end)

      self:sayI18n("click_7")
    end)
  end
  
  if progress == self:nextProgressIndex() then
    -- 跳转到攻击坏人的界面
    self:switchPlaceZoomIn("Attack", cc.rect(800, 152, 226 * 2, 320 * 2))
    
    return
  end
end

return E8Beginning
