local E8Dswitch = class("E8Dswitch", function()
  return BasePlace.new()
end)

function E8Dswitch:initPhoto()
end

function E8Dswitch:initButton()
  self:addButton("open", 738, 312, 524, 434)
end

function E8Dswitch:arrowRight(rect)
  self:switchPlaceRight("Ddoor")
end

function E8Dswitch:beforeLoad()
  if self:getInteger("room_d_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8Dswitch:afterLoad()

end

function E8Dswitch:afterLoad2()
  self:cacheImage("Ddoor/0")
end

function E8Dswitch:beforeUseItem(itemName)
  return false
end

function E8Dswitch:afterUseItem(itemName)
  return true
end

function E8Dswitch:open(rect)
  if self:imageIsOn("0") then
    -- 开灯
    self:imageOn("1")
    self:setInteger("room_d_switch", 1)
    self:play("switch")
    self:sayI18n("open_1")
    
    -- 记录开过灯，给tip用
    if self:getInteger("room_d_switched") < 1 then
      self:setInteger("room_d_switched", 1)
    end

    return
  end
  
  -- 关灯
  self:imageOn("0")
  self:setInteger("room_d_switch", 0)
  self:play("switch")
  self:sayI18n("open_2")
end

return E8Dswitch
