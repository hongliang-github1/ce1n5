local E8Attack = class("E8Attack", function()
  return BasePlace.new()
end)

function E8Attack:initPhoto()
  self:addPhoto("1", 1408, 576)
  self:addPhoto("2", 1088, 576)
  self:addPhoto("3", 1088, 384)
  self:addPhoto("4", 1088, 384)
  self:addPhoto("5", 1024, 64)
end

function E8Attack:initButton()
  self:addButton("electricShockAss", 642, 984, 822, 164)
  self:addButton("electricShockWaist", 640, 738, 826, 244)
  self:addButton("electricShockBack", 636, 396, 830, 338)
  self:addButton("electricShockNeck", 630, 0, 836, 396)
end

function E8Attack:shock()
  self.isShocked = true
  
  self:play("shock")
end

function E8Attack:beforeLoad()
  self:imageOn("0")
end

function E8Attack:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8Attack:afterLoad2()
  self:cacheImage("1")
  self:cacheImage("2")
  self:cacheImage("3")
  self:cacheImage("4")
  self:cacheImage("5")
  self:cacheImage("AttackDone/0")
end

function E8Attack:beforeUseItem(itemName)
  if "shock" == itemName then
    return not self.isShocking
  end
  
  return false
end

function E8Attack:afterUseItem(itemName)
  if "shock" == itemName then
    self:imageOn("1")
    self:sayI18n("afterUseItem_1")
    
    self.isShocking = true
    
    return true
  end
  
  return true
end

function E8Attack:electricShockAss(rect)
  if self.isShocked then
    self:shocked()
    
    return
  end
  
  if not self.isShocking then
    self:sayI18n("electricShockAss_1")
    
    return
  end
  
  -- 电击屁股
  self:imageOn("2")
  self:imageOff("1")
  self:sayI18n("electricShockAss_2")
  
  self:setInteger("enemy_dead", 1)
  self:shock()
end

function E8Attack:electricShockWaist(rect)
  if self.isShocked then
    self:shocked()
    
    return
  end
  
  if not self.isShocking then
    self:sayI18n("electricShockWaist_1")
    
    return
  end
  
  -- 电击腰部
  self:imageOn("3")
  self:imageOff("1")
  self:sayI18n("electricShockWaist_2")
  
  self:setInteger("enemy_dead", 1)
  self:shock()
end

function E8Attack:electricShockBack(rect)
  if self.isShocked then
    self:shocked()
    
    return
  end
  
  if not self.isShocking then
    self:sayI18n("electricShockBack_1")
    
    return
  end
  
  -- 电击后背
  self:imageOn("4")
  self:imageOff("1")
  self:sayI18n("electricShockBack_2")

  self:setInteger("enemy_dead", 1)
  self:shock()
end

function E8Attack:electricShockNeck(rect)
  if self.isShocked then
    self:shocked()
    
    return
  end
  
  if not self.isShocking then
    self:sayI18n("electricShockNeck_1")
    
    return
  end
  
  -- 电击脖子
  self:imageOn("5")
  self:imageOff("1")
  self:sayI18n("electricShockNeck_2")
  
  self:setInteger("enemy_dead", 1)
  self:shock()
end

function E8Attack:onTouchBegan(touch, event)
  if self.isShocked then
    self:shocked()
  end
end

function E8Attack:shocked()
  self:switchPlace("AttackDone")
end

return E8Attack
