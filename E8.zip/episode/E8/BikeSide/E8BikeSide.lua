local E8BikeSide = class("E8BikeSide", function()
  return BasePlace.new()
end)

function E8BikeSide:initPhoto()
  self:addPhoto("1", 1536, 1024)
  self:addPhoto("2", 768, 448)
end

function E8BikeSide:initButton()
  self:addButton("battery", 692, 430, 522, 490)
  self:addButton("lock", 1256, 814, 466, 332)
  self:addButton("goDashboard", 0, 0, 498, 366)
end

function E8BikeSide:arrowDown(rect)
  self:switchPlaceZoomOut("Bdoor")
end

function E8BikeSide:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("battery") < 0 then
    self:imageOn("2")
  end
end

function E8BikeSide:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8BikeSide:afterLoad2()
  if self:getInteger("throttle_hold") > 0 then
  -- 如果已经是定速巡航状态了，那就进入空转场景
    self:cacheImage("WheelSpin/0")
    
  else
    self:cacheImage("BikeWheel/0")
  end

  self:cacheImage("Dashboard/0")

  if self:getInteger("room_b_switch") == 1 then
    self:cacheImage("Bdoor/2")
    
  else  
    self:cacheImage("Bdoor/1")
  end
end

function E8BikeSide:beforeUseItem(itemName)
  return false
end

function E8BikeSide:afterUseItem(itemName)
  return true
end

function E8BikeSide:battery(rect)
  -- 先判断钥匙是否已经拿到，如果钥匙没拿到，先进到钥匙界面，拿到钥匙之后，在判断电瓶有没有使用，如果没有使用就进入放电瓶的界面
  if self:getInteger("keyb") == 0 then
    self:switchPlaceZoomIn("BatteryHole", rect)
    
    return
  end
  
  self:switchPlaceZoomIn("BikeBattery", rect)
end

function E8BikeSide:lock(rect)
  if self:getInteger("throttle_hold") > 0 then
    -- 如果已经是定速巡航状态了，那就进入空转场景
    self:switchPlaceZoomIn("WheelSpin", rect)
    
  else
    self:switchPlaceZoomIn("BikeWheel", rect)
  end
end

function E8BikeSide:goDashboard(rect)
  self:switchPlaceZoomIn("Dashboard", rect)
end

return E8BikeSide
