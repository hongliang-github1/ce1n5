local E8LuggageLock = class("E8LuggageLock", function()
  return BasePlace.new()
end)

function E8LuggageLock:initPhoto()
end

function E8LuggageLock:initButton()
  self:addButton("click", 538, 394, 992, 658)
end

function E8LuggageLock:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "WayGH")
end

function E8LuggageLock:beforeLoad()
  self:imageOn("0")
end

function E8LuggageLock:afterLoad()
  self:sayI18n("afterLoad_1")
end

function E8LuggageLock:afterLoad2()
  self:cacheImage("LuggageAskOpen/0" .. i18n.getLang())
end

function E8LuggageLock:recordLastPlaceName()
  return false
end

function E8LuggageLock:beforeUseItem(itemName)
  return false
end

function E8LuggageLock:afterUseItem(itemName)
  return true
end

function E8LuggageLock:click(rect)
  if self.isHelp then
    -- 跳转到打电话给小华求救如何开箱子
    self:switchPlace("LuggageAskOpen")
    
    return
  end
  
  self:sayI18n("lockDismiss_1")

  self.isHelp = true
end

return E8LuggageLock
