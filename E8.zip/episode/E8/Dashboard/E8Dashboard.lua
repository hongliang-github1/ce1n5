local E8Dashboard = class("E8Dashboard", function()
  return BasePlace.new()
end)

function E8Dashboard:initPhoto()
  self:addPhoto("1", 896, 704)
  self:addPhoto("2", 1088, 576)
  self:addPhoto("3", 768, 256)
  self:addPhoto("4", 1088, 576)
end

function E8Dashboard:initButton()
  self:addButton("goHorn", 0, 236, 642, 578)
  self:addButton("goKeyhole", 818, 330, 504, 400)
  self:addButton("goAccelerator", 1410, 260, 634, 520)
end

function E8Dashboard:arrowDown(rect)
  self:switchPlaceZoomOut("BikeSide")
end

function E8Dashboard:beforeLoad()
  self:imageOn("0")
    
  -- 判断是否插入了钥匙，如果插入了钥匙，判断是否使用过电池和保险丝，如果两个都是用了，表示车通电了
  if self:getInteger("keyb") < 0 then
    if self:getInteger("keyb_on") == 0 then
      self:imageOn("2")
      
      return
    end
    
    -- 钥匙已经拧到开的状态了，如果这个时候，保险丝和电池都使用过了，表示车通电了，这个时候显示3，否则显示4
    if self:getInteger("battery") < 0 then
      self:imageOn("3")

    else
      self:imageOn("4")
    end
  end
end

function E8Dashboard:afterLoad()
end

function E8Dashboard:afterLoad2()
  self:cacheImage("Horn/0")
  self:cacheImage("Keyhole/0")
  self:cacheImage("Throttle/0")

  if self:getInteger("throttle_hold") == 1 then
    self:cacheImage("Throttle/3")
  end

  self:cacheImage("BikeSide/0")
end

function E8Dashboard:beforeUseItem(itemName)
  return false
end

function E8Dashboard:afterUseItem(itemName)
  return true
end

function E8Dashboard:goHorn(rect)
  self:switchPlaceZoomIn("Horn", rect)
end

function E8Dashboard:goKeyhole(rect)
  self:switchPlaceZoomIn("Keyhole", rect)
end

function E8Dashboard:goAccelerator(rect)
  self:switchPlaceZoomIn("Throttle", rect)
end

return E8Dashboard
