local E8BikeBattery = class("E8BikeBattery", function()
  return BasePlace.new()
end)

function E8BikeBattery:initPhoto()
  self:addPhoto("1", 768, 448)
  self:addPhoto("21", 704, 448)
  self:addPhoto("22", 704, 448)
end

function E8BikeBattery:initButton()
  self:addButton("click", 312, 0, 1298, 1148)
end

function E8BikeBattery:arrowDown(rect)
  self:switchPlaceZoomOut("BikeSide")
end

function E8BikeBattery:beforeLoad()
  self:imageOn("0")
  
  -- 判断电瓶是否使用，如果已经使用了，就显示1.jpg
  if self:getInteger("battery") < 0 then
    self:imageOn("1")
    
    self:sayI18n("beforeLoad_1")
    
    return
  end
  
  self:sayI18n("beforeLoad_2")
end

function E8BikeBattery:afterLoad()

end

function E8BikeBattery:afterLoad2()
  self:cacheImage("BikeSide/0")
end

function E8BikeBattery:beforeUseItem(itemName)
  if "battery" == itemName then
    return true
  end
  
  return false
end

function E8BikeBattery:afterUseItem(itemName)
  if "battery" == itemName then
    if not self:imageIsOn("2") then
      self:sayI18n("afterUseItem_1")
      
      return true
    end
    
    self:imageOn("22")
    self:play("batteryplug")

    -- 隐藏一下回退的箭头
    self:hideArrowButton()
    
    self:sayI18n("afterUseItem_2")
    
    return false
  end
  
  return true
end

function E8BikeBattery:click(rect)
  -- 如果没安装电瓶，就先把后座打开
  if self:imageIsOn("0") and self:getInteger("battery") >= 0 then
    self:imageOn("2")
    self:play("seat")
    self:sayI18n("click_1")
    
    return
  end
  
  -- 后座打开了，但是没放电瓶，这时候再点就关上了
  if self:imageIsOn("2") and self:getInteger("battery") >= 0 then
    self:imageOn("0")
    self:play("seat")
    self:sayI18n("click_2")
    
    return
  end
  
  -- 打开后座了，判断电瓶是否使用，如果没使用，点击无效果，如果使用了，关掉22的图，打开21
  if self:getInteger("battery") < 0 and self:imageIsOn("22") then
    self:imageOff("22")
    self:imageOn("21")
    
    self:showArrowButton()
    
    self:sayI18n("click_3")
    
    return
  end
  
  -- 如果已经装好了，修改图片状态
  if self:imageIsOn("21") then
    self:imageOff("21")
    self:imageOn("0")
    self:imageOn("1")
    self:play("seat")
    self:sayI18n("click_4")
    
    return
  end
  
  self:sayI18n("click_5")
end

return E8BikeBattery
