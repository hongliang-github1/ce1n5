local E8Plug = class("E8Plug", function()
  return BasePlace.new()
end)

function E8Plug:initPhoto()
  self:addPhoto("1", 960, 320)
  self:addPhoto("2", 1024, 384)
  self:addPhoto("3", 1024, 384)
end

function E8Plug:initButton()
  self:addButton("click", 546, 204, 774, 686)
  self:addButton("shit", 28, 660, 418, 430, false)
end

function E8Plug:arrowDown(rect)
  self:switchPlaceZoomOut("WayCD")
end

function E8Plug:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("knife") == 0 then
    self:imageOn("1")
    self:sayI18n("beforeLoad_1")
  end
end

function E8Plug:afterLoad()
end

function E8Plug:afterLoad2()
  self:cacheImage("WayCD/0")
  self:cacheImage("Knife/0")
end

function E8Plug:beforeUseItem(itemName)
  return false
end

function E8Plug:afterUseItem(itemName)
  return true
end

function E8Plug:click(rect)
  if self:getInteger("knife") ~= 0 then
    self:sayI18n("click_2")
    
    return
  end


  local progress = self:nextProgress()

  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:sayI18n("click_1")

    return
  end

  if progress == self:nextProgressIndex() then
    self:imageOn("2")
    self:imageOff("1")
    self:sayI18n("handleSwipeFrom_1")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("3")
    self:imageOff("2")
    self:sayI18n("handleSwipeFrom_2")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    -- 这里直接跳转到 Knife
    self:imageOff("3")
    self:switchPlace("Knife")
    
    return
  end
end

function E8Plug:shit(rect)
  self:sayI18n("shit_1")
end

return E8Plug
