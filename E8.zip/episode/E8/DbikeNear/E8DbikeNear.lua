local E8DbikeNear = class("E8DbikeNear", function()
  return BasePlace.new()
end)

function E8DbikeNear:initPhoto()
end

function E8DbikeNear:initButton()
  self:addButton("DbikeDashboard", 394, 174, 1194, 606, false)
  self:addButton("goDbattery", 1506, 594, 538, 468)
  self:addButton("keyhole", 1104, 804, 200, 200, false)
end

function E8DbikeNear:arrowDown(rect)
  self:switchPlaceZoomOut("Dbike")
end

function E8DbikeNear:beforeLoad()
  self:imageOn("0")
end

function E8DbikeNear:afterLoad()
end

function E8DbikeNear:afterLoad2()
  self:cacheImage("Dbike/0")
  self:cacheImage("Dbattery/0")
end

function E8DbikeNear:beforeUseItem(itemName)
  if "keyb" == itemName then
    return true
  end
  
  return false
end

function E8DbikeNear:afterUseItem(itemName)
  if "keyb" == itemName then
    self:sayI18n("afterUseItem_1")

    return true
  end

  return true
end

function E8DbikeNear:DbikeDashboard(rect)
  self:sayI18n("DbikeDashboard_1")
end

function E8DbikeNear:goDbattery(rect)
  self:switchPlaceRight("Dbattery")
end

function E8DbikeNear:keyhole(rect)
  self:sayI18n("keyhole_1")
end

return E8DbikeNear
