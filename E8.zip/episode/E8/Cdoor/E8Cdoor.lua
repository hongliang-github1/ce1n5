local E8Cdoor = class("E8Cdoor", function()
  return BasePlace.new()
end)

function E8Cdoor:initPhoto()
end

function E8Cdoor:initButton()
  self:addButton("goCout", 0, 0, 1900, 1146)
end

function E8Cdoor:arrowRight(rect)
  self:switchPlaceRight("Cswitch")
end

function E8Cdoor:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsCD")
end

function E8Cdoor:beforeLoad()
  if self:getInteger("room_c_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8Cdoor:afterLoad()
end

function E8Cdoor:afterLoad2()
  if self:getInteger("room_c_switch") == 1 then
    self:cacheImage("Cswitch/1")

  else  
    self:cacheImage("Cswitch/0")
  end

  self:cacheImage("Cout/0")
  
  if self:getInteger("room_c_switch") == 1 and self:getInteger("room_d_switch") == 1 then
    self:cacheImage("DoorsCD/3")
  
  elseif self:getInteger("room_c_switch") == 1 then
    self:cacheImage("DoorsCD/2")
  
  elseif self:getInteger("room_d_switch") == 1 then
    self:cacheImage("DoorsCD/1")
    
  else
    self:cacheImage("DoorsCD/0")
  end
end

function E8Cdoor:beforeUseItem(itemName)
  return false
end

function E8Cdoor:afterUseItem(itemName)
  return true
end

function E8Cdoor:goCout(rect)
  if self:imageIsOn("1") then
    self:switchPlaceZoomIn("Cout", cc.rect(800, 320, 288 * 2, 296 * 2))
    
    return
  end
  
  self:sayI18n("goCout_1")
end

return E8Cdoor
