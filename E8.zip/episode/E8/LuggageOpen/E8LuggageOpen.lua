local E8LuggageOpen = class("E8LuggageOpen", function()
  return BasePlace.new()
end)

function E8LuggageOpen:initPhoto()
  self:addPhoto("1", 1024, 640)
  self:addPhoto("31", 1152, 832)
  self:addPhoto("3", 640, 320)
  self:addPhoto("4", 640, 320)
  self:addPhoto("5", 640, 320)
  self:addPhoto("6", 640, 320)
  self:addPhoto("7", 512, 320)
  self:addPhoto("82", 768, 640)
  self:addPhoto("8", 640, 256)
end

function E8LuggageOpen:initButton()
  self:addButton("click", 566, 240, 1286, 882, false)
end

function E8LuggageOpen:arrowDown(rect)
  self:switchPlaceZoomOut(self.lastPlaceName or "WayGH")
end

function E8LuggageOpen:beforeLoad()
  self:imageOn("0")

  if self:getInteger("envelope") ~= 0 then
    self:imageOn("8")
    
    self.opened = true
  end
end

function E8LuggageOpen:afterLoad()
  if self:imageIsOn("8") then
    self:sayI18n("afterLoad_1")
    
  elseif self:getInteger("luggage_open") == 1 then
    self:sayI18n("afterLoad_2")
    
  else
    self:sayI18n("afterLoad_3")
  end
end

function E8LuggageOpen:afterLoad2()
end

function E8LuggageOpen:recordLastPlaceName()
  return false
end

function E8LuggageOpen:beforeUseItem(itemName)
  if "pencil" == itemName then
    return not self:imageIsOn("8")
  end
  
  return false
end

function E8LuggageOpen:afterUseItem(itemName)
  if "pencil" == itemName then
    -- 铅笔还没有削尖
    if self:getInteger("pencil") ~= 2 then
      self:sayI18n("afterUseItem_1")
      
      return true
    end

    self:imageOn("1")
    self:voidItem("pencil")

    return true
  end
  
  return true
end

function E8LuggageOpen:click(rect)
  -- 箱子拉链已经划开了
  if self:getInteger("luggage_open") == 1 then
    -- 当箱子掀开后，有信封就得到信封，没有就盖上盖子
    if self.opened then
      if self:getInteger("envelope") == 0 then
        self:imageOff("82")
        self:getItem("envelope")
        self:sayI18n("click_1")
        
        return
      end
      
      self.opened = false
      self:imageOff("8")
      self:sayI18n("click_2")
      
      return
    end
    
    -- 掀开箱子
    self.opened = true
    
    -- 干掉出现过的图，防止漏掉，从而导致贴图错误
    self:imageOff("7")
    self:imageOff("6")
    self:imageOff("5")
    self:imageOff("4")
    self:imageOff("3")
    self:imageOn("8")
    
    if self:getInteger("envelope") == 0 then
      self:imageOn("82")
      self:sayI18n("click_3")
      
      return
    end
      
    self:sayI18n("click_4")
    
    return
  end
  
  -- 已经得到提示，用尖的东西划开拉链，当铅笔还没有插进箱子里
  if self:getInteger("pencil") >= 0 then
    self:sayI18n("click_5")
    
    return
  end
  
  -- 已经把铅笔插进去了
  local progress = self:nextProgress()
  
  self:resetProgressIndex()
  
  if progress == self:nextProgressIndex() then
    self:imageOn("3")
    self:imageOff("1")
    self:sayI18n("click_6")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOn("31")
    self:sayI18n("click_7")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOff("31")
    self:imageOff("3")
    self:imageOn("6")
    self:sayI18n("handleSwipeFrom_6")
    
    return
  end
  
  if progress == self:nextProgressIndex() then
    self:imageOff("6")
    self:imageOn("7")
    self:sayI18n("handleSwipeFrom_5")

    self:setInteger("luggage_open", 1)
    
    return
  end
end

return E8LuggageOpen
