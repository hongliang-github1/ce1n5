local E8Fstuff = class("E8Fstuff", function()
  return BasePlace.new()
end)

function E8Fstuff:initPhoto()
end

function E8Fstuff:initButton()
  self:addButton("click", 0, 0, 2044, 1148, false)
end

function E8Fstuff:arrowDown(rect)
  self:switchPlaceZoomOut("Fdoor")
end

function E8Fstuff:beforeLoad()
  self:imageOn("0")
end

function E8Fstuff:afterLoad()

end

function E8Fstuff:afterLoad2()
  self:cacheImage("Fdoor/0")
end

function E8Fstuff:beforeUseItem(itemName)
  return false
end

function E8Fstuff:afterUseItem(itemName)
  return true
end

function E8Fstuff:click(rect)
  self:sayI18n("click_1")
end

return E8Fstuff
