local E8DbatteryNear = class("E8DbatteryNear", function()
  return BasePlace.new()
end)

function E8DbatteryNear:initPhoto()
  self:addPhoto("1", 704, 128)
end

function E8DbatteryNear:initButton()
  self:addButton("getBattery", 664, 80, 800, 1056)
end

function E8DbatteryNear:arrowDown(rect)
  self:switchPlaceZoomOut("Dbattery")
end

function E8DbatteryNear:beforeLoad()
  self:imageOn("0")
  
  if self:getInteger("battery") == 0 then
    self:imageOn("1")
  end
end

function E8DbatteryNear:afterLoad()
  if self:imageIsOn("1") then
    self:sayI18n("afterLoad_1")
  end
end

function E8DbatteryNear:afterLoad2()
  self:cacheImage("Dbattery/0")
end

function E8DbatteryNear:beforeUseItem(itemName)
  return false
end

function E8DbatteryNear:afterUseItem(itemName)
  return true
end

function E8DbatteryNear:getBattery(rect)
  if self:getInteger("battery") == 0 then
    self:imageOff("1")
    self:getItem("battery")
    self:sayI18n("getBattery_1")
    
    return
  end
  
  self:sayI18n("getBattery_2")
end

return E8DbatteryNear
