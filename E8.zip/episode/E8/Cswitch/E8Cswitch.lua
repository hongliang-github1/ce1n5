local E8Cswitch = class("E8Cswitch", function()
  return BasePlace.new()
end)

function E8Cswitch:initPhoto()
end

function E8Cswitch:initButton()
  self:addButton("open", 994, 412, 380, 388)
end

function E8Cswitch:arrowLeft(rect)
  if self:getInteger("room_c_switch") > 0 then
    self:switchPlaceZoomOut("Cout")

  else
    self:switchPlaceZoomOut("Cdoor")
  end
end

function E8Cswitch:beforeLoad()
  if self:getInteger("room_c_switch") == 1 then
    self:imageOn("1")
    
    return
  end
  
  self:imageOn("0")
end

function E8Cswitch:afterLoad()
end

function E8Cswitch:afterLoad2()
  self:cacheImage("Cout/0")
  self:cacheImage("Cdoor/0")
end

function E8Cswitch:beforeUseItem(itemName)
  return false
end

function E8Cswitch:afterUseItem(itemName)
  return true
end

function E8Cswitch:open(rect)
  if self:imageIsOn("1") then
    -- 关灯
    self:imageOn("0")
    self:play("switch")
    self:setInteger("room_c_switch", 0)
    self:sayI18n("open_1")
    
    return
  end
  
  -- 开灯
  self:imageOn("1")
  self:play("switch")
  self:setInteger("room_c_switch", 1)
  self:sayI18n("open_2")
  
  -- 记录开过灯，给tip用
  if self:getInteger("room_c_switched") < 1 then
    self:setInteger("room_c_switched", 1)
  end
end

return E8Cswitch
