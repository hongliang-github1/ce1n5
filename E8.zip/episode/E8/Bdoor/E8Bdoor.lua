local E8Bdoor = class("E8Bdoor", function()
  return BasePlace.new()
end)

function E8Bdoor:initPhoto()
  self:addPhoto("21", 960, 768)
  self:addPhoto("22", 768, 832)
end

function E8Bdoor:initButton()
  self:addButton("goBikeTrunk", 672, 718, 302, 276)
  self:addButton("goBikeSide", 978, 510, 462, 638)
end

function E8Bdoor:arrowLeft(rect)
  self:switchPlaceLeft("Bswitch")
end

function E8Bdoor:arrowDown(rect)
  self:switchPlaceZoomOut("DoorsAB")
end

function E8Bdoor:beforeLoad()
  if self:getInteger("room_b_switch") == 1 then
    self:imageOn("2")
    
    if self:getInteger("battery") < 0 then
      self:imageOn("21")
    end
    
    if "Bswitch" == self.lastPlaceName and self:getInteger("bdoor_tipped") < 1 then
      self:setInteger("bdoor_tipped", 1)
      self:sayI18n("beforeLoad_1")
    end

    return
  end
  
  self:imageOn("1")
  self:sayI18n("beforeLoad_2")
end

function E8Bdoor:afterLoad()
  
end

function E8Bdoor:afterLoad2()
  e8.removeCacheGroomToFroom(self)
  e8.removeCacheDroomToCroom(self)
  e8.removeCacheAroomToXroom(self)
  
  if self:getInteger("room_b_switch") == 1 then
    self:cacheImage("Bswitch/2")

  else
    self:cacheImage("Bswitch/0")
  end

  self:cacheImage("BikeSide/0")

  if self:getInteger("room_a_switch") == 1 and self:getInteger("room_b_switch") == 1 then
    self:cacheImage("DoorsAB/3")
  
  elseif self:getInteger("room_a_switch") == 1 then
    self:cacheImage("DoorsAB/2")
    
  elseif self:getInteger("room_b_switch") == 1 then
    self:cacheImage("DoorsAB/1")
    
  else  
    self:cacheImage("DoorsAB/0")
  end
end

function E8Bdoor:beforeUseItem(itemName)
  return false
end

function E8Bdoor:afterUseItem(itemName)
  return true
end

function E8Bdoor:goBikeTrunk(rect)
  if self:imageIsOn("2") then
    self:switchPlaceZoomIn("BikeTrunk", rect)
    
    return
  end
  
  self:onTouchBegan(nil)
end

function E8Bdoor:goBikeSide(rect)
  if self:imageIsOn("2") then
    self:switchPlaceZoomIn("BikeSide", rect)
    
    return
  end

  self:onTouchBegan(nil)
end

function E8Bdoor:onTouchBegan(touch, event)
  if self:imageIsOn("1") then
    self:sayI18n("click_1")
    
    return
  end
end

return E8Bdoor
