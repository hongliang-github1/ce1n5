local E8DoorsEF = class("E8DoorsEF", function()
  return BasePlace.new()
end)

function E8DoorsEF:initPhoto()
end

function E8DoorsEF:initButton()
  self:addButton("goEdoor", 1142, 0, 902, 1148)
  self:addButton("goFdoor", 80, 0, 854, 1148)
end

function E8DoorsEF:arrowDown(rect)
  self:switchPlaceZoomOut("WayEF")
end

function E8DoorsEF:beforeLoad()
  self:imageOn("0")
end

function E8DoorsEF:afterLoad()

end

function E8DoorsEF:afterLoad2()
  if "Ebulb" == self.lastPlaceName or "Eswitch" == self.lastPlaceName or "Estuff" == self.lastPlaceName then
    self:cacheImage("Edoor/1")
    
  else
    self:cacheImage("Edoor/0")
  end

  self:cacheImage("Fdoor/0")

  if self:getInteger("baby_car_switch") == 1 then
    self:cacheImage("WayEF/1")
    
  else
    self:cacheImage("WayEF/0")
  end
end

function E8DoorsEF:beforeUseItem(itemName)
  return false
end

function E8DoorsEF:afterUseItem(itemName)
  return true
end

function E8DoorsEF:goEdoor(rect)
  self:switchPlaceZoomIn("Edoor", cc.rect(1140, 280, 900, 660))
end

function E8DoorsEF:goFdoor(rect)
  self:switchPlaceZoomIn("Fdoor", cc.rect(80, 280, 850, 656))
end

return E8DoorsEF
